# -*- coding: utf-8 -*-
"""①-E 文字效果分析:本机 OCR「读」出对标片/截图里的文字,量位置/大小/颜色/描边/阴影/底色块/渐变/倾角;动效判渐显/渐隐/滚动(方向速度)/弹出/瞬现/打字机/擦除显影/闪烁脉冲/抖动/呼吸缩放/模糊转清晰/变色/卡拉OK逐字变色/疑似3D翻转,判发光还是粗描边(径向剖面),
并给出能在剪映里直接照做的复刻建议。全程本机 ffmpeg + RapidOCR,不联网、不上传、不花钱。
用法: python text_style.py 参考片.mp4 [--out 对标文字.json] [--proj 项目目录]
        [--start 0] [--dur 90] [--fps 1.5] [--height 540] [--min-conf 0.5] [--max 40]
截图(jpg/png)也能分析:读得出样式,读不出动效(入场/出场标为「单帧无法判定」)。"""
import argparse, cv2, json, re, shutil, subprocess, sys, tempfile, time
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path
import math
import numpy as np

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm"}
IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


def say(msg):
    print(msg, flush=True)


def run(cmd):
    return subprocess.run([str(x) for x in cmd], capture_output=True, text=True,
                          encoding="utf-8", errors="replace")


def probe(src):
    p = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
             "stream=width,height,r_frame_rate", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=0", src])
    w = h = 0; fps = 0.0; dur = 0.0
    m = re.search(r"width\s*=\s*(\d+)", p.stdout); w = int(m.group(1)) if m else 0
    m = re.search(r"height\s*=\s*(\d+)", p.stdout); h = int(m.group(1)) if m else 0
    m = re.search(r"r_frame_rate\s*=\s*(\d+)/(\d+)", p.stdout)
    if m and int(m.group(2)): fps = int(m.group(1)) / int(m.group(2))
    m = re.search(r"duration\s*=\s*([\d.]+)", p.stdout); dur = float(m.group(1)) if m else 0.0
    return w, h, fps, dur


def hexof(bgr):
    b, g, r = [int(v) for v in bgr]
    return "#%02X%02X%02X" % (r, g, b)



def hex2bgr(h, default):
    """#RRGGBB -> BGR 三元组。切片是 [1:3][3:5][5:7],别再数错位。"""
    try:
        return np.array([int(h[5:7], 16), int(h[3:5], 16), int(h[1:3], 16)], float)
    except Exception as e:
        say("  [hex解析兜底] %r <- %r" % (default, h))
        return np.array(default, float)
def dist(a, b):
    return float(np.linalg.norm(np.asarray(a, float) - np.asarray(b, float)))


def rect_of(box):
    xs = [p[0] for p in box]; ys = [p[1] for p in box]
    return (min(xs), min(ys), max(xs), max(ys))


def iou(a, b):
    ax0, ay0, ax1, ay1 = a; bx0, by0, bx1, by1 = b
    iw = max(0.0, min(ax1, bx1) - max(ax0, bx0)); ih = max(0.0, min(ay1, by1) - max(ay0, by0))
    inter = iw * ih
    ua = (ax1 - ax0) * (ay1 - ay0) + (bx1 - bx0) * (by1 - by0) - inter
    return inter / ua if ua > 0 else 0.0


def cxy(r):
    return ((r[0] + r[2]) / 2.0, (r[1] + r[3]) / 2.0)


def angle_of(box):
    """OCR 四角框 -> 倾角(度)。取最上方两点的边,角度限制在 ±45 内。"""
    pts = sorted(box, key=lambda q: q[1])[:2]
    (xa, ya), (xb, yb) = pts[0], pts[1]
    if xb == xa and yb == ya:
        return 0.0
    ang = math.degrees(math.atan2(yb - ya, xb - xa))
    while ang > 90: ang -= 180
    while ang < -90: ang += 180
    return round(ang, 1)


def oscillation(vals):
    """去趋势后的摆动次数与振幅占比——闪烁/抖动/呼吸的共同指纹就是「围绕均值来回摆」。"""
    v = np.asarray(vals, float)
    if len(v) < 8:
        return 0, 0.0
    x = np.arange(len(v))
    A = np.vstack([x, np.ones_like(x)]).T
    try:
        k, b0 = np.linalg.lstsq(A, v, rcond=None)[0]
    except Exception:
        return 0, 0.0
    res = v - (k * x + b0)
    mean = float(abs(np.mean(v)))
    if mean < 1e-6:
        return 0, 0.0
    amp = float(np.std(res)) / mean
    s = np.sign(res); s[s == 0] = 1
    turns = int(np.count_nonzero(np.diff(s))) // 2
    return turns, round(amp, 3)


def anchor_name(cxp, cyp):
    v = "上" if cyp < 0.34 else ("中" if cyp < 0.68 else "下")
    h = "左" if cxp < 0.36 else ("右" if cxp > 0.64 else "横居中")
    if h == "横居中":
        return {"上": "画面上部横向居中", "中": "画面正中", "下": "画面下部横向居中"}[v]
    return "画面%s部偏%s" % (v, h)


def dump_frames(src, tmp, start, dur, fps, height, tag):
    d = Path(tmp) / tag
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True, exist_ok=True)
    r = run(["ffmpeg", "-y", "-v", "error", "-ss", max(0.0, start), "-i", src,
             "-t", dur, "-vf", "fps=%g,scale=-2:%d" % (fps, height), str(d / "f_%05d.png")])
    files = sorted(d.glob("f_*.png"))
    if r.returncode != 0 or not files:
        say("  [抽帧空窗] rc=%s %s(%s~%.1fs)" % (r.returncode, (r.stderr or "")[-120:], tag, start))
    return files



def ring_style(mask, crop, bg, textc):
    """径向亮度剖面分「硬描边 / 柔光晕 / 只有抗锯齿」:描边=颜色均匀然后断崖,发光=逐圈衰减。
    mask: 0/1 字形掩膜;crop: float BGR;返回 (样式, 光晕信息)。"""
    inv = (1 - mask).astype(np.uint8)
    od = cv2.distanceTransform(inv, cv2.DIST_L2, 3)
    dtb = max(1.0, float(np.linalg.norm(textc - bg)))
    prof = []
    for k in range(1, 9):
        band = (od >= k) & (od < k + 1) & (mask == 0)
        prof.append(float(np.linalg.norm(crop[band] - bg, axis=1).mean()) if band.any() else 0.0)
    p1 = prof[0]
    if p1 > 0.30 * dtb and prof[3] > 0.15 * p1 and prof[3] <= 0.75 * p1 and prof[6] > 0.06 * p1:
        n = max(3, next((i for i, v in enumerate(prof[2:], start=2) if v < 0.25 * p1), 8))
        return "柔光(发光)", {"扩散px": n}
    hard = [i for i, v in enumerate(prof) if v > 0.35 * dtb]
    if len(hard) >= 2 and max(hard) - min(hard) == len(hard) - 1 and hard[-1] + 2 <= 8:
        return "硬边(描边)", {"宽度px": hard[-1] + 1}
    return "无明显描边/发光", {}


def pca_angle(mask):
    """字形像素主轴角(度):比 OCR 四角框准得多的倾角测量。返回 [-45,45]。"""
    ys, xs = np.where(mask > 0)
    if len(xs) < 40:
        return 0.0
    pts = np.stack([xs, ys], axis=1).astype(np.float32)
    pts -= pts.mean(axis=0)
    cov = np.cov(pts.T)
    try:
        w, v = np.linalg.eigh(cov)
    except Exception:
        return 0.0
    ax = v[:, int(np.argmax(w))]
    ang = math.degrees(math.atan2(float(ax[1]), float(ax[0])))
    while ang > 90: ang -= 180
    while ang < -90: ang += 180
    if abs(ang) > 45:
        ang = ang - 90 if ang > 0 else ang + 90
    return round(ang, 1)


def angle_from_frame(img, r, color, pad_f=0.12):
    """在原始帧上、把框外扩一圈后量字形主轴角:小字直接裁会切角,PCA 就躺平。"""
    tc = hex2bgr(color.get("文字色"), (240, 240, 240))
    bgc = hex2bgr(color.get("背景色"), (32, 32, 40))
    x0, y0, x1, y1 = [int(v) for v in r]
    pw = int((x1 - x0) * pad_f); ph = int((y1 - y0) * 0.5)
    x0 = max(0, x0 - pw); y0 = max(0, y0 - ph)
    x1 = min(img.shape[1], x1 + pw); y1 = min(img.shape[0], y1 + ph)
    crop = img[y0:y1, x0:x1].astype(np.float32)
    dd = np.linalg.norm(crop - bgc, axis=2)
    dt2 = np.linalg.norm(crop - tc, axis=2)
    thr = max(30.0, float(dd.max()) * 0.30)
    m = ((dd > thr) & (dt2 <= dd)).astype(np.uint8)
    return pca_angle(m)


def analyze_colors(img, r, frame_wh):
    """在原始分辨率帧上量:文字色/背景色/描边/阴影/底色块/渐变/笔画粗细。img=BGR 全帧,r=框(原分辨率)。"""
    x0, y0, x1, y1 = [int(v) for v in r]
    x0 = max(0, x0); y0 = max(0, y0); x1 = min(frame_wh[0], x1); y1 = min(frame_wh[1], y1)
    if x1 - x0 < 6 or y1 - y0 < 6:
        return {"置信": "低", "说明": "框太小,量不了"}
    crop = img[y0:y1, x0:x1].astype(np.float32)
    rx0, ry0 = max(0, x0 - 18), max(0, y0 - 18)
    rx1, ry1 = min(frame_wh[0], x1 + 18), min(frame_wh[1], y1 + 18)
    ring = np.concatenate([img[ry0:y0].reshape(-1, 3), img[y1:ry1].reshape(-1, 3),
                           img[ry0:ry1, rx0:x0].reshape(-1, 3), img[ry0:ry1, x1:rx1].reshape(-1, 3)])
    if len(ring) < 20:
        return {"置信": "低", "说明": "贴边了,取不到背景"}
    bg = np.median(ring.astype(np.float32), axis=0)
    dd = np.linalg.norm(crop - bg, axis=2)
    thr = max(40.0, float(dd.max()) * 0.35)
    mask = (dd > thr).astype(np.uint8)
    frac = float(mask.mean())
    if frac < 0.012:
        return {"置信": "低", "说明": "文字颜色太接近背景,量不准(可能是渐变字或半透明字)"}
    px = crop[mask > 0]
    textc = np.median(px, axis=0)
    dd2 = np.linalg.norm(crop - textc, axis=2)
    keep = (mask > 0) & (dd2 <= dd)          # 「离字色不比离背景远」才算字:排除底块/双色字里的另一色
    mask = mask * keep.astype(np.uint8)
    if not mask.any():
        return {"置信": "低", "说明": "量色掩膜落空"}
    px = crop[mask > 0]
    textc = np.median(px, axis=0)
    dd2 = np.linalg.norm(crop - textc, axis=2)
    ringm = (mask > 0) & (dd2 > 60)
    outline = None
    if ringm.sum() > 0.15 * mask.sum():
        oc = np.median(crop[ringm], axis=0)
        v = textc - bg
        k = float(np.dot(oc - bg, v) / max(1.0, float(np.dot(v, v))))
        perp = float(np.linalg.norm((oc - bg) - k * v))
        if not (0.12 < k < 0.88 and perp < 34.0):
            if dist(oc, textc) > 70 and dist(oc, bg) > 60:
                outline = {"颜色": hexof(oc), "占比": round(float(ringm.sum()) / float(mask.sum()), 2)}
    th = float(y1 - y0)
    rstyle, rinfo = ring_style(mask, crop, bg, textc)
    pixang = pca_angle(mask)
    dtx = cv2.distanceTransform(mask, cv2.DIST_L2, 3)
    stroke = float(np.percentile(dtx[mask > 0], 75)) * 2.0 if mask.any() else 0.0
    ratio = stroke / max(1.0, th)
    weight = "特粗" if ratio >= 0.155 else ("粗" if ratio >= 0.105 else ("中" if ratio >= 0.062 else "细"))
    out = {"文字色": hexof(textc), "背景色": hexof(bg), "描边": outline,
           "笔画粗细比": round(ratio, 3), "字重猜测": weight,
           "文字像素占比": round(frac, 3), "置信": "高" if frac > 0.03 else "中",
           "描边/发光": rstyle, "倾角像素deg": pixang}
    if rinfo.get("扩散px"):
        out["光晕"] = rinfo
    if outline is not None:
        outline["样式"] = "硬边(描边)" if "硬边" in rstyle else rstyle
    # ―― 阴影:把字形的复制按小偏移平移,落在「既不是字、又明显不是背景」的位置 ――
    kk = max(1.0, th / 24.0)
    ys, xs = np.where(mask > 0)
    maskN = mask.shape
    for dx, dy, name in ((2, 3, "右下"), (4, 5, "右下"), (0, 4, "正下"), (3, 2, "右"), (-3, 3, "左下")):
        ox, oy = int(round(dx * kk)), int(round(dy * kk))
        gx, gy = xs + ox, ys + oy
        fit = (gx >= 0) & (gx < maskN[1]) & (gy >= 0) & (gy < maskN[0])
        ghost = np.zeros_like(mask)
        ghost[gy[fit], gx[fit]] = 1
        gsel = (ghost > 0) & (mask == 0)
        if int(gsel.sum()) < 0.25 * int(mask.sum()):
            continue
        gp = crop[gsel]
        gdb = np.linalg.norm(gp - bg, axis=1)
        if float(((gdb > 18) & (gdb < 220)).mean()) < 0.5:
            continue
        gc = np.median(gp, axis=0)
        if float(gc.sum()) < float(textc.sum()) * 0.92 and dist(gc, textc) > 40:
            out["阴影"] = {"颜色": hexof(gc), "方向": name, "偏移px": [ox, oy]}
            break
    # ―― 底色块:框内「非字形」像素的均色与外围背景明显不同且很平 ――
    inner = crop[mask == 0]
    if len(inner) > 0.25 * mask.size:
        fx0, fy0 = max(0, x0 - 56), max(0, y0 - 56)
        fx1, fy1 = min(frame_wh[0], x1 + 56), min(frame_wh[1], y1 + 56)
        far = np.concatenate([img[fy0:y0].reshape(-1, 3), img[y1:fy1].reshape(-1, 3),
                              img[fy0:fy1, fx0:x0].reshape(-1, 3), img[fy0:fy1, x1:fx1].reshape(-1, 3)])
        if len(far) < 20:
            far = ring
        bgf = np.median(far.astype(np.float32), axis=0)
        st_i = inner[::max(1, len(inner) // 4000)]
        bins = {}
        for q in st_i:
            key = (int(q[0]) >> 5, int(q[1]) >> 5, int(q[2]) >> 5)
            acc = bins.setdefault(key, [0, 0.0, 0.0, 0.0])
            acc[0] += 1; acc[1] += q[0]; acc[2] += q[1]; acc[3] += q[2]
        vb = textc - bg
        vv = max(1.0, float(np.dot(vb, vb)))
        n_i = len(st_i) or 1
        for key, c in sorted(bins.items(), key=lambda x: -x[1][0])[:2]:
            if c[0] < 0.15 * n_i:
                continue
            cm = np.array([c[1] / c[0], c[2] / c[0], c[3] / c[0]])
            if dist(cm, bgf) < 60:
                continue
            k = float(np.dot(cm - bgf, vb)) / vv
            perp = float(np.linalg.norm((cm - bgf) - k * vb))
            if 0.10 < k < 0.90 and perp < 34.0:
                continue
            out["底色块"] = hexof(cm)
            break
    # ―― 渐变字:字形左 20% 与右 20% 的均色差得远 ――
    order = np.argsort(xs)
    n5 = max(1, int(len(xs) * 0.2))
    lc = np.median(crop[ys[order[:n5]], xs[order[:n5]]], axis=0)
    rc = np.median(crop[ys[order[-n5:]], xs[order[-n5:]]], axis=0)
    if dist(lc, rc) > 60:
        out["渐变"] = [hexof(lc), hexof(rc)]
    return out


def coverage_curve(src, tmp, stable_r, scale_f, native_wh, t_center, color, height, tag):
    """t_center 前后 1.4s 以 12fps 密集采样,量「文字出现度」曲线(渐变动画的指纹)。"""
    w, h = native_wh
    x0, y0, x1, y1 = [int(v * scale_f) for v in stable_r]
    ex = max(8, int((x1 - x0) * 0.2)); ey = max(8, int((y1 - y0) * 0.4))
    cx0, cy0 = max(0, x0 - ex), max(0, y0 - ey)
    cx1, cy1 = min(w, x1 + ex), min(h, y1 + ey)
    if cx1 - cx0 < 10 or cy1 - cy0 < 10:
        return [], 0.0
    start = max(0.0, t_center - 1.4)
    files = dump_frames(src, tmp, start, 2.8, 12, h, tag)
    bgc = hex2bgr(color.get("背景色"), (32, 32, 40))
    tcc = hex2bgr(color.get("文字色"), (240, 240, 240))
    delta = float(np.linalg.norm(tcc - bgc))
    thr = max(24.0, delta * 0.30)
    curve = []
    for i, f in enumerate(files):
        img = cv2.imread(str(f))
        if img is None:
            continue
        sc = img.shape[1] / w
        crop = img[int(cy0 * sc):max(int(cy0 * sc) + 1, int(cy1 * sc)),
                   int(cx0 * sc):max(int(cx0 * sc) + 1, int(cx1 * sc))].astype(np.float32)
        if crop.size == 0:
            continue
        dd = np.linalg.norm(crop - bgc, axis=2)
        curve.append((round(start + i / 12.0, 3), round(float((dd > thr).mean()), 4)))
    full = max([c for _, c in curve], default=0.0)
    return curve, full



def classify_entrance(obs, curve, full, stable_cyp, fh, stable_cxp=None, fw=None):
    if not curve or full <= 0.004:
        return "瞬现", "低", "出现窗内量不到渐变曲线"
    t0 = obs[0][0]
    early = max([c for t, c in curve if t <= t0 + 0.25], default=0.0)
    late = max([c for t, c in curve if t >= t0 + 0.35], default=0.0)
    if late > 0.55 * full and early < 0.45 * full:
        onset = [t for t, c in curve if t >= t0 - 0.8 and c > 0.12 * full]
        done = [t for t, c in curve if c >= 0.8 * full]
        sec = round(done[0] - onset[0], 2) if onset and done and done[0] > onset[0] else 0.6
        return "渐显", "高", "约 %.1fs 淡入" % max(0.2, sec)
    mh = float(np.median([r[3] - r[1] for _, r in obs]))
    good = [r for t, r in obs if t <= t0 + 0.6 and mh > 0 and abs((r[3] - r[1]) - mh) / mh <= 0.5]
    if good:
        dy = max(abs(cxy(r)[1] / fh - stable_cyp) for r in good[:2])
        dx = 0.0
        if stable_cxp is not None and fw:
            dx = max(abs(cxy(r)[0] / fw - stable_cxp) for r in good[:2])
        if max(dy, dx) >= 0.03:
            if dy >= dx:
                d = "从下往上滑入" if cxy(good[0])[1] / fh > stable_cyp else "从上往下滑入"
            else:
                d = "从左滑入" if cxy(good[0])[0] / fw < stable_cxp else "从右滑入"
            return d, "中", "首帧位置与稳定位置差 纵%.1f%% 横%.1f%%" % (dy * 100, dx * 100)
    hm = mh
    h0 = obs[0][1][3] - obs[0][1][1]
    if hm > 0 and (hm - h0) / hm > 0.18:
        return "弹出/缩放", "中", "首框高只有稳定框的 %.0f%%(越弹越大)" % (h0 / hm * 100)
    return "瞬现", "中", ""
def classify_exit(curve, full, t1):
    if not curve or full <= 0.004:
        return "未知"
    pre = [c for t, c in curve if t1 - 0.9 <= t <= t1 - 0.2]
    post = [c for t, c in curve if t >= t1]
    if not pre:
        return "未知"
    m = max(pre)
    if m <= 0.01:
        return "未知"
    if post and max(post) >= 0.5 * m:
        return "还在(截断在分析窗内)"
    ramp = [c for t, c in curve if t1 - 0.5 <= t < t1]
    if ramp and max(ramp) < 0.75 * m:
        return "渐隐"
    return "瞬隐/被硬切"


def lifetime_metrics(src, tmp, sr, scale_f, native_wh, t0, t1, color, tag):
    """固定框、全生命周期 12fps 密集度量(只给不滚动的块用)。返回的六条序列就是字效的指纹:
    出现度(闪烁)/框右缘(打字机、擦除)/重心(抖动)/字高(呼吸)/清晰度(模糊转清晰)/主色(变色)。"""
    w, h = native_wh
    x0, y0, x1, y1 = [int(v * scale_f) for v in sr]
    ex = max(8, int((x1 - x0) * 0.25)); ey = max(8, int((y1 - y0) * 0.6))
    cx0, cy0 = max(0, x0 - ex), max(0, y0 - ey)
    cx1, cy1 = min(w, x1 + ex), min(h, y1 + ey)
    if cx1 - cx0 < 10 or cy1 - cy0 < 10:
        return {}
    start = max(0.0, t0 + 0.1)
    dur = min(8.0, max(0.6, t1 - start))
    files = dump_frames(src, tmp, start, dur, 12, h, tag)
    bgc = hex2bgr(color.get("背景色"), (32, 32, 40))
    tcc = hex2bgr(color.get("文字色"), (240, 240, 240))
    delta = float(np.linalg.norm(tcc - bgc))
    thr = max(24.0, delta * 0.30)
    S = {"t": [], "cov": [], "lx": [], "rx": [], "cy": [], "cx": [], "mh": [], "sharp": [], "br": [], "col": []}
    samp = []
    for i, f in enumerate(files):
        img = cv2.imread(str(f))
        if img is None:
            continue
        sc = img.shape[1] / float(w)
        yy0 = int(cy0 * sc); yy1 = max(yy0 + 1, int(cy1 * sc))
        xx0 = int(cx0 * sc); xx1 = max(xx0 + 1, int(cx1 * sc))
        crop = img[yy0:yy1, xx0:xx1].astype(np.float32)
        if crop.size == 0:
            continue
        dd = np.linalg.norm(crop - bgc, axis=2)
        m = (dd > thr) & (np.linalg.norm(crop - tcc, axis=2) <= dd)
        m_any = dd > thr
        t = round(start + i / 12.0, 3)
        S["t"].append(t)
        if not m.any():
            S["cov"].append(0.0); S["lx"].append(0.0); S["rx"].append(0.0)
            S["cy"].append(0.0); S["cx"].append(0.0); S["mh"].append(0.0)
            S["sharp"].append(0.0); S["br"].append(0.0); S["col"].append([0, 0, 0])
            continue
        ys, xs = np.where(m)
        g = cv2.Sobel(np.asarray(dd, np.float32), cv2.CV_32F, 1, 1, ksize=3)
        cw = float(crop.shape[1]); chh = float(crop.shape[0])
        S["cov"].append(round(float(m.mean()), 4))
        S["lx"].append(round(float(xs.min()) / cw, 4))
        S["rx"].append(round(float(xs.max()) / cw, 4))
        S["cy"].append(round(float(np.median(ys)) / chh, 4))
        S["cx"].append(round(float(np.median(xs)) / cw, 4))
        S["mh"].append(round(float(ys.max() - ys.min()) / chh, 4))
        S["sharp"].append(round(float(np.abs(g[m]).mean()), 2))
        S.setdefault("br", []).append(round(float(crop[m].mean(axis=0).sum() / 3.0), 1))
        ya, xa = np.where(m_any)
        if len(xa) > 4:
            sub2 = np.linspace(0, len(xa) - 1, min(300, len(xa))).astype(int)
            samp.append((t, xa[sub2].astype(float) / max(1.0, float(crop.shape[1])),
                         crop[ya[sub2], xa[sub2]].astype(float)))
        mc = np.median(crop[m], axis=0)
        S["col"].append([int(mc[0]), int(mc[1]), int(mc[2])])
    # ―― 卡拉OK边界:全局两色聚类(取最暗/最亮种子),逐帧算「少数色」的 x 中线 ――
    S["bd"] = []; S["kA"] = None; S["kB"] = None
    allc = np.concatenate([s[2] for s in samp]) if samp else np.zeros((0, 3))
    if len(allc) > 60:
        lum = allc.mean(axis=1)
        cA = np.asarray(allc[int(np.argmin(lum))], float)
        cB = np.asarray(allc[int(np.argmax(lum))], float)
        for _ in range(4):
            da = np.linalg.norm(allc - cA, axis=1); db = np.linalg.norm(allc - cB, axis=1)
            sa = allc[da < db]; sb = allc[db <= da]
            if len(sa) < 4 or len(sb) < 4:
                break
            nA = sa.mean(axis=0); nB = sb.mean(axis=0)
            done = float(np.abs(nA - cA).max()) < 1.0 and float(np.abs(nB - cB).max()) < 1.0
            cA, cB = nA, nB
            if done:
                break
        if float(np.linalg.norm(cA - cB)) > 90:
            S["kA"] = [int(v) for v in cA]; S["kB"] = [int(v) for v in cB]
            for (tt, xsf, cols) in samp:
                da = np.linalg.norm(cols - cA, axis=1); db = np.linalg.norm(cols - cB, axis=1)
                sa = da < db
                share = float(sa.mean()) if len(sa) else 0.0
                medA = round(float(np.median(xsf[sa])), 4) if sa.any() else -1.0
                medB = round(float(np.median(xsf[~sa])), 4) if (~sa).any() else -1.0
                S["bd"].append([tt, round(share, 3), medA, medB])
    return S


def classify_extras(S, obs, color, tilt):
    """从 OCR 框序列 + 全生命周期像素序列判附加字效。每条带依据和置信;判不动的宁可不写。"""
    ex = []
    t = S.get("t") or []
    cov = np.asarray(S["cov"], float) if S else np.array([])
    plateau = float(np.percentile(cov, 75)) if len(cov) >= 8 else 0.0
    # ―― 打字机/擦除:以 OCR 框宽为主判(密集像素窗会被邻行经过的内容污染,框宽=这行读到几个字) ――
    good = [(o["t"], o["r"]) for o in sorted(obs, key=lambda o: o["t"]) if o["score"] >= 0.75]
    if len(good) >= 4:
        ws = [(r[2] - r[0]) for _, r in good]
        lxs = [r[0] for _, r in good]
        w_first = float(np.median(ws[:2]))
        w_final = float(np.percentile(ws, 85))
        lx_stable = (max(lxs) - min(lxs)) < 0.35 * max(1.0, float(np.median(ws)))
        if w_final > 10 and w_first < 0.60 * w_final:
            dw = np.diff(ws)
            jumps = int(np.count_nonzero(np.abs(dw) > 0.15 * w_final))
            if jumps >= 2 and lx_stable:
                ex.append({"效果": "打字机(逐字出现)", "置信": "高",
                           "依据": "OCR 框宽 %d→%dpx 分 %d 级跳,左缘稳定" % (round(w_first), round(w_final), jumps)})
            elif jumps <= 1 and lx_stable:
                ex.append({"效果": "擦除式显影", "置信": "中",
                           "依据": "OCR 框宽从 %.0f%% 连续扩展到 %.0fpx" % (w_first / w_final * 100, w_final)})
    elif len(cov) >= 8 and plateau > 0.008:
        rx = np.asarray(S["rx"], float); lx = np.asarray(S["lx"], float)
        pres = cov > 0.55 * plateau
        if pres.sum() >= 4:
            wid = rx - lx
            w_first = float(np.median(wid[pres][:3])); w_final = float(np.percentile(wid[pres], 92))
            if w_final > 0 and w_first < 0.55 * w_final:
                dw = np.diff(wid[pres])
                jumps = int(np.count_nonzero(np.abs(dw) > 0.09 * w_final))
                if jumps >= 2:
                    ex.append({"效果": "打字机(逐字出现)", "置信": "中",
                               "依据": "像素框宽分 %d 级长到满(起 %.0f%%)" % (jumps + 1, w_first / w_final * 100)})
                elif float(np.mean(np.abs(dw) <= 0.03 * w_final)) > 0.8:
                    ex.append({"效果": "擦除式显影", "置信": "中",
                               "依据": "像素框宽从 %.0f%% 平滑扩展到满" % (w_first / w_final * 100)})
    if len(t) < 8:
        return ex
    cy = np.asarray(S["cy"], float); cx = np.asarray(S["cx"], float)
    mh = np.asarray(S["mh"], float); sharp = np.asarray(S["sharp"], float)
    br = np.asarray(S.get("br") or [], float)
    pres = cov > max(0.015, 0.15 * plateau)
    full = cov > 0.7 * plateau
    if not pres.any():
        pres = cov > 0
    # ―― 闪烁/脉冲:亮度来回摆(透明闪烁)或出现度摆(完全消失型) ――
    if len(br) == len(cov) and pres.sum() > 8 and float(br[pres].max()) > 1.0:
        trn_b, amp_b = oscillation(br[pres])
        if trn_b >= 3 and amp_b >= 0.13:
            ex.append({"效果": "闪烁/脉冲", "置信": "高" if amp_b >= 0.2 else "中",
                       "依据": "亮度摆 %d 次(振幅 %.0f%%)" % (trn_b, amp_b * 100)})
    tail = cov[max(1, int(len(cov) * 0.15)):]
    trn, amp = oscillation(tail)
    if trn >= 3 and amp >= 0.2 and not any("闪烁" in e["效果"] for e in ex):
        ex.append({"效果": "闪烁/脉冲", "置信": "中",
                   "依据": "出现度摆 %d 次(振幅 %.0f%%)——可能间歇完全消失" % (trn, amp * 100)})
    # ―― 抖动:重心高频振荡 ――
    jty = oscillation(cy[pres])[0]
    jtx = oscillation(cx[pres])[0]
    if (float(np.std(cy[pres])) >= 0.010 or float(np.std(cx[pres])) >= 0.010) and jtx + jty >= 5:
        ex.append({"效果": "抖动/震动", "置信": "中",
                   "依据": "重心摆 %d 次(纵±%.3f 横±%.3f)" % (jtx + jty, float(np.std(cy[pres])), float(np.std(cx[pres])))})
    # ―― 呼吸缩放:字高大摆幅周期变化 ――
    mtrn, mamp = oscillation(mh[pres])
    if mtrn >= 3 and mamp >= 0.10 and not any(("打字机" in e["效果"] or "闪烁" in e["效果"]) for e in ex):
        ex.append({"效果": "呼吸缩放", "置信": "中", "依据": "字高周期变 ±%.0f%%(摆 %d 次)" % (mamp * 100, mtrn)})
    # ―― 卡拉OK逐字变色:两种真色 + 分界线单向扫过 + 框宽稳定(和打字机区分) ――
    bd = [r_ for r_ in (S.get("bd") or []) if len(r_) == 4]
    pts = []
    if len(bd) >= 8 and S.get("kA") is not None:
        sh = np.asarray([r_[1] for r_ in bd], float)
        n4 = max(1, len(sh) // 4)
        d_sh = float(sh[-n4:].mean()) - float(sh[:n4].mean())
        if abs(d_sh) > 0.35:
            idx = 2 if d_sh > 0 else 3
            pts = [r_[idx] for r_ in bd if r_[idx] >= 0]
            pts = pts[:max(8, len(pts))]
        else:
            pts = []
    if len(pts) >= 6 and S.get("kA") is not None:
        bx = np.asarray(pts, float)
        q1 = float(np.median(bx[:max(1, len(bx) // 4)])); q4 = float(np.median(bx[-max(1, len(bx) // 4):]))
        diffs = np.diff(bx)
        mono = float((diffs >= -0.02).mean())
        bgv2 = hex2bgr(color.get("背景色"), (32, 32, 40))
        txtv2 = hex2bgr(color.get("文字色"), (240, 240, 240))
        seg2 = txtv2 - bgv2; vv2 = max(1.0, float(np.dot(seg2, seg2)))
        def _perp2(cvv):
            k = float(np.dot(cvv - bgv2, seg2)) / vv2
            return float(np.linalg.norm((cvv - bgv2) - k * seg2))
        kA = np.asarray(S["kA"], float); kB = np.asarray(S["kB"], float)
        wide = not any(("打字机" in e["效果"] or "擦除" in e["效果"]) for e in ex)
        if abs(q4 - q1) >= 0.15 and mono >= 0.70 and max(_perp2(kA), _perp2(kB)) >= 50 and wide:
            ex.append({"效果": "卡拉OK逐字变色", "置信": "中",
                       "依据": "两种颜色(%s/%s),分界线自%s扫过 %.0f%% 字宽" % (
                           hexof(kA), hexof(kB), "左向右" if q4 > q1 else "右向左", abs(q4 - q1) * 100)})
    # ―― 模糊转清晰:全亮帧里清晰度爬升 ――
    no_kar = not any("卡拉OK" in e["效果"] for e in ex)
    cov_steady = full.sum() >= 6 and float(np.std(cov[full])) < 0.12 * max(1e-6, float(np.mean(cov[full])))
    if cov_steady and no_kar:
        shf = sharp[full]
        seg = max(1, len(shf) // 4)
        a = float(np.mean(shf[:seg])); b = float(np.mean(shf[-seg:]))
        if a > 1 and b / max(1e-6, a) >= 1.7:
            ex.append({"效果": "模糊转清晰", "置信": "中", "依据": "清晰度 %.0f→%.0f(出现度基本稳)" % (a, b)})
        elif b > 1 and a / max(1e-6, b) >= 1.7:
            ex.append({"效果": "清晰转模糊", "置信": "中", "依据": "清晰度 %.0f→%.0f" % (a, b)})
    # ―― 变色:只看全亮帧,两簇都离背景远且色差大 ――
    cols = np.asarray(S["col"], float)
    bgv = hex2bgr(color.get("背景色"), (32, 32, 40))
    txtv = hex2bgr(color.get("文字色"), (240, 240, 240))
    dtb = float(np.linalg.norm(txtv - bgv))
    if len(cols) == len(cov) and full.sum() >= 12 and dtb > 200 and no_kar:
        cc = cols[full]
        base = np.median(cc, axis=0)
        far = np.linalg.norm(cc - base, axis=1)
        cA = np.median(cc[far <= np.percentile(far, 25)], axis=0)
        cB = np.median(cc[far >= np.percentile(far, 75)], axis=0)
        segv = txtv - bgv
        vv2 = max(1.0, float(np.dot(segv, segv)))
        def _perp(cvv):
            k = float(np.dot(cvv - bgv, segv)) / vv2
            return float(np.linalg.norm((cvv - bgv) - k * segv))
        if (dist(cA, cB) > 110 and min(float(np.linalg.norm(cA - bgv)), float(np.linalg.norm(cB - bgv))) > 0.6 * dtb
                and max(_perp(cA), _perp(cB)) >= 50
                and not any("卡拉OK" in e["效果"] for e in ex)):
            ex.append({"效果": "变色", "置信": "中", "依据": "全亮帧主色 %s↔%s" % (hexof(cA), hexof(cB))})
    # ―― 疑似3D翻转/水平拉伸:框宽周期振荡而字高不变 ――
    if pres.any() and len(pres[pres]) >= 8 and not any(("打字机" in e["效果"] or "擦除" in e["效果"]) for e in ex):
        rtrn, ramp = oscillation(np.asarray(S["rx"], float)[pres])
        mtrn0, mamp0 = oscillation(np.asarray(S["mh"], float)[pres])
        if rtrn >= 3 and ramp >= 0.08 and mamp0 < 0.03:
            ex.append({"效果": "疑似3D翻转/水平拉伸", "置信": "低",
                       "依据": "框宽周期变 ±%.0f%% 而字高不变(翻轴方向无法定死)" % (ramp * 100)})
    # ―― 发光(光晕):径向剖面是衰减环 ――
    if color.get("光晕"):
        ex.append({"效果": "发光/光晕", "置信": "中", "依据": "字形外亮度逐圈衰减(扩散≈%spx)" % color["光晕"].get("扩散px")})
    # ―― 静态属性类:倾斜/阴影/底色块/渐变 ――
    if tilt is not None and abs(tilt) >= 4:
        ex.append({"效果": "倾斜字", "置信": "高", "依据": "OCR 四角框量到倾角 %.1f°(近似值,以截图为准)" % tilt})
    if color.get("阴影"):
        z = color["阴影"]
        ex.append({"效果": "有阴影", "置信": "中", "依据": "字形%s方偏移%spx的影子 %s" % (z["方向"], z["偏移px"], z["颜色"])})
    if color.get("底色块"):
        ex.append({"效果": "底色块/高亮底", "置信": "中", "依据": "文字垫着 %s 色块" % color["底色块"]})
    if color.get("渐变"):
        ex.append({"效果": "渐变字", "置信": "中", "依据": "左%s 右%s" % tuple(color["渐变"])})
    return ex


def suggest_jianying(b):
    s = []
    pos = b["位置"]; size = b["大小"]; col = b["颜色"]; mo = b["动效"]
    s.append("文字内容(OCR):「%s」,以画面截图为准核对错字" % b["文字"])
    if col.get("文字色"):
        s.append("字体颜色:取色 %s;描边:%s" % (
            col["文字色"],
            ("%s(约占字块%d%%)" % (col["描边"]["颜色"], int(col["描边"]["占比"] * 100))) if col.get("描边") else "看不出"))
    if col.get("字重猜测"):
        s.append("字重看起来是「%s」;字高≈%dpx(按1920高的屏换算),剪映里先打任意文案、拖字号对到一样高" % (
            col["字重猜测"], size["字高px(按1920高换算)"]))
    xpx = round((pos["中心X%"] - 50) / 100 * 1080); ypx = round((50 - pos["中心Y%"]) / 100 * 1920)
    s.append("位置:%s(剪映 位置 X=%d Y=%d,Y 正方向为上)" % (pos["锚位"], xpx, ypx))
    if pos["中心Y%"] > 75:
        s.append("注意:本片字幕一律下沿(横屏底边留8%,竖屏留20%在遮挡区上方)——对标若把字贴死底部(留白<本规则)要抬上来;对标放正中的按本片规则改下沿")
    e = mo["入场"]; x = mo["出场"]
    if "渐显" in e:
        s.append("入场:剪映 字幕动画-入场「渐显」,%s" % (mo["依据"] or "时长先按默认试"))
    elif "滑入" in e:
        s.append("入场:动画入「上移入/下移入」一类,或关键帧:位置从偏移滑到锚位,0.3~0.5s")
    elif "弹出" in e:
        s.append("入场:动画入「弹入/缩放」类")
    elif "滚动" in e:
        s.append("入场:文字随滚动从画面外进入(整段是连续滚动)")
    elif "打字机" in e:
        s.append("入场:剪映 动画入-「打字机」,时长按实测逐字速度拉")
    elif "擦除" in e:
        s.append("入场:动画入「显影/擦除」类,或蒙版平移擦出")
    elif "滑入" in e:
        s.append("入场:动画入「%s」,时长0.3~0.5s" % e)
    elif "单帧" in e:
        s.append("入场:截图看不出,需要给视频再分析")
    else:
        s.append("入场:硬切直接出现(不需要入场动画)")
    if "渐隐" in x:
        s.append("出场:字幕动画-出场「渐隐」")
    elif "瞬隐" in x:
        s.append("出场:直接消失(硬切),不出场动画")
    elif "单帧" not in x and "未知" not in x:
        s.append("出场:%s" % x)
    for e in (mo.get("附加效果") or []):
        nm = e.get("效果", "")
        if ("打字机" in nm or "擦除" in nm) and e["效果"] in (mo.get("入场") or ""):
            continue
        if "闪烁" in nm:
            s.append("停留期间:不透明度关键帧 100→0→100 循环(依据:%s)" % e.get("依据", ""))
        elif "抖动" in nm:
            s.append("停留期间:特效-「动态-抖动」,幅度照实测(%s)" % e.get("依据", ""))
        elif "呼吸" in nm:
            s.append("停留期间:缩放关键帧循环 A→B→A(%s)" % e.get("依据", ""))
        elif "模糊转清晰" in nm:
            s.append("入场:动画入「虚化显现」,或清晰度关键帧 0→100(%s)" % e.get("依据", ""))
        elif "清晰转模糊" in nm:
            s.append("出场:清晰度关键帧 100→0(%s)" % e.get("依据", ""))
        elif "变色" in nm:
            s.append("停留期间变色:拆两段文案换色,切换点照实测(%s)" % e.get("依据", ""))
        elif "倾斜" in nm:
            s.append("倾斜:剪映文字「旋转」参数≈%.1f°,以截图微调(%s)" % (b["位置"].get("倾角deg") or 0, e.get("依据", "")))
        elif "阴影" in nm:
            z = (b["颜色"].get("阴影") or {})
            s.append("阴影:花字-阴影,方向%s、颜色%s、偏移%spx(%s)" % (z.get("方向"), z.get("颜色"), z.get("偏移px"), e.get("依据", "")))
        elif "底色块" in nm:
            s.append("底色块:文字下垫矩形色块 %s(剪映「背景-单色」勾圆角)(%s)" % (b["颜色"].get("底色块"), e.get("依据", "")))
        elif "渐变字" in nm:
            s.append("渐变字:花字-渐变填充 %s→%s(%s)" % (tuple(b["颜色"].get("渐变") or ("", "")), e.get("依据", "")))
        elif "卡拉OK" in nm:
            s.append("卡拉OK:剪映 动画-「出现-卡拉OK」类,两层文字法也行(白字打底+色字带横向位置关键帧从左推到右);两色看依据")
        elif "3D翻转" in nm:
            s.append("疑似3D翻转:先用动画入「翻转」试(或缩放X关键帧循环);置信低,看截图定")
        elif "发光" in nm:
            s.append("发光:花字→发光,光晕扩散≈%spx(和粗描边的区别:发光外圈渐暗)" % ((b["颜色"].get("光晕") or {}).get("扩散px")))
    if mo["滚动"] not in ("", None) and mo["滚动"] != "无":
        v = mo["滚动速度%屏每秒"]
        s.append("滚动:%s,速度≈%.1f%%屏/秒 → 剪映关键帧:开头打一个位置关键帧,结尾把 Y 再移动「速度×镜头秒数」,曲线选线性" % (mo["滚动"], v))
    return s


def make_md(out):
    L = ["# 对标文字效果报告(工作台①-E生成)", "",
         "- 对标源: `%s`(输入类型:%s)" % (out["对标源"], out["输入类型"]),
         "- 分析时间: %s,抽帧 %s 帧,OCR 用时 %ss" % (
             out["分析时间"], out["采样"]["抽帧数"], out["采样"]["OCR耗时秒"]),
         "- 结论:共 %d 个文字块,%d 套样式" % (out["统计"]["文字块数"], out["统计"]["样式组数"]), ""]
    for g in out["样式分组"]:
        L.append("- %s:%d 块(%s)" % (g["名"], len(g["块"]), "、".join(g["块"])))
    L.append("")
    for b in out["文字块"]:
        L.append("## %s「%s」%.1fs~%.1fs" % (b["编号"], b["文字"][:18], b["首现"], b["末现"]))
        L.append("")
        for sline in b["复刻建议"]:
            L.append("- %s" % sline)
        L.append("")
    L.append("---")
    L.append("技术上限:字体名无法从画面精确识别(只能猜粗细类别);颜色/大小是按像素量的近似值;"
             "动效判定的置信度写在 对标文字.json 里。")
    return "\n".join(L)


def assemble_tracks(dets, times, fps, fh):
    """把逐帧 OCR 结果拼成「文字块轨迹」。评分制:文字相似度 + 框位置预测重叠度,
    两者加和最高且达标的才合并——专治两件事:①OCR 首帧错字(剪房事试→剪辑新手第一反应)
    ②滚动字幕路过静默字幕时不能被它吞掉(滚动自己速度预测后重叠度更高,赢)。"""
    dt_gap = 2.5 / fps + 0.5
    tracks = []
    for fi, got in enumerate(dets):
        t = times[fi]
        for d in got:
            best = None; best_score = 0.0; best_iou = 0.0; best_sim = 0.0
            for tr in tracks:
                obs = tr["obs"]
                last = obs[-1]
                if t - last["t"] > dt_gap:
                    continue
                pred = last["r"]
                vx = vy = 0.0
                if len(obs) >= 2:
                    o = obs[-4:]
                    vxs = [(cxy(o[i + 1]["r"])[0] - cxy(o[i]["r"])[0]) /
                           max(1e-3, o[i + 1]["t"] - o[i]["t"]) for i in range(len(o) - 1)]
                    vys = [(cxy(o[i + 1]["r"])[1] - cxy(o[i]["r"])[1]) /
                           max(1e-3, o[i + 1]["t"] - o[i]["t"]) for i in range(len(o) - 1)]
                    vx = float(np.median(vxs)); vy = float(np.median(vys))
                    dt = t - last["t"]
                    x0, y0, x1, y1 = last["r"]
                    pred = (x0 + vx * dt, y0 + vy * dt, x1 + vx * dt, y1 + vy * dt)
                v = iou(pred, d["r"])
                sim = max(SequenceMatcher(None, o_["text"], d["text"]).ratio() for o_ in obs[-4:])
                sc = sim + v
                if sc > best_score:
                    best_score = sc; best = tr; best_iou = v; best_sim = sim
            if best is not None and best_score >= 0.55 and (best_iou >= 0.15 or (best_sim >= 0.7 and best_iou >= 0.02)):
                best["obs"].append(d)
            else:
                tracks.append({"obs": [d]})
        for tr in tracks:
            if not tr.get("closed") and t - tr["obs"][-1]["t"] > dt_gap * 1.4:
                tr["closed"] = True
    return [tr["obs"] for tr in tracks]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("media")
    ap.add_argument("--out", default="对标文字.json")
    ap.add_argument("--proj", default="")
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--dur", type=float, default=90.0)
    ap.add_argument("--fps", type=float, default=1.5)
    ap.add_argument("--height", type=int, default=540)
    ap.add_argument("--min-conf", dest="min_conf", type=float, default=0.5)
    ap.add_argument("--max", type=int, default=40)
    a = ap.parse_args()
    src = Path(a.media)
    if not src.exists():
        say("[错误] 素材不存在: %s" % src); sys.exit(2)
    try:
        from rapidocr_onnxruntime import RapidOCR
    except Exception as e:
        say("[错误] OCR 引擎缺失(%s)。安装: python -m pip install pyclipper shapely six pyyaml && "
            "python -m pip install rapidocr-onnxruntime --no-deps" % e)
        sys.exit(2)
    tmp = tempfile.mkdtemp(prefix="textstyle_")
    try:
        is_img = src.suffix.lower() in IMG_EXT
        if is_img:
            img0 = cv2.imread(str(src))
            if img0 is None:
                say("[错误] 图片读不了: %s" % src); sys.exit(2)
            W, H = img0.shape[1], img0.shape[0]
            sc0 = a.height / H
            frames = [cv2.resize(img0, (max(1, int(W * sc0)), a.height))]
            times = [0.0]
            scale_f = H / float(a.height)
            fpsv = durv = 0.0
        else:
            if src.suffix.lower() not in VIDEO_EXT:
                say("[错误] 只支持视频(%s)或图片(%s)" % (
                    "/".join(sorted(VIDEO_EXT)), "/".join(sorted(IMG_EXT)))); sys.exit(2)
            W, H, fpsv, durv = probe(str(src))
            if not W or not H:
                say("[错误] 取不到画面信息(编码不支持?)"); sys.exit(2)
            t1 = min(durv if durv > 0 else a.start + a.dur, a.start + a.dur)
            say("画面 %dx%d %.1ffps,分析 %.0f~%.0fs,采样 %gfps(约 %d 帧)" % (
                W, H, fpsv, a.start, t1, a.fps, int((t1 - a.start) * a.fps)))
            files = dump_frames(src, tmp, a.start, t1 - a.start, a.fps, a.height, "fr")
            frames = [cv2.imread(str(f)) for f in files]
            frames = [f for f in frames if f is not None]
            times = [a.start + i / a.fps for i in range(len(files))][:len(frames)]
            scale_f = H / float(a.height)
        if not frames:
            say("[错误] 一帧都没抽出来,素材可能是坏的/纯音频"); sys.exit(2)
        ocr = RapidOCR()
        say("OCR 已加载,开始逐帧识别(%d 帧)…" % len(frames))
        t_watch = time.time()
        dets = []
        for fi, (img, t) in enumerate(zip(frames, times)):
            res, _ = ocr(img)
            got = []
            for box, text, score in (res or []):
                if float(score) < a.min_conf:
                    continue
                txt = re.sub(r"\s+", "", str(text))
                if len(txt) < 2:
                    continue
                got.append({"t": t, "r": rect_of(box), "text": txt, "score": float(score), "ang": angle_of(box)})
            dets.append(got)
            if (fi + 1) % 20 == 0 or fi == len(frames) - 1:
                say("  已识别 %d/%d 帧(%.0fs)" % (fi + 1, len(frames), time.time() - t_watch))
        fh, fw = frames[0].shape[:2]
        tracks = assemble_tracks(dets, times, a.fps, fh)
        native_wh = (W, H)
        blocks = []
        seq = [0]
        def nat_at(t):
            if is_img:
                return img0
            d2 = tempfile.mkdtemp(dir=tmp)
            fs = dump_frames(src, d2, max(0.0, t - 0.05), 0.14, 25, H, "nat")
            img = cv2.imread(str(fs[min(3, len(fs) - 1)])) if fs else None
            shutil.rmtree(d2, ignore_errors=True)
            return img
        for obs in tracks:
            if len(obs) < (1 if is_img else 2):
                continue
            text = Counter(o["text"] for o in sorted(obs, key=lambda o: -o["score"])).most_common(1)[0][0]
            hs = [o["r"][3] - o["r"][1] for o in obs]; ws = [o["r"][2] - o["r"][0] for o in obs]
            cx = float(np.median([cxy(o["r"])[0] for o in obs])); cy = float(np.median([cxy(o["r"])[1] for o in obs]))
            mh = float(np.median(hs)); mw = float(np.median(ws))
            sr = (cx - mw / 2, cy - mh / 2, cx + mw / 2, cy + mh / 2)
            t0 = obs[0]["t"]; t1b = obs[-1]["t"]
            cxp, cyp = cx / fw, cy / fh
            scroll = None; dirv = ""; speed = 0.0
            if len(obs) >= 4 and not is_img:
                dys = [(obs[i + 1]["r"][1] - obs[i]["r"][1]) / fh for i in range(len(obs) - 1)]
                dys = [x for x in dys if abs(x) < 0.10]
                dxs = [(obs[i + 1]["r"][0] - obs[i]["r"][0]) / fw for i in range(len(obs) - 1)]
                dxs = [x for x in dxs if abs(x) < 0.10]
                tot_y = (obs[-1]["r"][1] - obs[0]["r"][1]) / fh
                tot_x = (obs[-1]["r"][0] - obs[0]["r"][0]) / fw
                span = max(0.5, t1b - t0)
                up = sum(1 for x in dys if x < -0.004); dn = sum(1 for x in dys if x > 0.004)
                lf = sum(1 for x in dxs if x < -0.004); rt = sum(1 for x in dxs if x > 0.004)
                n = max(1, len(dys))
                if abs(tot_y) >= 0.08 and max(up, dn) >= 0.6 * n:
                    scroll = "纵向"; dirv = "向下" if dn > up else "向上"; speed = round(abs(tot_y) / span * 100, 1)
                elif abs(tot_x) >= 0.10 and max(lf, rt) >= 0.6 * len(dxs):
                    scroll = "横向"; dirv = "向右" if rt > lf else "向左"; speed = round(abs(tot_x) / span * 100, 1)
            nat = nat_at((t0 + t1b) / 2.0)
            color = {"置信": "低", "说明": "取帧失败"}
            if nat is not None:
                s2 = nat.shape[1] / fw
                color = analyze_colors(nat, [v * s2 for v in sr], (nat.shape[1], nat.shape[0]))
            seq[0] += 1
            tag = "cv%d" % seq[0]
            entrance, ex_conf, ex_note = "单帧无法判定", "低", ""
            exit_ = "单帧无法判定"
            if not is_img and color.get("文字色"):
                curve, full = coverage_curve(src, tmp, sr, scale_f, native_wh, t0 + 0.3, color, a.height, tag + "a")
                entrance, ex_conf, ex_note = classify_entrance(
                    [(o["t"], o["r"]) for o in obs], curve, full, cyp, fh, cxp, fw)
                if scroll:
                    entrance = "随%s滚动入场" % (dirv or scroll); ex_conf = "中"
                    exit_ = "随%s滚出画面(位置一直在变,出场靠滚动本身)" % (dirv or scroll)
                if not scroll:
                    curve2, full2 = coverage_curve(src, tmp, sr, scale_f, native_wh, t1b, color, a.height, tag + "b")
                    exit_ = classify_exit(curve2, max(full2, full if curve else 0.0), t1b)
            angs = [o["ang"] for o in obs if o.get("ang") is not None and o["score"] >= 0.8]
            tilt = float(np.median(angs)) if len(angs) >= 2 else None
            if tilt is not None and abs(tilt) >= 45:
                tilt = None
            pa = color.get("倾角像素deg")
            if isinstance(pa, (int, float)) and abs(pa) >= 2.5:
                tilt = pa
            if nat is not None and color.get("文字色") and color.get("置信") in ("高", "中"):
                s3 = nat.shape[1] / fw
                pa2 = angle_from_frame(nat, [v * s3 for v in sr], color)
                qt = tilt if tilt is not None else 0.0
                if abs(pa2) >= 6 and (abs(qt) < 1.0 or (pa2 > 0) == (qt >= 0)):
                    tilt = pa2
            extras = []
            if not is_img and not scroll and color.get("文字色") and (t1b - t0) >= 0.8:
                S = lifetime_metrics(src, tmp, sr, scale_f, native_wh, t0, t1b, color, tag + "L")
                extras = classify_extras(S, obs, color, tilt)
                for e in ("打字机(逐字出现)", "擦除式显影"):
                    if any(x["效果"] == e for x in extras):
                        entrance = e; ex_conf = "高"; ex_note = "见附加效果依据"
            else:
                if tilt is not None and abs(tilt) >= 4:
                    extras = [{"效果": "倾斜字", "置信": "高", "依据": "OCR 四角框量到倾角 %.1f°" % tilt}]
            blocks.append({
                "编号": "T%02d" % len(blocks),
                "文字": text, "首现": round(t0, 2), "末现": round(t1b, 2), "持续秒": round(t1b - t0, 2),
                "位置": {"中心X%": round(cxp * 100, 1), "中心Y%": round(cyp * 100, 1),
                         "锚位": anchor_name(cxp, cyp), "倾角deg": tilt},
                "大小": {"字高占屏%": round(mh / fh * 100, 1), "宽占屏%": round(mw / fw * 100, 1),
                         "字高px(按1920高换算)": int(round(mh / fh * 1920))},
                "颜色": color,
                "字体猜测": {"字重": color.get("字重猜测", "?"),
                             "说明": "字体名无法从画面确认;拿截图在剪映字体列表里比对最可靠"},
                "动效": {"入场": entrance, "出场": exit_, "滚动": ((scroll + dirv) if scroll else "无"),
                         "滚动速度%屏每秒": speed, "置信": ex_conf, "依据": ex_note,
                         "附加效果": extras},
            })
        blocks.sort(key=lambda b: (b["首现"], b["末现"]))
        if len(blocks) > a.max:
            say("[说明] 块太多(%d),只保留停留最久的 %d 个" % (len(blocks), a.max))
            blocks = sorted(blocks, key=lambda b: -b["持续秒"])[:a.max]
            blocks.sort(key=lambda b: b["首现"])
        for i, b in enumerate(blocks, 1):
            b["编号"] = "T%02d" % i
            b["复刻建议"] = suggest_jianying(b)
        groups = []
        for b in blocks:
            sig = (b["位置"]["锚位"], round(b["大小"]["字高占屏%"] / 4),
                   b["颜色"].get("文字色", "#000000"), b["动效"]["入场"])
            g = next((x for x in groups if x["sig"] == sig), None)
            if not g:
                g = {"sig": sig, "名": "样式%d" % (len(groups) + 1), "块": []}
                groups.append(g)
            g["块"].append(b["编号"])
        for g in groups:
            g.pop("sig")
        out = {"对标源": str(src), "分析时间": time.strftime("%Y-%m-%d %H:%M:%S"),
               "画面": {"宽": W, "高": H, "比例": ("横屏" if W > H else ("竖屏" if H > W else "方屏"))},
               "输入类型": ("图片" if is_img else "视频"),
               "采样": {"帧率": a.fps, "分析秒数": (round(times[-1] - times[0], 1) if not is_img else 0),
                        "抽帧数": len(frames), "OCR耗时秒": round(time.time() - t_watch, 1)},
               "统计": {"文字块数": len(blocks), "样式组数": len(groups)},
               "文字块": blocks, "样式分组": groups,
               "提示": ["字体名无法精确识别(技术上限),给出的是字重猜测+候选,请以截图人工比对",
                        "OCR 识别的文字可能有错字,复刻时以你核对过的文案为准",
                    "现已能判:卡拉OK逐字变色(色界扫描)、发光vs粗描边(径向剖面)、倾角(像素主轴,±2°级);"
                    "3D翻转只能给「疑似」(与水平拉伸动画在像素上同形);字体名依旧定不死——拿截图贴多模态AI最靠谱"]}
        if a.proj:
            pd = Path(a.proj) / "对标文字块"; pd.mkdir(parents=True, exist_ok=True)
            for b in blocks:
                tmid = (b["首现"] + b["末现"]) / 2.0
                nat = nat_at(tmid)
                if nat is None:
                    continue
                w2, h2 = nat.shape[1], nat.shape[0]
                hh = max(20, int(b["大小"]["字高占屏%"] / 100 * h2 * 2.2))
                ww = max(40, int(b["大小"]["宽占屏%"] / 100 * w2 * 1.25))
                x = int(b["位置"]["中心X%"] / 100 * w2); y = int(b["位置"]["中心Y%"] / 100 * h2)
                crop = nat[max(0, y - hh // 2):min(h2, y + hh // 2), max(0, x - ww // 2):min(w2, x + ww // 2)]
                if crop.size:
                    ok, buf = cv2.imencode(".png", crop)
                    if not ok:
                        say("  [截图编码失败] %s" % b["编号"])
                    else:
                        (pd / ("%s.png" % b["编号"])).write_bytes(buf.tobytes())  # Windows 中文路径下 cv2.imwrite 会写坏文件名,必须走 imencode+bytes
                        b["截图"] = "%s.png" % b["编号"]
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
        mdp = Path(a.out).parent / "文字效果报告.md"
        mdp.write_text(make_md(out), encoding="utf-8")
        say("完成:%d 个文字块 / %d 套样式 → %s、%s" % (len(blocks), len(groups), a.out, mdp))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
