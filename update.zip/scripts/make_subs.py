# -*- coding: utf-8 -*-
"""字幕生成:转写.json(逐词时间戳) -> ASS(逐字点亮 + 数字/百分号放大换色) + SRT。全程本机、不联网。
定稿优先:给了 文案定稿.txt 就按定稿的字显示(错字以定稿为准),时间用整条字符流全局对齐反推。
用法: python make_subs.py 转写.json [--final 文案定稿.txt] [--style 对标风格.json]
        [--cuts 剪切点清单.json] [--out 字幕.ass] [--srt 字幕.srt] [--size 888x1920]
--cuts: 把时间换算到剪完之后的成片轴(近似,不含静音吸附;烧录由 render_cut.py 用精确映射)。"""
import argparse, difflib, json, re, sys
from pathlib import Path
import sys as _sys
_sys.stdout.reconfigure(encoding="utf-8", errors="replace")   # Windows 控制台默认 GBK,统一 UTF-8 供上层解码

KEEP = re.compile(r"[\u4e00-\u9fa5A-Za-z0-9%％]+")
BRK = "。！？!?…；;~"
BRK_ALL = "。！？!?…；;~,，、："          # 断行边界:标点处优先断开,不劈词组
# 断在这些字前面通常安全:它们是"另起一个短语"的字,不会把词劈开
FAKE = set("的了吗呢啊吧也都就在和与很更这那有个来过着把被让向对从以而但或到要会能没不又还最"
           "自己我们你们他们它其并且但是因为所以如果然后现在以后之前之后一样其实东西事情"
           "问题地方时间情况认为觉得知道看到听说是非不是")


def hex_to_ass(h):
    h = (h or "#FFFFFF").lstrip("#")
    return "&H%s%s%s" % (h[4:6], h[2:4], h[0:2])


def style_of(path, size):
    w, h = size or (1080, 1920)
    st = {"字号": int(round((0.055 if h > w else 0.062) * h)), "每行": 8,
          "下沿": 0.08 if w > h else 0.20,
          "字色": "#FFFFFF", "强调": "#FFD84D", "字体": "Noto Serif SC",   # 思源宋体(本机注册名)
          "描边": 0, "阴影": 0, "加粗": 1, "底条": 0, "画幅": size or (1080, 1920),
          # 字幕位置(2026-11-02 修订铁律 v2):一律下沿——横屏底边留8%(标题条在黑边区
          # 不遮画面底);竖屏底边留20%(竖屏底部约15%被标题栏/活动条遮,20%=遮挡+5%缓冲,
          # 字在遮挡区上方且不压脸)。正中只压人不压信息,退役。对标参数可覆盖。
          "垂直位置": "下沿"}
    geo_from = "本机默认"
    if path and Path(path).exists():
        s = (json.loads(Path(path).read_text(encoding="utf-8")).get("建议") or {})
        st["字色"] = s.get("字幕颜色") or st["字色"]
        st["强调"] = s.get("强调色") or st["强调"]
        same = (s.get("画幅") == ("竖屏" if h > w else "横屏"))
        if same:
            st["字号"] = int(s.get("字幕字号px") or st["字号"])
            st["每行"] = int(s.get("每行字数") or st["每行"])
            st["下沿"] = float(s.get("字幕下沿留白比例") or st["下沿"])
            st["垂直位置"] = s.get("字幕垂直位置") or st["垂直位置"]
            geo_from = "对标片" + ("(只借字号配色,位置按本片下沿规则)" if st["垂直位置"] == "下沿" else "(位置按对标)")
        else:
            # 画幅不同只借配色:字号/每行/边距按本片几何重算,否则横屏会沿用竖屏的"每行7字",切得稀碎
            st["每行"] = int(max(8, min(18, round(w * 0.92 / max(st["字号"], 1)))))
            st["下沿"] = 0.08 if w > h else 0.20
            geo_from = "对标片横竖与本片不符,字号/每行/边距按本片画幅重算"
    st["_geo"] = geo_from
    if not (path and Path(path).exists()):
        # 没有对标档也要按本片画幅算每行字数,否则横屏会沿用写死的 8 字,切得稀碎
        st["每行"] = int(max(6, min(18, round(w * 0.92 / max(st["字号"], 1)))))
    st["每行"] = max(4, min(18, st["每行"]))
    st["底条自动"] = 0
    if path and Path(path).exists():
        j = json.loads(Path(path).read_text(encoding="utf-8"))
        lum = (j.get("明暗") or {}).get("亮度均值")
        if lum is not None and lum >= 0.5 and not st.get("底条"):
            st["底条"] = 1; st["底条自动"] = 1        # 亮背景+无描边=白字看不见,只能上底条
    return st


def chars_of_words(words):
    """逐词 -> 逐字,词内按时长均分。返回 [(字, 起, 止)]。"""
    out = []
    for w in words:
        cs = "".join(KEEP.findall(w["t"]))
        if not cs: continue
        per = (w["e"] - w["s"]) / len(cs)
        for i, c in enumerate(cs):
            out.append((c, w["s"] + i * per, w["s"] + (i + 1) * per))
    return out


def words_of(data):
    out = []
    for si, seg in enumerate(data.get("segments", [])):
        ws = seg.get("words") or []
        for wi, w in enumerate(ws):
            t = (w.get("word") or "").strip()
            if t: out.append({"s": float(w["start"]), "e": float(w["end"]), "t": t,
                              "last": wi == len(ws) - 1})
        if not ws and (seg.get("text") or "").strip():
            out.append({"s": float(seg["start"]), "e": float(seg["end"]), "t": seg["text"].strip(), "last": True})
    return out


def sentences(text):
    """按标点/换行切成"语义块":一块=一句话或一个短语,后面成行时尽量一块一行。"""
    parts = []
    for line in text.splitlines():
        for chunk in re.split(r"[^\u4e00-\u9fa5A-Za-z0-9%％]+", line.replace(" ", "")):
            if chunk: parts.append(chunk)
    return parts


def _字(x):
    """块里的元素可能是纯字符(转写路径),也可能是 (字,起,止) 三元组(定稿路径),统一取字。"""
    return x[0] if isinstance(x, (tuple, list)) else x


def wrap_chunks(chunks, perline):
    """一块一行(一句一行)。确实超长才拆:拆点优先落在"另起短语"的字前面,
    找不到就退回中点;不足 4 字的尾巴并回上一行,避免闪一下。"""
    lines = []
    for c in chunks:
        while len(c) > perline:
            cut = -1
            for k in range(min(perline, len(c) - 1), max(3, perline - 5), -1):
                z = _字(c[k])
                if z in FAKE or not ("\u4e00" <= z <= "\u9fa5"):
                    cut = k; break
            if cut < 0: cut = (len(c) + 1) // 2
            lines.append(c[:cut]); c = c[cut:]
        if c and lines and len(c) < 4 and len(lines[-1]) + len(c) <= perline:
            lines[-1] = lines[-1] + c
        elif c:
            lines.append(c)
    return lines


def align_final(words, final_text, perline=14):
    """整条字符流对齐:定稿每个字 -> 转写里对应字的真实时间。返回 (逐字时间表, 覆盖率)。"""
    fins = sentences(final_text)
    if not fins: return None, 0.0
    fin_str = "".join(fins)
    raw = chars_of_words(words)
    raw_str = "".join(c[0] for c in raw)
    sm = difflib.SequenceMatcher(None, raw_str, fin_str, autojunk=False)
    ft = [None] * len(fin_str)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                ft[j1 + k] = (raw[i1 + k][1], raw[i1 + k][2])
    hit = sum(1 for x in ft if x)
    if hit < len(fin_str) * 0.45: return None, round(hit / max(len(fin_str), 1), 2)
    chunks, o = [], 0
    for sen in fins:
        seg = ft[o:o + len(sen)]; o += len(sen)
        # 没对上的字:在左右已知时间之间线性插值,保证整句连续不缺字
        known = [(i, t) for i, t in enumerate(seg) if t]
        if not known:
            continue
        filled = []
        for i in range(len(seg)):
            if seg[i]: filled.append(seg[i]); continue
            prev = next((x for x in reversed(known) if x[0] < i), None)
            nxt = next((x for x in known if x[0] > i), None)
            if prev and nxt:
                f = (i - prev[0]) / (nxt[0] - prev[0])
                s = prev[1][0] + (nxt[1][0] - prev[1][0]) * f
                e = prev[1][1] + (nxt[1][1] - prev[1][1]) * f
            elif prev: s, e = prev[1][0], prev[1][1]
            else: s, e = nxt[1][0], nxt[1][0] + (nxt[1][1] - nxt[1][0]) * 0.3
            filled.append((s, e))
        chunks.append([(ch, filled[i][0], filled[i][1]) for i, ch in enumerate(sen)])
    return wrap_chunks(chunks, perline), round(hit / len(fin_str), 2)


def lines_from_words(words, perline, maxdur=4.0):
    lines, cur = [], []
    for w in words:
        cs = chars_of_words([w])
        if not cs: continue
        if any(ch in BRK_ALL for ch in w["t"]) and len(cur) >= max(3, perline // 2):
            lines.append(cur); cur = []
        cur += cs
        if len(cur) >= perline or w["last"] or (cur[-1][2] - cur[0][1]) >= maxdur:
            lines.append(cur); cur = []
    if cur: lines.append(cur)
    return lines


def map_time(t, mapping):
    if not mapping: return t
    for (s0, e0, o0) in mapping:
        if s0 - 0.03 <= t <= e0: return o0 + max(0.0, t - s0)
        if e0 < t < s0: return None
    return None


def ass_head(st):
    W, H = st["画幅"]
    pri, acc = hex_to_ass(st["字色"]), hex_to_ass(st["强调"])
    fs = st["字号"]
    居中 = st.get("垂直位置", "正中") == "正中"
    # 居中=an8(垂直水平都取中线);贴底才用 an2 + 下沿留白
    an = 8 if 居中 else 2
    mv = H // 2 if 居中 else max(20, int(round(H * st["下沿"])))
    return ("[Script Info]\nScriptType: v4.00+\nPlayResX: %d\nPlayResY: %d\nWrapStyle: 2\n"
            "ScaledBorderAndZoom: yes\nYCbCr Matrix: TV.709\n\n[V4+ Styles]\n"
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
            "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
            "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
            "Style: 主体,%s,%d,%s,%s,&H00101010,&H%02X000000,%s,0,0,0,100,100,%d,0,%d,%d,%d,%d,%d,%d,%d,1\n\n"
            "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
            % (W, H, st["字体"], fs, pri, acc, int(st.get("底条", 0) and 0x50 or 0x80),
               "-1" if st.get("加粗", 1) else "0", max(1, round(fs * 0.03)),
               3 if st.get("底条") else 1,
               int(st.get("描边", 0)) or (max(8, round(fs * 0.16)) if st.get("底条") else 0),
               int(st.get("阴影", 0)),
               an, int(W * 0.05), int(W * 0.05), mv))


def tidy(lines):
    """行与行不许重叠(定稿插值偶尔会把两句的时间撞在一起,libass 会两层字叠着显示)。"""
    out, last_e = [], 0.0
    for ln in lines:
        shift = max(0.0, last_e - ln[0][1])
        nl = [(c, a + shift, max(b + shift, a + shift + 0.02)) for (c, a, b) in ln]
        if nl[-1][2] - nl[0][1] < 0.25: continue
        out.append(nl); last_e = nl[-1][2] + 0.02
    return out




def voiced_onsets(media, thresh=-40.0, min_sil=0.05):
    """用逐 ~13ms 的音频能量找"真正开口"的时刻与有声段(静音->有声的跳变)。
    零依赖(只要 ffmpeg),比 Whisper 的词级时间戳更接近物理事实。"""
    import subprocess
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(media), "-vn", "-af",
                        "aformat=channel_layouts=mono,asetnsamples=640,"
                        "astats=metadata=1:reset=1,"
                        "ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
                        "-f", "null", "-"], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    frames, t = [], None
    for line in (r.stdout or "").splitlines():
        m = re.search(r"pts_time:([\d.]+)", line)
        if m: t = float(m.group(1)); continue
        m = re.search(r"RMS_level=(-?[\d.]+|inf)", line)
        if m and t is not None:
            v = m.group(1)
            frames.append((t, -99.0 if v == "inf" else float(v)))
    spans, cur = [], None
    for t, v in frames:
        if v > thresh:
            if cur is None:
                cur = [t, t]; spans.append(cur)
            else:
                cur[1] = t
        else:
            cur = None                      # 静音一出现就闭合有声段,下次再响=新的开口
    spans = [(round(a, 3), round(b, 3)) for a, b in spans if b - a >= 0.06]   # 丢掉抖振噪声
    return sorted(set(a for a, b in spans)), spans


def snap_to_voice(lines, onsets, spans=None, back=0.90, fwd=0.15, to_voiced=0.50, gap=0.12):
    """只动"新开口的那一行"(与上一行结尾有 >=gap 秒间隔),句中换行一律不碰。
    - 出场时人已在说话:往回最多 back 秒贴到这句真正的起音(Whisper 常晚 0.3~0.7 秒)
    - 出场时人还没说话(落在静音里):往前最多 to_voiced 秒贴到下一个开口,避免字幕先响
    按顺序处理并夹住上一行的结尾,不会把后一行拽到前一行之前。"""
    if not onsets: return lines, 0
    spans = spans or []
    out, moved, prev_e = [], 0, 0.0
    for k, ln in enumerate(lines):
        s0, e0 = ln[0][1], ln[-1][2]
        t = s0
        head = (k == 0) or (s0 - lines[k - 1][-1][2] >= gap)
        if head:
            in_voiced = any(a <= s0 <= b for a, b in spans)
            if in_voiced:
                c = [o for o in onsets if s0 - back <= o <= s0 + fwd and o >= prev_e]
                if c:
                    best = min(c, key=lambda o: abs(o - s0))
                    if abs(best - s0) > 0.03: t = best
            else:
                c = [o for o in onsets if s0 <= o <= s0 + to_voiced and o >= prev_e]
                if c: t = min(c)
                else:
                    c2 = [o for o in onsets if s0 - back <= o < s0 and o >= prev_e]
                    if c2: t = max(c2)
            if abs(t - s0) > 0.03: moved += 1
        d = t - s0
        nl = [(ch, x + d, y + d) for (ch, x, y) in ln]
        prev_e = nl[-1][2] + 0.02
        out.append(nl)
    return out, moved


def map_sil(sil, mapping):
    """静音区间从原片轴换算到成片轴(被剪掉的截断,整段被删的丢掉)。"""
    if not sil or not mapping: return sil or []
    out = []
    for a, b in sil:
        x, y = map_time(a, mapping), map_time(b, mapping)
        if x is None and y is None: continue
        if x is None: x = y
        if y is None: y = x
        if y - x > 0.02: out.append((min(x, y), max(x, y)))
    return out


def snap_lines(lines, sil, hold=0.35, gap=0.25):
    """换气校正:出场落在真换气里就推到开口;比开口晚不到 0.2 秒就拉回开口;
    退场落在真换气里就收到闭嘴那一刻(最少留 hold 秒可读)。gap 内的微停顿不算。"""
    if not lines: return lines, 0
    big = [(a, b) for a, b in (sil or []) if b - a >= gap]
    if not big: return lines, 0
    onsets = sorted(b for a, b in big)
    outs = sorted(a for a, b in big)
    out, prev_e, moved = [], 0.0, 0
    for ln in lines:
        s0, e0 = ln[0][1], ln[-1][2]
        s = s0
        inside = [b for a, b in big if a <= s0 <= b]
        if inside:
            s = min(inside) - 0.02
        else:
            c = [o for o in onsets if 0 <= s0 - o <= 0.20]
            if c: s = max(c)
        s = max(s - 0.04, prev_e)
        e = e0
        tail = [a for a in outs if e0 <= a <= e0 + hold]
        if tail: e = min(tail) + 0.02
        e = max(e, s + 0.40, e0)
        k = (e - s) / max(e0 - s0, 0.01)
        nl = [(c2, s + (t - s0) * k, s + (u - s0) * k) for (c2, t, u) in ln]
        if abs(s - s0) > 0.08 or abs(e - e0) > 0.08: moved += 1
        out.append(nl); prev_e = e
    return out, moved


def ts(t):
    t = max(0.0, float(t)); h = int(t // 3600); m = int(t % 3600 // 60); x = t % 60
    return "%d:%02d:%02d.%02d" % (h, m, int(x), int(round((x % 1) * 100)))


def srt_ts(t):
    t = max(0.0, float(t)); h = int(t // 3600); m = int(t % 3600 // 60); x = t % 60
    return "%02d:%02d:%02d,%03d" % (h, m, int(x), int(round((x % 1) * 100)))


def render_ass(lines, st, mapping=None):
    r"""逐字 \k 点亮 + 数字/百分号放大换色;行尾不许压到下一行。"""
    lines = tidy(lines)
    pri, acc = hex_to_ass(st["字色"]), hex_to_ass(st["强调"])
    body, prev = [], 0.0
    _W, _H = st["画幅"]
    # 逐行钉死锚点:an8 + pos(画幅中心)。样式里也设了 an8,这里再写一次防某些渲染器只认行内标签
    anchor = ("{\\an8\\pos(%d,%d)}" % (_W // 2, _H // 2)
              if st.get("垂直位置", "正中") == "正中" else "{\\an2}")
    for idx, ln in enumerate(lines):
        nxt = None
        if idx + 1 < len(lines):
            nxt = map_time(lines[idx + 1][0][1], mapping)
            if nxt is None and not mapping: nxt = lines[idx + 1][0][1]
        s = map_time(ln[0][1], mapping); e = map_time(ln[-1][2] - 0.02, mapping)
        if s is None or e is None: continue
        e = max(e + 0.06, s + 0.4)
        if nxt is not None and e > nxt: e = max(s + 0.4, nxt)
        parts = []
        for (ch, a, b) in ln:
            cs = max(1, int(round((b - a) * 100)))
            if re.fullmatch(r"[\d%％]", ch):
                parts.append("{\\k%d\\c%s\\fscx118}%s{\\c%s\\fscx100}" % (cs, acc, ch, pri))
            else:
                parts.append("{\\k%d}%s" % (cs, ch))
        fade = anchor + "{\\fad(50,%d)}" % min(120, max(40, int((s - prev) * 1000)))
        prev = e
        body.append("Dialogue: 0,%s,%s,主体,,0,0,0,,%s%s" % (ts(s), ts(e), fade, "".join(parts)))
    return ass_head(st) + "\n".join(body) + "\n", len(body)


def render_srt(lines, mapping=None):
    lines = tidy(lines)
    out, i = [], 0
    for ln in lines:
        s = map_time(ln[0][1], mapping); e = map_time(ln[-1][2], mapping)
        if s is None or e is None: continue
        i += 1
        out += [str(i), "%s --> %s" % (srt_ts(s), srt_ts(e + 0.05)), "".join(x[0] for x in ln), ""]
    return "\n".join(out) + "\n"


def mapping_from_cuts(duration, cuts):
    dels = sorted([(float(c["开始"]), float(c["结束"])) for c in cuts if c.get("执行", "删") == "删"])
    keep, cur = [], 0.0
    for a, b in dels:
        if a - cur > 0.02: keep.append((cur, a))
        cur = max(cur, b)
    if duration and duration - cur > 0.02: keep.append((cur, duration))
    out, acc = [], 0.0
    for (a, b) in keep:
        out.append((a, b, acc)); acc += b - a
    return out


def keep_stream(words, mapping):
    """先丢掉被剪掉的词、把剩下的换算到成片轴,再和定稿对齐;
    否则定稿的字会绑到"被删掉的那一遍"上,导致字幕整段凭空消失。"""
    if not mapping: return words
    out = []
    for (s0, e0, o0) in mapping:
        for w in words:
            if w["e"] <= s0 or w["s"] >= e0: continue
            a = max(w["s"], s0); b = min(w["e"], e0)
            w2 = dict(w); w2["s"] = (a - s0) + o0; w2["e"] = (b - s0) + o0
            out.append(w2)
    out.sort(key=lambda x: x["s"])
    return out


def build(transcript, final=None, style=None, cuts=None, size=None, mapping=None, sil=None,
          over=None, media=None):
    """mapping: render_cut 传入的精确成片轴映射(含气口补齐);cuts: 命令行按清单近似换算。"""
    data = json.loads(Path(transcript).read_text(encoding="utf-8"))
    if not size and data.get("画幅"): size = tuple(data["画幅"])
    st = style_of(style, size or (1080, 1920))
    if over:
        for k, v in over.items():
            if v is None or v == "": continue
            st[k] = int(float(v)) if k in ("描边", "阴影", "底条", "加粗") else v
    words = words_of(data)
    mp = mapping
    if not mp and cuts and Path(cuts).exists():
        cj = json.loads(Path(cuts).read_text(encoding="utf-8"))
        mp = mapping_from_cuts(float(cj.get("duration") or data.get("duration") or 0), cj.get("cuts", []))
    if mp: words = keep_stream(words, mp)
    src = "转写原文"
    lines = None
    if final and Path(final).exists():
        got, rate = align_final(words, Path(final).read_text(encoding="utf-8"), st["每行"])
        if got:
            lines = got; src = "文案定稿(逐字对齐覆盖 %.0f%%)" % (rate * 100)
    if lines is None:
        lines = lines_from_words(words, st["每行"])
    moved = 0
    if sil:
        lines, moved = snap_lines(lines, map_sil(sil, mp))
    vo = 0
    if media and Path(media).exists():
        try:
            ons, spans = voiced_onsets(media)
            if mp:
                ons = sorted(x for x in (map_time(o, mp) for o in ons) if x is not None)
                spans = [(x, y) for x, y in ((map_time(a, mp), map_time(b, mp)) for a, b in spans)
                         if x is not None and y is not None and y > x]
            lines, vo = snap_to_voice(lines, ons, spans)
        except Exception as e:
            print("起音校正跳过:", e)
    st["贴开口"], st["贴起音"] = moved, vo
    lines = tidy(lines)          # 先统一去掉过短行,保证 ASS / SRT / 逐字时间轴 三份行数一致
    ass, n = render_ass(lines, st)
    srt = render_srt(lines, None)
    tl = timeline_json(lines, st, data.get("file", ""))
    return ass, srt, st, {"行数": n, "文字来源": src, "换算": "已按成片轴" if mp else "原片轴(未剪)"}, tl


def timeline_json(lines, st, src_media=""):
    """把已经贴准的行拆成 {行:[{字,起,止}]} 的 JSON,时间都在成片轴上。
    第④步做"逐字弹入/卡拉OK"直接按这个走,不用自己再猜时间。"""
    rows = []
    for ln in lines:
        if not ln: continue
        zi = [{"字": c, "起": round(t, 3), "止": round(u, 3)} for (c, t, u) in ln]
        rows.append({"起": round(ln[0][1], 3), "止": round(ln[-1][2], 3),
                     "文": "".join(c for c, _, _ in ln), "字": zi})
    W, H = st["画幅"]
    return json.dumps({
        "说明": "时间轴由本机 faster-whisper 词级时间戳 + 静音开口校正算出,已换算到粗剪成片轴;"
                "第④步做字幕动画请以此为准,不要再自行断句。字幕位置(2026-11-02修订v2):一律下沿——横屏底边留8%,"
                "竖屏底边留20%(竖屏底部约15%被抖音标题条遮,20%在遮挡区上方);做动效按本JSON的 垂直位置/下沿比例 走,别放画面正中压人物",
        "素材": src_media, "画幅": [W, H], "字体": st["字体"], "字号px": st["字号"],
        "每行字数": st["每行"], "垂直位置": st.get("垂直位置", "正中"), "下沿比例": st["下沿"],
        "字色": st["字色"], "强调色": st["强调"],
        "描边": st.get("描边", 0), "阴影": st.get("阴影", 0), "底条": st.get("底条", 0),
        "行数": len(rows), "行": rows}, ensure_ascii=False, indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("transcript"); ap.add_argument("--final"); ap.add_argument("--style")
    ap.add_argument("--cuts"); ap.add_argument("--out"); ap.add_argument("--srt"); ap.add_argument("--size")
    ap.add_argument("--font", default=None, help="字幕字体,默认 Noto Serif SC(思源宋体)")
    ap.add_argument("--outline", default=None, help="描边像素,默认 0(不加描边)")
    ap.add_argument("--shadow", default=None, help="阴影像素,默认 0(不加阴影)")
    ap.add_argument("--box", default=None, help="1=加半透明底条(代替描边保证亮背景可读),默认 0")
    ap.add_argument("--json", default=None, help="另存逐字时间轴 JSON(给第④步做字幕动画用)")
    a = ap.parse_args()
    if not Path(a.transcript).exists(): sys.exit("找不到转写: %s" % a.transcript)
    size = None
    if a.size and "x" in a.size.lower():
        w, h = a.size.lower().split("x"); size = (int(w), int(h))
    over = {"字体": a.font, "描边": a.outline, "阴影": a.shadow, "底条": a.box}
    ass, srt, st, info, tl = build(a.transcript, a.final, a.style, a.cuts, size, over=over)
    out = Path(a.out) if a.out else Path(a.transcript).with_name("字幕.ass")
    out.write_text(ass, encoding="utf-8")
    print("字幕: %s | %d 行 | 字号%dpx 每行≤%d字 位置%s 强调%s | 文字来源:%s" % (
        out, info["行数"], st["字号"], st["每行"], st.get("垂直位置", "正中"), st["强调"], info["文字来源"]))
    if a.srt:
        Path(a.srt).write_text(srt, encoding="utf-8"); print("  SRT: %s" % a.srt)
    if a.json:
        Path(a.json).write_text(tl, encoding="utf-8"); print("  逐字时间轴: %s (%d 行)" % (a.json, info["行数"]))


if __name__ == "__main__":
    main()
