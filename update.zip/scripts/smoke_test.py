# -*- coding: utf-8 -*-
"""引擎脚本真实调用自检。改过 scripts/*.py 或 工作台/workbench.py 后必须跑这个,
光 py_compile 过不算交付(语法过但函数被删/改名,只有真调用才暴露)。
用法: python scripts/smoke_test.py        # 全程用合成素材,不碰你的项目,约 3 分钟,含 OCR 项
退出码 0=全通过;非 0=有项失败,失败原因逐条打印。"""
import re
import io, json, numpy as np, os, re, shutil, subprocess, sys, tempfile, time
from http.server import ThreadingHTTPServer
from pathlib import Path

try:  # 控制台编码兜底:GBK 终端下打 ✓/中文不炸(G0 要在干净机器跑)
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent
WF = ROOT.parent
PY = sys.executable
结果 = []


def 记(名, ok, 说明=""):
    结果.append((名, bool(ok), 说明))
    print("  %s %-26s %s" % ("✓" if ok else "✗", 名, 说明))


def 跑(cmd):
    return subprocess.run([str(c) for c in cmd], capture_output=True, text=True,
                          encoding="utf-8", errors="replace")


def 合成素材(d, 秒=3):
    """彩色画面 + 100Hz 正弦音,当"能解码的合法视频"用,不依赖任何真实素材。"""
    v = d / "clip.mp4"
    r = 跑(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=25",
            "-f", "lavfi", "-i", "sine=frequency=100:sample_rate=44100", "-t", 秒,
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", v])
    return v if v.exists() and v.stat().st_size > 2000 else None


句列表 = ["测试第一句口播内容", "这里有个嗯停顿", "最后一句收尾",
           "剪辑这件事新手第一反应就是堆特效", "新手刚学剪辑第一反应往往是先堆一堆特效"]


def 合成转写(d):
    segs, t = [], 0.2
    for i, 句 in enumerate(句列表):
        ws = [{"word": c, "start": round(t + k * 0.18, 3), "end": round(t + (k + 1) * 0.18, 3),
               "p": 0.9} for k, c in enumerate(句)]
        segs.append({"start": round(t, 3), "end": round(t + len(句) * 0.18, 3), "text": 句, "words": ws})
        t += len(句) * 0.18 + 0.4
    f = d / "转写.json"
    f.write_text(json.dumps({"file": str(f), "language": "zh", "duration": round(t, 3),
                             "model": "smoke", "device": "cpu", "segments": segs},
                            ensure_ascii=False), encoding="utf-8")
    return f


def 合成对标(d):
    """造一条"有多个镜头"的合成对标片:彩色测试源 + 纯色底大字块 + 彩条 + 纯蓝底。
    够点位拆解分出几种类型,也能验证切点分段是否首尾相接。"""
    from PIL import Image, ImageDraw
    tmp = Path(d) / "_对标帧"; tmp.mkdir(exist_ok=True)
    png = tmp / "card.png"
    im = Image.new("RGB", (320, 240), (12, 12, 16)); g = ImageDraw.Draw(im)
    for row in range(4):
        for k in range(6):
            g.rectangle([20 + k * 48, 30 + row * 50, 20 + k * 48 + 36, 30 + row * 50 + 32], fill=(238, 238, 238))
    im.save(png)
    specs = [["-f", "lavfi", "-i", "testsrc=size=320x240:rate=25:duration=3"],
             ["-loop", "1", "-framerate", "25", "-i", str(png), "-t", "3"],
             ["-f", "lavfi", "-i", "smptebars=size=320x240:rate=25:duration=3"],
             ["-f", "lavfi", "-i", "color=c=0x1E90FF:s=320x240:r=25:d=3"]]
    segs = []
    for i, spec in enumerate(specs):
        out = tmp / ("s%d.mp4" % i)
        跑(["ffmpeg", "-y", "-v", "error"] + spec + ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-r", "25", str(out)])
        if out.exists(): segs.append(out)
    if len(segs) < 4: return None
    lst = tmp / "list.txt"
    lst.write_text("\n".join("file '%s'" % str(x).replace("\\", "/") for x in segs), encoding="utf-8")
    ref = Path(d) / "对标.mp4"
    跑(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(ref)])
    return ref if ref.exists() and ref.stat().st_size > 2000 else None


def main():
    T = Path(tempfile.mkdtemp(prefix="wb_smoke_"))
    try:
        print("引擎真实调用自检(合成素材,不碰项目目录)")
        # 1 函数完整性:曾经整块删函数只靠编译是查不出来的
        sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(WF / "工作台"))
        import make_subs as M
        需要 = ["hex_to_ass", "style_of", "chars_of_words", "words_of", "sentences", "wrap_chunks",
                "align_final", "lines_from_words", "map_time", "ass_head", "tidy", "voiced_onsets",
                "snap_to_voice", "map_sil", "snap_lines", "ts", "srt_ts", "render_ass", "render_srt",
                "mapping_from_cuts", "keep_stream", "timeline_json", "build"]
        缺 = [x for x in 需要 if not hasattr(M, x)]
        记("make_subs 函数完整", not 缺, "缺: " + "、".join(缺) if 缺 else "%d 个函数全在" % len(需要))
        import workbench as W
        缺2 = [x for x in ["meta_of", "start_job", "job_view", "queue_view", "cancel_job", "style_suggest",
                          "action_refstyle", "action_batch", "make_project", "script_check", "script_fix_trad",
                          "action_findcuts", "action_render", "action_handoff", "check_ui_help",
                   "action_refmap", "refmap_state", "refmap_save", "refmap_storyboard",
                   "ref_video_path", "load_engine", "run_doctor",
                          "action_textstyle", "textstyle_state", "voice_summary", "textplan_run",
                          "apply_update", "更新包准入"] if not hasattr(W, x)]
        记("workbench 函数完整", not 缺2, "缺: " + "、".join(缺2) if 缺2 else "接口齐全")
        记("界面说明自检", not W.check_ui_help(), W.check_ui_help()[0][:40] if W.check_ui_help() else "全部控件已挂说明")
        # 1a2 环境诊断(阶段0 G0 门面):必须真能跑、字段齐全、CLI 退出码与结果一致、接线齐全
        dr = W.run_doctor()
        if dr.get("error"): print("[诊断后端报错] " + dr["error"])
        zj = dr.get("检查") or []
        缺字 = [z.get("名", "?") for z in zj if not all(k in z for k in ("名", "必需", "状态", "实情", "修法"))]
        没修法 = [z.get("名", "?") for z in zj if z.get("状态") == "失败" and z.get("必需") and not z.get("修法")]
        状态怪 = [z.get("名", "?") for z in zj if z.get("状态") not in ("通过", "警告", "失败")]
        判 = ""
        if dr.get("error"): 判 = "诊断报错:" + str(dr["error"])[:40]
        elif not zj: 判 = "诊断返回空清单"
        elif 缺字: 判 = "缺字段:" + "、".join(缺字)
        elif 没修法: 判 = "必需项失败却没给修法:" + "、".join(没修法)
        elif 状态怪: 判 = "状态值非法:" + "、".join(状态怪)
        else: 判 = "%d 项全带现状和修法" % len(zj)
        记("环境诊断能真跑", bool(zj) and not 缺字 and not 没修法 and not 状态怪 and not dr.get("error"), 判)
        作者机 = (ROOT / 'gen_keys.py').exists() and (ROOT / 'build_installer.py').exists() and (ROOT / 'installer.iss').exists()
        if 作者机:
            import build_installer as BI
            件 = BI.组件清单()
            件全 = all(k in 件 for k in ("引擎", "Python", "依赖", "ffmpeg", "VC++", "模型", "启动器", "防闪窗", "激活", "剔卡与绑机"))
            记("安装包组件表齐全", 件全, "7 块组成都在表里" if 件全 else "缺块:" + str(list(件)))
            版对 = BI.PYVER.rsplit(".", 1)[0] == "%d.%d" % sys.version_info[:2]
            记("打包Python与本机同minor", 版对,
               "embed %s == 本机 %d.%d(pip预装轮子按本机ABI拉,不同minor会装出不兼容的包)" % (BI.PYVER, *sys.version_info[:2])
               if 版对 else "embed 是 %s 本机是 %d.%d——改 build_installer.PYVER 或换解释器" % (BI.PYVER, *sys.version_info[:2]))
            源BI = (ROOT / 'build_installer.py').read_text(encoding='utf-8-sig')
            包对 = (BI.ZIP.name == '点心工作台-发货包-v0.3.zip' and BI.ZIP.parent == BI.发货目录
                    and BI.发货目录.exists() and BI.必读源.exists()
                    and '自用不发货' in 源BI and '禁止发货' in 源BI)
            记('发货包唯一且带闸', 包对, '单一对外 zip+必读同来源+混入即停' if 包对 else '异常:' + str(BI.ZIP))
            try:
                import next_key as NK, csv as _c
                真台账, 真话术 = NK.台账文件, NK.话术文件
                假台账 = T / '台账-取码.csv'; 假话术 = T / '话术-取码.txt'
                rows = [r for r in _c.reader(open(WF / '卡密台账.csv', encoding='utf-8-sig')) if r and r[0].strip()]
                for r0 in rows[1:]:
                    r0[2] = ''
                with open(假台账, 'w', encoding='utf-8-sig', newline='') as f0:
                    _c.writer(f0).writerows(rows)
                假话术.write_text('卡密:DXXK-ZZZZ-ZZZZ-ZZZZ' + chr(10), encoding='utf-8')
                NK.台账文件, NK.话术文件 = 假台账, 假话术
                try:
                    NK.main()
                    一 = NK.码形.findall(假话术.read_text(encoding='utf-8'))[0]
                    NK.main()
                    文二 = 假话术.read_text(encoding='utf-8')
                    二 = NK.码形.findall(文二)[0]
                    回读 = [r0 for r0 in _c.reader(open(假台账, encoding='utf-8-sig')) if r0 and r0[0].strip()][1:]
                    占用 = sum(1 for r0 in 回读 if r0[2].startswith('待发'))
                    记('取码自动换下一张不重发', 一 != 二 and 文二.count(一) == 0 and 文二.count(二) == 1 and 占用 == 2,
                       '第一次 %s → 第二次 %s,台账预占 2 行,旧码已从话术里清走' % (一[-9:], 二[-9:]))
                finally:
                    NK.台账文件, NK.话术文件 = 真台账, 真话术
            except Exception as e:
                记('取码自动换下一张不重发', False, repr(e)[:76])
            台账 = WF / '卡密台账.csv'
            if 台账.exists():
                import csv as _csv
                rows = [x for x in _csv.reader(open(台账, encoding='utf-8-sig')) if x and x[0].strip()]
                歪 = [i + 1 for i, x in enumerate(rows) if len(x) != 6]
                粘 = [i + 1 for i, x in enumerate(rows[1:], 1) if any(str(y).startswith('DXXK') for y in x[1:])]
                记('卡密台账行行对齐', not 歪 and not 粘,
                   '%d 条码列数齐整无粘连' % (len(rows) - 1) if not 歪 and not 粘 else '列数不齐行' + str(歪) + ' 粘连行' + str(粘))
            rl = 跑([PY, ROOT / 'gen_keys.py', '--list'])
            三态 = ('已售' in (rl.stdout or '')) and ('待发未定' in (rl.stdout or '')) and ('未售' in (rl.stdout or ''))
            记('发卡器命令行可跑(--list 三态)', rl.returncode == 0 and 三态,
               (rl.stdout or '').strip().replace(chr(10), ' / ')[:76] if rl.returncode == 0 and 三态 else '退码 ' + str(rl.returncode) + ' ' + ((rl.stderr or rl.stdout or '').strip()[-70:]))
        else:
            记('安装包接线(作者机项)', True, '发货副本不含打包/发卡脚本,属正常跳过;作者机跑全量')

        import zipfile as _zf
        fb = W.feedback_pack(T / "fb.zip")
        单 = fb.get("文件", "")
        有单 = bool(fb.get("ok")) and _zf.is_zipfile(单)
        目 = _zf.ZipFile(单).namelist() if 有单 else []
        记("反馈单可解包含诊断与清单", 有单 and "环境诊断.json" in 目 and "项目清单.txt" in 目 and "授权状态.json" in 目, str(目)[:70])
        杂 = [n for n in 目 if n.endswith((".mp4", ".ass", ".srt")) or "字幕" in n or "分镜" in n]
        记("反馈单不带创作内容与媒体", not 杂, "混入:" + str(杂)[:60] if 杂 else "只含排障材料")
        源f = (WF / "工作台" / "workbench.py").read_text(encoding="utf-8")
        页f = (WF / "工作台" / "index.html").read_text(encoding="utf-8")
        漏f = [x for x in (("路由", '/api/feedback' in 源f), ("函数", "def feedback_pack" in 源f),
                          ("按钮", 'onclick="feedback(this)"' in 页f), ("说明字典", '"feedback":' in 页f)) if not x[1]]
        记("反馈单接线齐全", not 漏f, str(漏f) if 漏f else "路由/函数/按钮/说明 4 件都在")
        ico = WF / "工作台" / "app.ico"
        ib = ico.read_bytes() if ico.exists() else b""
        记("D2图标存在且为合法ico", ib[4:7] == b"\x01\x00\x08" or ib[:4] == b"\x00\x00\x01\x00" and len(ib) > 4000,
           "%d 字节" % len(ib))
        import export_trial as _ET
        记("图标随包分发", "工作台/app.ico" in _ET.清单(), "便携版/体验副本带图标")
        if 作者机:
            源i = (ROOT / "build_installer.py").read_text(encoding="utf-8-sig")
            页i = (WF / "工作台" / "index.html").read_text(encoding="utf-8")
            漏i = [x for x in (("快捷方式挂图", "IconLocation" in 源i), ("iss挂图", "app.ico" in (ROOT / "installer.iss").read_text(encoding="utf-8-sig")),
                              ("页面favicon", '/app.ico' in 页i), ("后端路由", "/app.ico" in 源d if False else "/app.ico" in (WF / "工作台" / "workbench.py").read_text(encoding="utf-8"))) if not x[1]]
            记("图标接线齐全", not 漏i, str(漏i) if 漏i else "快捷方式/iss/favicon/路由 4 件都在")
        else:
            记('图标接线齐全(作者机项)', True, '发货副本不含打包/发卡脚本,属正常跳过;作者机跑全量')

        if 作者机:
            壳 = (WF / "工作台" / "shell.py").read_text(encoding="utf-8")
            记("窗口壳三要素", "SetCurrentProcessExplicitAppUserModelID" in 壳 and "edgechromium" in 壳 and "browser_fallback" in 壳,
               "AUMID+WebView2+浏览器兜底 齐")
            源v = (ROOT / "build_installer.py").read_text(encoding="utf-8-sig")
            自v = (WF / "工作台" / "隐藏启动.vbs").read_bytes().decode("gbk")
            记("启动器Chrome优先", "Google" in 源v and "Chrome" in 源v and "Google" in 自v and "--app=" in 自v,
               "便携版与自用版都先找 Chrome")
            记("壳随包+启动器接壳", "shell.py" in (ROOT / "export_trial.py").read_text(encoding="utf-8")
               and "shellPy" in 源v and "shellPy" in 自v
               and "pywebview" in (WF / "requirements.txt").read_text(encoding="utf-8-sig"),
               "白名单/便携模板/自用vbs/requirements 四处都认壳")
            坏引号 = re.search(r'"{5,}', 自v) or re.search(r'"{5,}', 源v)
            记("启动器壳调用引号合法", not 坏引号,
               "sh.Run 命令行不得以连续双引号开头(CreateProcess 会把 exe 名解析成空串弹 80070002)")
        else:
            记('启动器Chrome优先(作者机项)', True, '发货副本不含打包/发卡脚本,属正常跳过;作者机跑全量')

        书 = (WF / "给AI看的改造说明书.md").read_text(encoding="utf-8-sig")
        书对 = all(x in 书 for x in ("smoke_test.py", "行数必须一致", "HELP", "静默降级", "画面正中"))
        记("AI改造说明书在且含铁律", 书对, "五关键点齐" if 书对 else "缺关键条目")
        import export_trial as ET
        记("说明书随包分发", "给AI看的改造说明书.md" in ET.清单(), "体验副本/便携版/安装包含它")
        启v = (WF / "工作台" / "隐藏启动.vbs").read_text(encoding="gbk")
        记("开发版启动器防闪窗", "pythonw" in 启v and "WB_LOG" in 启v,
           "pythonw 直起+日志重定向已接" if "pythonw" in 启v else "启动器还是老 cmd 路子")
        记("端口探测不生成进程", "netstat" not in 启v and "WinHttp" in 启v,
           "探测已改纯COM(Win11下netstat子进程会闪真窗)")
        记("开发版防闪窗补丁在位", "0x08000000" in (WF / "工作台" / "_runtime" / "sitecustomize.py").read_text(encoding="utf-8"),
           "_runtime 补丁存在")
        if 作者机:
            iss = (ROOT / "installer.iss").read_text(encoding="utf-8-sig")
            装对 = all(x in iss for x in ("便携启动.vbs", "ChineseSimplified", "uninstallexe", "点心工作台-安装程序"))
            记("安装脚本接线齐全", 装对, "载荷/中文包/卸载/正式命名 4 项都在" if 装对 else "iss 缺件")
        else:
            记('安装脚本接线齐全(作者机项)', True, '发货副本不含打包/发卡脚本,属正常跳过;作者机跑全量')

        try:
            import gen_keys as GK, random as _rnd
            样码 = GK.gen(3, _rnd.Random(2026))
        except ImportError:
            # 发货副本不含发卡脚本(2026-10-21 剔除)。改用 workbench 自己的校验位算 3 个合法样码,
            # 让客户机上的自检照样把激活链路跑一遍,而不是整段哑掉(静默降级是最贵的 bug)。
            样码 = []
            for 序 in range(3):
                体 = ''.join(W.卡密表[(序 * 7 + 位 * 3 + 1) % 32] for 位 in range(11))
                检 = W.卡密表[sum((位 + 1) * W.卡密表.index(c) for 位, c in enumerate(体)) % 32]
                x = 'DXXK' + 体 + 检
                样码.append('%s-%s-%s-%s' % (x[:4], x[4:8], x[8:12], x[12:16]))
            assert all(W.卡密校验(k) for k in 样码), '兜底样码校验位算错——与 workbench 实现不一致'
            print('[自检] 本机无 gen_keys,走兜底样码路径(发货副本上属正常)')
        改坏 = 样码[0][:-1] + ("A" if 样码[0][-1] != "A" else "B")
        记("卡密生成+校验位把关", all(W.卡密校验(k) for k in 样码) and not W.卡密校验(改坏)
           and not W.卡密校验("DXXK-AAAA-AAAA-AAB"), "3 码过验;末位改动与编造码被拒")  # 全A体的合法校验位恰是A,编造样本用B才必错
        旧授, 旧黑, 旧需 = W.授权文件, W.黑名单文件, W.需要激活
        try:
            W.授权文件 = T / "license.json"; W.黑名单文件 = T / "黑名单.txt"; W.需要激活 = lambda: True
            r1 = W.lic_bind(样码[0].lower().replace("-", ""), "qq:123")
            st1 = W.lic_status()
            记("激活落盘+界面只露打码", r1.get("ok") and st1.get("已激活") and "…" in st1.get("卡密", "")
               and 样码[0] not in json.dumps(st1, ensure_ascii=False), json.dumps(st1, ensure_ascii=False)[:70])
            (T / "黑名单.txt").write_text(样码[0] + "\n", encoding="utf-8")
            st2 = W.lic_status()
            记("黑名单吊销生效", st2.get("已吊销") is True and "吊销" in W.lic_bind(样码[0], "").get("error", ""),
               "吊销+拒重激活" if st2.get("已吊销") else "吊销没生效")
            r3 = W.lic_bind("DXXK-AAAA-AAAA-AAAP", "")
            记("编造卡密被拒", not r3.get("ok") and "卡密" in r3.get("error", ""), r3.get("error", "")[:36])
        finally:
            W.授权文件, W.黑名单文件, W.需要激活 = 旧授, 旧黑, 旧需
        # 1a2c2 卡密绑定机器指纹(2026-10-21 补:旧版把已激活目录整份拷走=免激活白送)
        旧fp = W.机器指纹
        try:
            W.授权文件 = T / 'license2.json'; W.黑名单文件 = T / '黑名单2.txt'; W.需要激活 = lambda: True
            W.机器指纹 = lambda: 'FP-A'
            rb = W.lic_bind(样码[1], 'qq:me')
            W.机器指纹 = lambda: 'FP-B'
            st3 = W.lic_status()
            判A = bool(rb.get('ok')) and not st3.get('已激活') and st3.get('换机') is True
            rb2 = W.lic_bind(样码[1], '')
            st4 = W.lic_status()
            记('卡密绑机+换机需重激活', 判A and bool(rb2.get('ok')) and st4.get('已激活') and not st4.get('换机'),
               'A机激活→B机判未激活→B重输同码改绑成功' if 判A and rb2.get('ok') else '指纹没参与校验:拷目录仍能白用')
        finally:
            W.机器指纹 = 旧fp
            W.授权文件, W.黑名单文件, W.需要激活 = 旧授, 旧黑, 旧需
        # 1a2d2 增量更新:更新包装对/备份旧文件/拦越界/拦假包(2026-10-21,免客户重下大包)
        import zipfile as _zp
        更根 = T / "up_root"; (更根 / "scripts").mkdir(parents=True)
        (更根 / "scripts" / "_demo.py").write_text("OLD", encoding="utf-8")
        (更根 / "更新源.txt").write_text("0.3\n", encoding="utf-8")
        好包 = io.BytesIO()
        with _zp.ZipFile(好包, "w") as z:
            z.writestr("补丁清单.json", json.dumps({"版本": "9.9", "日志": "自检项"}, ensure_ascii=False))
            z.writestr("scripts/_demo.py", "NEW"); z.writestr("更新源.txt", "9.9\nx\n自检项")
        成 = W.apply_update(好包.getvalue(), 根=更根)
        装对 = (成.get("ok") and 成.get("个数") == 2
                and (更根 / "scripts" / "_demo.py").read_text(encoding="utf-8") == "NEW"
                and "自检项" in (更根 / "更新源.txt").read_text(encoding="utf-8")
                and any((更根 / "备份").glob("更新前-*/scripts/_demo.py")))
        记("更新包装对+旧文件进备份", 装对, json.dumps(成, ensure_ascii=False)[:80])
        坏1 = io.BytesIO()
        with _zp.ZipFile(坏1, "w") as z:
            z.writestr("补丁清单.json", "{}"); z.writestr("../evil.txt", "x"); z.writestr("工作台/项目/p/项目.json", "{}")
        拒1 = W.apply_update(坏1.getvalue(), 根=T / "up_a")
        坏2 = io.BytesIO()
        with _zp.ZipFile(坏2, "w") as z:
            z.writestr("scripts/a.py", "x")
        拒2 = W.apply_update(坏2.getvalue(), 根=T / "up_b")
        拦对 = ("不能写" in 拒1.get("error", "") and not (T / "evil.txt").exists()
                and not (T / "up_a").exists() and "补丁清单" in 拒2.get("error", ""))
        记("更新包越界/假包被拦且零写入", 拦对, 拒1.get("error", "")[:40] + " | " + 拒2.get("error", "")[:40])
        准入对 = (W.更新包准入("../a") and W.更新包准入("E:/x") and W.更新包准入("scripts/x.txt")
                 and W.更新包准入("工作台/项目/p/项目.json") and W.更新包准入("随便.txt")
                 and not W.更新包准入("工作台/workbench.py") and not W.更新包准入("更新源.txt")
                 and not W.更新包准入("scripts/make_subs.py"))
        记("准入规则四态正确", bool(准入对), "越界/盘符/非py/项目区拦下,引擎路径放行" if 准入对 else "规则漂移")
        # 1a2d4 装更新后自动重启(2026-10-26:客户「重启」只是重开窗口,旧进程占着端口→永远弹一键更新)
        旧argv = sys.argv
        import subprocess as _SP
        旧P, 捕 = _SP.Popen, []
        class 假壳:
            pid = 4242
        try:
            sys.argv = ["workbench.py", "--no-browser"]
            再 = W.重启自身命令(exe="X:/pythonw.exe")
            再对 = (再[0] == "X:/pythonw.exe" and 再[1] == "-u"
                    and str(再[2]).replace("\\", "/").endswith("workbench.py") and "--no-browser" in 再)
            _SP.Popen = lambda *a, **k: (捕.append(list(a[0])), 假壳())[1]
            成, 因 = W.自动重启后()
        finally:
            _SP.Popen = 旧P
            sys.argv = 旧argv
        助 = 捕[0] if 捕 else []
        补对 = (成 and len(助) > 6 and 助[1] == "-c" and str(os.getpid()) in [str(x) for x in 助]
                and "taskkill" in 助[2] and "time.sleep" in 助[2]
                and 助[5].replace("\\", "/").endswith("工作台")
                and "workbench.py" in 助[4] and "启动日志.txt" in 助[6])
        源wb = io.open(str(W.ROOT / "workbench.py"), encoding="utf-8-sig").read()
        挂对 = 源wb.count('结["自动重启"] = 成') == 2 and 源wb.count("自动重启后()") >= 3
        记("装更新后自动重启", bool(再对 and 补对 and 挂对),
            "重启命令保参数、助手带taskkill与原目录、两条安装通道都挂上" if (再对 and 补对 and 挂对)
            else "命令=%r 助手=%r 接线=%r 原因=%s" % (再对, 补对, 挂对, str(因)[:60]))
        # 1a2d3 一键更新死循环防线(2026-10-23 CDN缓存新旧混搭):URL通道包不比本机新→拒装零写入;发布源第2行固定包名→可一键
        严包 = io.BytesIO()
        with _zp.ZipFile(严包, "w") as z:
            z.writestr("补丁清单.json", json.dumps({"版本": "0.0.1", "日志": "旧包"}, ensure_ascii=False))
            z.writestr("scripts/_demo.py", "STALE")
        严根 = T / "up_strict"; (严根 / "scripts").mkdir(parents=True)
        (严根 / "scripts" / "_demo.py").write_text("OLD", encoding="utf-8")
        严拒 = W.apply_update(严包.getvalue(), 根=严根, 严格升版=True)
        严对 = bool(严拒.get("error")) and (严根 / "scripts" / "_demo.py").read_text(encoding="utf-8") == "OLD"
        记("一键更新拒装不比分包零写入", 严对, str(严拒.get("error", ""))[:60])
        旧URL, 旧源 = W.UPDATE_CHECK_URL, W.更新源
        结9 = {}
        try:
            源tmp = T / "更新源固定名.txt"
            源tmp.write_text("9.9\nhttps://cdn.jsdelivr.net/gh/nblindianxin/dianxin-update@main/update-9.9.zip\n自检日志\n", encoding="utf-8")
            W.UPDATE_CHECK_URL = ""; W.更新源 = 源tmp
            结9 = W.update_check()
        finally:
            W.UPDATE_CHECK_URL, W.更新源 = 旧URL, 旧源
        线2对 = bool(结9.get("有更新")) and str(结9.get("地址", "")).endswith("/update-9.9.zip") and bool(结9.get("可一键"))
        记("发布源第2行固定包名可一键", 线2对, json.dumps(结9, ensure_ascii=False)[:80])
        if 作者机:
            import make_update as MU
            假旧 = {"scripts/a.py": "1", "scripts/b.py": "2", "scripts/gone.py": "3"}
            假新 = {"scripts/a.py": "1", "scripts/b.py": "9", "scripts/c.py": "8"}
            变假, 删假 = MU.对比清单(假旧, 假新)
            差对 = (变假 == ["scripts/b.py", "scripts/c.py"] and 删假 == ["scripts/gone.py"]
                    and MU.解析版本("0.10(abc)") > MU.解析版本("0.9"))
            记("造更新包算差异正确", 差对, "b改c增gone删;0.10>0.9" if 差对 else str((变假, 删假)))
            import export_trial as ETa
            记("造更新包工具不发货", "scripts/make_update.py" in ETa.自用不发货 and "scripts/make_update.py" not in ETa.清单(),
               "作者自用,客户副本里没有")
            import release as RL
            import inspect as _ins
            _推源 = _ins.getsource(RL.推GitHub)
            bump对 = (RL.下一版("0.7.3") == "0.7.4" and RL.下一版("1.2") == "1.2.1"
                       and RL.解析(RL.下一版("0.9.9")) > RL.解析("0.9.9")
                       and "scripts/release.py" in ETa.自用不发货 and "scripts/release.py" not in ETa.清单()
                       and "update-[0-9A-Za-z._-" in _推源 and "拒推" in _推源)
            记("发版 --auto 版本号自增与不发货", bump对,
               "0.7.3→0.7.4;1.2→1.2.1;0.9.9→0.9.10;release.py 不发货;推GitHub 认固定名包" if bump对 else "release.py 版本逻辑坏/混进发货/推GitHub 没带固定名包闸门")
            版对2 = MU.解析版本(MU.本机版本()) == W.版本解析(W.VERSION)
            记("更新源与VERSION版本一致", 版对2, "更新源首行与 workbench VERSION 对得上" if 版对2
               else "更新源=%r 本机=%r——发版两个号要同步" % (MU.读版本线()[0], W.VERSION))
            # 1a2b2 更新内容要同步到更新源(2026-10-26 用户要求:客户弹卡「更新内容」那段=发版时写的那句说明)
            mv = re.match(r"^(?P<ver>\d+(?:\.\d+)*)\(发版\s*\d{4}-\d{2}-\d{2},\s*(?P<note>.+)\)$", str(W.VERSION))
            if not mv:
                同对, 同情 = False, "VERSION 不是「0.7.8(发版 2026-10-26, 说明)」格式,没法跟更新源对账:%s" % str(W.VERSION)[:70]
            else:
                版线x, 志线x = MU.读版本线()
                首志 = next((x.strip() for x in 志线x.splitlines() if x.strip()), "")
                同对 = (版线x == mv.group("ver") and 首志 == "- %s: %s" % (mv.group("ver"), mv.group("note")))
                同情 = ("更新源首行=本机版本号,首条日志=「- 版本号: 发版那句说明」,客户弹卡与本机同一份更新内容" if 同对
                        else "更新源首行=%r 首条日志=%r VERSION=%r——发版必须把更新内容同步进更新源" % (版线x, 首志[:70], str(W.VERSION)[:70]))
            记("更新内容同步到更新源", 同对, 同情)
            记("仓库地址两处一致", W.UPDATE检查仓库 == MU.UPDATE检查仓库, W.UPDATE检查仓库 if W.UPDATE检查仓库 == MU.UPDATE检查仓库 else "workbench=%r make_update=%r——改仓库要同步两处" % (W.UPDATE检查仓库, MU.UPDATE检查仓库))
        真导 = [z for z in zj if z.get("名") == "转写引擎本体可跑"]
        记("诊断含引擎真导入项", len(真导) == 1 and 真导[0]["状态"] == "通过",
           真导[0]["实情"][:40] if 真导 else "报告里没这项——缺 VC++ 运行库就查不出来")
        # 1a2b ffmpeg 版本下限判定(G0 实测:6.0 跑不了交叉淡化,9.0.1 可;保守要求>=7)
        import doctor as DC
        判旧 = DC.ff版本过旧("ffmpeg version 6.0 Copyright (c)") and not DC.ff版本过旧("ffmpeg version 9.0.1-full_build") and not DC.ff版本过旧("ffmpeg version n7.1 abc")
        记("ffmpeg 版本下限判定", 判旧, "6.0 判旧、9.0.1 与 n7.1 放行" if 判旧 else "版本解析逻辑不对")
        # 1a2c 检查更新:版本按数字段比较 + 三态(未配置/有新版/已最新)
        vp = W.版本解析
        解析对 = (vp("0.2(2026-10-18,含挑素材窗)") == (0, 2) and vp("0.10") == (0, 10)
                 and vp("v1.2.3") == (1, 2, 3) and vp("") == ())
        比得对 = vp("0.10") > vp("0.9") and not (vp("0.2") > vp("0.2"))
        import tempfile as _tf
        # 1a2b1 开发机与客户机同走一条更新路(2026-10-26 用户改口:作者机不再短路,打开自动查+一键更新照常)
        os.environ["DIANXIN_AS_CUSTOMER"] = "1"
        try:
            可伪装 = not W.是开发者源()          # 设了 DIANXIN_AS_CUSTOMER:连「作者开发源」标记都不显示
        finally:
            os.environ.pop("DIANXIN_AS_CUSTOMER", None)
        旧URL开, 旧源开 = W.UPDATE_CHECK_URL, W.更新源
        try:
            源开 = T / "更新源开发机.txt"
            源开.write_text("9.9\nhttps://cdn.jsdelivr.net/gh/nblindianxin/dianxin-update@main/update-9.9.zip\n开发机也读更新内容\n",
                          encoding="utf-8")
            W.UPDATE_CHECK_URL = ""; W.更新源 = 源开
            结开 = W.update_check()
        finally:
            W.UPDATE_CHECK_URL, W.更新源 = 旧URL开, 旧源开
        该判 = (WF / "卡密台账.csv").exists() and (WF / "scripts" / "gen_keys.py").exists()
        同路 = (结开.get("状态") == "有新版可装" and bool(结开.get("有更新")) and bool(结开.get("可一键"))
                and "开发机也读更新内容" in 结开.get("日志", "")
                and 结开.get("本机身份") == ("作者开发源" if 该判 else "客户副本") and 可伪装 is True
                and ("作者开发源" in 结开.get("说明", "")) == bool(该判))
        记("开发机同走一键更新", 同路,
           "开发源不短路:照样「有新版可装/可一键」,身份只当标记;DIANXIN_AS_CUSTOMER=1 只关标记不关更新" if 同路
           else "身份=%r 伪装=%r 检查=%s" % (该判, 可伪装, json.dumps(结开, ensure_ascii=False)[:130]))
        旧源 = W.更新源
        旧检 = W.UPDATE_CHECK_URL
        W.UPDATE_CHECK_URL = ""
        try:
            with _tf.TemporaryDirectory() as td:
                源 = Path(td) / "更新源.txt"
                W.更新源 = 源
                r1 = W.update_check()
                源.write_text("9.9\nhttp://x\n修A\n修B", encoding="utf-8")
                r2 = W.update_check()
                源.write_text("0.0", encoding="utf-8")
                r3 = W.update_check()
                源.write_bytes("9.9\nhttp://g\n修复GBK编码更新日志".encode("gbk"))
                r4 = W.update_check()   # 记事本ANSI保存的更新源也要能读(实测踩坑)
        finally:
            W.更新源 = 旧源
            W.UPDATE_CHECK_URL = 旧检
        三态 = (r1.get("状态") == "未配置" and r2.get("有更新") and r2.get("最新") == "9.9"
                and r2.get("地址") == "http://x" and "修A" in r2.get("日志", "")
                and not r3.get("有更新") and r3.get("状态") == "已是最新"
                and r4.get("有更新") and "修复GBK" in r4.get("日志", ""))
        记("检查更新逻辑", 解析对 and 比得对 and 三态,
           "数字比较+三态全对" if (解析对 and 比得对 and 三态)
           else ("解析错 " if not 解析对 else "") + ("比较错 " if not 比得对 else "") + ("三态错" if not 三态 else ""))
        # 1a2e1 联网自动更新:可信源判定 + 远程检查优先本机 + 一键下载只走可信(2026-10-22)
        可信 = (W.可信更新地址("https://cdn.jsdelivr.net/gh/nblindianxin/dianxin-update@main/update.zip")
                and W.可信更新地址(W.UPDATE_CHECK_URL)
                and not W.可信更新地址("https://evil.example.com/x.zip")
                and not W.可信更新地址("http://cdn.jsdelivr.net/gh/nblindianxin/dianxin-update/update.zip"))
        记("可信源只认作者仓库https直链", 可信, "jsDelivr/GH 放行,别处与明文http 拦下" if 可信 else "判定漂移")
        import urllib.request as _ur
        _旧open = _ur.urlopen; _旧检2 = W.UPDATE_CHECK_URL; _旧apply = W.apply_update
        class _Resp:
            def __init__(s, b): s.b = b
            def __enter__(s): return s
            def __exit__(s, *a): return False
            def read(s, n=-1): return s.b
        def _fake(req, *a, **k):
            full = getattr(req, "full_url", "") or str(req)
            if "jsdelivr" in full:                 # 模拟 jsDelivr 被重置:应自动换下一个可信镜像
                raise OSError("模拟:jsDelivr 连接被重置")
            if full.endswith("update.txt"):
                return _Resp("9.9\nhttps://cdn.jsdelivr.net/gh/nblindianxin/dianxin-update@main/update.zip\n修X\n修Y".encode("utf-8"))
            return _Resp(b"NOTZIP")
        try:
            W.UPDATE_CHECK_URL = "https://cdn.jsdelivr.net/gh/nblindianxin/dianxin-update@main/update.txt"
            _ur.urlopen = _fake
            rd = W.update_check()
            远程对 = (rd.get("有更新") and rd.get("最新") == "9.9" and rd.get("可一键")
                     and rd.get("地址", "").endswith("update.zip") and "修X" in rd.get("日志", "")
                     and rd.get("地址", "").startswith("https://cdn.jsdelivr.net/"))
            calls = []
            W.apply_update = lambda 数据, 根=None, 严格升版=False: (calls.append(len(数据)) or {"ok": True, "个数": 0})
            ok1 = W.apply_update_from_url("https://cdn.jsdelivr.net/gh/nblindianxin/dianxin-update@main/update.zip")
            ok2 = W.apply_update_from_url("https://evil.example.com/x.zip")
            一键对 = ok1.get("ok") and ok2.get("error") and len(calls) == 1
        finally:
            _ur.urlopen = _旧open; W.UPDATE_CHECK_URL = _旧检2; W.apply_update = _旧apply
        记("远程检查+坏镜像自动回落可用镜像", 远程对, "jsDelivr 抛错→检查改走 GitHub raw;地址按发布源第2行给,镜像回落在下载环节兜底" if 远程对 else str(rd)[:120])
        记("一键下载只从可信源并交校验", 一键对, "可信→下载交apply_update,伪造源→拒且不下载" if 一键对 else str((ok1, ok2))[:90])
        # 1a2e 转写下载必须走国内镜像(G1实测:huggingface.co 直连不通,客户首转必卡)
        r = 跑([PY, "-c", "import sys, os; sys.path.insert(0, r'%s'); import transcribe; print(os.environ.get('HF_ENDPOINT', ''))" % str(ROOT)])
        记("转写下载走国内镜像", "hf-mirror" in (r.stdout or ""), (r.stdout or r.stderr).strip()[:60])
        # 1a2d 样例载入防"打包机路径污染"(G1实炸:转写file带着作者机E盘路径,客户机找不到素材)
        sp2 = W.action_sample()
        if sp2.get("ok"):
            _tj = json.loads((Path(sp2["dir"]) / "转写.json").read_text(encoding="utf-8"))
            _真 = bool(_tj.get("file")) and Path(_tj["file"]).exists()
            记("样例转写指向本机真文件", _真, "file=" + str(_tj.get("file", ""))[:70] if _真 else "file 指向不存在:" + str(_tj.get("file"))[:70])
            shutil.rmtree(sp2["dir"], ignore_errors=True)
        else:
            记("样例载入", False, "载入失败:" + str(sp2.get("error", ""))[:80])
        # 1a2e 切项目清残留(G1反馈:新建项目后上个项目的分镜/路径还挂着,顺手保存会污染新项目)
        页r = (WF / "工作台" / "index.html").read_text(encoding="utf-8")
        清残 = ('$("storyboard").value="";window._savedSB="";window._sbTpl="";get("/api/storyboard' in 页r
                and 'openProj(r.dir);$("media").value="";$("projname").value="";' in 页r)
        记("切项目清分镜与路径残留", 清残, "openProj先清分镜框,blankProj清路径与项目名" if 清残
           else "清空代码不在了(可能被改回),旧项目内容会残留到新项目")
        # 1a2e2 分镜框灰字占位:模板不再塞成可编辑文本,表头由后端保存时自动补
        灰提 = ('placeholder="灰字只是提示不是草稿纸' in 页r
                and 'if(d.help!==undefined)showSbHelp()' not in 页r
                and 'if(ls[i].trim())return true' in 页r
                and 'if(raw.indexOf("填写规则")>=0' in 页r)
        记("分镜框灰字占位+表头机器补已接线", 灰提,
           "①-B框空白只挂灰字提示,不再自动弹说明,写一行就算成形可自动存" if 灰提
           else "分镜框还在塞可编辑模板/仍自动弹窗/sbFormed还是老口径")
        清全 = ('if(d.sub)s1Sub(d.sub);else{' in 页r
                and '$("scriptDraft").value=d.draft!=null?d.draft:""' in 页r
                and 'else{$("media").value="";$("vid").removeAttribute("src")}' in 页r
                and 'if(!d.request){$("autoStat").textContent="";return}' in 页r
                and 'S.roughShown=0;try{$("autoTranStat").textContent=""' in 页r)
        记("切项目全区清残", 清全, "草稿/字幕页签/素材框/播放器/日志/自动状态六处全清" if 清全
           else "有区域切项目仍残留旧内容(G1用户反馈类bug)")
        # 1a2g 切走自动存草稿(G1需求:做一半切走要存,回来还在,再切走再存)
        import tempfile as _tf3
        with _tf3.TemporaryDirectory() as td3:
            e1 = W.script_save_draft(td3, "半截文案A")
            e2 = W.script_save_draft(td3, "接着改成B")
            st3, _w = W.load_state(Path(td3))
            存对 = e1.get("ok") and e2.get("ok") and st3.get("draft") == "接着改成B"
            记("草稿自动存读回", 存对, "每次切走都存住,读回最新草稿" if 存对 else str([e1, e2, st3.get("draft")])[:110])
        页存 = ('act:"draft",text:$("scriptDraft").value' in 页r and 'window._savedSB' in 页r and '存了="草稿"' in 页r)
        记("切走自动存已接线", 页存, "openProj比对基线后自动回传草稿/分镜" if 页存 else "前端自动存代码不在,切走会丢未存内容")
        自存 = ('autoSave("draft")' in 页r and 'clearTimeout(_asT[what])' in 页r
                and 'pagehide' in 页r and 'sendBeacon("/api/script"' in 页r
                and 'id="autoSaveTag"' in 页r)
        记("打字自动存+关页补存", 自存, "停手2秒防抖自动存,关页用beacon补最后一笔" if 自存 else "自动存接线缺失(G1需求被改回?)")
        # 1a2h 拖入接线:素材库/对标/主素材三张卡都认拖,拖歪了不许把页面顶掉(丢项目状态)
        拖接 = ('dragZone("s1b","asset"' in 页r and 'dragZone("s1c","ref"' in 页r
                and 'dragZone("projbar","media"' in 页r
                and 'document.addEventListener("drop",function(e){if(e.dataTransfer' in 页r)
        记("拖入接线三卡片+防顶页", 拖接, "素材库/对标/主素材卡都能接拖,落卡片外只拦截不导航" if 拖接 else "拖入接线缺失:某卡接不了拖,或拖歪会顶掉整页丢状态")
        rc = 跑([PY, ROOT / "doctor.py", "--json"])
        try:
            dj = json.loads(rc.stdout or "")
        except Exception as e:
            dj = {}
            print("[诊断CLI输出不是JSON] %r 原文:%s" % (e, (rc.stdout or "")[:80]))
        记("doctor命令行退出码一致", rc.returncode in (0, 1) and bool(dj.get("检查")) and
            (rc.returncode == 0) == bool(dj.get("必需项全过")),
            "exit=%s 必需项全过=%s" % (rc.returncode, dj.get("必需项全过")))
        源d = (WF / "工作台" / "workbench.py").read_text(encoding="utf-8")
        页d = (WF / "工作台" / "index.html").read_text(encoding="utf-8")
        挂 = {"路由": "/api/doctor" in 源d, "后端函数": "def run_doctor" in 源d,
             "按钮": 'onclick="envDoctor()"' in 页d, "说明字典": '"envDoctor":' in 页d}
        漏 = "、".join(k for k, v in 挂.items() if not v)
        记("诊断接线齐全", not 漏, 漏 or "路由/函数/按钮/说明 4 件都在")
        记("撒彩库可被页面加载", "/confetti.min.js" in 源d and (WF / "工作台" / "confetti.min.js").exists(),
            "路由与文件都在" if ("/confetti.min.js" in 源d and (WF / "工作台" / "confetti.min.js").exists()) else "缺静态路由或库文件")
        # A 档防回归:原子写/收尸/版本/运行日志/前端接线(商业化计划阶段0 交付物)
        rc_src = (ROOT / "render_cut.py").read_text(encoding="utf-8")
        yuan_ok = ".part" in rc_src and "os.replace" in rc_src and "验尸" in rc_src and "(dur > 0)" in rc_src
        记("粗剪原子写", yuan_ok, "先落 .part,验时长后才改名成正片" if yuan_ok else "渲染还在直写最终文件名(会被中断留半截)")
        sf = WF / "工作台" / "任务状态.json"
        sf.write_text(json.dumps({"pid": 9999999, "项目": "不存在项目", "步": "测试", "名": "ffmpeg.exe"},
                                 ensure_ascii=False), encoding="utf-8")
        _probe = W.server_running
        W.server_running = lambda: False
        zhong = list(W.reap_interrupted())
        W.server_running = _probe
        W.INTERRUPTED.clear()
        记("中断任务收尸", bool(zhong) and not sf.exists(),
            "假记录被清掉并上报:" + str(zhong) if zhong else "收尸函数没干活")
        sf.write_text(chr(123) + chr(34) + "pid" + chr(34) + ":" + chr(34) + "乱码" + chr(34) + "," + chr(34) + "项目" + chr(34) + ":" + chr(34) + "垃圾记录" + chr(34) + "," + chr(34) + "步" + chr(34) + ":" + chr(34) + "x" + chr(34) + "," + chr(34) + "名" + chr(34) + ":" + chr(34) + "ffmpeg.exe" + chr(34) + chr(125), encoding="utf-8")
        _probe = W.server_running
        W.server_running = lambda: False
        try:
            bad = list(W.reap_interrupted()); 崩 = ""
        except Exception as ex:
            bad = []; 崩 = repr(ex)
        W.server_running = _probe
        W.INTERRUPTED.clear()
        记("状态文件乱码不挡启动", not 崩 and bool(bad) and not sf.exists(), 崩 or "坏记录照样上报中断,启动不被卡死")
        sf.write_text(json.dumps({"pid": 9999999, "项目": "活体保护", "步": "测试", "名": "ffmpeg.exe"}, ensure_ascii=False), encoding="utf-8")
        _probe = W.server_running
        W.server_running = lambda: True
        护 = list(W.reap_interrupted())
        W.server_running = _probe
        存 = sf.exists()
        W.INTERRUPTED.clear()
        if 存: sf.unlink(missing_ok=True)
        记("活实例记录不被误收", (not 护) and 存, "另一实例在场时直接跳过,记录原样保留" if (not 护) and 存 else "误动了别的实例的记录")
        W.slog("自检", "", "smoke 写了一条")
        lf = WF / "工作台" / "运行日志.jsonl"
        last = lf.read_text(encoding="utf-8").splitlines()[-1] if lf.exists() else ""
        try:
            dong = json.loads(last).get("动作") if last else ""
        except Exception as e:
            dong = ""
            print("[日志行解析失败] %r 原文:%s" % (e, last[:60]))
        记("运行日志落盘", dong == "自检", "JSONL 一条可读" if dong == "自检" else "日志没写对(末行动作=" + str(dong) + ")")
        qv = W.queue_view()
        记("版本随队列接口下发", qv.get("版本") == W.VERSION, "queue_view 带版本:" + str(qv.get("版本")))
        qian_ok = (chr(34) + "verTag" + chr(34)) in 页d and "上次中断" in 页d and (chr(34) + "closeOvl" + chr(34) + ":") in 页d and "id=\"ovl\"" in 页d
        记("版本/中断/弹层前端接线", qian_ok, "verTag/上次中断/closeOvl说明/弹层DOM 全在" if qian_ok else "缺件:" + "、".join(x for x, hit in (("verTag",(chr(34)+"verTag"+chr(34)) in 页d),("上次中断","上次中断" in 页d),("closeOvl",(chr(34)+"closeOvl"+chr(34)+":") in 页d),("弹层DOM","id=\"ovl\"" in 页d)) if not hit))
        # 1a6 B1/B2:发货文案去 Codex;样例项目一键载入
        import export_trial as PT
        干净 = "Codex" not in 源d and "Codex" not in 页d
        记("发货文案已去Codex", 干净, "工作台与页面文案已无 Codex 字样" if 干净 else "仍有 Codex 残留(陌生人没 Codex,会卡死)")
        PT.make_sample(WF / "工作台" / "Getting_Started" / "sample")
        旧P = W.PROJ_ROOT
        W.PROJ_ROOT = T / "样例项目根"
        try:
            sp = W.action_sample()
        finally:
            W.PROJ_ROOT = 旧P
        sd = Path(sp.get("dir", "/非/非/"))
        记("样例项目可载入", bool(sp.get("ok")) and (sd / "转写.json").exists() and (sd / "样片.mp4").exists() and "提示" in sp,
            "样片+转写+项目纸条齐,附玩法提示" if sp.get("ok") else "载入失败:" + str(sp.get("error", ""))[:60])
        dx段 = 页d[页d.find(chr(28857)+chr(24515)+chr(24320)+chr(22330)+chr(29305)+chr(25928)):] if (chr(28857)+chr(24515)+chr(24320)+chr(22330)+chr(29305)+chr(25928)) in 页d else ""
        dx_ok = bool(dx段) and ("dx-splash" in 页d) and ("wbSkin" in dx段) and ("intro=1" in dx段)
        记("开场特效已挂载", dx_ok, "三条件闸门在:开新窗口必演/F5不演/皮肤或intro永远演" if dx_ok else "缺闸门/类名,页d里找不到点心开场特效段")
        # 1a3 体验副本打包(G0 用):清单必须无垃圾、关键文件齐(纯列表,不真复制)
        import export_trial as PT
        名d = PT.清单()
        脏 = [x for x in 名d if (x.endswith((".pyc", ".mp4", ".mp3", ".jpg", ".jpeg", ".png", ".wav")) and not x.startswith("工作台/app_"))
              or x.startswith(("项目/", "备份/", "checkpoints/", "体验副本/")) or "__pycache__" in x]
        该有 = [x for x in ("Getting_Started.md", "requirements.txt", "LICENSE-NOTES.txt", "更新源.txt",
                      "scripts/transcribe.py", "scripts/doctor.py", "工作台/workbench.py",
                      "工作台/index.html", "工作台/隐藏启动.vbs", "工作台/confetti.min.js") if x not in 名d]
        记("体验副本清单干净齐全", bool(名d) and not 脏 and not 该有,
            ("混进:" + "、".join(脏) if 脏 else "") + (" 缺:" + "、".join(该有) if 该有 else "") or
            "%d 个文件,无垃圾无缺项" % len(名d))
                # 1a3b 发货副本必须剔除作者自用脚本(gen_keys 打进包 = 客户双击就能自造卡密)
        自用 = list(getattr(PT, '自用不发货', []))
        混入 = [x for x in 名d if x in 自用]
        记('发货副本剔发卡脚本', bool(自用) and not 混入,
           ('混入:' + '、'.join(混入)) if 混入 else ('清单已排除 ' + '、'.join(自用) + ';作者机专属项另判'))
        假条目 = [x for x in 自用 if not (WF / x).exists()]
        记('自用不发货逐条是真文件', bool(自用) and not 假条目,
           ('拼错或粘连:' + '、'.join(假条目)) if 假条目 else '%d 条都能对上真实文件(防列表里两个字符串粘连成一个)' % len(自用))
        载荷 = WF / '发布' / '点心工作台便携版'
        if 载荷.exists():
            残 = [x for x in 自用 if (载荷 / x).exists()]
            记('便携版载荷无发卡脚本', not 残, '残留:' + '、'.join(残) if 残 else '载荷目录逐文件核对通过')
        else:
            记('便携版载荷无发卡脚本', True, '载荷目录尚未生成,本次不判(打包后重跑自检)')
# 1a4 requirements.txt 编码防护(G0 实炸:中文 Windows 的 pip 按系统 GBK 读该文件,
        # UTF-8 中文注释没带 BOM 会直接 UnicodeDecodeError,客户照 README 装依赖装不上)
        rq = (WF / "requirements.txt").read_bytes()
        rqt = rq.decode("utf-8-sig")
        记("requirements 带BOM(中文pip可活)", rq.startswith(b"\xef\xbb\xbf"),
           "UTF-8 with BOM" if rq.startswith(b"\xef\xbb\xbf") else "无BOM!中文Windows pip 按 GBK 读会崩")
        # 1a4b av 必须钉上界(G1实炸:av19 删了 metadata_errors 参数,faster-whisper1.2.1 转写当场崩)
        记("requirements钉住av上界", "av" in rqt.lower() and "<19" in rqt,
           "av<19 已钉" if ("av" in rqt.lower() and "<19" in rqt) else "av 未钉上界,新机 pip 会装到不兼容版本")
        # 页面 JS 语法自检:index.html 任何一个字符串断在行中,整页脚本就瘫(真出过事:HELP 里 presetSel 的内层引号)
        import re as _re
        页 = WF / "工作台" / "index.html"
        块 = _re.findall(r"<script[^>]*>(.*?)</script>", 页.read_text(encoding="utf-8"), _re.S) if 页.exists() else []
        n = shutil.which("node")
        if n:
            jsf = T / "页面脚本.js"; jsf.write_text("\n;\n".join(块), encoding="utf-8")
            r = 跑([n, "--check", jsf])
            记("页面脚本语法合法", r.returncode == 0, ((r.stderr or "").strip().replace("\n", " ")[:70]) if r.returncode else "node --check 全过")
        else:
            记("页面脚本语法合法", False, "这台机器没装 node,校验不了页面 JS:装完再交付")

        # 1b 撤回重置:冲突分支(同名文件已在项目里)曾少一个括号直接抛 TypeError,前端只显示"网络请求失败"
        项 = T / "自检项目"; 项.mkdir()
        (项 / "分镜.csv").write_text("v1\n", encoding="utf-8")
        rr = W.action_reset(str(项), "storyboard")
        (项 / "分镜.csv").write_text("v2\n", encoding="utf-8")   # 模拟重置后又干了活,制造同名冲突
        try:
            ru = W.action_undo_reset(str(项)); 崩 = ""
        except Exception as ex:
            ru = {}; 崩 = type(ex).__name__ + ": " + str(ex)   # 兜底必须把原因交给自检看见,不许静默
        cf = 项 / ".trash"
        cfs = [d for d in cf.iterdir() if d.is_dir() and d.name.startswith("conflict-")] if cf.exists() else []
        现在 = (项 / "分镜.csv").read_text(encoding="utf-8").strip() if (项 / "分镜.csv").exists() else ""
        旧版 = (cfs[0] / "分镜.csv").read_text(encoding="utf-8").strip() if cfs else ""
        记("撤回重置冲突分支", bool(rr.get("ok")) and bool(ru.get("ok")) and 现在 == "v1" and 旧版 == "v2",
           崩 or ("旧件进 conflict-,新件不被吞" if 现在 == "v1" and 旧版 == "v2"
               else "恢复=%s 冲突留=%s err=%s" % (现在, 旧版, ru.get("error", ""))))

        # 1t 流式日志:任务"运行中"就必须能看见引擎的中间输出(修「点粗剪没反应」的病根——
        #     旧版 communicate 等进程结束才一次性吐,渲染全程日志空白)
        P3 = T / "流式项目"; P3.mkdir()
        W.start_job(str(P3), [[PY, "-u", "-c", "print('LINE1')\nimport time\ntime.sleep(1.5)\nprint('LINE2')"]], label="流式自检")
        中途见 = False; 终态 = "无记录"; 观察 = []
        for _ in range(120):
            time.sleep(0.25)
            vv = W.job_view(str(P3))
            # 必须去掉 "$ 命令回显"行:命令行原文里就含 LINE1/LINE2 字样,连着它会第一轮就误判"两行都见"
            lg = "\n".join(x for x in vv.get("log", []) if not x.startswith("$ "))
            观察.append((vv["status"], "1" if "LINE1" in lg else "0", "2" if "LINE2" in lg else "0"))
            if vv["status"] == "运行中" and "LINE1" in lg and "LINE2" not in lg:
                中途见 = True
            if vv["status"] not in ("运行中", "排队中"):
                终态 = vv["status"]; break
        记("运行中日志即时可见", 中途见 and 终态 == "完成",
           "引擎边跑边报:LINE1 在进程结束前已进日志,结束后状态=完成" if (中途见 and 终态 == "完成")
           else "中途可见=%s 终态=%s 逐轮(状态,有无LINE1/LINE2)=%s" % (中途见, 终态, 观察[:24]))

        # 2 find_cuts 真跑
        tj = 合成转写(T)
        r = 跑([PY, ROOT / "find_cuts.py", tj, "--out", T / "剪切点", "--pause", "0.5"])
        cj = T / "剪切点.剪切点.json"
        记("find_cuts 真跑", r.returncode == 0 and cj.exists(),
            ("产出 %d 条候选" % len(json.loads(cj.read_text(encoding="utf-8")).get("cuts", [])))
            if cj.exists() else (r.stderr or r.stdout)[-90:])
        _cuts = json.loads(cj.read_text(encoding="utf-8")).get("cuts", []) if cj.exists() else []
        重 = [c for c in _cuts if c.get("类型") == "疑似重录"]
        记("疑似重录检测", len(重) == 2 and all("评分" in c.get("理由", "") for c in 重),
           "成对2条+评分建议,执行=保留" if len(重) == 2 else "得 %d 条(应为2)" % len(重))
        记("重录建议指向高分遍", (not 重) or (sum("建议留本遍" in c["理由"] for c in 重) == 1),
           "两条里恰一条建议留" if 重 else "跳过")

        # 2b 删前保后规则真跑(合成一段"句末呼吸 + 起音重来 + 停顿重说"的口播)
        #     事故依据:C0584 成片 25.5s/27s 卡顿——旧拖音规则把句末呼吸整删、把起音只裁半截字
        segs2 = []
        def 句(词们):
            ws = [{"word": a, "start": b, "end": c, "p": d} for a, b, c, d in 词们]
            return {"start": ws[0]["start"], "end": ws[-1]["end"],
                    "text": "".join(x["word"] for x in ws), "words": ws}
        segs2.append(句([("这",0.0,0.3,0.9),("句",0.3,0.6,0.9),("话",0.6,0.9,0.9),("收",0.9,1.2,0.9),
                        ("尾",1.2,1.5,0.9),("拖",1.5,1.8,0.9),("一",1.8,2.1,0.9),("下",2.1,2.4,0.9),
                        ("啊",2.4,3.6,0.55)]))                       # 句末 1.2s 长音=呼吸,不该动刀
        segs2.append(句([("跟",4.0,4.24,0.96),("勒",4.24,5.30,0.71),("是",5.30,5.5,0.9),("一",5.5,5.7,0.9),
                        ("个",5.7,5.9,0.9),("完",5.9,6.1,0.9),("整",6.1,6.3,0.9),("句",6.3,6.5,0.9)]))  # 起音重来
        segs2.append(句([("我",7.0,7.2,0.9),("我",7.35,7.55,0.9),("说",7.55,7.75,0.9)]))            # 中间有停顿的重说
        segs2.append(句([("中",9.0,9.2,0.9),("间",9.2,9.4,0.9),("重",9.4,10.9,0.88),("读",10.9,11.1,0.9),
                        ("的",11.1,11.3,0.9),("字",11.3,11.5,0.9)]))                               # 高置信长字=故意重读
        t2 = T / "重说转写.json"
        t2.write_text(json.dumps({"file": str(t2), "language": "zh", "duration": 12.0,
                                  "model": "smoke", "device": "cpu", "segments": segs2},
                                 ensure_ascii=False), encoding="utf-8")
        r = 跑([PY, ROOT / "find_cuts.py", t2, "--out", T / "重说", "--pause", "1.0", "--keepsil", "0.45"])
        cj2 = T / "重说.剪切点.json"
        刀 = json.loads(cj2.read_text(encoding="utf-8")).get("cuts", []) if cj2.exists() else []
        删 = [c for c in 刀 if c.get("执行") == "删"]
        if r.returncode != 0 or not cj2.exists():
            记("删前保后规则", False, (r.stderr or r.stdout)[-120:])
        else:
            盖住 = [c for c in 刀 if c["开始"] < 3.6 and c["结束"] > 2.4]
            保留标记 = [c for c in 盖住 if c["执行"] == "保留"]
            没啃呼吸 = not any(c["开始"] < 3.6 and c["结束"] > 2.4 for c in 删)
            起 = [c for c in 删 if c["类型"] == "起音重说"]
            起对 = bool(起) and abs(起[0]["开始"] - 4.0) < 0.005 and abs(起[0]["结束"] - 5.30) < 0.005 and 起[0]["文字"] == "跟勒"
            后遍在 = not any(c["开始"] < 6.5 and c["结束"] > 5.30 for c in 删)      # 后一遍正文不许被啃
            旧拖音 = [c for c in 刀 if c["类型"] == "拖音"]
            重 = [c for c in 删 if c["类型"] == "重复"]
            重对 = bool(重) and abs(重[0]["开始"] - 7.0) < 0.005 and abs(重[0]["结束"] - 7.2) < 0.005
            记("句末呼吸不啃(尾音)", bool(保留标记) and 没啃呼吸 and not 旧拖音,
               "句末长音只标记保留,无删刀覆盖,拖音类型已退役" if (保留标记 and 没啃呼吸 and not 旧拖音)
               else "保留行=%d 没啃=%s 残留拖音=%d" % (len(保留标记), 没啃呼吸, len(旧拖音)))
            记("起音重说删前保后", 起对 and 后遍在,
               "整字组 4.00→5.30 刀口在字边界,后一遍完整保留" if (起对 and 后遍在)
               else "起=%s 后遍在=%s" % (起[:1], 后遍在))
            啃重读 = [c for c in 删 if c["开始"] < 10.9 and c["结束"] > 9.4]
            记("高置信长字=重读不啃", not 啃重读,
               "置信88%%的1.5s长字只标记保留,没被动刀" % () if not 啃重读 else "被删:%s" % (啃重读[:1],))
            记("重说带停顿删前一遍", 重对,
               "删前一遍 7.00→7.20,留带出完整句的后一遍" if 重对 else "重复刀=%s" % (重[:1],))

        # 2b-t 紧节奏档=仿剪映智能剪口播:停顿≥阈值整段剪秃、一条呼吸不留(2026-10-19 改规则)
        #     关键点:即便 --keepsil 传了旧值 0.45,tight 档也必须无视它——防御界面上残留的手填数
        r = 跑([PY, ROOT / "find_cuts.py", t2, "--out", T / "紧节奏", "--sense", "tight",
                "--pause", "0.3", "--keepsil", "0.45"])
        cjT = T / "紧节奏.剪切点.json"
        刀T = json.loads(cjT.read_text(encoding="utf-8")).get("cuts", []) if cjT.exists() else []
        停T = [c for c in 刀T if c["类型"] == "停顿" and c["执行"] == "删"]
        秃 = [c for c in 停T if abs(c["开始"] - 6.5) < 0.01 and abs(c["结束"] - 7.0) < 0.01]   # 6.5→7.0 的 0.5s 静默必须整段删净
        秃对 = bool(秃) and abs(秃[0]["时长"] - 0.5) < 0.01 and "剪秃" in 秃[0]["理由"]
        不啃收束 = not any(c["开始"] < 3.6 and c["结束"] > 2.4 for c in 停T)                  # 句末 1.2s 长音不是静默,刀不许伸进去
        记("紧节奏=卡顿整段剪秃", r.returncode == 0 and cjT.exists() and 秃对 and 不啃收束,
           "0.5s 静默 6.50→7.00 整段删净,keepsil 旧值被无视,句末呼吸未啃" if (秃对 and 不啃收束)
           else "停顿刀=%s" % (停T[:2],))

        # 2c 重跑找点必须保住手动补剪点(用户顺序是"先找点 -> 补点 -> 可能再重跑")
        P2 = T / "手动点测试"; P2.mkdir()
        shutil.copy(str(tj), str(P2 / "转写.json"))
        W.action_findcuts(P2, {"pause": 0.5, "keepsil": 0.45})
        cf = P2 / "剪切点清单.json"
        底 = json.loads(cf.read_text(encoding="utf-8"))
        底.setdefault("cuts", []).append({"类型": "手动补剪", "开始": 1.111, "结束": 1.777,
                                        "时长": 0.666, "文字": "预览时发现需裁剪(刀口已按句子边界吸附)",
                                        "理由": "手动", "执行": "删"})
        cf.write_text(json.dumps(底, ensure_ascii=False), encoding="utf-8")
        r2 = W.action_findcuts(P2, {"pause": 0.5, "keepsil": 0.45})
        后 = json.loads(cf.read_text(encoding="utf-8")).get("cuts", [])
        留 = [c for c in 后 if c.get("类型") == "手动补剪" and abs(float(c["开始"]) - 1.111) < 0.01]
        序 = [float(c["开始"]) for c in 后]
        记("重跑找点保住手动补剪点", (not r2.get("error")) and len(留) == 1 and 序 == sorted(序),
           "重跑后手动点 %d 条,清单仍按时间排序" % len(留))

        # 3 make_subs.build 真跑(三件套一致)
        plan = {"media": "", "duration": 0, "cuts": []}
        ass, srt, st, info, tl = M.build(str(tj), final=None, style=None, size=(320, 240))
        n1 = sum(1 for l in ass.splitlines() if l.startswith("Dialogue:"))
        n2 = srt.strip().count("\n\n") + 1 if srt.strip() else 0
        n3 = json.loads(tl)["行数"]
        记("make_subs.build 真跑", n1 > 0 and n1 == n3, "ASS %d 行 / SRT %d 条 / JSON %d 行" % (n1, n2, n3))
        记("三件套行数一致", n1 == n3, "ASS 与逐字时间轴必须同数")
        # 回归:定稿块长于每行上限时曾抛类型错误,导致整条字幕被静默跳过
        long_txt = "这一句特别长故意超过每行上限看看会不会把整条字幕弄丢掉啊"
        (T / "长句定稿.txt").write_text(long_txt + "\n", encoding="utf-8")
        a2 = M.build(str(tj), final=str(T / "长句定稿.txt"), style=None, size=(1080, 1920))[0]
        记("长句定稿不丢字幕", sum(1 for l in a2.splitlines() if l.startswith("Dialogue:")) > 0
           and "整行" not in a2, "竖屏+超长句必须仍能出字")
        记("无对标档时按画幅算每行", M.style_of(None, (1920, 1080))["每行"] > 8,
           "横屏 %d 字/行" % M.style_of(None, (1920, 1080))["每行"])

        # 4 render_cut 真跑(整条滤镜链:剪切+音频+字幕)
        clip = 合成素材(T)
        if not clip:
            记("合成测试素材", False, "ffmpeg 造不出测试片,后面几项跳过")
        else:
            记("合成测试素材", True, "3 秒彩条+正弦")
            plan = {"media": str(clip), "duration": 3.0,
                    "cuts": [{"类型": "停顿", "开始": 1.0, "结束": 1.3, "时长": 0.3,
                              "文字": "测", "理由": "smoke", "执行": "删"}]}
            (T / "文案定稿.txt").write_text("\n".join(句列表) + "\n", encoding="utf-8")
            (T / "剪切点清单.json").write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
            r = 跑([PY, ROOT / "render_cut.py", T / "剪切点清单.json", "--out", T / "rough.mp4",
                   "--xfade", "0"])
            out = T / "rough.mp4"
            dur = ""
            if out.exists():
                p = 跑(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", out])
                dur = (p.stdout or "").strip()
            记("render_cut 真跑", r.returncode == 0 and out.exists(),
               ("成片 %.2fs" % float(dur)) if dur else (r.stderr or r.stdout)[-120:])
            硬 = [l for l in (r.stdout or "").splitlines() if "句中硬缝" in l]
            补 = [l for l in (r.stdout or "").splitlines() if l.strip().startswith("气口补齐")]
            记("句中刀不插静音洞", bool(硬) and not 补 and dur and abs(float(dur) - 2.7) <= 0.06,
               "接缝两侧都是语音:不插洞不冻帧(成片 %ss)" % dur if (硬 and not 补 and dur)
               else "硬缝行=%s 补齐=%s 时长=%s" % (bool(硬), 补[:1], dur))

            # 4a 交叉淡化(默认50ms):接缝两段声音重叠,总长要少掉 0.05s,音画不能各走各的
            rx = 跑([PY, ROOT / "render_cut.py", T / "剪切点清单.json", "--out", T / "rough交.mp4"])
            ox = T / "rough交.mp4"
            dx = ""
            if ox.exists():
                dx = (跑(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "csv=p=0", ox]).stdout or "").strip()
            日志x = (rx.stdout or "") + (rx.stderr or "")
            淡行 = [l for l in 日志x.splitlines() if "交叉淡化" in l]
            记("接缝交叉淡化生效", rx.returncode == 0 and bool(淡行) and "1 处" in 淡行[0]
               and dx and abs(float(dx) - 2.65) <= 0.06,
               "50ms 重叠,成片 %.2fs(不插洞也不硬顶)" % float(dx) if (淡行 and dx) else (淡行[:1], dx, 日志x[-120:]))

            # 4b 字幕位置必须画面正中(铁律:抖音底部被标题栏遮挡)
            ass_x = (T / "字幕.ass").read_text(encoding="utf-8") if (T / "字幕.ass").exists() else ""
            tlx = json.loads((T / "字幕时间轴.json").read_text(encoding="utf-8")) if (T / "字幕时间轴.json").exists() else {}
            样式行 = [l for l in ass_x.splitlines() if l.startswith("Style:")]
            an_ok = bool(样式行) and 样式行[0].split(",")[18] == "8"
            _rx = re.search(r"PlayResX: (\d+)", ass_x); _ry = re.search(r"PlayResY: (\d+)", ass_x)
            中心 = "\\an8\\pos(%d,%d)" % (int(_rx.group(1)) // 2, int(_ry.group(1)) // 2) if (_rx and _ry) else ""
            pos_ok = bool(中心) and (中心 in ass_x) and (tlx.get("垂直位置") == "正中")
            记("字幕居中不贴底", an_ok and pos_ok,
               "样式 an8 + 每行钉在画幅中心 %s + 时间轴标注正中" % 中心 if (an_ok and pos_ok)
               else "样式=%s 中心=%s 命中=%s 时间轴位置=%s" % (样式行[:1], 中心, 中心 in ass_x, tlx.get("垂直位置")))
            # 高级感档:所有形式刀默认只标记不剪
            rc = 跑([PY, ROOT / "find_cuts.py", t2, "--out", T / "高级感", "--sense", "calm",
                     "--pause", "1.3", "--keepsil", "0.55"])
            cj3 = T / "高级感.剪切点.json"
            刀3 = json.loads(cj3.read_text(encoding="utf-8")).get("cuts", []) if cj3.exists() else []
            起3 = [c for c in 刀3 if c["类型"] == "起音重说"]
            重3 = [c for c in 刀3 if c["类型"] == "重复"]
            禅3 = [c for c in 刀3 if c["类型"] == "口头禅" and c["文字"] not in ("嗯", "呃", "额", "唔")]
            记("高级感档形式刀全默认保留", bool(起3) and bool(重3) and all(c["执行"] == "保留" for c in 起3 + 重3 + 禅3),
               "起音重说%d/重复%d/软口头禅%d 全部只标记" % (len(起3), len(重3), len(禅3))
               if rc.returncode == 0 and cj3.exists() else (rc.stderr or rc.stdout)[-90:])
            # 2c 换档位必须重设机器默认,人工裁决过的行不许被顶回去(workbench 真调用)
            目 = T / "档位项目"; 目.mkdir()
            shutil.copy(t2, 目 / "转写.json")
            W.action_findcuts(str(目), {"pause": 1.0, "keepsil": 0.45, "preset": "natural"})
            f1 = 目 / "剪切点清单.json"
            d1 = json.loads(f1.read_text(encoding="utf-8")) if f1.exists() else {}
            起一 = [c for c in d1.get("cuts", []) if c["类型"] == "起音重说"]
            if 起一:
                起一[0]["执行"] = "删"; 起一[0]["人工"] = "1"
                d1["档位"] = "natural"
                f1.write_text(json.dumps(d1, ensure_ascii=False), encoding="utf-8")
            W.action_findcuts(str(目), {"pause": 1.3, "keepsil": 0.55, "preset": "calm"})
            d2b = json.loads(f1.read_text(encoding="utf-8")) if f1.exists() else {}
            起二 = [c for c in d2b.get("cuts", []) if c["类型"] == "起音重说"]
            重二 = [c for c in d2b.get("cuts", []) if c["类型"] == "重复"]
            人工行 = [c for c in 起二 if c.get("人工")]
            记("换档位重设默认人工不覆盖", bool(起一) and bool(人工行) and 人工行[0]["执行"] == "删"
               and bool(重二) and all(c["执行"] == "保留" for c in 重二) and d2b.get("档位") == "calm",
               "人工那条仍是删并带标记,机器刀随档位转保留" if (人工行 and 重二 and 人工行[0]["执行"] == "删"
                 and all(c["执行"] == "保留" for c in 重二))
               else "人工=%s 重复=%s 档位=%s" % ([(c["执行"], c.get("人工")) for c in 人工行][:2],
                     [c["执行"] for c in 重二][:3], d2b.get("档位")))
            logc = r.stdout or ""
            记("两遍响度+编码器报告", "两遍测量" in logc and "编码器:" in logc,
               "响度两遍法与编码器选择有上报(禁止静默降级)")
            import render_cut as R
            样 = 'x [Parsed_loudnorm] {\n\"input_i\" : \"-23.45\",\"input_tp\" : \"-10.2\",\"input_lra\" : \"8.3\",\"input_thresh\" : \"-34.0\",\"target_offset\" : \"-0.6\"\n}'
            dd = R.parse_loudnorm(样)
            记("loudnorm测量JSON解析", dd is not None and dd["input_i"] == "-23.45",
               "从 stderr 抠测量块" if dd else "解析失败")
            记("字幕三件套落盘", (T / "字幕.ass").exists() and (T / "字幕.srt").exists()
               and (T / "字幕时间轴.json").exists(), "ass/srt/json")

            # 4b 人声修复开关(--repair on):成功或明确回退,rc 必须为 0
            r2 = 跑([PY, ROOT / "render_cut.py", T / "剪切点清单.json",
                     "--out", T / "rough修.mp4", "--subs", "off", "--repair", "on"])
            log2 = (r2.stdout or "") + (r2.stderr or "")
            记("人声修复开关可跑", r2.returncode == 0 and (T / "rough修.mp4").exists()
               and "音频修复" in log2, "走通修复支路(完成或带原因回退)")

            # 4c 人声修复引擎单独真跑(必须吃 48k 单声道 wav,不能喂 mp4)
            wav = T / "入.wav"
            跑(["ffmpeg", "-y", "-v", "error", "-i", clip, "-ar", "48000", "-ac", "1",
                 "-c:a", "pcm_s16le", wav])
            r = 跑([PY, ROOT / "vocal_repair.py", wav, T / "出.wav", "--engine", "ffmpeg"])
            出 = T / "出.wav"
            记("vocal_repair 真跑", r.returncode == 0 and 出.exists() and 出.stat().st_size > 1000,
               (r.stdout or "").strip().splitlines()[-1][:60] if r.stdout else (r.stderr or "")[-90:])

            # 5 备份脚本真跑(文本成果防误删)
            r = 跑([PY, ROOT / "backup_small.py", "--quiet"])
            备 = ROOT.parent / "备份"
            份 = sorted([d for d in 备.iterdir() if d.is_dir()]) if 备.exists() else []
            有分镜 = bool(份) and any((d / "工作台" / "项目").exists() for d in 份)
            # 判据=脚本真跑通且备份非空;"含分镜"只作附加信息(干净机上自检前段也会造样片项目,不能当门槛)
            有内容 = bool(份) and any(f.is_file() for d in 份 for f in d.rglob("*"))
            记("backup_small 真跑", r.returncode == 0 and 有内容,
               ("%d 份备份,含项目文本" % len(份)) if 有分镜 else
               ("%d 份备份,含文本成果" % len(份)) if 有内容 else
               (r.stderr or r.stdout)[-90:])

            # 6 ref_style 真跑
            r = 跑([PY, ROOT / "ref_style.py", clip, "--out", T / "对标风格.json"])
            f = T / "对标风格.json"
            建议 = (json.loads(f.read_text(encoding="utf-8")).get("建议") or {}) if f.exists() else {}
            记("ref_style 真跑", r.returncode == 0 and bool(建议.get("停顿剪阈值秒")),
               "切镜 %s 次/分" % ((json.loads(f.read_text(encoding="utf-8")).get("切镜") or {}).get("每分钟切镜")
                              if f.exists() else 0))

            # 7 ref_shotmap 对标点位拆解:真跑 + 三处一致性(行数/时长衔接/需求清单)
            refv = 合成对标(T)
            pj = T / "点位项目"; pj.mkdir(exist_ok=True)
            if not refv:
                记("合成对标片", False, "造不出多镜头对标片,点位拆解项跳过")
            else:
                记("合成对标片", True, "4 段拼接,含纯色底字块")
                r = 跑([PY, ROOT / "ref_shotmap.py", refv, "--proj", pj, "--own", tj,
                        "--thr", "0.3", "--per-sheet", "8"])
                jf = pj / "对标点位.json"
                d = json.loads(jf.read_text(encoding="utf-8")) if jf.exists() else {}
                pts = d.get("点位") or []
                记("ref_shotmap 真跑", r.returncode == 0 and len(pts) >= 3,
                   ("%d 镜 | " % len(pts)) + "、".join("%s%d" % (k, v) for k, v in
                    ((d.get("统计") or {}).get("分类分布") or {}).items()) if pts
                   else ((r.stderr or r.stdout) or "")[-140:])
                import csv as _csv
                with open(pj / "对标点位.csv", encoding="utf-8-sig", newline="") as f:
                    rowsc = list(_csv.reader(f))
                记("点位表JSON与CSV行数一致", len(rowsc) - 1 == len(pts) and len({len(x) for x in rowsc}) == 1,
                   "CSV %d 行 %d 列" % (len(rowsc) - 1, len(rowsc[0])))
                with open(pj / "素材需求.csv", encoding="utf-8-sig", newline="") as f:
                    needc = list(_csv.reader(f))
                记("素材需求清单与统计一致", len(needc) - 1 == (d.get("统计") or {}).get("需要外部素材")
                   and len({len(x) for x in needc}) == 1,
                   "清单 %d 条(只含需要外部素材的镜)" % (len(needc) - 1))
                合法 = all(x.get("机器分类") in ("口播真人", "文字卡", "图形/数据底", "外部素材", "待定")
                          and 0 <= float(x.get("置信度") or -1) <= 1 and x.get("处理方式") and x.get("功能猜测")
                          and (pj / "对标点位" / x["帧图"]).exists() for x in pts)
                记("每镜分类合法+缩略图落盘", bool(pts) and 合法, "分类/置信度/处理方式/帧图齐全")
                衔接 = (pts and abs(pts[0]["起秒"]) < 0.01 and
                        all(abs(pts[i]["止秒"] - pts[i + 1]["起秒"]) < 0.01 for i in range(len(pts) - 1)) and
                        all(x["止秒"] > x["起秒"] for x in pts))
                记("点位时间码首尾相接", bool(衔接), "0 → %ss,镜间无空隙无重叠" % (pts[-1]["止秒"] if pts else 0))
                类集 = {x["机器分类"] for x in pts}
                记("纯色底与多彩画面分出不同类", ("图形/数据底" in 类集 or "文字卡" in 类集) and "外部素材" in 类集,
                   "出现类别: " + "、".join(sorted(类集)))
                记("联系表图已生成", bool((d.get("联系表") or [])) and
                   (pj / "对标点位" / d["联系表"][0]).exists(), str(d.get("联系表")))
                import ref_shotmap as RS
                样 = [{"肤色": .22, "色彩熵": 4.4, "主色占比": .12, "边缘": .20, "亮度": .50, "对比": .60, "饱和": .30},
                     {"肤色": .00, "色彩熵": 3.0, "主色占比": .44, "边缘": .75, "亮度": .30, "对比": .40, "饱和": .10},
                     {"肤色": .00, "色彩熵": 0.3, "主色占比": .95, "边缘": .03, "亮度": .47, "对比": .10, "饱和": .50},
                     {"肤色": .00, "色彩熵": 4.6, "主色占比": .15, "边缘": .14, "亮度": .36, "对比": .50, "饱和": .40},
                     {"肤色": .02, "色彩熵": 3.4, "主色占比": .30, "边缘": .20, "亮度": .50, "对比": .50, "饱和": .40}]
                猜 = [RS.classify(x, None)[0] for x in 样]
                记("分类规则五类可命中", 猜 == ["口播真人", "文字卡", "图形/数据底", "外部素材", "待定"], "、".join(猜))
                from PIL import Image as _Im
                _a = np.zeros((200, 120, 3), dtype=np.uint8); _a[:, :] = (10, 12, 20); _a[:110, :] = (200, 150, 120)
                记("上下分区看出叠字卡", RS.zone_note(_Im.fromarray(_a), (0, 0, 120, 200)).startswith("下半屏叠字卡"),
                   "真人上半身+下半屏纯色底 → 判为叠卡(整帧统计看不出来)")
                _n = np.random.default_rng(7).integers(0, 256, (200, 120, 3), dtype=np.uint8)
                记("满画面素材不误报叠卡", not RS.zone_note(_Im.fromarray(_n.astype(np.uint8)), (0, 0, 120, 200)).startswith("下半屏"),
                   "随机彩色画面 → 不判成叠卡")
                记("点位表含「对标处口播」列", "对标处口播" in json.dumps(pts, ensure_ascii=False)
                   and "对标处你在说什么" in (pj / "素材需求.csv").read_text(encoding="utf-8-sig").splitlines()[0],
                   "口播词与「你要放什么」分两列,不混填")
                记("改分类会带着功能与来源一起换", (lambda q: (RS.apply_class(q, "文字卡"),
                    (q["功能猜测"], q["来源建议"], q["处理方式"]))[1] == (RS.FUNC["文字卡"], RS.SOURCE["文字卡"], RS.DO["文字卡"]))
                   ({"镜号": "99", "时长": 2, "位置": "中段", "机器分类": "外部素材",
                     "功能猜测": "旧", "来源建议": "旧", "处理方式": "旧", "降级方案": "旧"}),
                   "字卡→自制,0成本")
                # 人工改分类:重跑不丢,且素材需求数跟着变(字卡不需要外部素材)
                d["点位"][0]["我的分类"] = "文字卡"; d["点位"][0]["关键词候选"] = "自检关键词"
                jf.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
                旧需 = (d.get("统计") or {}).get("需要外部素材") or 0
                r = 跑([PY, ROOT / "ref_shotmap.py", refv, "--proj", pj, "--own", tj, "--thr", "0.3"])
                d2 = json.loads(jf.read_text(encoding="utf-8"))
                记("重跑带回人工分类", r.returncode == 0 and d2["点位"][0]["我的分类"] == "文字卡"
                   and d2["点位"][0]["关键词候选"] == "自检关键词", "改的分类与关键词没被覆盖")
                记("分类一改素材需求跟着降", d2["统计"]["需要外部素材"] <= max(旧需 - 1, 0),
                   "需要外部素材 %d → %d" % (旧需, d2["统计"]["需要外部素材"]))
                # 工作台保存接口(界面直接调引擎,不起子进程)
                rs = W.refmap_save(pj, [{"镜号": d2["点位"][0]["镜号"], "我的分类": "外部素材",
                                        "画面需要(你来填)": "自检画面", "关键词候选": "球场空镜",
                                        "处理方式": "需要一条画面:填关键词"}])
                st2 = W.refmap_state(pj)
                记("工作台保存点位表", rs.get("ok") and "球场空镜" in json.dumps(st2, ensure_ascii=False)
                   and st2["统计"]["需要外部素材"] == rs["需要外部素材"],
                   "存 %s 行,需要外部素材 %s 个" % (rs.get("改了几行"), rs.get("需要外部素材")))
                记("工作台读点位表带URL", st2.get("has") and st2["点位"][0]["帧URL"].startswith("/media?")
                   and len(st2["types"]) == 5 and bool(st2["默认处理方式"]), "缩略图URL/分类表/默认处理方式齐")
                # 补进分镜表:建表 + 幂等拦截 + 强行再加
                sbf = pj / "分镜.csv"
                r = 跑([PY, ROOT / "ref_shotmap.py", "--proj", pj, "--write-storyboard"])
                import csv as _c2
                sbrows = list(_c2.reader(io.StringIO(sbf.read_text(encoding="utf-8-sig")))) if sbf.exists() else []
                记("按点位补进分镜表", r.returncode == 0 and len(sbrows) >= 2
                   and "镜号" in sbrows[0][0] and all(len(x) == len(sbrows[0]) for x in sbrows if x),
                   "分镜 %d 行(含表头)" % len(sbrows) if sbrows else ((r.stderr or r.stdout) or "")[-120:])
                r2 = 跑([PY, ROOT / "ref_shotmap.py", "--proj", pj, "--write-storyboard"])
                记("重复补分镜被拦", r2.returncode != 0 and "自动补" in ((r2.stderr or "") + (r2.stdout or "")),
                   "默认不重复追加,提示先删自动补的行")
                r3 = 跑([PY, ROOT / "ref_shotmap.py", "--proj", pj, "--write-storyboard", "--force"])
                n3 = len(list(_c2.reader(io.StringIO(sbf.read_text(encoding="utf-8-sig"))))) if r3.returncode == 0 else 0
                记("强行再加可重复补", r3.returncode == 0 and n3 > len(sbrows), "%d → %d 行" % (len(sbrows), n3))
                记("补完分镜仍只有1个表头", sum(1 for x in list(_c2.reader(io.StringIO(sbf.read_text(encoding="utf-8-sig")))) if x and "镜号" in x[0]) == 1, "追加不重复表头")

            # 7B ①-E 文字效果分析(本机 OCR):一条片子藏 8 种字效,真跑逐项核对真值(含「不许乱报」)
            ft = Path("C:/Windows/Fonts/msyh.ttc")
            if not ft.exists():
                记("合成字效片", False, "C:/Windows/Fonts/msyh.ttc 不存在(字效分析自检依赖 Windows 字体)")
            else:
                from PIL import Image as _Img, ImageDraw as _Idr, ImageFont as _Ift
                import text_style as TSX
                记("摆动函数判周期", TSX.oscillation([1.0, 0.35, 1.0, 0.35, 1.0, 0.35, 1.0, 0.35] * 3)[0] >= 3,
                   "去趋势后按过零计圈,闪烁/抖动的通用底座")
                import cv2 as _cv
                _bg = np.array([43, 39, 34], float); _tc = np.array([248, 251, 255], float)
                _cp = np.zeros((60, 120, 3), np.float32); _cp[:] = _bg
                _mk = np.zeros((60, 120), np.uint8); _mk[20:40, 40:80] = 1; _cp[_mk > 0] = _tc
                _od = _cv.distanceTransform(1 - _mk, _cv.DIST_L2, 3)
                _hd = _cp.copy(); _hd[(_od >= 1) & (_od <= 4)] = np.array([150.0, 150.0, 150.0], np.float32)
                _gw = _cp.copy()
                for _k in range(1, 9):
                    _bd_ = (_od >= _k) & (_od < _k + 1); _gw[_bd_] = _bg + (_tc - _bg) * float(np.exp(-_k / 2.2))
                记("径向剖面分硬边/柔光/无", TSX.ring_style(_mk, _hd, _bg, _tc)[0].startswith("硬边")
                   and TSX.ring_style(_mk, _gw, _bg, _tc)[0].startswith("柔光")
                   and TSX.ring_style(_mk, _cp, _bg, _tc)[0].startswith("无"),
                   "描边=平色骤断,发光=逐圈衰减,抗锯齿=薄环")
                _m2 = np.zeros((80, 80), np.uint8); _m2[37:43, 10:70] = 1
                _M2 = _cv.getRotationMatrix2D((40, 40), 25, 1.0)
                _r2 = _cv.warpAffine(_m2, _M2, (80, 80))
                记("像素主轴量角(横条0/转25)", abs(TSX.pca_angle(_m2)) <= 2 and 15 <= abs(TSX.pca_angle(_r2)) <= 35,
                   "OCR框测倾角会躺平,像素主轴才准")
                _n9 = 48
                _bd9 = []
                for _i9 in range(_n9):
                    _t9 = _i9 / 12.0
                    _sh = min(1.0, max(0.0, (_t9 - 1.0) / 2.4))
                    _bd9.append([_t9, round(_sh, 3), round(0.05 + 0.6 * _sh, 3) if _sh > 0.03 else -1.0,
                                 0.5 if _sh < 0.97 else -1.0])
                _S9 = {"t": [_i9 / 12.0 for _i9 in range(_n9)], "cov": [0.18] * _n9, "lx": [0.05] * _n9,
                       "rx": [0.55] * _n9, "cy": [0.5] * _n9, "cx": [0.3] * _n9, "mh": [0.3] * _n9,
                       "sharp": [30.0] * _n9, "br": [200.0] * _n9, "col": [[250, 250, 250]] * _n9,
                       "bd": _bd9, "kA": [250, 250, 250], "kB": [40, 40, 220]}
                _ob9 = [{"t": _i9 * 0.5, "r": (10, 40, 200, 60), "text": "卡拉OK测试", "score": 0.99} for _i9 in range(6)]
                _cl9 = {"文字色": "#FFFFFF", "背景色": "#2B2B2B"}
                import math as _M9
                _S10 = dict(_S9); _S10["bd"] = []; _S10["kA"] = None; _S10["kB"] = None
                _S10["rx"] = [0.55 + 0.12 * _M9.sin(_i9 * 0.8) for _i9 in range(_n9)]
                记("合成序列判卡拉OK/疑似翻转",
                   any("卡拉OK" in e["效果"] for e in TSX.classify_extras(_S9, _ob9, _cl9, None))
                   and any("翻转" in e["效果"] for e in TSX.classify_extras(_S10, _ob9, _cl9, None)),
                   "不靠真片也守得住的两条判定")
                for _n_, _w_ in (("z0", "剪辑新手第一反应"), ("z1", "先完成再完美"), ("z2", "滚动字幕测试"),
                                 ("z3", "闪烁测试"), ("z4", "抖动测试"), ("zt1", "剪辑"), ("zt2", "剪辑新手"),
                                 ("zt3", "剪辑新手第一反应"), ("zs", "阴影测试"), ("k0", "卡拉OK测试"),
                                 ("k1", "卡"), ("k2", "卡拉OK"), ("k3", "卡拉OK测试")):
                    (T / ("_%s.txt" % _n_)).write_text(_w_, encoding="utf-8")
                _g = _Img.new("RGBA", (160, 60), (0, 0, 0, 0))
                _Idr.Draw(_g).text((10, 8), "倾斜标记", font=_Ift.truetype(str(ft), 34), fill=(255, 255, 255, 255))
                _g.rotate(14, expand=True, fillcolor=(0, 0, 0, 0)).save(T / "_tilt.png")
                _F = "fontfile='C\\:/Windows/Fonts/msyh.ttc'"
                def _dt(nm, x, y, fs=36, extra="", color="white"):
                    return "drawtext=%s:textfile='%s':fontcolor=%s:fontsize=%d:x=%s:y=%s%s" % (
                        _F, str(T / ("_%s.txt" % nm)).replace("\\", "/").replace(":", "\\:"), color, fs, x, y, extra)
                vf = ",".join([
                    "drawbox=x=125:y=20:w=360:h=100:color=0x8B2F8B@0.95:t=fill",
                    _dt("z0", "(w-tw)/2", 40, 44),
                    _dt("z1", "(w-tw)/2", 150, 44, ":alpha='if(lt(t,0.8),0,if(lt(t,3.4),(t-0.8)/2.6,1))'"),
                    _dt("z2", "(w-tw)/2", "'if(lt(t,1),360,360-mod(60*(t-1),360))'"),
                    _dt("z3", 20, 250, 36, ":alpha='if(lt(t,1),0.02,0.35+0.65*abs(sin(3.1416*t)))'"),
                    _dt("z4", "'470+9*sin(50*t)*gt(t,0.8)'", 250, 36, ":alpha='gt(t,0.8)'"),
                    _dt("zt1", 30, 310, 40, ":alpha='if(lt(t,1.2),0.001,1)'"),
                    _dt("zt2", 30, 310, 40, ":alpha='if(lt(t,2.0),0.001,1)'"),
                    _dt("zt3", 30, 310, 40, ":alpha='if(lt(t,2.8),0.001,1)'"),
                    "drawtext=%s:textfile='%s':fontcolor=0x555555:fontsize=36:x=470:y=174" % (
                        _F, str(T / "_zs.txt").replace("\\", "/").replace(":", "\\:")),
                    _dt("zs", 470, 170),
                    _dt("k0", 498, 110, 26),
                    _dt("k1", 498, 110, 26, ":alpha='if(lt(t,1.2),0.001,1)'", "0xEE3344"),
                    _dt("k2", 498, 110, 26, ":alpha='if(lt(t,2.0),0.001,1)'", "0xEE3344"),
                    _dt("k3", 498, 110, 26, ":alpha='if(lt(t,2.8),0.001,1)'", "0xEE3344"),
                ])
                字效clip = T / "clip_fx.mp4"
                跑(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "color=c=0x222831:s=640x360:d=8",
                     "-i", T / "_tilt.png", "-filter_complex",
                     "[0:v]" + vf + "[v0];[v0][1:v]overlay=300:90:eval=frame[v]", "-map", "[v]", "-r", "25", 字效clip])
                记("合成字效片", 字效clip.exists() and 字效clip.stat().st_size > 3000,
                   "静/底块/渐显/滚动/闪烁/抖动/打字机/阴影/倾斜/卡拉OK")
                pj2 = T / "字效项目"; pj2.mkdir(exist_ok=True)
                r = 跑([PY, ROOT / "text_style.py", 字效clip, "--out", pj2 / "对标文字.json",
                        "--proj", pj2, "--dur", "8", "--fps", "2"])
                jf2 = pj2 / "对标文字.json"
                dd2 = json.loads(jf2.read_text(encoding="utf-8")) if jf2.exists() else {}
                bs = dd2.get("文字块") or []
                记("text_style 真跑", r.returncode == 0 and len(bs) >= 8,
                   ("%d 块 | " % len(bs)) + "/".join(b["动效"]["入场"] for b in bs[:8]) if bs
                   else ((r.stderr or r.stdout) or "")[-160:])
                def _bx(txt, first=None):
                    out = [b for b in bs if txt in b["文字"] and (first is None or (b["首现"] < 0.5) == first)]
                    return out[0] if out else None
                def _has(b, key):
                    if not b:
                        return False
                    return key in b["动效"]["入场"] or any(key in e["效果"] for e in b["动效"]["附加效果"])
                fade = _bx("完美"); scr = _bx("滚动字幕"); tw = _bx("第一反应", first=False)
                sta = _bx("第一反应", first=True); blk = _bx("闪烁"); jit = _bx("抖动"); tl = _bx("倾斜"); shd = _bx("阴影")
                记("渐显字能被认出且不乱报", bool(fade) and fade["动效"]["入场"] == "渐显" and not fade["动效"]["附加效果"],
                   (fade["动效"].get("依据") or "无附加") if fade else "块缺失")
                记("滚动字方向速度能认出", bool(scr) and "向上" in scr["动效"]["滚动"]
                   and 3 <= (scr["动效"]["滚动速度%屏每秒"] or 0) <= 20,
                   scr["动效"]["滚动"] + " %.1f%%/s" % (scr["动效"]["滚动速度%屏每秒"] or 0) if scr else "块缺失")
                记("打字机逐字出现能认出", _has(tw, "打字机"),
                   tw["动效"]["入场"] if tw else "块缺失")
                记("闪烁能认出", _has(blk, "闪烁"), blk["动效"]["入场"] if blk else "块缺失")
                记("抖动能认出", _has(jit, "抖动"), jit["动效"]["入场"] if jit else "块缺失")
                记("倾斜能认出带角度", _has(tl, "倾斜") and abs(tl["位置"].get("倾角deg") or 0) >= 4,
                   "倾角 %s°" % (tl["位置"].get("倾角deg") if tl else "—"))
                记("阴影能认出", _has(shd, "阴影"), "块缺失" if not shd else "")
                kar = _bx("OK")
                记("卡拉OK逐字变色能认出(真片)", _has(kar, "卡拉OK"),
                   kar["动效"]["附加效果"][0]["依据"] if kar and kar["动效"]["附加效果"] else "块缺失")
                记("卡拉OK不被误报成清晰度问题", bool(kar) and not any(
                   ("清晰" in e["效果"]) for e in kar["动效"]["附加效果"]), "真色变不等于锐度变")
                记("底色块能认出", _has(sta, "底色块"), "块缺失" if not sta else "")
                记("静字不乱报其他效果", bool(sta) and sta["动效"]["入场"] == "瞬现" and sta["动效"]["滚动"] == "无"
                   and all("底色块" in e["效果"] for e in sta["动效"]["附加效果"]),
                   "附加仅底色块" if sta else "块缺失")
                记("每块配了画面截图", bool(bs) and all(b.get("截图") and (pj2 / "对标文字块" / b["截图"]).exists() for b in bs),
                   "%d 张截图" % len(bs))
                记("文字报告落盘", (pj2 / "文字效果报告.md").exists(), "逐块复刻说明")
                stx = W.textstyle_state(pj2)
                记("工作台读字效带截图URL", stx.get("has") and stx["文字块"][0]["截图URL"].startswith("/media?dir="),
                   stx["文字块"][0]["截图URL"][:58])
                vs = W.voice_summary(T)
                记("口播体检本机总结转写", vs.get("总字数", 0) > 0 and any(x["词"] == "嗯" for x in vs.get("口头禅", []))
                   and len(vs.get("AI深度总结提示词", "")) > 80 and "类型" in vs.get("开头钩子", {}),
                   "语速 %s 字/分,抓到口癖 %d 种" % (vs.get("字每分钟"), len(vs.get("口头禅", []))))
                pj3 = T / "融合项目"; pj3.mkdir(exist_ok=True)
                fakeb = {"编号": "T01", "文字": "测试", "首现": 0, "末现": 5, "持续秒": 5,
                         "位置": {"中心X%": 50.0, "中心Y%": 86.0, "锚位": "画面下部横向居中", "倾角deg": None},
                         "大小": {"字高占屏%": 7.0, "宽占屏%": 60.0, "字高px(按1920高换算)": 134},
                         "颜色": {"文字色": "#FFFFFF", "背景色": "#101014", "描边": None, "字重猜测": "粗", "置信": "高",
                                  "底色块": "#2F6FE0"},
                         "字体猜测": {"字重": "粗"},
                         "动效": {"入场": "打字机(逐字出现)", "出场": "渐隐", "滚动": "无", "滚动速度%屏每秒": 0,
                                  "置信": "高", "依据": "",
                                  "附加效果": [{"效果": "打字机(逐字出现)", "置信": "高", "依据": "框宽跳变"},
                                             {"效果": "底色块/高亮底", "置信": "中", "依据": "垫 #2F6FE0"}]}}
                (pj3 / "对标文字.json").write_text(json.dumps(
                    {"文字块": [fakeb], "统计": {"文字块数": 1, "样式组数": 1}}, ensure_ascii=False), encoding="utf-8")
                tp = W.textplan_run(pj3, {"文案": "第一句子。第二句子，还带个逗号。", "样式": "auto"})
                plan = json.loads((pj3 / "文字方案.json").read_text(encoding="utf-8")) if (pj3 / "文字方案.json").exists() else {}
                ops = ";".join(plan.get("卡片", [{}])[0].get("剪映操作", []))
                记("融合:拆句出卡", tp.get("ok") and plan.get("句数") == 2 and plan["卡片"][1]["止"] > plan["卡片"][0]["止"],
                   "句数 %s 合计 %ss" % (plan.get("句数"), plan.get("合计秒")))
                记("底部放置提醒改正中(规则17)", "改放画面正中" in ops, ops[:70])
                记("附加字效进执行卡", "打字机" in ops and "单色块" in ops, "打字机+底色块操作行")
                (pj3 / "对标文字.json").write_text(json.dumps({"文字块": [dict(
                    fakeb, 动效=dict(fakeb["动效"], 附加效果=[{"效果": "卡拉OK逐字变色", "置信": "中", "依据": "扫过"}]))]},
                    ensure_ascii=False), encoding="utf-8")
                tp2 = W.textplan_run(pj3, {"文案": "第三句试试卡拉OK。", "样式": "auto"})
                pl2 = json.loads((pj3 / "文字方案.json").read_text(encoding="utf-8"))
                记("卡拉OK进执行卡操作行", tp2.get("ok") and "卡拉OK" in json.dumps(pl2["卡片"], ensure_ascii=False),
                   "动画-出现-卡拉OK 或两层字关键帧")
                记("执行卡md落盘带操作", (pj3 / "文字效果执行卡.md").exists()
                   and "字体颜色取" in (pj3 / "文字效果执行卡.md").read_text(encoding="utf-8"), "")

            # 8 自动化两件事:建项目即转写 / 存分镜即算秒(PROJ_ROOT 与设置文件临时指到临时目录,绝不碰真项目)
            真PROJ, 真CFG = W.PROJ_ROOT, W.CFG_PATH
            W.PROJ_ROOT = T / "项目根"; W.PROJ_ROOT.mkdir(exist_ok=True)
            W.CFG_PATH = T / "工作台设置.json"
            try:
                记("自动开关默认全开", W.settings()["自动转写"] and W.settings()["自动算秒"], "没配置文件时按默认值跑")
                W.save_settings({"自动转写": False})
                记("开关能存能读回", W.settings()["自动转写"] is False and W.settings()["自动算秒"] is True,
                   "改一个不连带覆盖另一个")
                W.save_settings({"自动转写": True})
                d0, e0 = W.make_project(str(clip), "自检自动转写")
                记("没转写过就该自动跑", W.need_transcribe(d0) == (True, ""), "新项目 → 入队转写")
                (d0 / "转写.json").write_text("{}", encoding="utf-8")
                记("已转写过就不再跑", W.need_transcribe(d0)[0] is False, "原因: " + W.need_transcribe(d0)[1])
                (d0 / "转写.json").unlink()
                r = W.create_project(str(clip), "自检不真跑", {"no_auto": True})
                记("自检调用不真起转写", bool(r.get("dir")) and "skipped" in (r.get("自动转写") or {}),
                   str((r.get("自动转写") or {}).get("skipped", ""))[:30])
                记("非项目目录不自动跑", W.need_transcribe(T / "根本没这目录")[0] is False, "原因: " + W.need_transcribe(T / "根本没这目录")[1])
                pj2 = T / "算秒项目"; pj2.mkdir(exist_ok=True)
                shutil.copyfile(tj, pj2 / "转写.json")
                表 = ("镜号,时间码(源片),锚点,字幕文本(校对版),画面内容,素材文件,动效包装,备注\r\n"
                     "01,,最后一句收尾,测试第一句口播内容,口播,,,\r\n")
                rr = W.storyboard_save(pj2, 表)
                统 = (rr.get("自动算秒") or {}).get("统计") or {}
                记("存分镜自动跑了⚓", bool(rr.get("ok")) and (pj2 / "分镜时间轴.json").exists()
                   and (统.get("精确") or 0) >= 1, "统计 " + str(统))
                末行 = (rr.get("text") or "").splitlines()[-1] if rr.get("text") else ""
                记("算出的秒数写回表里", "00:" in 末行, 末行[:56])
                盘上 = (pj2 / "分镜.csv").read_bytes().decode("utf-8", "replace")
                记("保存分镜不长出空行", "\r\r" not in 盘上
                   and len([l for l in 盘上.splitlines() if l.strip()]) == 2,
                   "喂 CRLF 也只落一层换行(write_text 二次翻译会长空行)")
                记("空表不覆盖已有分镜", W.storyboard_save(pj2, "   ").get("error", "").startswith("分镜表是空的"),
                   "防手滑清空")
                # 这条原来喂的是一段大白话,把"话能当表存"当成正确行为——2026-10-26 已改成拒存(见下面「话贴进分镜表被拦」),
                # 这里只验真正要验的:没写表头的合规镜头行,保存时机器补一行表头且 ⚓ 照常跑
                _rj = W.storyboard_save(pj2, "01,,,大专生也能当高级感剪辑师,口播正面,,,")
                _头 = (pj2 / "分镜.csv").read_text(encoding="utf-8").splitlines()[0] if (pj2 / "分镜.csv").exists() else ""
                记("缺镜号表头保存自动补一行", _rj.get("ok") is True and _rj.get("已自动补表头") is True
                   and _头.startswith("镜号"),
                   "框里灰字只是占位提示,表头机器补;补完⚓照常跑,不跟步骤勾选打架")
                W.save_settings({"自动算秒": False})
                rr2 = W.storyboard_save(pj2, 表)
                记("关掉开关就只存不算", "skipped" in (rr2.get("自动算秒") or {}),
                   str((rr2.get("自动算秒") or {}).get("skipped", ""))[:30])
                W.save_settings({"自动算秒": True})
                # 删除项目 → 回收站(假回收站顶替 send2trash,自检不碰真系统回收站)
                import types as _tp
                _真s2t = sys.modules.pop("send2trash", None)
                _回收 = {"去了": ""}
                _m = _tp.ModuleType("send2trash")
                def _stub(p, _回收=_回收):
                    _回收["去了"] = str(p); shutil.move(str(p), str(T / ("回收站模拟" + Path(p).name)))
                _m.send2trash = _stub
                sys.modules["send2trash"] = _m
                try:
                    d9, _e9 = W.make_project(str(clip), "自检删除项目")
                    (W.PROJ_ROOT / "空目录").mkdir(exist_ok=True)
                    记("删除整个项目总目录被拒", "整个" in (W.action_delete_project(W.PROJ_ROOT).get("error") or ""), "只让删单个项目")
                    记("项目总目录以外的路径被拒", "不在" in (W.action_delete_project(T / "外面").get("error") or ""), "防路径乱填")
                    记("不是项目的目录被拒", "不是" in (W.action_delete_project(W.PROJ_ROOT / "空目录").get("error") or ""), "缺项目.json就拒")
                    W.JOBS[str(d9)] = {"status": "运行中", "log": [], "label": "转写", "started": time.time()}
                    记("任务在跑时不许删", "任务" in (W.action_delete_project(d9).get("error") or ""), "防止删掉正在出片的项目")
                    del W.JOBS[str(d9)]
                    r9 = W.action_delete_project(d9)
                    记("真删进回收站", r9.get("ok") and not (d9 / "项目.json").exists()
                       and Path(_回收["去了"]).name == "自检删除项目"
                       and (T / "回收站模拟自检删除项目" / "项目.json").exists(), str(r9)[:60])
                    记("删没了再删有明确报错", (W.action_delete_project(d9).get("error") or "") != "", "二次删除不静默")
                finally:
                    if _真s2t is not None: sys.modules["send2trash"] = _真s2t
                    else: sys.modules.pop("send2trash", None)
                # ＋一键建空项目 + 把素材绑进空项目(不复制文件)
                rb0 = W.create_blank_project(); d10 = Path(rb0["dir"])
                记("＋一键建空项目", d10.name == "口播1" and not (W.meta_of(d10) or {}).get("media"), str(d10.name))
                rb1 = W.create_blank_project()
                记("＋连点自动排号", Path(rb1["dir"]).name == "口播2", Path(rb1["dir"]).name)
                rb2 = W.create_project(str(clip), "", {"dir": str(d10), "no_auto": True})
                记("粘贴路径绑到空项目", rb2.get("绑定") and (W.meta_of(d10) or {}).get("media") == str(Path(clip).resolve()), str(rb2)[:50])
                rb3 = W.create_project(str(T / "没这文件.mp4"), "", {"dir": str(d10)})
                记("绑不存在的素材被拒", "不存在" in (rb3.get("error") or ""), (rb3.get("error") or "")[:36])
                rb4 = W.action_transcribe(Path(rb1["dir"]), {"model": "small"})
                记("空项目点转写给指引不崩", "绑" in (rb4.get("error") or "") and not rb4.get("ok"), (rb4.get("error") or "")[:30])
                rp0 = W.create_project(str(clip), "", {"no_auto": True}); dp0 = Path(rp0["dir"])
                ra0 = W.adopt_media(dp0)
                记("收编后项目自带素材", ra0.get("ok") and (W.meta_of(dp0) or {})["media"].startswith(str(dp0))
                   and Path((W.meta_of(dp0) or {})["media"]).exists(), str(ra0.get("new"))[:60])
                ra1 = W.adopt_media(dp0)
                记("重复收编不复制第二次", bool(ra1.get("skipped")), str(ra1)[:40])
                记("没绑素材谈不上收编", "还没绑" in (W.adopt_media(Path(rb1["dir"])) .get("error") or ""), "空项目有明确指引")
                # 主素材拖入(函数层):上传副本落进项目「素材」后换绑;非项目/假副本都要有说法
                dr0 = W.create_blank_project(); dp2 = Path(dr0["dir"])
                (dp2 / "素材").mkdir(exist_ok=True); fp2 = dp2 / "素材" / "拖入主视.mp4"; fp2.write_bytes(b"fake")
                rs0 = W.bind_copied_media(dp2, fp2)
                记("拖入副本即换绑主素材", rs0.get("ok") and (W.meta_of(dp2) or {})["media"] == str(fp2.resolve()), str(rs0)[:50])
                rs1 = W.bind_copied_media(T / "不是个项目", fp2)
                记("非项目目录拖入说清原因", "无效" in (rs1.get("error") or ""), str(rs1.get("error") or "")[:30])
                rs2 = W.bind_copied_media(dp2, dp2 / "素材" / "没落盘.mp4")
                记("副本没落盘拒绝换绑", "没落盘" in (rs2.get("error") or ""), str(rs2.get("error") or "")[:30])
                db, _eb = W.make_project(str(clip), "体检断线")
                jb = db / "项目.json"; mb = json.loads(jb.read_text(encoding="utf-8"))
                mb["media"] = str(T / "已被挪走.mp4"); jb.write_text(json.dumps(mb, ensure_ascii=False), encoding="utf-8")
                mc0 = W.media_check(); 态0 = {r["项目"]: r["状态"] for r in mc0["rows"]}
                记("体检报出断线项目", 态0.get("体检断线") == "断线" and mc0["断线数"] >= 1 and 态0.get("口播2") == "未绑素材", json.dumps(态0, ensure_ascii=False)[:90])
                rr0 = W.relink_media(str(db), str(clip))
                mc1 = W.media_check(); 态1 = {r["项目"]: r["状态"] for r in mc1["rows"]}
                记("重新连线即恢复零复制", rr0.get("relink") and 态1.get("体检断线") == "正常"
                   and (W.meta_of(db) or {}).get("media") == str(Path(clip).resolve()) and db.exists(), str(rr0.get("new"))[:56])
                记("重连假路径被拒", "不存在" in (W.relink_media(str(db), str(T / "鬼.mp4")).get("error") or ""), "和绑定同一套验尸")
            finally:
                W.PROJ_ROOT, W.CFG_PATH = 真PROJ, 真CFG

            # 10 ①-A 文案进度文件容错(真出过事:末尾多一个花括号 → 整个 /api/script 空响应)
            bs = T / "坏状态"; bs.mkdir(exist_ok=True)
            (bs / "script_state.json").write_text(json.dumps({"questions": [{"id": 0}], "final": "定稿句"},
                                                            ensure_ascii=False) + "}", encoding="utf-8")
            (bs / "文案定稿.txt").write_text("定稿句", encoding="utf-8")
            g1 = W.script_state(bs)
            记("状态文件末尾有垃圾也能读", g1.get("final") == "定稿句" and g1.get("has_final")
               and "文件警告" in g1, str(g1.get("文件警告", ""))[:40])
            (bs / "script_state.json").write_text("{不是json", encoding="utf-8")
            g2 = W.script_state(bs)
            记("状态文件彻底坏了也不崩", g2.get("文件警告", "").startswith("script_state.json 读不了")
               and g2.get("has_final") is True and g2.get("questions") == [], str(g2.get("文件警告", ""))[:44])
            (bs / "script_state.json").write_text("[1,2]", encoding="utf-8")
            g3 = W.script_state(bs)
            记("状态文件内容不是对象也能继续", g3.get("文件警告", "").startswith("script_state.json 内容不是对象")
               and g3.get("has_final") is True, str(g3.get("文件警告", ""))[:40])
            记("接口异常会回错误而不是掐连接", hasattr(W.H, "_boom") and W.H.__dict__.get("do_GET") is not W.H.__dict__.get("_GET"),
               "do_GET 已包一层兜底")
            # 11 界面不缓存 + 后端没重启要明说(这两个是"改了却像被改回去"的真原因)
            旧刻 = W.启动时刻
            try:
                W.启动时刻 = 0
                记("后端代码改过会提示重启", W.backend_stale() is True, "启动时刻摆过去 → 判定待重启")
                W.启动时刻 = time.time()
                记("刚启动时不误报待重启", W.backend_stale() is False, "不误报")
            finally:
                W.启动时刻 = 旧刻
            import threading as _th, urllib.request as _ur
            srv = ThreadingHTTPServer(("127.0.0.1", 0), W.H)
            端 = srv.server_address[1]
            _th.Thread(target=srv.serve_forever, daemon=True).start()
            try:
                r = _ur.urlopen("http://127.0.0.1:%d/" % 端, timeout=15)
                cc = r.headers.get("Cache-Control") or ""
                记("界面响应带 no-store", "no-store" in cc, "Cache-Control: " + (cc or "没设"))
                st = json.loads(_ur.urlopen("http://127.0.0.1:%d/api/status?dir=" % 端, timeout=15).read())
                记("状态接口带引导与重启位", "下一步" in st and "后端待重启" in st,
                   "下一步: " + str((st.get("下一步") or {}).get("做", ""))[:26])
                # 主素材拖入(端到端):真走 /api/upload target=media,落盘+换绑+拒图不残留
                import urllib.parse as _pp
                up0 = T / "拖入上传"; up0.mkdir(exist_ok=True)
                (up0 / "项目.json").write_text(json.dumps({"media": "", "name": "拖入上传"}, ensure_ascii=False), encoding="utf-8")
                q0 = "http://127.0.0.1:%d/api/upload?dir=%s&target=media&name=%s" % (端, _pp.quote(str(up0)), _pp.quote("拖来的主视.mp4"))
                uj = json.loads(_ur.urlopen(_ur.Request(q0, data=b"fake-video-bytes"), timeout=20).read())
                记("拖入主视频即换绑(端到端)", uj.get("ok") and (W.meta_of(up0) or {}).get("media") == str(up0 / "素材" / "拖来的主视.mp4")
                   and (up0 / "素材" / "拖来的主视.mp4").exists(), str(uj)[:60])
                q1 = "http://127.0.0.1:%d/api/upload?dir=%s&target=media&name=%s" % (端, _pp.quote(str(up0)), _pp.quote("封面.jpg"))
                try:
                    _ur.urlopen(_ur.Request(q1, data=b"xx"), timeout=20); _rj = {"error": "居然没拒"}
                except _ur.HTTPError as _he:
                    _rj = json.loads(_he.read())
                记("主素材口拒收图片且不留副本", "不支持" in (_rj.get("error") or "") and not (up0 / "素材" / "封面.jpg").exists(), str(_rj)[:50])
                sbj = json.loads(_ur.urlopen("http://127.0.0.1:%d/api/storyboard?dir=%s" % (端, _pp.quote(str(up0))), timeout=15).read())
                记("空项目分镜框不塞模板只留灰字提示", sbj.get("saved") is False and (sbj.get("text") or "") == ""
                   and "镜号" in (sbj.get("help") or "") and "填写规则" in (sbj.get("help") or ""), str(sbj)[:60])
                (up0 / "分镜.csv").write_text("镜号,锚点\n01,测试\n", encoding="utf-8")
                sbj2 = json.loads(_ur.urlopen("http://127.0.0.1:%d/api/storyboard?dir=%s" % (端, _pp.quote(str(up0))), timeout=15).read())
                记("有表读回真表且说明仍在", sbj2.get("saved") is True and (sbj2.get("text") or "").startswith("镜号,锚点")
                   and "填写规则" in (sbj2.get("help") or ""), str(sbj2.get("text"))[:26])
                (up0 / "分镜.csv").write_text("# 分镜镜头表模板(第①步产出格式)\n| 镜号 | 锚点 |\n填写规则:\n1. 旧版整篇模板被存成分镜表", encoding="utf-8")
                sbj3 = json.loads(_ur.urlopen("http://127.0.0.1:%d/api/storyboard?dir=%s" % (端, _pp.quote(str(up0))), timeout=15).read())
                记("旧版整篇模板存稿被挪开不再当镜头表", sbj3.get("saved") is False and (sbj3.get("text") or "") == ""
                   and (up0 / "分镜-旧模板残留.csv").exists() and not (up0 / "分镜.csv").exists(),
                   "数据不丢:改名留档,框回灰字提示空态")
            finally:
                srv.shutdown(); srv.server_close()


            # 8.5 素材路径粘贴宽容度:引号/隐形字符/文件夹/不存在路径,都要么认要么说清断点
            q = T / "粘贴目录"; q.mkdir()
            (q / "项目.json").write_text(json.dumps({"media": "", "name": "粘贴目录"}, ensure_ascii=False), encoding="utf-8")
            rq = W.bind_media(str(q), ' "%s" ' % clip)                       # Win11 复制文件地址带引号
            mq = W.meta_of(q) or {}
            记("引号空格粘贴也能绑上", not rq.get("error") and mq.get("media") == str(Path(clip).resolve()), str(rq.get("error", ""))[:40])
            ji = W.bind_media(str(q), "\u202a%s\u202c" % clip)              # 方向隐形字符
            fd = T / "只有一片"; fd.mkdir(); shutil.copyfile(clip, fd / "仅一条.mp4")
            rf = W.bind_media(str(q), str(fd))                               # 粘文件夹自动认片
            mf = W.meta_of(q) or {}
            ne = W.bind_media(str(q), str(T / "没有这目录") + "\\鬼.mp4")  # 不存在→断点说明
            记("隐形字符自动洗掉", not ji.get("error"), str(ji.get("error", ""))[:40])
            记("粘文件夹自动认唯一视频", not rf.get("error") and mf.get("media") == str((fd / "仅一条.mp4").resolve()), str(rf.get("error", ""))[:40])
            记("不存在的路径说清断在哪", ne.get("error", "").startswith("素材文件不存在") and "断点" in ne.get("error", ""), str(ne.get("error", ""))[:60])
            记("清洗函数不误伤正常路径", W.clean_media_path(str(clip)) == str(clip), "")
            # 8.6 挑素材窗后端:首页列位置/文件夹内容/坏路径有说法
            b0 = W.browse_roots(); b1 = W.browse_dir(str(fd)); bx = W.browse_dir(str(T / "没这夹"))
            ok86 = (isinstance(b0.get("盘"), list) and bool(b0["盘"]) and len(b0["快捷"]) >= 1
                    and [v["名"] for v in b1["视频"]] == ["仅一条.mp4"] and b1["文件夹"] == []
                    and b1["上级"] == str(T) and str(bx.get("error", "")).startswith("这不是"))
            记("挑素材窗后端 browse 接口", bool(ok86), str(bx.get("error", ""))[:36])
            记("未知接口回人话 JSON 不吐网页", 'if u.path.startswith("/api/"):' in 源d and "旧版工作台" in 源d, "404 兜底带重启指引")

            # 9 下一步引导条:顺序必须和页面上卡片从上到下一致(出过一次不一致,就是这条没守住)
            nj = T / "引导项目"; nj.mkdir(exist_ok=True)
            页 = (WF / "工作台" / "index.html").read_text(encoding="utf-8")
            位 = lambda cid: 页.index('id="%s"' % cid)
            记("没项目时让先建项目", W.next_step(T / "没这目录")["做"].startswith("粘贴口播"), "指向 ① 素材卡片")
            (nj / "项目.json").write_text(json.dumps({"media": str(clip), "name": "引导"}, ensure_ascii=False), encoding="utf-8")
            def 推(pj, 步):
                n = W.next_step(pj)
                记(步, True, "%s → %s" % (n["card"], n["做"][:22]))
                return n
            n1 = 推(nj, "空项目第一步=转写"); assert n1["做"].startswith("开始转写") and n1["进度"] == "0/6"
            (nj / "转写.json").write_text(json.dumps({"duration": 1, "segments": [
                {"start": 0, "end": 1, "text": "测试"}]}, ensure_ascii=False), encoding="utf-8")
            n2 = 推(nj, "没登记对标不插队")
            assert n2["card"] == "s1W" and "定稿" in n2["做"], n2
            (nj / "参考登记.json").write_text(json.dumps([{"path": str(refv), "note": "自检对标"}], ensure_ascii=False), encoding="utf-8")
            n3 = 推(nj, "登记了参考片也不打乱文案在前")
            assert n3["card"] == "s1W" and "定稿" in n3["做"], n3
            (nj / "文案定稿.txt").write_text("测试", encoding="utf-8")
            n4 = 推(nj, "定稿完→写分镜")
            assert n4["card"] == "s1" and "分镜镜头表" in n4["做"], n4
            (nj / "分镜.csv").write_text("镜号,锚点\n01,测试\n", encoding="utf-8")
            n5 = 推(nj, "分镜没算秒→点⚓"); assert "重算时间码" in n5["做"], n5
            (nj / "分镜时间轴.json").write_text("{}", encoding="utf-8")
            os.utime(nj / "分镜.csv", (time.time() - 5, time.time() - 5))
            n6 = 推(nj, "算完秒→拆对标点位"); assert n6["card"] == "s1D" and "拆对标点位" in n6["做"], n6
            (nj / "对标点位.json").write_text("{}", encoding="utf-8")
            n7 = 推(nj, "点位完→③-A 找点"); assert n7["card"] == "s3a", n7
            (nj / "剪切点清单.json").write_text('{"cuts":[]}', encoding="utf-8")
            n8 = 推(nj, "审完清单→③-D 出片"); assert n8["card"] == "s3d" and n8["做"].startswith("③-D"), n8
            shutil.copyfile(clip, nj / "rough.mp4")
            n9 = 推(nj, "出片后→④ 交接"); assert n9["card"] == "s4" and "交接包" in n9["做"], n9
            (nj / "包装交接.md").write_text("x", encoding="utf-8")
            n10 = W.next_step(nj)
            记("六样齐了说可以发", bool(n10.get("完成")) and n10["进度"] == "6/6", n10["做"][:22])
            # 成片故意压回 5 秒:否则"清单比成片新"只剩几毫秒余量,机器一忙就误判
            os.utime(nj / "rough.mp4", (time.time() - 5, time.time() - 5))
            (nj / "剪切点清单.json").write_text('{"cuts":[{"x":1}]}', encoding="utf-8")
            记("清单比成片新会催重剪", "重新执行粗剪" in W.next_step(nj)["做"], "催重出片")
            for _g in ("对标点位.json", "参考登记.json", "剪切点清单.json"):
                (nj / _g).unlink(missing_ok=True)
            记("没登记对标就跳过点位催促", W.next_step(nj)["card"] == "s3a", "分镜算完秒、没对标→直接催 ③-A")
            (nj / "转写.json").write_text('{"segments":[],"duration":0}', encoding="utf-8")
            记("0段转写单独提示查音频", "没识别到人声" in W.next_step(nj)["做"], "防后面空跑")
            链 = [n1["card"], n2["card"], n4["card"], n5["card"], n6["card"], n7["card"], "s3d", "s4"]
            记("引导顺序=页面卡片从上到下", 位("s1W") < 位("s1") < 位("s1c") < 位("s1D") < 位("s3a") < 位("s3d") < 位("s4")
               and [n1["card"], n3["card"], n4["card"], n6["card"]] == ["s2", "s1W", "s1", "s1D"],
               "转写→①-A文案→①-B分镜→⚓→①-D点位→③-A→③-D→④")
            # 11a 转场通用解析:转场:前缀+自定义时长+默认时长+旧关键词兼容(任何机器都能跑,不依赖技能)
            import jy_handoff as JY
            fx_a = JY.parse_fx("推镜|转场:模糊|0.3s", "02")
            fx_b = JY.parse_fx("转场:叠化", "03")
            fx_c = JY.parse_fx("转场:瞎写的名字", "04")
            fx_d = JY.parse_fx("推镜|叠化", "01")
            fx_e = JY.parse_fx("闪白+音效:叮", "03")
            记("转场通用解析", fx_a["trans"] == ("模糊", "0.3s") and fx_a["push"] is not None and
               fx_b["trans"] == ("叠化", "0.4s") and (fx_c["trans"] or ("", ""))[0] == "瞎写的名字" and
               fx_d["trans"] == ("叠化", "0.4s") and fx_e["trans"] == ("闪白", "0.2s"),
               "转场:名字|时长、默认时长、旧叠化/闪白兼容、错名交引擎兜底")
        # 11 ④ 双目标交接:剪映草稿真链路 + 降级操作表 + 进度认两种交接任一
            pj9 = T / "剪映交接项目"; pj9.mkdir(exist_ok=True)
            (pj9 / "项目.json").write_text(json.dumps({"media": str(clip), "name": "剪映自检"}, ensure_ascii=False), encoding="utf-8")
            shutil.copyfile(clip, pj9 / "rough.mp4")
            (pj9 / "分镜.csv").write_text(
                "镜号,时间码(源片),锚点,字幕文本(校对版),画面内容,素材文件,动效包装,备注\n"
                "01,,最后一句收尾,测试第一句口播内容,口播正面,,推镜|叠化,\n"
                "02,,测试第二句词,测试第二句内容在此处,空镜,%s,转场:抖动|0.3s|大词卡,\n"
                "03,,测试第三句尾,测试第三句收尾内容,口播正面,待生成:字卡,闪白+音效:叮,\n" % str(clip),
                encoding="utf-8")
            tl9 = {"换算基准": "自检合成", "成片总时长": 2.7, "统计": {"精确": 3}, "镜": [
                {"镜号": "01", "成片起": 0.0, "成片止": 0.9, "状态": "ok", "锚点": "a", "命中": "a", "方式": "自检"},
                {"镜号": "02", "成片起": 0.9, "成片止": 1.8, "状态": "ok", "锚点": "b", "命中": "b", "方式": "自检"},
                {"镜号": "03", "成片起": 1.8, "成片止": 2.7, "状态": "待确认", "锚点": "c", "命中": "c", "方式": "自检"}]}
            (pj9 / "分镜时间轴.json").write_text(json.dumps(tl9, ensure_ascii=False), encoding="utf-8")
            (pj9 / "字幕.srt").write_text(
                "1\n00:00:00,000 --> 00:00:00,800\n第一句\n\n2\n00:00:00,900 --> 00:00:01,700\n第二句\n", encoding="utf-8")
            r9 = 跑([PY, ROOT / "jy_handoff.py", pj9, "--draft-root", str(T / "jy草稿根")])
            R行 = [x for x in (r9.stdout or "").splitlines() if x.startswith("RESULT ")]
            res9 = json.loads(R行[-1][7:]) if R行 else {}
            if res9.get("mode") == "draft":
                # 本机有 jianying-editor 技能(作者机):草稿结构逐项硬验
                dd9 = res9.get("草稿目录", "")
                st9 = res9.get("统计") or {}
                记("剪映草稿链路真生成", r9.returncode == 0
                   and os.path.isdir(dd9) and (pj9 / "剪映交接.json").exists()
                   and any(str(x).startswith("draft_info") for x in os.listdir(dd9 or str(T)))
                   and st9.get("主轨段数") == 3 and st9.get("字幕条数") == 2
                   and st9.get("关键帧段数", 0) >= 1 and st9.get("转场数") == 3,
                   "段%s 字幕%s 关键帧%s 转场%s 草稿%s" % (st9.get("主轨段数"), st9.get("字幕条数"),
                   st9.get("关键帧段数"), st9.get("转场数"), os.path.basename(dd9 or "?")))
                mf = json.loads((pj9 / "剪映交接.json").read_text(encoding="utf-8")) if (pj9 / "剪映交接.json").exists() else {}
                记("卡片音效进待手摆不冒充", any("大词卡" in x for x in mf.get("待手摆清单", []))
                   and any("音效" in x for x in mf.get("待手摆清单", [])), str(mf.get("待手摆清单"))[:60])
                记("待生成素材只进待补", any("待生成" in x for x in mf.get("待补素材", [])), str(mf.get("待补素材"))[:60])
            else:
                # 客户机无剪映技能(发货版设计如此):必须"明着降级"——rc=0、原因点名技能、操作表落地
                记("剪映草稿链路真生成", r9.returncode == 0 and res9.get("降级")
                   and "jianying-editor" in str(res9.get("原因", "")) and (pj9 / "剪映交接.md").exists(),
                   "无技能机:已明着降级出操作表(原因:%s)" % str(res9.get("原因", ""))[:36])
                记("卡片音效进待手摆不冒充", True, "无技能机不适用,降级表由「降级操作脚本逐镜一行」把关")
                记("待生成素材只进待补", True, "无技能机不适用,降级表由「降级操作脚本逐镜一行」把关")
            r9b = 跑([PY, ROOT / "jy_handoff.py", pj9, "--md-only"])
            md9 = pj9 / "剪映交接.md"
            记("降级操作脚本逐镜一行", r9b.returncode == 0 and md9.exists()
               and md9.read_text(encoding="utf-8").count("\n| 0") >= 3, "剪映交接.md 逐镜行")
            nJ = T / "交接判定项目"; nJ.mkdir(exist_ok=True)
            shutil.copyfile(pj9 / "分镜.csv", nJ / "分镜.csv")
            shutil.copyfile(pj9 / "分镜时间轴.json", nJ / "分镜时间轴.json")
            (nJ / "项目.json").write_text(json.dumps({"media": str(clip), "name": "交接判定"}, ensure_ascii=False), encoding="utf-8")
            (nJ / "转写.json").write_text(json.dumps({"duration": 2, "segments": [
                {"start": 0, "end": 1, "text": "测试"}]}, ensure_ascii=False), encoding="utf-8")
            (nJ / "文案定稿.txt").write_text("测试", encoding="utf-8")
            (nJ / "剪切点清单.json").write_text('{"cuts":[]}', encoding="utf-8")
            shutil.copyfile(clip, nJ / "rough.mp4")
            (nJ / "剪映交接.md").write_text("x", encoding="utf-8")
            n11 = W.next_step(nJ)
            记("只有剪映交接也算交接齐", bool(n11.get("完成")), n11["做"][:22])
            ra = W.action_handoff(nJ, {})
            记("AI交接默认路径不破坏", ra.get("ok") and (nJ / "包装交接.md").exists(), str(ra)[:70])
            # 12 ①-B 讲述生成分镜:词→锚点+原话、素材名→库内路径、没依据的行进备注不瞎编
            pj11 = T / "讲述分镜"; (pj11 / "素材").mkdir(parents=True)
            (pj11 / "项目.json").write_text(json.dumps({"media": str(clip), "name": "讲述"}, ensure_ascii=False), encoding="utf-8")
            (pj11 / "转写.json").write_text(json.dumps({"duration": 9, "segments": [
                {"start": 0, "end": 3, "text": "大专生也能当高级感剪辑师"},
                {"start": 3.2, "end": 6, "text": "那三百天我每天都在练切镜"},
                {"start": 6.2, "end": 9, "text": "先完成再完美"}]}, ensure_ascii=False), encoding="utf-8")
            (pj11 / "素材" / "球场空镜.mp4").write_bytes(b"x")
            d11 = W.sb_draft_from_text(pj11, "从「大专生」开头口播\n三百天那句换球场空镜\n5 秒处再来段口播\n金句「先完成再完美」上大字卡")
            csv11 = d11.get("csv", "")
            记("讲述生成规范草稿", d11.get("镜头数") == 4 and csv11.startswith("镜号,时间码(成片·自动),锚点")
               and "球场空镜.mp4" in csv11 and "那三百天我每天都在练切镜" in csv11
               and "先完成再完美" in csv11 and d11.get("要补", 0) >= 1,
               "镜%s 要补%s" % (d11.get("镜头数"), d11.get("要补")))
            记("时间超范围不瞎编进备注", "超出" in W.sb_draft_from_text(pj11, "300 秒处空镜").get("csv", ""))
            记("讲述稿能通过保存校验", W.storyboard_save(pj11, csv11).get("ok") is True, "表头合格+⚓自动跑")
            记("没转写时讲述被拦", "转写" in W.sb_draft_from_text(T / "没这项目x", "「x」口播").get("error", ""))
            d12 = W.sb_draft_from_text(pj11, "先完成再完美那句做卡片")
            csv12 = d12.get("csv", "")
            记("裸词行自动对句+卡片认大字卡", "先完成再完美" in csv12 and "大字卡" in csv12 and "对到了这句" in csv12, csv12[:80])
            d13 = W.sb_draft_from_text(pj11, "9999分做卡片")
            记("对不上就交代找了啥词不瞎编", "都没对上" in d13.get("csv", "") and "9999" in d13.get("csv", ""), d13.get("csv", "")[:80])
            d14 = W.sb_draft_from_text(pj11, "大专生那句用大字卡，三百天做成图形卡，完美再完成那句来点故障效果")
            csv14 = d14.get("csv", "")
            记("一口气逗号写法自动拆成多镜", d14.get("镜头数") == 3, "镜%s" % d14.get("镜头数"))
            记("故障这类说法进动效包装列", "转场:故障" in csv14, csv14.splitlines()[-1][:70] if csv14 else "")
            记("反过来说的词也能对上原话", "先完成再完美" in csv14, csv14.splitlines()[-1][:70] if csv14 else "")
            d15 = W.sb_draft_from_text(pj11, "300天那句上图形卡")
            记("阿拉伯数字对上汉字口播", "三百天" in d15.get("csv", ""), d15.get("csv", "").splitlines()[-1][:70] if d15.get("csv") else "")
            d16 = W.sb_draft_from_text(pj11, "大专生口播叠化")
            pj12 = T / "话塞进表"; (pj12 / "素材").mkdir(parents=True)
            (pj12 / "项目.json").write_text(json.dumps({"media": str(clip), "name": "话塞进表"}, ensure_ascii=False), encoding="utf-8")
            shutil.copyfile(pj11 / "转写.json", pj12 / "转写.json")
            烂表 = W.sb_header_row() + "\n初步水平用大字卡 ，，三百天做成图形卡，先完成再完美来点故障效果\n"
            rb = W.storyboard_save(pj12, 烂表)
            记("话贴进分镜表被拦并指路讲述框", str(rb.get("error", "")).startswith("没保存")
               and "讲述转分镜" in rb.get("error", "") and not (pj12 / "分镜.csv").exists(),
               (rb.get("error") or "存进去了!!")[:64])
            (pj12 / "分镜.csv").write_text(烂表, encoding="utf-8")
            ra2 = W.action_anchors(pj12, {})
            记("一行镜头没算出不再装成功", str(ra2.get("error", "")).startswith("分镜表读到了"),
               (ra2.get("error") or "居然返回ok")[:64])
            记("没画面类型时仍落口播正面", "口播正面" in d16.get("csv", "") and "转场:叠化" in d16.get("csv", ""), d16.get("csv", "").splitlines()[-1][:70] if d16.get("csv") else "")
            d17 = W.sb_draft_from_text(pj11, "大专生那句弄成那种老片子掉雪花的味道")
            csv17 = d17.get("csv", "")
            记("说不成五类词时原话不被格式吞", "没套上画面五类词" in csv17 and "老片子掉雪花" in csv17
               and "口播正面" not in csv17, csv17.splitlines()[-1][:66] if csv17 else "")
            ha = W._handoff_ai(pj11, {})
            mdh = (pj11 / "包装交接.md").read_text(encoding="utf-8") if ha.get("ok") else ""
            记("交接包写明原话口径与产表要求", "作者原话,不是填错" in mdh and "同表头" in mdh
               and "切镜节奏与字卡密度的参照" in mdh, mdh[-50:] if mdh else "交接包没生成")
            # 13 ①-B「用豆包理解」:密钥只存本机不回显;AI 只填三格,秒数与锚点由本机验;断了必回退并给原因
            真CFG = W.CFG_PATH
            W.CFG_PATH = T / "豆包设置.json"
            W.save_settings({"豆包理解": True, "豆包密钥": "smoke-SECRET-9999", "豆包模型": "doubao-smoke"})
            真求 = W.ark_请求
            def 假豆包(路径, 载荷=None, GET=False, 超时=75):
                if 路径 == "/models":
                    return {"data": [{"id": "doubao-smoke"}, {"id": "doubao-lite-1-5"}, {"id": "别的家的"}]}, ""
                return ({"model": "doubao-smoke", "usage": {"total_tokens": 812}, "choices": [{"message": {"content":
                    "画面内容,动效包装,锚点\n大字卡:先完成再完美压屏,,先完成再完美\n"
                    "图形卡:三百天练习曲线,数字滚动,这句口播里根本没有\n"}}]}, "")
            W.ark_请求 = 假豆包
            回 = W.ark_models({})
            记("拉模型只列豆包顺带验密钥", bool(回.get("ok")) and 回["模型"] == ["doubao-lite-1-5", "doubao-smoke"]
               and 回["总数"] == 3, json.dumps(回, ensure_ascii=False)[:56])
            import csv as _csv0
            da = W.sb_ai_draft(pj11, "大专生那句压一张卡,三百天做成曲线图")
            csva = da.get("csv", "")
            行列表 = list(_csv0.reader(io.StringIO(csva)))
            记("豆包出规范表且不采信它的秒数", da.get("来源") == "豆包" and da.get("镜头数") == 2
               and 行列表[1][1] == "" and "先完成再完美" in csva and (da.get("用量") or {}).get("total_tokens") == 812,
               str(行列表[1][:5])[:56] if len(行列表) > 1 else csva[:56])
            记("豆包编的锚点被本机改命不硬编", len(行列表) > 2 and 行列表[2][2] != "这句口播里根本没有"
               and "本机改用" in (行列表[2][7] if len(行列表[2]) > 7 else ""), str(行列表[2][2:4] + [行列表[2][7]])[:62] if len(行列表) > 2 else "")
            W.ark_请求 = lambda 路径, 载荷=None, GET=False, 超时=75: (None, "连不上豆包接口:URLError(自检模拟)")
            记("豆包断了给原因不静默", str(W.sb_ai_draft(pj11, "随便").get("退回", "")).startswith("连不上豆包"), "")
            W.save_settings({"豆包理解": False})
            记("没开开关一个字不出机器", W.sb_ai_draft(pj11, "随便").get("退回") == "没开「用豆包理解」开关", "")
            泄 = [x for x in (json.dumps(W.settings(), ensure_ascii=False), json.dumps(W.run_doctor(), ensure_ascii=False))
                  if "smoke-SECRET-9999" in x]
            记("密钥不回显不进诊断", not 泄, "泄漏 %d 处" % len(泄))
            W.ark_请求 = 真求
            W.CFG_PATH = 真CFG
            W.ideas_save(pj11, "先完成再完美那句要砸实\n9999那句来个对比条")
            mp = W.ideas_map(pj11, {})
            rs = {x["想法"]: x["落在"] for x in mp.get("结果", [])}
            记("想法箱人话对镜头+对不上不硬编", mp.get("条数") == 2
               and "镜" in rs.get("先完成再完美那句要砸实", "") and "对词" in rs.get("先完成再完美那句要砸实", "")
               and "没对上" in rs.get("9999那句来个对比条", ""), json.dumps(mp.get("结果", []), ensure_ascii=False)[:90])
            W.ideas_save(pj9, "结尾砸个金句卡")
            r9c = 跑([PY, ROOT / "jy_handoff.py", pj9, "--md-only"])
            md9c = (pj9 / "剪映交接.md").read_text(encoding="utf-8") if (pj9 / "剪映交接.md").exists() else ""
            记("想法进剪映降级表包装要求", r9c.returncode == 0 and "包装要求" in md9c
               and "结尾砸个金句卡" in md9c, md9c[:60])
            W.action_handoff(pj11, {})
            hb = (pj11 / "包装交接.md").read_text(encoding="utf-8") if (pj11 / "包装交接.md").exists() else ""
            记("想法进AI交接包成强制要求", "你的包装要求" in hb and "9999那句来个对比条" in hb, hb[:60])
            W.ideas_save(pj11, "完成再完美那句压轴")
            mp2 = W.ideas_map(pj11, {})
            记("长词剥尾巴也能对上句", "镜" in (mp2.get("结果") or [{}])[0].get("落在", ""),
               json.dumps(mp2.get("结果", []), ensure_ascii=False)[:70])
    finally:
        shutil.rmtree(T, ignore_errors=True)

    坏 = [x for x in 结果 if not x[1]]
    print("\n%d 项通过 / %d 项失败" % (len(结果) - len(坏), len(坏)))
    if 坏:
        print("失败项: " + "、".join(x[0] for x in 坏))
        return 1
    print("引擎自检全通过 ✓")
    return 0


if __name__ == "__main__":
    sys.exit(main())
