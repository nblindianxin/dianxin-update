# -*- coding: utf-8 -*-
"""环境诊断:检查这台机器能不能跑通口播工作流(商业化阶段0的 G0 门面前半)。
用法: python scripts/doctor.py          大白话逐项输出,含每项修法
       python scripts/doctor.py --json   结构化输出(工作台顶栏「环境诊断」按钮用)
退出码 0=必需项全过(警告不拦);非 0=有必需项失败。
除写一个临时探针文件确认目录可写(立刻删)外,全程只读,不动任何文件。"""
import argparse, json, os, shutil, subprocess, sys, time, urllib.request
from pathlib import Path

WF = Path(__file__).resolve().parent.parent          # 工作流根目录
PROJ = WF / "工作台" / "项目"                          # 项目文件夹存放处
PORTS = range(9527, 9537)                              # 工作台端口区间(启动会依次试)

try:  # 控制台编码兜底:重定向到 GBK 管道时打 ✓/中文会炸,统一转 utf-8
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def _chk(名, 必需, 状态, 实情, 修法=""):
    return {"名": 名, "必需": 必需, "状态": 状态, "实情": 实情, "修法": 修法}


def _imp(名):
    import importlib.util
    try:
        return importlib.util.find_spec(名) is not None
    except Exception as e:
        print("[诊断:模块探测失败 %s] %r" % (名, e))  # 兜底不许静默,原因要让自检看得见
        return False


def c_python():
    v = sys.version_info
    ok = v >= (3, 9)
    return _chk("Python 版本", True, "通过" if ok else "失败",
                "%d.%d.%d" % v[:3],
                "" if ok else "装 Python 3.10 以上(官网安装包,勾 Add to PATH),装完重开工作台")


def ff版本过旧(首行):
    """G0 实测:ffmpeg 6.0 静态版跑不了引擎的交叉淡化滤镜(报 frame into filter network),9.0.1 可;保守要求主版本>=7。
    读不出版本号时不判旧——宁可放过,误杀会把好机器标成坏机器。"""
    import re as _re
    m = _re.search(r"ffmpeg version\s+n?(\d+)", 首行)
    return bool(m) and int(m.group(1)) < 7


def c_ffmpeg():
    缺 = [n for n in ("ffmpeg", "ffprobe") if not shutil.which(n)]
    if 缺:
        return _chk("视频处理命令 ffmpeg", True, "失败", "找不到:" + "、".join(缺),
                    "装 ffmpeg 并加入 PATH(命令行执行 winget install Gyan.FFmpeg 最省事),装完重开工作台")
    r = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    首行 = (r.stdout or "").splitlines()[0][:60] if r.stdout else "版本号没读到"
    if ff版本过旧(首行):
        return _chk("视频处理命令 ffmpeg", True, "失败", "版本太旧:" + 首行,
                    "引擎交叉淡化需 ffmpeg 7 以上(6.0 实测报错);去 gyan.dev/ffmpeg/builds 下载 full 版,解压后把 bin 目录加入 PATH,重开工作台")
    return _chk("视频处理命令 ffmpeg", True, "通过", 首行)


def c_libs():
    需要 = {"faster_whisper": "faster-whisper(转写)", "numpy": "numpy(找停顿)",
            "PIL": "Pillow(对标拆帧)", "send2trash": "Send2Trash(撤回重置)",
            "opencc": "opencc(锚点简繁归一)"}
    缺 = [v for k, v in 需要.items() if not _imp(k)]
    if 缺:
        return _chk("依赖库", True, "失败", "没装:" + "、".join(缺),
                    "在工作流目录运行: python -m pip install -r requirements.txt")
    return _chk("依赖库", True, "通过", "5 个第三方库全在")


def c_native():
    """G1 实测:干净机 pip 装了 ctranslate2,但缺微软 VC++ 运行库时照样 import 失败——
    find_spec 只能查到"装没装",查不到"能不能跑",必须真 import 一次。
    放子进程里导:就算它把进程弄崩,诊断本身也安然无恙。"""
    try:
        r = subprocess.run([sys.executable, "-c", "import ctranslate2"],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=90)
    except Exception as e:
        return _chk("转写引擎本体可跑", True, "失败", "诊断命令自己没跑起来:%r" % e,
                    "关掉工作台重开一次再按诊断;反复这样就按 🎫 反馈单把原因发给作者")
    if r.returncode == 0:
        return _chk("转写引擎本体可跑", True, "通过", "转写引擎真import成功,能开工")
    err = ((r.stderr or "") + (r.stdout or "")).strip()
    low = err.lower()
    if "dll load failed" in low or "winerror 126" in low or "找不到指定的模块" in err:
        return _chk("转写引擎本体可跑", True, "失败",
                    "缺微软 VC++ 运行库(装好了转写引擎也起不来,②转写会秒失败)",
                    "浏览器打开 aka.ms/vs/17/release/vc_redist.x64.exe 下载,双击安装(UAC 弹窗点【是】),装完重启工作台再按一次诊断")
    return _chk("转写引擎本体可跑", True, "失败", "转写引擎起不来:" + err[:140],
                "在工作流目录运行 python -m pip install -r requirements.txt 后重启工作台;仍失败就按 🎫 反馈单把这段原文发给作者")


def c_model():
    缓存目录 = []
    for env, 子 in (("HUGGINGFACE_HUB_CACHE", ""), ("HF_HOME", "hub")):
        if os.environ.get(env):
            缓存目录.append(Path(os.environ[env]) / 子)
    缓存目录.append(Path.home() / ".cache" / "huggingface" / "hub")
    for hub in 缓存目录:
        try:
            命中 = list(hub.glob("models--Systran--faster-whisper-small/snapshots/*/model.bin"))
        except Exception as e:
            print("[诊断:模型缓存扫描失败] %r" % e)
            continue
        if 命中:
            return _chk("转写模型 small", True, "通过",
                        "已离线缓存(约 %d MB),断网也能转写" % (命中[0].stat().st_size // 1048576))
    return _chk("转写模型 small", True, "警告", "本机没有离线缓存,第一次转写会自动从国内镜像(hf-mirror)下载约461MB,视网速约3~15分钟",
                "想提前备好:联网时在工作流目录运行  python -c \"from faster_whisper import WhisperModel; WhisperModel('small')\"  (作者机实测约 460 MB,下完永久离线)")


def c_port():
    import socket
    占用 = []
    for p in PORTS:
        try:
            raw = urllib.request.urlopen("http://127.0.0.1:%d/" % p, timeout=0.3).read(2000)
            if "口播剪辑工作台".encode("utf-8") in raw:
                return _chk("工作台端口", True, "通过", "工作台已在端口 %d 运行" % p)
            占用.append(str(p))
        except Exception:
            pass
    for p in PORTS:
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", p))
            尾 = ("(注:端口 " + "、".join(占用) + " 被别的程序占着,但 " + str(p) + " 可用,不受影响)") if 占用 else ""
            return _chk("工作台端口", True, "通过", "端口 %d 空闲,可正常启动" % p + 尾)
        except OSError:
            continue
        finally:
            s.close()
    return _chk("工作台端口", True, "警告", "9527-9536 全被别的程序占着(可能装了别的开发工具)",
                "关掉占端口的程序,或启动时用 --port 换个号")


def c_disk():
    太 = shutil.disk_usage(str(WF)).free / 1073741824
    if 太 >= 3:
        return _chk("磁盘空间", True, "通过", "所在盘剩 %.1f GB" % 太)
    if 太 >= 1:
        return _chk("磁盘空间", True, "警告", "只剩 %.1f GB" % 太,
                    "先清磁盘:5 分钟 1080p 粗剪一条最多吃掉约 1 GB(估) [待核实]")
    return _chk("磁盘空间", True, "失败", "只剩 %.1f GB,快满了" % 太,
                "腾空间再剪,不然渲染会中途失败")


def c_write():
    坏 = []
    for d in (PROJ, WF / "工作台"):
        try:
            d.mkdir(parents=True, exist_ok=True)
            t = d / ".doctor_probe.tmp"
            t.write_text("x", encoding="utf-8")
            t.unlink()
        except Exception as e:
            坏.append("%s(%s)" % (d, e.__class__.__name__))
            print("[诊断:写测试失败] %r" % e)
    if 坏:
        return _chk("目录可写", True, "失败", "写不进去:" + "、".join(坏),
                    "把整个工作流文件夹挪到普通目录(避开系统盘受保护位置),或给它加写权限")
    return _chk("目录可写", True, "通过", "项目目录和工作台目录都可写")


def c_node():
    if shutil.which("node"):
        return _chk("网页动效渲染 node", False, "通过", "已装,第④步高级包装可用")
    return _chk("网页动效渲染 node", False, "警告", "未装——只影响第④步高级动效,不影响粗剪出片",
                "需要时去 nodejs.org 装 LTS 版")


def c_clearvoice():
    有库 = _imp("clearvoice")
    有权重 = (WF / "checkpoints" / "MossFormer2_SE_48K").exists()
    if 有库 and 有权重:
        return _chk("人声修复(可选)", False, "通过", "ClearVoice + 权重齐,粗剪可勾「人声修复」")
    return _chk("人声修复(可选)", False, "警告",
                "缺%s" % ("、".join(x for x, bad in (("库", 有库), ("权重", 有权重)) if not bad)),
                "底噪重/有回声才用得上: python -m pip install clearvoice(权重首跑自动下载);不装也能剪")


def c_ai():
    """①-B「用AI理解」+ ⑤助手用的那套接口配置。只报配置与档位,绝不回显密钥。
    立这条的原因(2026-11-15):本机小档跑不动结构化翻译,而客户那边撞了看不出来——
    反馈单里以前没有这项,等于漏口没有眼睛。"""
    设置 = WF / "工作台设置.json"
    if not 设置.exists():
        return _chk("AI 接口配置(可选)", False, "通过", "没配过 AI:①-B 讲述转分镜只用本机词表,一个字不出机器")
    try:
        d = json.loads(设置.read_text(encoding="utf-8"))
    except Exception as e:
        return _chk("AI 接口配置(可选)", False, "警告", "工作台设置.json 读不出来: %r" % e,
                    "删掉这个文件重开工作台会回默认值(项目/素材/卡密都不受影响)")
    开 = bool(d.get("豆包理解"))
    址 = str(d.get("豆包地址") or "")
    模型 = str(d.get("豆包模型") or "")
    本机 = ("127.0.0.1" in 址) or ("localhost" in 址) or (not 址)
    有密 = bool(str(d.get("豆包密钥") or "").strip())
    档 = "1.5B" if "1.5B" in 模型 else ("4B" if "4B" in 模型 else ("8B" if "8B" in 模型 else "?"))
    实情 = "%s | %s | 模型 %s(%s档) | 密钥%s" % (
        "开" if 开 else "关", "本机服务" if 本机 else ("云端 " + 址[:40]), 模型 or "空", 档,
        "已填" if 有密 else "没填(本机服务本来就不用填)")
    if not 开:
        return _chk("AI 接口配置(可选)", False, "通过", 实情 + " —— 开关没开,讲述转分镜走本机词表")
    if 本机 and 档 == "1.5B":
        return _chk("AI 接口配置(可选)", False, "警告", 实情,
                    "本机 1.5B 只够⑤助手问答,干不了①-B 讲述转分镜(实测会抄行号、给每句话配画面,已会自动退回词表但白等几秒):"
                    "换 ①-C「一键装本地AI」的大档(4B 以上,慢但能用),或到 ①-B 改填云端接口地址+密钥(豆包/DeepSeek/Kimi,快)")
    if not 本机 and not 有密:
        return _chk("AI 接口配置(可选)", False, "警告", 实情, "开关开着但没填密钥,云端连不上:填密钥或把开关关掉")
    if not 模型:
        return _chk("AI 接口配置(可选)", False, "警告", 实情, "没填模型名:点①-B「拉模型」选一个")
    return _chk("AI 接口配置(可选)", False, "通过", 实情)


def c_font():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts") as k:
            i = 0
            while True:
                try:
                    n, v, _ = winreg.EnumValue(k, i)
                except OSError:
                    break
                i += 1
                if "Noto Serif SC" in n or "Source Han Serif" in n or "SourceHanSerif" in str(v):
                    return _chk("字幕字体", False, "通过", "本机已装思源宋体系")
        return _chk("字幕字体", False, "警告", "没检测到思源宋体,字幕会回落成系统默认字体",
                    "在意观感就装思源宋体(SIL OFL 许可,免费商用);安装包不捆绑字体")
    except Exception as e:
        print("[诊断:字体注册表读取失败] %r" % e)
        return _chk("字幕字体", False, "警告", "这台机器读不了字体列表(%s),自行确认是否装了思源宋体" % e.__class__.__name__)


def report():
    检查 = [c_python(), c_ffmpeg(), c_libs(), c_native(), c_model(), c_port(), c_disk(), c_write(),
            c_node(), c_clearvoice(), c_font(), c_ai()]
    统 = {"通过": sum(1 for x in 检查 if x["状态"] == "通过"),
          "警告": sum(1 for x in 检查 if x["状态"] == "警告"),
          "失败": sum(1 for x in 检查 if x["状态"] == "失败")}
    return {"检查": 检查, "统计": 统, "必需项全过": 统["失败"] == 0,
            "时间": time.strftime("%Y-%m-%d %H:%M")}


def report_json():
    try:
        return report()
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": "诊断自身崩了: %r(详情已打印)" % e}


def main():
    ap = argparse.ArgumentParser(description="环境诊断(只读)")
    ap.add_argument("--json", action="store_true", help="输出 JSON(工作台界面用)")
    a = ap.parse_args()
    d = report_json()
    if a.json:
        print(json.dumps(d, ensure_ascii=False))
        return 0 if d.get("必需项全过") else 1
    if d.get("error"):
        print("✗ " + d["error"])
        return 1
    print("环境诊断(只读,不改任何文件) — %s" % d["时间"])
    for x in d["检查"]:
        ic = {"通过": "✓", "警告": "⚠", "失败": "✗"}[x["状态"]]
        尾 = "" if x["必需"] else "(可选功能)"
        print("%s %s%s: %s" % (ic, x["名"], 尾, x["实情"]))
        if x["状态"] != "通过" and x["修法"]:
            print("    修:" + x["修法"])
    s = d["统计"]
    print("合计:通过 %d / 警告 %d / 失败 %d" % (s["通过"], s["警告"], s["失败"]))
    return 0 if s["失败"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
