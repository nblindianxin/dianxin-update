# -*- coding: utf-8 -*-
"""体验副本打包:导出"别人干净机器要装的全部"一份副本,用于 G0 在虚拟机/另一台电脑上实测安装流程。
用法: python scripts/export_trial.py     重建 体验副本 目录并压成 体验副本.zip
排除:项目数据(项目/备份)、大模型(checkpoints)、渲染媒体、缓存——新机不需要。
每次重建覆盖旧的(AGENTS 铁律:只保留最新)。"""
import json, shutil, subprocess
import sys
from pathlib import Path

try:  # 控制台编码兜底:GBK 管道下打中文/勾叉不炸
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

WF = Path(__file__).resolve().parent.parent
OUT = WF / "体验副本"
ZIP = WF / "体验副本.zip"

KEEP_FILES = ["Getting_Started.md", "requirements.txt", "LICENSE-NOTES.txt", "分镜镜头表模板.md", "更新源.txt", "给AI看的改造说明书.md", "功能总览.md", "动效包装协议.md"]
KEEP_DIRS = {
    "scripts": lambda p: p.suffix == ".py",
    "工作台": lambda p: p.name in ("workbench.py", "index.html", "启动工作台.cmd", "sitecustomize.py",
                                   "停止工作台.cmd", "隐藏启动.vbs", "confetti.min.js", "app.ico", "app_192.png", "app_512.png", "manifest.webmanifest", "shell.py"),
}


# 作者自用脚本:发卡器与打包器,绝不进任何对外副本(体验副本/便携版/安装包共用 清单() 这一道闸)。
# 发卡只在本机双击 造卡密.cmd;台账在作者机 卡密台账.csv。
自用不发货 = ['scripts/gen_keys.py', 'scripts/build_installer.py', 'scripts/make_update.py', 'scripts/next_key.py', 'scripts/release.py', '发版.cmd']


def 清单():
    out = []
    for f in KEEP_FILES:
        if (WF / f).exists():
            out.append(f)
    for d, keep in KEEP_DIRS.items():
        base = WF / d
        for x in sorted(base.rglob('*')):
            if x.is_file() and '__pycache__' not in x.parts and keep(x):
                rel = x.relative_to(WF).as_posix()
                if rel in 自用不发货:
                    continue        # 2026-10-21 实测:旧包把 gen_keys.py 打进了发货包,客户双击即可自造卡密
                out.append(rel)
    return out


def make_sample(dst):
    """生成 12 秒样例(彩条+正弦底+合成逐词转写),离线确定性产物,给「🎬 试样例」用。"""
    dst.mkdir(parents=True, exist_ok=True)
    v = dst / "样片.mp4"
    if not v.exists() or v.stat().st_size < 2000:
        if not shutil.which("ffmpeg"):
            raise SystemExit("生成样例需要 ffmpeg,请先按 Getting_Started.md 装好")
        r = subprocess.run(["ffmpeg", "-y", "-v", "error",
                            "-f", "lavfi", "-i", "testsrc=size=1080x1920:rate=25:duration=12",
                            "-f", "lavfi", "-i", "sine=frequency=120:sample_rate=48000",
                            "-t", "12", "-c:v", "libx264", "-preset", "veryfast", "-crf", "30",
                            "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(v)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0 or not v.exists() or v.stat().st_size < 2000:
            raise SystemExit("样例视频生成失败: " + ((r.stderr or "").strip()[-160:] or "无输出"))
    tj = dst / "转写.json"
    if not tj.exists():
        句 = ["今天讲新手最容易犯的错", "嗯就是特效堆得越多越好", "其实恰恰相反",
              "观众看的是信息和节奏", "不是数你用了多少转场"]
        segs, t0 = [], 0.3
        for i2, s2 in enumerate(句):
            ws = [{"word": c, "start": round(t0 + k * 0.2, 3), "end": round(t0 + (k + 1) * 0.2, 3),
                  "p": 0.9} for k, c in enumerate(s2)]
            e = t0 + len(s2) * 0.2
            segs.append({"start": round(t0, 3), "end": round(e, 3), "text": s2, "words": ws})
            t0 = e + (0.9 if i2 == 1 else 0.45)
        tj.write_text(json.dumps({"file": str(v), "language": "zh",
                                  "duration": round(t0 + 0.2, 3), "model": "sample",
                                  "device": "cpu", "segments": segs}, ensure_ascii=False),
                      encoding="utf-8")
    return v, tj

def build():
    names = 清单()
    if OUT.exists():
        shutil.rmtree(OUT)               # 同名覆盖,不留旧版
    for rel in names:
        src = WF / rel
        dst = OUT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    sample_dir = OUT / "工作台" / "Getting_Started" / "sample"
    make_sample(sample_dir)
    make_sample(WF / "工作台" / "Getting_Started" / "sample")   # 作者机也补一份,试样例按钮才有米下锅
    if ZIP.exists():
        ZIP.unlink()
    shutil.make_archive(str(WF / "体验副本"), "zip", str(WF), "体验副本")
    mb = sum((OUT / r).stat().st_size for r in names) / 1048576
    mb = sum((OUT / r).stat().st_size for r in names) / 1048576
    print("体验副本就绪:%d 个文件+样例(%.1f MB)" % (len(names), mb))
    print("压缩包:%s" % ZIP)
    return names


if __name__ == "__main__":
    build()
