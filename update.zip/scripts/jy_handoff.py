# -*- coding: utf-8 -*-
"""④ 剪映交接:把工作台产物拼成剪映草稿工程;失败自动降级出逐镜操作脚本 剪映交接.md。

用法: python jy_handoff.py <项目目录> [--draft-root 目录] [--md-only] [--dry] [--skill-root 目录]
  --draft-root  草稿输出根(自检/临时用;默认自动探测本机剪映草稿目录)
  --md-only     只出操作脚本不建草稿
  --dry         只算计划不写任何文件(自检兜底)
末行输出机器行 RESULT {json};workbench 解析它。引擎约定:任何 except 都打印原因,不许静默降级。
输入: 项目.json rough.mp4 分镜.csv 分镜时间轴.json (字幕.srt 可选,缺则按镜头摆字幕)
"""
import argparse, json, os, re, shutil, sys, time, traceback
for _st in (sys.stdout, sys.stderr):
    try:
        _st.reconfigure(encoding="utf-8", errors="replace")
    except Exception as _e:
        print("[输出编码设置失败] %s" % _e)
from pathlib import Path

TIME_FMT = lambda s: ("%.1fs" % s) if s < 60 else ("%d:%04.1f" % (int(s // 60), s % 60))


def result(obj):
    print("RESULT " + json.dumps(obj, ensure_ascii=False))


def split_row(l, md):
    s = l.strip()
    if md:
        return [c.strip() for c in s.strip("|").split("|")] if s.startswith("|") else []
    if not s:
        return []
    return [c.strip().strip('"') for c in re.split(r",", s)]


def find_col(header, keys):
    for i, h in enumerate(header):
        if any(k in h for k in keys):
            return i
    return -1


def load_storyboard(proj):
    """分镜.csv(md或csv) → {镜号: {字幕,素材,动效,画面}} 与表头校验。"""
    raw = (proj / "分镜.csv").read_text(encoding="utf-8-sig")
    lines = raw.splitlines()
    md = any(l.strip().startswith("|") for l in lines[:8])
    header, gi, zi, ci, mi, hi = None, -1, -1, -1, -1, -1
    out = {}
    for l in lines:
        cells = split_row(l, md)
        if not cells or all(not c for c in cells):
            continue
        if header is None:
            if any("镜号" in c for c in cells):
                header = cells
                gi = find_col(header, ("镜号",))
                zi = find_col(header, ("字幕",))
                ci = find_col(header, ("素材",))
                mi = find_col(header, ("动效", "包装"))
                hi = find_col(header, ("画面",))
            continue
        g = lambda i: cells[i] if 0 <= i < len(cells) else ""
        shot = g(gi)
        if not shot:
            continue
        out[shot] = {"字幕": g(zi), "素材": g(ci), "动效": g(mi), "画面": g(hi)}
    return out


CARD_KEYS = ("词卡", "大字卡", "信息条", "数据卡", "图形卡", "音效", "BGM", "金句")


# ---- 转场:技能内置 433 种剪映免费转场(data/transitions.csv),旧表只认死 叠化/闪白 两种 ----
# 写法:动效/包装列里写 转场:名字,可带时长(转场:模糊|0.3s 或 转场:模糊0.3s);
#       不带「转场:」前缀时,整段(|、+、逗号分隔的段)恰好等于标准转场名也算(防误伤画面描述);
#       叠化/闪白 保留旧默认时长(0.4s/0.2s),其余优先用剪映表里的默认时长,查不到按 0.5s。
# 认不出的名字不在这里硬卡:原样交给引擎,引擎写不上会进「待补」清单提示手加——不静默消失。
_TRANS_DEFAULT = {"叠化": "0.4s", "闪白": "0.2s", "闪黑": "0.2s"}
_TN = None  # 合法转场名全集(惰性缓存)
_TD = None  # 转场名 -> 剪映默认时长(如 "0.8s")


def _load_trans_table():
    global _TN, _TD
    if _TN is not None:
        return _TN, _TD
    names, durs = set(), {}
    try:
        sr = skill_root("")
        f = os.path.join(sr, "data", "transitions.csv") if sr else ""
        if f and os.path.exists(f):
            import csv as _csv
            with open(f, encoding="utf-8-sig", newline="") as fh:
                for row in _csv.DictReader(fh):
                    n = (row.get("identifier") or "").strip()
                    if n:
                        names.add(n)
            mf = os.path.join(sr, "scripts", "vendor", "pyJianYingDraft", "metadata", "transition_meta.py")
            if os.path.exists(mf):
                pat = re.compile(r"^\s+(\S+)\s*=\s*TransitionMeta\(\"[^\"]*\",[^,]+,[^,]+,[^,]+,[^,]+,\s*([\d.]+)")
                with open(mf, encoding="utf-8", errors="replace") as mh:
                    for ln in mh:
                        mm = pat.match(ln)
                        if mm:
                            durs[mm.group(1)] = "%.3gs" % float(mm.group(2))
        else:
            print("[转场表没找到] 缺 jianying-editor 技能或 transitions.csv;只认「转场:」前缀写法,名字交给引擎兜底")
    except Exception as e:
        print("[转场表读失败] %s;只认「转场:」前缀写法" % e)
    _TN, _TD = names, durs
    return _TN, _TD


def _norm_trans_name(raw):
    s = re.sub(r"\s+", "", str(raw or "")).strip("。.、,，+")
    if not s:
        return ""
    names = _load_trans_table()[0]
    for cand in (s, "_" + s):
        if cand in names:
            return cand
    return s


def _parse_trans(cell):
    names, durs = _load_trans_table()
    parts = [p.strip() for p in re.split(r"[|+，,]", cell) if p.strip()]
    for i, p in enumerate(parts):
        m = re.match(r"^转场[:：]\s*(.+)$", p)
        if m:
            rest = m.group(1).strip()
            dm = re.search(r"(\d+(?:\.\d+)?)\s*(?:[sS]|秒)\s*$", rest)
            dur = None
            if dm:
                dur = "%.3gs" % float(dm.group(1))
                rest = rest[:dm.start()].strip()
            if not dur and i + 1 < len(parts):
                dm2 = re.match(r"^(\d+(?:\.\d+)?)\s*(?:[sS]|秒)$", parts[i + 1])
                if dm2:
                    dur = "%.3gs" % float(dm2.group(1))
            name = _norm_trans_name(rest)
            if not name:
                return None
            if not dur:
                dur = _TRANS_DEFAULT.get(name) or durs.get(name) or "0.5s"
            return (name, dur)
    for p in parts:
        if p in names:
            return (p, _TRANS_DEFAULT.get(p) or durs.get(p) or "0.5s")
    return None


def parse_fx(cell, shotno):
    d = {"push": None, "trans": None, "cards": []}
    if not cell:
        return d
    pct = re.search(r"(\d{2,3})\s*%", cell)
    if any(k in cell for k in ("推镜", "缓推", "放大", "punch")):
        hi = (int(pct.group(1)) / 100.0) if pct else 1.15
        d["push"] = (min(1.08, hi - 0.02), hi)
    elif any(k in cell for k in ("拉镜", "缓拉")):
        lo = (int(pct.group(1)) / 100.0) if pct else 1.08
        d["push"] = (max(lo, 1.15), lo)
    if "奇推偶拉" in cell and d["push"] is None:
        digits = re.sub(r"\D", "", str(shotno))
        odd = (int(digits) % 2 == 1) if digits else True
        d["push"] = (1.08, 1.15) if odd else (1.15, 1.08)
    tr = _parse_trans(cell)
    if tr:
        d["trans"] = tr
    elif "叠化" in cell:
        d["trans"] = ("叠化", "0.4s")
    elif "闪白" in cell:
        d["trans"] = ("闪白", "0.2s")
    for t in CARD_KEYS:
        if t in cell:
            d["cards"].append(t)
    return d


def load_srt(path, warn):
    cues = []
    try:
        txt = path.read_text(encoding="utf-8-sig", errors="replace")
    except Exception as e:
        print("[字幕.srt读不了] %s" % e)
        warn.append("字幕.srt 读不了(%s),改按镜头摆字幕" % str(e)[:40])
        return cues
    for blk in re.split(r"\n\s*\n", txt.strip()):
        ls = [x for x in blk.splitlines() if x.strip()]
        idx = next((i for i, l in enumerate(ls) if "-->" in l), -1)
        if idx < 0:
            continue
        a, b = [x.strip() for x in ls[idx].split("-->")]

        def sec(t):
            t = t.replace(",", ".")
            p = [float(x) for x in t.split(":")]
            if len(p) == 3:
                return p[0] * 3600 + p[1] * 60 + p[2]
            if len(p) == 2:
                return p[0] * 60 + p[1]
            return p[0]
        try:
            s0, s1 = sec(a), sec(b)
            text = " ".join(ls[idx + 1:]).strip()
            if text and s1 > s0:
                cues.append({"起": s0, "时长": s1 - s0, "文本": text})
        except Exception as e:
            print("[srt块解析失败] %s: %s" % (blk[:40], e))
    return cues


def build_plan(proj, rough, warn, 待补, 待手摆):
    tl = json.loads((proj / "分镜时间轴.json").read_text(encoding="utf-8-sig"))
    sb = load_storyboard(proj)
    total = tl.get("成片总时长") or 0.0
    shots = []
    for r in tl.get("镜") or []:
        if "成片起" not in r or r.get("状态") not in ("ok", "待确认"):
            if r.get("状态") in ("未匹配", "无锚点", "手锁定"):
                待补.append("镜%s 没时间码(状态:%s),回①-B补锚点或手填秒数" % (r.get("镜号"), r.get("状态")))
            continue
        起 = float(r["成片起"])
        止 = float(r.get("成片止") or 0) or 0.0
        if 止 <= 起:
            止 = float(total) if total and float(total) > 起 else 起 + 2.0
            warn.append("镜%s 缺成片止,按片尾/2秒兜底" % r.get("镜号"))
        shotno = str(r.get("镜号"))
        row = sb.get(shotno) or {}
        fx = parse_fx(row.get("动效", ""), shotno)
        s = {"镜号": shotno, "起": round(起, 3), "止": round(止, 3),
             "字幕": row.get("字幕", "") or "", "画面": row.get("画面", "") or "",
             "素材": "", "push": fx["push"], "trans": fx["trans"], "cards": fx["cards"]}
        mat = (row.get("素材", "") or "").strip()
        if mat:
            if mat.startswith("待生成"):
                待补.append("镜%s %s" % (shotno, mat))
            elif os.path.isabs(mat) and os.path.exists(mat):
                if os.path.normcase(mat) != os.path.normcase(str(rough)):
                    s["素材"] = mat
            else:
                待补.append("镜%s 素材不存在: %s" % (shotno, mat))
        for t in fx["cards"]:
            待手摆.append("镜%s %s(%s)" % (shotno, t, (row.get("动效", "") or "")[:24]))
        shots.append(s)
    if not shots:
        raise RuntimeError("分镜时间轴.json 里没有可换算的镜(全是未匹配/手锁定)")
    if total:
        cap = float(total)
        for s in shots:
            if s["止"] > cap + 0.05:
                s["止"] = round(cap, 3)
    srtf = proj / "字幕.srt"
    subs = load_srt(srtf, warn) if srtf.exists() else []
    if not subs:
        for s in shots:
            if s["字幕"]:
                subs.append({"起": s["起"], "时长": round(s["止"] - s["起"], 3), "文本": s["字幕"]})
        warn.append("没有 字幕.srt,按镜头粒度摆字幕轨;若第③步已烧录字幕,在剪映删掉这条轨以免双层")
    else:
        warn.append("字幕轨来自 字幕.srt;若第③步已烧录字幕进画面,请在剪映删掉这条轨以免双层")
    return {"项目名": "", "shots": shots, "subs": subs, "总时长": float(total or max(s["止"] for s in shots))}


def 读想法(proj):
    f = proj / "包装想法.txt"
    if not f.exists(): return []
    return [x.strip() for x in f.read_text(encoding="utf-8-sig").splitlines() if x.strip()]


def write_md(proj, plan, reason, stats=None, 待补=None, 待手摆=None):
    L = ["# 剪映交接操作表(工作台生成)", ""]
    L.append("生成时间: %s" % time.strftime("%Y-%m-%d %H:%M:%S"))
    if reason:
        L.append("")
        L.append("**本轮没直接生成草稿,原因: %s**" % reason)
        L.append("处理建议见文末;本表可先在剪映手动照摆,修好原因后重按「生成交接包」即可出真草稿。")
    L.append("")
    L.append("- 画幅:竖屏 1080x1920;主轨=粗剪 rough.mp4 按镜分段;转场支持剪映全部免费库(动效列写 转场:名字|时长,认不出的列在文末待补,手加);字幕位置一律下沿:横屏底边留8%、竖屏底边留20%(2026-11-02修订铁律v2,正中退役)。")
    L.append("- 粗剪已定,改剪切请回工作台重跑③-D,再重新生成本表。")
    L.append("")
    L.append("| 镜号 | 成片时间码 | 画面内容 | 素材文件 | 转场/推镜 | 字幕文本 | 待手摆 |")
    L.append("|---|---|---|---|---|---|---|")
    for s in plan["shots"]:
        tm = []
        if s["trans"]:
            tm.append(s["trans"][0])
        if s["push"]:
            tm.append("推镜 %.0f%%→%.0f%%" % (s["push"][0] * 100, s["push"][1] * 100))
        L.append("| %s | %s–%s | %s | %s | %s | %s | %s |" % (
            s["镜号"], TIME_FMT(s["起"]), TIME_FMT(s["止"]), s["画面"] or "口播正面",
            s["素材"] or "-", " ".join(tm) or "-", s["字幕"][:28], ",".join(s["cards"]) or "-"))
    想 = 读想法(proj)
    if 想:
        L.append("")
        L.append("## 包装要求(想法箱原话,摆的时候逐条落实,做不了的写一句原因)")
        L += ["- " + x for x in 想]
    L.append("")
    L.append("## 待手摆清单(词卡/大字卡/音效这类 v1 不自动摆)")
    L += ["- " + x for x in (待手摆 or ["(无)"])]
    L.append("")
    L.append("## 待补/待处理")
    L += ["- " + x for x in (待补 or ["(无)"])]
    if stats:
        L.append("")
        L.append("统计: " + json.dumps(stats, ensure_ascii=False))
    (proj / "剪映交接.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return str(proj / "剪映交接.md")


def skill_root(opt):
    cands = [opt, os.environ.get("JY_SKILL_ROOT", ""),
             os.path.expanduser(os.path.join("~", ".codex", "skills", "jianying-editor"))]
    for c in filter(None, cands):
        if os.path.exists(os.path.join(c, "scripts", "jy_wrapper.py")):
            return os.path.abspath(c)
    return None


def build_draft(proj, rough, plan, draft_root, warn, 待补, dry=False):
    sr = skill_root("")
    if not sr:
        raise RuntimeError("没找到 jianying-editor 技能(设 JY_SKILL_ROOT 环境变量指向技能根)")
    scripts = os.path.join(sr, "scripts")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    os.environ["JY_SKILL_ROOT"] = sr
    from jy_wrapper import JyProject
    import pyJianYingDraft as draft
    from pyJianYingDraft import KeyframeProperty as KP, Keyframe

    meta_name = ""
    try:
        meta_name = json.loads((proj / "项目.json").read_text(encoding="utf-8-sig")).get("name", "")
    except Exception as e:
        print("[项目.json读不了] %s" % e)
    name = "口播_" + re.sub(r'[\\/:*?"<>|\s]', "", str(meta_name or proj.name))[:28]
    p = JyProject(name, width=1080, height=1920,
                  drafts_root=(draft_root or None), overwrite=True)
    try:
        p.script.add_track(draft.TrackType.video, "覆盖", relative_index=1)
    except Exception as e:
        print("[覆盖轨预建失败] %s" % e)
    nseg = nkf = ntn = nov = nsub = 0
    for s in plan["shots"]:
        seg = p.add_media_safe(str(rough), s["起"], round(s["止"] - s["起"], 3), "主轨", source_start=s["起"])
        if seg is None:
            待补.append("镜%s 主轨段没摆上(素材读不了)" % s["镜号"])
            continue
        nseg += 1
        if s["push"]:
            try:
                t0 = int(s["起"] * 1000000) + 1000
                t1 = int(s["止"] * 1000000) - 1000
                seg.add_keyframe(KP.uniform_scale, t0, s["push"][0], **Keyframe.EASE_IN_OUT)
                seg.add_keyframe(KP.uniform_scale, t1, s["push"][1], **Keyframe.EASE_IN_OUT)
                nkf += 1
            except Exception as e:
                print("[关键帧失败 镜%s] %s" % (s["镜号"], e))
                待补.append("镜%s 关键帧没加上: %s" % (s["镜号"], str(e)[:40]))
        if s["trans"]:
            try:
                got = p.add_transition_simple(s["trans"][0], video_segment=seg, duration=s["trans"][1])
            except Exception as e:
                print("[转场异常 镜%s] %s" % (s["镜号"], e))
                got = None
            if got:
                ntn += 1
            else:
                待补.append("镜%s 转场「%s」没解析出来,手加" % (s["镜号"], s["trans"][0]))
        if s["素材"]:
            ov = p.add_media_safe(s["素材"], s["起"], round(s["止"] - s["起"], 3), "覆盖")
            if ov is None:
                待补.append("镜%s 素材没摆上: %s" % (s["镜号"], s["素材"]))
            else:
                nov += 1
    font = None
    try:
        for mem in draft.FontType:
            probe = str(getattr(mem, "name", "")) + str(getattr(mem, "value", ""))
            if "思源" in probe or "宋体" in probe:
                font = mem
                break
    except Exception as e:
        print("[字体枚举探测失败] %s" % e)
    if font is None:
        warn.append("没在剪映字体表找到思源/宋体,字幕用剪映默认字体(可在剪映里全选字幕一次性替换)")
    for c in plan["subs"]:
        kw = {"font": font} if font else {}
        try:
            p.add_text_simple(c["文本"], c["起"], max(0.3, c["时长"]), "字幕", **kw)
            nsub += 1
        except Exception as e1:
            print("[字幕带字体失败,回落默认] %s" % e1)
            try:
                p.add_text_simple(c["文本"], c["起"], max(0.3, c["时长"]), "字幕")
                nsub += 1
            except Exception as e2:
                print("[字幕失败] %s: %s" % (c["文本"][:12], e2))
                待补.append("字幕没上: %s(%s)" % (c["文本"][:12], str(e2)[:30]))
    stats = {"主轨段数": nseg, "素材行数": nov, "字幕条数": nsub, "关键帧段数": nkf, "转场数": ntn}
    if dry:
        return stats, None
    p.save()
    draft_dir = os.path.join(p.root, p.name)
    return stats, {"草稿名": p.name, "草稿目录": draft_dir}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("proj")
    ap.add_argument("--draft-root", default="")
    ap.add_argument("--md-only", action="store_true")
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()
    proj = Path(a.proj)
    rough = proj / "rough.mp4"
    cf, tlf = proj / "分镜.csv", proj / "分镜时间轴.json"
    if not rough.exists():
        result({"ok": False, "mode": "missing", "error": "缺少 rough.mp4:先完成③-D出片"})
        sys.exit(1)
    if not cf.exists() or not tlf.exists():
        result({"ok": False, "mode": "missing", "error": "缺少 分镜.csv 或 分镜时间轴.json:先去①-B写镜头表并保存(自动算秒)"})
        sys.exit(1)
    if cf.stat().st_mtime > tlf.stat().st_mtime:
        result({"ok": False, "mode": "missing", "error": "分镜表比时间轴新:回工作台点「保存镜头表」或「⚓ 按锚点重算时间码」再来"})
        sys.exit(1)
    warn, 待补, 待手摆 = [], [], []
    try:
        plan = build_plan(proj, rough, warn, 待补, 待手摆)
    except Exception as e:
        traceback.print_exc()
        result({"ok": False, "mode": "missing", "error": "拼剪映计划失败: %s" % str(e)[:200]})
        sys.exit(1)
    if a.dry:
        result({"ok": True, "mode": "dry", "统计": {"镜头数": len(plan["shots"]), "字幕条数": len(plan["subs"])},
                "待手摆": 待手摆, "待补": 待补, "警告": warn})
        sys.exit(0)
    if a.md_only:
        write_md(proj, plan, "按参数指定只出操作脚本(未建草稿)", None, 待补, 待手摆)
        result({"ok": True, "mode": "md", "文件": str(proj / "剪映交接.md"), "待手摆": 待手摆, "警告": warn})
        sys.exit(0)
    try:
        stats, outinfo = build_draft(proj, rough, plan, a.draft_root, warn, 待补, dry=False)
        if not outinfo:
            raise RuntimeError("草稿没生成(未知原因)")
        manifest = dict(outinfo)
        manifest.update({
            "打开方式": "剪映→草稿列表找「%s」:轨道=主轨(按镜分段)+覆盖(素材)+字幕;词卡/音效按待手摆清单加" % outinfo["草稿名"],
            "统计": stats, "待手摆清单": 待手摆, "待补素材": 待补, "警告": warn,
            "包装要求": 读想法(proj),
            "生成时间": time.strftime("%Y-%m-%d %H:%M:%S")})
        (proj / "剪映交接.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
        result({"ok": True, "mode": "draft", "文件": str(proj / "剪映交接.json"),
                "草稿目录": outinfo["草稿目录"], "统计": stats, "警告": warn})
        sys.exit(0)
    except PermissionError as e:
        print("[草稿被占用] %s" % e)
        write_md(proj, plan, "剪映正打开这份草稿,自动释放失败:请关闭剪映(或切回主界面)后再生成", None, 待补, 待手摆)
        result({"ok": False, "mode": "md", "降级": True, "原因": "草稿被剪映占用", "文件": str(proj / "剪映交接.md")})
        sys.exit(0)
    except Exception as e:
        traceback.print_exc()
        write_md(proj, plan, "生成草稿失败: %s" % str(e)[:180], None, 待补, 待手摆)
        result({"ok": False, "mode": "md", "降级": True, "原因": str(e)[:200], "文件": str(proj / "剪映交接.md")})
        sys.exit(0)


if __name__ == "__main__":
    main()
