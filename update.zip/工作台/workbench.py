# -*- coding: utf-8 -*-
"""口播剪辑工作台。启动: python workbench.py(自动开浏览器, http://127.0.0.1:8765)
依赖同套件 ../scripts 下三个脚本 + faster-whisper + ffmpeg,均为本机已有。"""
import argparse, json, os, re, shutil, subprocess, sys, threading, time, traceback, webbrowser, urllib.request
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote, quote

ROOT = Path(__file__).resolve().parent
WF = ROOT.parent
SCRIPTS = WF / "scripts"
PROJ_ROOT = ROOT / "项目"
VERSION = "0.7(2026-10-23,工作台界面摆盘:毛玻璃顶栏+胶囊页签+卡片层次,顶栏版本号清爽常显)"     # 顶栏显示,随 /api/queue 下发;发包时同步打 git tag 对账
STATEF = ROOT / "任务状态.json"   # 在跑任务的活体记录:工作台没了而 ffmpeg 还活着时由启动收尸用
LOGF = ROOT / "运行日志.jsonl"    # 售后证据:入队/开始/结束/取消/接口异常逐条落盘(纯本地,不外发)
INTERRUPTED = []                  # 本次启动清理掉的上次中断任务(给前端弹提醒)
PY = sys.executable
JOBS = {}                       # 任务状态表(带锁):key=项目目录
_QUEUE = []                     # 待跑任务(简单列表即可,单工作线程串行消费)
_LOCK = threading.Lock()
_WORKER = [None]
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm"}

启动时刻 = time.time()

更新源 = WF / "更新源.txt"      # 发版时随包更新:第1行=版本号或版本信息URL,第2行=下载页,第3行起=更新日志
# ―― 联网自动更新:作者把 update.txt + update.zip 传到下面这个 GitHub 仓库即全网生效 ――
UPDATE检查仓库 = "nblindianxin/dianxin-update"
UPDATE_CHECK_URL = "https://cdn.jsdelivr.net/gh/" + UPDATE检查仓库 + "@main/update.txt"
更新源可信用户 = UPDATE检查仓库.split("/")[0]
更新源可信前缀 = ("https://cdn.jsdelivr.net/gh/" + 更新源可信用户 + "/",
                "https://raw.githubusercontent.com/" + 更新源可信用户 + "/",
                "https://github.com/" + 更新源可信用户 + "/")

def 可信更新地址(u):
    """只认作者这一个仓库的 https 直链——别的一律拒绝,防止有人伪造下载地址远程装代码。"""
    return isinstance(u, str) and u.startswith(更新源可信前缀)

更新镜像基址 = ("https://cdn.jsdelivr.net/gh/" + UPDATE检查仓库 + "@main",
              "https://raw.githubusercontent.com/" + UPDATE检查仓库 + "/main")

def _镜像替换(url):
    """把一个可信镜像地址换算成所有可信镜像的同一尾路径,供检查/下载逐个重试(某个镜像被墙就换下一个)。"""
    for b in 更新镜像基址:
        if url.startswith(b):
            尾 = url[len(b):]
            return [bb + 尾 for bb in 更新镜像基址]
    return [url]

def 版本解析(s):
    """'0.2(2026-10-18,...)' → (0,2);取开头数字段按数字比大小(0.10 必须大于 0.9,不能按字符串比)。"""
    import re as _re
    m = _re.match(r"\s*v?(\d+(?:\.\d+)*)", str(s or ""))
    return tuple(int(x) for x in m.group(1).split(".")) if m else ()

def update_check():
    """检查更新:按镜像顺序联网读作者发布源(先 jsDelivr,失败自动换 GitHub raw),全不可达或已关闭则回退本机 更新源.txt。
    只读一个小文本,不动用户任何文件;联网失败静默回退,绝不弹假更新。UPDATE_CHECK_URL 置空=只用本机(自检/离线)。"""
    try:
        文 = None; 基 = ""
        if UPDATE_CHECK_URL:
            候选 = [UPDATE_CHECK_URL]
            for b in 更新镜像基址:
                u = b + "/update.txt"
                if u not in 候选:
                    候选.append(u)
            import urllib.request
            for u in 候选:
                if not 可信更新地址(u):
                    continue
                try:
                    req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
                    with urllib.request.urlopen(req, timeout=15) as r:
                        文 = r.read().decode("utf-8-sig", "replace")
                    基 = u[:u.rindex("/update.txt")]
                    break
                except Exception as e:
                    print("[更新源该镜像不可达,试下一个] %s -> %r" % (u[:48], e))
        if 文 is None:
            基 = ""
            if not 更新源.exists():
                return {"有更新": False, "状态": "未配置", "当前": VERSION,
                        "说明": "更新源.txt 不存在——作者发新版时会带上它,现在按本机版本用"}
            字 = 更新源.read_bytes()
            try:
                文 = 字.decode("utf-8-sig")
            except UnicodeDecodeError:
                文 = 字.decode("gbk", "replace")
        raw = [x.strip() for x in 文.splitlines()]
        最新 = raw[0] if raw else ""
        if 基:
            地址 = 基 + "/update.zip"
        else:
            地址 = raw[1] if len(raw) > 1 else ""
        日志 = "\n".join(x for x in raw[2:] if x)
        if not 版本解析(最新):
            return {"有更新": False, "状态": "更新源读不懂", "当前": VERSION,
                    "说明": "第一行没有版本号(现在:" + (最新[:30] or "空") + ")"}
        有 = 版本解析(最新) > 版本解析(VERSION)
        一键 = bool(有 and 可信更新地址(地址))
        return {"有更新": 有, "状态": "有新版可装" if 有 else "已是最新", "当前": VERSION,
                "最新": 最新, "地址": 地址, "日志": 日志, "可一键": 一键}
    except Exception as e:
        print("[检查更新失败] %r" % e)
        return {"有更新": False, "状态": "检查失败", "当前": VERSION, "说明": repr(e)[:150]}


# —— 增量更新:装 scripts/make_update.py 产的小「更新包」,客户不用重下 500MB 大包 ——
补丁根白名单 = {"更新源.txt", "黑名单.txt", "功能总览.md", "工作流说明.md", "给AI看的改造说明书.md",
              "分镜镜头表模板.md", "Getting_Started.md", "LICENSE-NOTES.txt", "动效包装协议.md"}
补丁禁止段 = {"项目", "备份", "__pycache__", "Getting_Started", ".runtime",
              "license.json", "任务状态.json", "运行日志.jsonl", "说明自检.txt", "启动日志.txt"}

def 更新包准入(n):
    """更新包 zip 里一个成员能否落盘:None=放行,否则给拒绝理由(防恶意/手改的包写到别处)。"""
    seg = str(n).split("/")
    if "\\" in n or ":" in n or n.startswith("/") or any(s in ("", ".", "..") for s in seg):
        return "路径不是干净的相对路径: %s" % n[:40]
    if any(s in 补丁禁止段 for s in seg):
        return "禁止触碰项目数据/运行区: %s" % n[:40]
    if len(seg) == 1:
        return None if n in 补丁根白名单 else "根文件不在白名单: %s" % n[:40]
    if seg[0] == "scripts":
        return None if (len(seg) == 2 and n.endswith(".py")) else "scripts 只允许根级 .py: %s" % n[:40]
    if seg[0] == "工作台":
        return None
    return "位置不认识,拒绝写入: %s" % n[:40]

def apply_update(数据, 根=None):
    """装更新包(zip 字节):整包校验→旧文件备份→就地覆盖。任何校验不过,一个文件都不碰;
    备份/写入全部读进内存后才动手,zip 中途损坏不会半装。根默认 WF,自检可传临时目录。"""
    import io as _io, zipfile as _zip
    根 = Path(根) if 根 else WF
    try:
        zf = _zip.ZipFile(_io.BytesIO(数据))
    except Exception as e:
        print("[更新包读不了] %r" % e)
        return {"error": "不是能打开的 zip 更新包: " + repr(e)[:120]}
    名 = [n for n in zf.namelist() if not n.endswith("/")]
    if "补丁清单.json" not in 名:
        zf.close()
        return {"error": "不是官方更新包(缺补丁清单.json)——请找作者重发"}
    件 = [n for n in 名 if n != "补丁清单.json"]
    歪 = []
    for n in 件:
        r = 更新包准入(n)
        if r:
            歪.append(r)
    if 歪:
        zf.close()
        return {"error": "更新包里有不能写的东西:" + "; ".join(歪[:3])}
    try:
        信息 = json.loads(zf.read("补丁清单.json").decode("utf-8-sig"))
        存 = {n: zf.read(n) for n in 件}
    except Exception as e:
        zf.close()
        print("[更新包内容坏了] %r" % e)
        return {"error": "更新包内容读不出来(zip 可能截断): " + repr(e)[:120]}
    zf.close()
    if not 存:
        return {"error": "更新包里没有任何文件"}
    if 根 == WF and 版本解析(信息.get("版本")) and 版本解析(信息.get("版本")) <= 版本解析(VERSION):
        print("[更新包版本不比本机新] 包 %s ≤ 本机 %s——照常装(修复场景)" % (信息.get("版本"), VERSION))
    印戳 = time.strftime("%Y-%m-%d_%H%M%S")
    备份根 = 根 / "备份" / ("更新前-" + 印戳)
    写 = []
    try:
        for n, b in 存.items():
            dst = 根.joinpath(*n.split("/"))
            if dst.exists():
                bk = 备份根.joinpath(*n.split("/"))
                bk.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, bk)
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(b)
            写.append(n)
    except Exception as e:
        print("[更新包装到一半] 已写 %d/%d 后炸: %r" % (len(写), len(存), e))
        return {"error": "安装中断(第 %d/%d 个): %r——旧文件已备份在 备份\\更新前-*,把这条发给作者" % (len(写), len(存), e)}
    slog("更新包已装", "", "%d 个文件 → 版本 %s" % (len(写), 信息.get("版本", "?")))
    return {"ok": True, "个数": len(写), "版本": 信息.get("版本", ""), "日志": 信息.get("日志", ""),
            "备份": str(备份根)}

def apply_update_from_url(url):
    """从可信地址下载更新包交给 apply_update 走全量校验。非可信源直接拒;某个镜像下载失败自动换下一个可信镜像重试。"""
    if not 可信更新地址(url):
        print("[更新拒绝] 下载地址不在作者可信仓库:", str(url)[:120])
        return {"error": "下载地址不是作者的可信仓库,拒绝自动更新"}
    import urllib.request
    最后错 = None
    for cu in _镜像替换(url):
        if not 可信更新地址(cu):
            continue
        try:
            req = urllib.request.Request(cu, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=90) as r:
                数据 = r.read(64 * 1024 * 1024 + 1)
            if len(数据) > 64 * 1024 * 1024:
                return {"error": "更新包过大(>64MB),拒绝下载"}
            return apply_update(数据)
        except Exception as e:
            print("[镜像下载失败,试下一个] %s -> %r" % (cu[:48], e))
            最后错 = e
    return {"error": "下载更新包失败(所有可信镜像都连不上):" + repr(最后错)[:120]}


def backend_stale():
    """workbench.py 比本进程启动时间还新 = 代码改了但没重启,界面是新的、后端行为还是旧的。
    这种情况必须明说,否则人会以为改动被撤销了。"""
    try:
        return (ROOT / "workbench.py").stat().st_mtime > 启动时刻 + 1
    except Exception as e:
        print("[版本检查失败] %s" % e)
        return False


def meta_of(proj):
    f = Path(proj) / "项目.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None

def job_key(proj): return str(Path(proj))

def slog(动作, 项目="", 详情=""):
    """运行日志:一行一条 JSON,是反馈单/售后判定的底料。写不进必须喊出来,不许静默。"""
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": time.strftime("%Y-%m-%d %H:%M:%S"), "动作": 动作,
                                "项目": Path(项目).name if 项目 else "",
                                "详情": str(详情)[:300]}, ensure_ascii=False) + "\n")
        if LOGF.exists() and LOGF.stat().st_size > 2097152:      # 超 2MB 留最近一半
            keep = LOGF.read_text(encoding="utf-8").splitlines()[-3000:]
            LOGF.write_text("\n".join(keep) + "\n", encoding="utf-8")
    except Exception as e:
        print("[运行日志写不进] %r" % (e,), flush=True)

def server_running():
    """有没有别的活工作台在跑(按页面签名认,不认"端口有响应"——别的程序占了 9527 不算)。"""
    for p in range(9527, 9537):
        try:
            raw = urllib.request.urlopen("http://127.0.0.1:%d/" % p, timeout=0.5).read(2000)
            if "口播剪辑工作台".encode("utf-8") in raw: return True
        except Exception:
            continue
    return False


def reap_interrupted():
    """启动收尸:只在确认没有别的工作台实例活着时才动手(活实例的任务记录归它,杀=误伤,删=丢账)。
    记录怎么坏都不许把启动卡死:pid 解析失败就跳过杀进程,中断照常上报。"""
    global INTERRUPTED
    if not STATEF.exists(): return []
    if server_running():
        print("[收尸跳过] 另一个工作台实例在跑,任务记录归它管", flush=True)
        return []
    st = {}
    try:
        st = json.loads(STATEF.read_text(encoding="utf-8"))
    except Exception as e:
        print("[任务状态文件读不了,按中断处理] %r" % (e,), flush=True)
    STATEF.unlink(missing_ok=True)
    pid = 0
    try:
        pid = int(st.get("pid") or 0)
    except Exception as e:
        print("[状态里 pid 字段非法,不杀任何进程] %r" % (e,), flush=True)
    proj = str(st.get("项目", "") or "未知项目")
    nm = str(st.get("名", ""))
    if pid and nm:
        row = ""
        try:
            r = subprocess.run(["tasklist", "/FI", "PID eq %d" % pid, "/NH"], capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=10)
            row = r.stdout or ""
        except Exception as e:
            print("[进程探测失败] %r" % (e,), flush=True)
        if nm.split(".")[0].lower() in row.lower():
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=15)
                slog("收尸", proj, "杀掉上次遗留进程 %s(%s)" % (pid, nm))
            except Exception as e:
                slog("收尸失败", proj, repr(e))
        else:
            slog("启动", proj, "记录里的进程 %s 不在或名字对不上,不杀" % pid)
    INTERRUPTED.append(Path(proj).name + "(" + str(st.get("步", "")) + ")")
    slog("启动", proj, "发现上次中断任务")
    print("[启动提醒] 上次任务被中断: " + "、".join(INTERRUPTED), flush=True)
    return INTERRUPTED


def _log(k, line):
    with _LOCK:
        j = JOBS.get(k)
        if not j: return
        j["log"].append(line)
        if len(j["log"]) > 300: j["log"] = j["log"][-300:]

def _worker():
    while True:
        job = None
        with _LOCK:                      # 只在真的取任务时持锁,空闲时绝不霸锁
            if _QUEUE: job = _QUEUE.pop(0)
        if job is None:
            time.sleep(0.35); continue
        k = job["key"]
        with _LOCK:
            j = JOBS.get(k)
            if not j: continue
            if j.get("cancel"): j["status"] = "已取消"; continue
            j["status"] = "运行中"; j["started"] = time.time()
        ok = True
        for cmd in job["cmds"]:
            with _LOCK:
                if JOBS[k].get("cancel"): ok = False
            if not ok: break
            _log(k, "$ " + " ".join(str(c) for c in cmd))
            try:
                pr = subprocess.Popen([str(c) for c in cmd], stdout=subprocess.PIPE,
                                      stderr=subprocess.STDOUT, text=True,
                                      encoding="utf-8", errors="replace")
                with _LOCK: JOBS[k]["proc"] = pr
                try:
                    STATEF.write_text(json.dumps({"pid": pr.pid, "项目": k, "步": job.get("label", ""),
                                                  "名": Path(str(cmd[0])).name}, ensure_ascii=False),
                                      encoding="utf-8")
                except Exception as e: _log(k, "[任务状态写不进] " + repr(e))
                slog("任务开始", k, job.get("label", ""))
                try:
                    # 2026-10-19 改流式逐行读:旧写法 communicate 要等引擎整个跑完才一次性吐,
                    # 粗剪 1~5 分钟里日志框全空,人以为点了没反应。现在引擎印一行,日志框进一行。
                    for ln in (pr.stdout or []):
                        _log(k, ln.rstrip("\n"))
                    pr.wait(timeout=job.get("timeout", 3600))
                except subprocess.TimeoutExpired:
                    pr.kill()
                    try: pr.wait(timeout=10)
                    except Exception: pass
                    _log(k, "[超时中止] 单步超过 %d 秒,已杀掉进程" % job.get("timeout", 3600))
                    ok = False
                if pr.returncode != 0 and ok: ok = False
            except Exception as e:
                _log(k, "[异常] " + str(e)); ok = False
            finally:
                with _LOCK: JOBS[k]["proc"] = None
                try: STATEF.unlink(missing_ok=True)
                except Exception as e: _log(k, "[任务状态清不掉] " + repr(e))
            if not ok: break
        with _LOCK:
            j = JOBS.get(k) or {}
            j["ended"] = time.time()
            if j.get("cancel"): j["status"] = "已取消"
            else: j["status"] = "完成" if ok else "失败"
        slog("任务结束", k, j.get("status", ""))
        if ok and job.get("on_done"):
            try: job["on_done"]()
            except Exception as e: _log(k, "[收尾异常] " + str(e))

def _ensure_worker():
    with _LOCK:
        if _WORKER[0] and _WORKER[0].is_alive(): return
        _WORKER[0] = threading.Thread(target=_worker, daemon=True)
        _WORKER[0].start()

def start_job(proj, cmds, label="", on_done=None, timeout=3600):
    """cmds: 一条命令,或按顺序跑的命令列表。排队串行跑,不再互相抢 CPU。"""
    if cmds and isinstance(cmds[0], (str, Path)): cmds = [cmds]
    k = job_key(proj)
    with _LOCK:
        cur = JOBS.get(k)
        if cur and cur.get("status") in ("排队中", "运行中"):
            return {"error": "这个项目已有任务在跑(等它完成或点「停止任务」)"}
        JOBS[k] = {"status": "排队中", "log": [], "label": label, "cancel": False,
                   "proc": None, "started": 0}
        _QUEUE.append({"key": k, "cmds": cmds, "on_done": on_done, "timeout": timeout})
        pos = len(_QUEUE)
    _ensure_worker()
    slog("入队", k, label)
    if pos > 1: _log(k, "[排队] 前面还有 %d 个任务" % (pos - 1))
    return {"ok": True, "排队位": pos}

def job_view(proj):
    k = job_key(proj)
    with _LOCK:
        j = JOBS.get(k)
        if not j: return {"status": "空闲", "log": []}
        return {"status": j["status"], "label": j.get("label", ""), "log": list(j["log"][-60:]),
                "已用秒": round(time.time() - j["started"], 1) if j.get("started") else 0,
                "排队在前": max(0, len(_QUEUE) - (0 if j["status"] != "排队中" else 1))}

def queue_view():
    with _LOCK:
        run = [{"项目": Path(k).name, "状态": v["status"], "步": v.get("label", "")}
               for k, v in JOBS.items() if v.get("status") in ("运行中", "排队中")]
        run.sort(key=lambda x: x["状态"] != "运行中")
        return {"在跑/排队": run, "队列长度": len(_QUEUE), "版本": VERSION,
                "上次中断": list(INTERRUPTED)}

def cancel_job(proj):
    k = job_key(proj)
    with _LOCK:
        j = JOBS.get(k)
        if not j or j["status"] not in ("排队中", "运行中"): return {"error": "该项目没有进行中的任务"}
        j["cancel"] = True; pr = j.get("proc")
    if pr:
        try: pr.kill()
        except Exception: pass
    _log(k, "[已请求停止] 正在终止当前进程")
    slog("取消", k, "用户点了停止")
    return {"ok": True}

CFG_PATH = ROOT / "工作台设置.json"
CFG_DEFAULT = {"自动转写": True, "自动算秒": True}

def settings():
    """读工作台全局开关;文件坏了不拦路,回默认值并把原因打出来(不许静默)。"""
    out = dict(CFG_DEFAULT)
    if not CFG_PATH.exists(): return out
    try:
        d = json.loads(CFG_PATH.read_text(encoding="utf-8"))
        if not isinstance(d, dict): raise ValueError("内容不是对象")
    except Exception as e:
        print("[设置读不了] %s: %s —— 本次按默认值跑" % (CFG_PATH, e))
        return out
    for k in CFG_DEFAULT:
        if k in d: out[k] = bool(d[k])
    return out

def save_settings(body):
    cur = settings()
    for k in CFG_DEFAULT:
        if k in body: cur[k] = bool(body[k])
    try:
        CFG_PATH.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        print("[设置存不下] %s: %s" % (CFG_PATH, e))
    return cur

def need_transcribe(proj):
    """该不该自动转写:没转写过 + 这项目没任务在跑 + 素材路径还在。返回 (该不该, 原因)。"""
    proj = Path(proj)
    if not (proj / "项目.json").exists(): return False, "不是项目目录"
    if (proj / "转写.json").exists(): return False, "已经转写过"
    if job_view(proj).get("status") in ("排队中", "运行中"): return False, "该项目已有任务在跑"
    if not (meta_of(proj) or {}).get("media"): return False, "项目里没记素材路径"
    if not Path(meta_of(proj)["media"]).exists(): return False, "素材文件不在原位置"
    return True, ""

def adopt_media(proj):
    """收编素材:把项目引用的外部原片复制进项目\素材,并把 项目.json 改指副本。
    原文件保留不动,项目从此自带素材;之后删原片也不断线。"""
    d = Path(proj)
    meta = meta_of(d)
    if not meta: return {"error": "当前项目目录无效,先在顶栏重选一个项目"}
    if not meta.get("media"): return {"error": "还没绑素材,谈不上收编:先在① 粘贴视频绝对路径"}
    src = Path(meta["media"])
    if not src.exists():
        return {"error": "素材已经断线了(原位置找不到): %s。先回原文件夹核对名字/位置,重新绑一次再收编" % src}
    if d.resolve() in src.resolve().parents:
        return {"ok": True, "skipped": "素材本来就在项目文件夹里,不用收编"}
    dest = d / "素材" / src.name; i = 2
    while dest.exists():
        dest = d / "素材" / ("%s-%d%s" % (src.stem, i, src.suffix)); i += 1
    dest.parent.mkdir(exist_ok=True)
    try:
        shutil.copy2(src, dest)
    except Exception as e:
        print("[收编素材] 复制失败: %r" % (e,), flush=True)
        dest.unlink(missing_ok=True)
        return {"error": "复制失败(是不是磁盘空间不够?): %s" % e}
    meta["media"] = str(dest.resolve())
    (d / "项目.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "new": str(dest), "old": str(src), "复制MB": round(dest.stat().st_size / 1048576.0, 1)}

def bind_copied_media(proj, dest):
    """主素材拖入/上传的副本已落进项目「素材」文件夹后换绑:验项目+验副本+验是视频,写 项目.json。
    原文件本来就不动(浏览器只能传内容,传不了原位置)。"""
    d = Path(proj); m = Path(dest)
    meta = meta_of(d)
    if not meta: return {"error": "当前项目目录无效,先在顶栏重选一个项目"}
    if not m.exists(): return {"error": "副本没落盘: %s" % m}
    if m.suffix.lower() not in VIDEO_EXT:
        return {"error": "主素材只收视频(mp4/mov/m4v/avi/mkv/webm),这个不是: %s" % m.name}
    meta["media"] = str(m.resolve())
    (d / "项目.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "new": str(m), "复制MB": round(m.stat().st_size / 1048576.0, 1)}

def media_check():
    """素材体检:扫全部项目,报告每个项目的素材在原位/断线/未绑。只读,不动任何文件。"""
    rows = []
    if PROJ_ROOT.exists():
        for d in sorted(PROJ_ROOT.iterdir()):
            m = meta_of(d)
            if not m: continue
            media = m.get("media") or ""
            if not media: rows.append({"项目": d.name, "状态": "未绑素材", "路径": ""})
            elif Path(media).exists(): rows.append({"项目": d.name, "状态": "正常", "路径": media})
            else: rows.append({"项目": d.name, "状态": "断线", "路径": media})
    return {"rows": rows, "断线数": sum(1 for r in rows if r["状态"] == "断线")}

def run_doctor():
    """顶栏「🧯 诊断」后端:跑 scripts/doctor.py 检查,返回 JSON 给页面。
    诊断自己炸了也要把原因带回去,不许静默(AGENTS.md 铁律)。"""
    if str(SCRIPTS) not in sys.path: sys.path.insert(0, str(SCRIPTS))
    try:
        import doctor
        return doctor.report_json()
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": "诊断跑不起来: %r(更多在启动工作台的黑窗口里)" % e}

def relink_media(dir_, media):
    """重新连线:素材被挪/改名后,把项目里的路径纸条改成新位置。验存在+验视频+写回,复用绑定逻辑,0 复制。"""
    d = Path(dir_); old = (meta_of(d) or {}).get("media", "")
    r = bind_media(dir_, media)
    if not r.get("error"):
        r["relink"] = True; r["old"] = old; r["项目"] = d.name
        r["new"] = (meta_of(d) or {}).get("media", "")
    return r

def create_blank_project():
    """「＋新建项目」一键版:建 口播N 空项目(自动排号)并打开,不复制任何文件。
    空项目没绑素材,转写/剪辑会明确提示先绑,不会跑到一半崩。"""
    i = 1
    while (PROJ_ROOT / ("口播%d" % i)).exists(): i += 1
    d = PROJ_ROOT / ("口播%d" % i); d.mkdir()
    (d / "项目.json").write_text(json.dumps({"media": "", "name": d.name},
                                            ensure_ascii=False, indent=1), encoding="utf-8")
    return {"dir": str(d)}

SAMPLE_HINT = "样例项目:12 秒样片+自带转写(不占你的素材)。依次点 ③-A 找剪切点 → ③-B 审清单 → ③-D 执行粗剪,就能看全流程;玩完删掉这个项目即可"

def action_sample(proj=None, body=None):
    """载入样例项目(B2):复制 工作台\\Getting_Started\\sample 的样片和转写,建「样例演示」项目。
    缺文件必须报原因,不许静默。"""
    src = ROOT / "Getting_Started" / "sample"
    m, t = src / "样片.mp4", src / "转写.json"
    缺 = [x.name for x in (m, t) if not x.exists()]
    if 缺:
        return {"error": "缺样例文件:" + "、".join(缺) + "(应在 工作台\\Getting_Started\\sample);运行 python scripts\\export_trial.py 可再生"}
    nm = "样例演示"; d = PROJ_ROOT / nm; i = 2
    while d.exists(): d = PROJ_ROOT / ("%s-%d" % (nm, i)); i += 1
    d.mkdir(parents=True)
    shutil.copy2(m, d / "样片.mp4"); shutil.copy2(t, d / "转写.json")
    # 样例转写里 file 字段带着打包机的绝对路径,客户机照着找会撞"G1实炸:找不到素材"→改写指向项目内样片
    try:
        tj = json.loads((d / "转写.json").read_text(encoding="utf-8"))
        tj["file"] = str(d / "样片.mp4")
        (d / "转写.json").write_text(json.dumps(tj, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        return {"error": "样例转写路径改写失败:" + repr(e)[:100]}
    (d / "项目.json").write_text(json.dumps({"media": str(d / "样片.mp4"), "name": d.name},
                                            ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "dir": str(d), "提示": SAMPLE_HINT}

_INVIS = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\ufeff\t\r\n"))
_QUOTES = "\"\'“”‘’"

def clean_media_path(raw):
    """把粘进来的路径携带的"必是垃圾"洗掉:外层引号(Win11「复制文件地址」自带)、零宽/方向等不可见字符、
    file:// 前缀、首尾空格与结尾点号。只清洗,不猜用户心思;Windows 文件名本就不允许引号,剥了不会误伤。"""
    s = str(raw or "").strip().translate(_INVIS)
    if s[:8].lower() == "file:///": s = unquote(s[8:])
    elif s[:7].lower() == "file://": s = unquote(s[7:])
    s = s.strip().strip(_QUOTES + " ")
    if len(s) >= 3 and s[0] in "\\/" and s[2] == ":": s = s[1:]
    s = s.replace("/", "\\")
    if len(s) > 2: s = s.rstrip(" .")
    return s.strip()

def resolve_media_input(media, where=""):
    """粘贴素材路径的统一入口:先洗垃圾;允许粘文件夹(里面恰好 1 个视频自动认);
    找不到就指明断在哪一级。返回 (Path, 错误信息),错误信息为空表示可用。"""
    raw = str(media or "").strip()
    s = clean_media_path(raw)
    if s and s != raw:
        slog("路径清洗", where, "%r -> %r" % (raw, s))
    if not s:
        return None, "先粘贴视频绝对路径,如 E:\\视频\\口播1.mp4(也可以直接粘贴它所在的文件夹)"
    m = Path(s)
    if m.is_dir():
        vids = sorted(f for f in m.iterdir() if f.suffix.lower() in VIDEO_EXT and f.is_file())
        if len(vids) == 1:
            m = vids[0]
            slog("文件夹自动认片", where, m.name)
        elif len(vids) > 1:
            return None, "你粘的是文件夹,里面有 %d 个视频,请把要用的那条完整路径粘上:%s" % (
                len(vids), "、".join(v.name for v in vids[:5]))
        else:
            return None, "这个文件夹里没有视频(只收 mp4/mov/m4v/avi/mkv/webm): %s" % s
    if not m.exists():
        duankai = "连盘符/根目录都到不了,先检查盘符对不对、U盘/移动硬盘有没有拔走"
        pa = m
        while pa.parent != pa:
            pa = pa.parent
            if pa.exists():
                duankai = "「%s」是有的,但它里面找不到「%s」" % (pa, m.relative_to(pa))
                break
        slog("素材不存在", where, "原始粘贴: %r" % raw)
        return None, "素材文件不存在: %s(断点: %s)" % (m, duankai)
    return m, ""

def bind_media(dir_, media):
    """把粘贴的视频路径绑进当前空项目:自动剥引号/隐形字符、允许直接粘它所在文件夹、
    验是视频,更新 项目.json。成功返回 {"dir":...}。"""
    d = Path(dir_)
    if not (d / "项目.json").exists(): return {"error": "当前项目目录无效,先在下拉里重选一个"}
    m, err = resolve_media_input(media, d.name)
    if err: return {"error": err}
    if m.suffix.lower() not in VIDEO_EXT:
        return {"error": "那不是视频文件,只收 mp4/mov/m4v/avi/mkv/webm: %s" % m.name}
    meta = meta_of(d) or {"name": d.name}
    meta["media"] = str(m.resolve())
    (d / "项目.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"dir": str(d)}
def create_project(media, name="", body=None):
    """建项目;开关开着就顺手把转写排进队列(固定 small,不会偷偷联网下模型)。"""
    body = body or {}
    if body.get("dir"):
        bind = bind_media(body["dir"], media)
        if bind.get("error"): return {"error": bind["error"]}
        d = Path(bind["dir"]); out = {"dir": str(d), "绑定": True}
    else:
        d, err = make_project(media, name)
        if not d: return {"error": err}
        out = {"dir": str(d)}
    if body.get("no_auto"):
        out["自动转写"] = {"skipped": "自检调用,不真跑转写"}
        return out
    if not settings().get("自动转写", True):
        out["自动转写"] = {"skipped": "「建项目自动转写」开关是关的(① 素材卡片可打开)"}
        return out
    ok, why = need_transcribe(d)
    if not ok:
        out["自动转写"] = {"skipped": why or "不需要"}
        return out
    out["自动转写"] = action_transcribe(d, {"model": "small"})
    return out

_T2S = None
def _norm_cn(x):
    """去标点空格+小写+繁转简:对词匹配的统一口径(和 ⚓ 的简繁归一同一方向)。"""
    global _T2S
    v = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]", "", str(x or "")).lower()
    if _T2S is None:
        try:
            from opencc import OpenCC
            _T2S = OpenCC("t2s")
        except Exception as e:
            print("[简繁归一不可用,只能同体对词] %s" % e)
            _T2S = False
    if _T2S:
        try:
            v = _T2S.convert(v)
        except Exception as e:
            print("[繁转简失败,降级同体匹配] %s" % e)
            _T2S = False
    return v

def _词窗(wd):
    """长词整体对不上就剥尾巴/掐头再试:安心结果砸→安心的结果。最多4个窗,宁短不歪。"""
    ws = [wd]
    if len(wd) > 4:
        for cut in (1, 2):
            if len(wd) - cut >= 4: ws.append(wd[:-cut])
        ws.append(wd[:4])
    seen, out = set(), []
    for w in ws:
        if w and w not in seen: seen.add(w); out.append(w)
    return out


def _ideas_lines(proj):
    f = Path(proj) / "包装想法.txt"
    if not f.exists(): return []
    return [x.strip() for x in f.read_text(encoding="utf-8-sig").splitlines() if x.strip()]

def ideas_save(proj, text):
    """①-B 包装想法箱:人话原样存,永不自动加工——加工发生在对镜头和交接两处。"""
    text = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
    (Path(proj) / "包装想法.txt").write_text(text, encoding="utf-8")
    return {"ok": True}

def ideas_map(proj, body):
    """想法箱逐行对分镜:剥动作词拿内容词去转写找句(唯一命中才认),再用源起定位落在第几镜。
    对不上的不硬编:明说试过哪些词,语义活交给豆包。"""
    proj = Path(proj)
    ls = _ideas_lines(proj)
    if not ls: return {"error": "想法箱是空的:先在①-B 下方「包装想法」写两句"}
    tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成第②步转写,想法才能对上句"}
    segs = (json.loads(tj.read_text(encoding="utf-8")) or {}).get("segments") or []
    if not segs: return {"error": "转写 0 段,对不了:回②检查音频"}
    shots = []
    tlf = proj / "分镜时间轴.json"
    if tlf.exists():
        try:
            shots = [r for r in (json.loads(tlf.read_text(encoding="utf-8-sig")).get("镜") or []) if "成片起" in r]
        except Exception as e:
            print("[时间轴读不了] %s: %s" % (proj, e))
    norm = _norm_cn
    def shot_of(t):
        best = None
        for r in sorted(shots, key=lambda x: float(x.get("源起") or x.get("成片起") or 0)):
            s0 = r.get("源起")
            s0 = float(s0) if s0 is not None else float(r.get("成片起", 0))
            if t >= s0 - 0.2: best = r
        return best
    out = []
    for line in ls:
        junk = re.sub(r"(做|来|上|放|加|换|插入?|开场|开头|结尾|这[个段句]|那[个段句]|里|时[候句]|口播|大字卡|图形卡|卡片|字卡|空镜|录屏|视频|图片|一句|一段|话)", " ", line)
        hit_word = hit_seg = None
        tried = []
        for wd in re.findall(r"[0-9]{2,}|[A-Za-z]{2,}|[\u4e00-\u9fff]{2,8}", junk):
            if len(tried) >= 4: break
            tried.append(wd)
            for w in _词窗(wd):
                hs = [sg for sg in segs if norm(w) in norm(sg.get("text"))]
                if len(hs) == 1:
                    hit_word = w; hit_seg = hs[0]; break
            if hit_seg is not None: break
        if hit_seg is None:
            out.append({"想法": line, "落在": "没对上(试过:%s)——语义活交给豆包,或把原话加「」" % "、".join(tried)})
            continue
        t = float(hit_seg.get("start", 0))
        r = shot_of(t)
        if r:
            out.append({"想法": line, "落在": "镜%s(对词「%s」)" % (r.get("镜号"), hit_word)})
        else:
            out.append({"想法": line, "落在": "对上句 %.1fs,但不在任何镜里——分镜表还没盖住这句" % t})
    return {"结果": out, "条数": len(out)}


def sb_draft_from_text(proj, text):
    """①-B「讲述生成分镜」:一行一镜的随口讲解 → 规范分镜草稿(只回文本,不落盘——
    审没审、存不存、⚓ 算秒,都由人按下一次保存说了算)。
    能认:「说过的词」→锚点+对口播原话;时间(按原片秒)→取那句;画面五类词;素材库文件名/绝对路径。
    认不出的一律不丢,原因写进备注列等人补。"""
    proj = Path(proj)
    tj = proj / "转写.json"
    if not tj.exists(): return {"error": "还没转写,没法对原话:先完成第②步再讲述"}
    segs = (json.loads(tj.read_text(encoding="utf-8")) or {}).get("segments") or []
    if not segs: return {"error": "转写是 0 段,对不了词:回第②步换模型重转"}
    total = max(float(s.get("end", 0)) for s in segs)

    norm = _norm_cn

    st = assets_state(proj)
    pool, seen = [], set()
    for it in st.get("items") or []:
        pth = it.get("path") or os.path.join(st.get("folder", ""), it.get("name", ""))
        stem = norm(Path(it.get("name", "")).stem)
        if stem and stem not in seen:
            seen.add(stem); pool.append((stem, pth))
    ZONES = [("口播正面", ("口播", "坐讲", "真人", "对镜", "自己讲")),
             ("空镜", ("空镜", "外景", "风景", "b-roll", "broll")),
             ("录屏", ("录屏", "屏幕", "软件操作", "演示")),
             ("图形卡", ("图形卡", "图标", "流程", "对比", "图表")),
             ("大字卡", ("大字卡", "金句", "满屏字", "大字幕", "卡片", "字卡"))]
    rows, shotno = [], 0
    for raw in re.split(r"[\n。;；]+", str(text or "")):
        line = re.sub(r"^\s*(?:第\s*\d+\s*[个镜行条]?[：:、,\.]?\s*|\d{1,2}[\.\)、]\s*)", "", raw).strip()
        if not line: continue
        shotno += 1
        note = []
        qm = re.search(r'[\u300c\u300a\u201c"]([^\u300d\u300b\u201d"]{2,12})[\u300d\u300b\u201d"]', line)
        anchor = qm.group(1) if qm else ""
        tsec = None
        tm = re.search(r"(\d{1,2})[:：](\d{2})", line)
        sm = re.search(r"(\d+(?:\.\d+)?)\s*(?:[sS]|秒)", line)
        if tm: tsec = int(tm.group(1)) * 60 + int(tm.group(2))
        elif sm: tsec = float(sm.group(1))
        zone = "口播正面"; zh = False
        for z, keys in ZONES:
            if any(k in line.lower() for k in keys): zone = z; zh = True; break
        if not zh: note.append("没说画面类型,默认口播正面")
        mat = ""
        pm = re.search(r"[A-Za-z]:[^\s,;，；|、]+?\.(?:mp4|mov|png|jpe?g|wav|mp3)", line)
        if pm:
            mat = pm.group(0)
            if not os.path.exists(mat): note.append("这路径的文件不存在")
        else:
            for stem, path in pool:
                if stem in norm(line): mat = path; break
        mat_cell = mat
        if not mat and zone in ("空镜", "录屏"):
            kw = re.search(r"(?:空镜|录屏)[:：]?\s*([^\s,，;；「」()（）]{2,10})", line)
            mat_cell = "待生成:" + (kw.group(1) if kw else zone)
        sub = ""
        if anchor:
            for sg in segs:
                if norm(anchor) in norm(sg.get("text")):
                    sub = str(sg.get("text", "")); break
            if not sub: note.append("锚点词在转写里没找到(没说过?打错字?)")
        elif tsec is not None:
            if tsec > total + 1:
                note.append("时间%.1fs超出素材总长%.1fs,对不上句" % (tsec, total))
            else:
                hit = None
                for sg in segs:
                    if float(sg.get("start", 0)) <= tsec + 0.4: hit = sg
                    else: break
                if hit:
                    sub = str(hit.get("text", ""))
                    anchor = norm(sub)[:6]
                    note.append("按%.1fs取的这句,锚点用开头6字,不对就改成你真说的词" % tsec)
        else:
            # 模糊兜底:剥掉动作词/画面词,拿剩下的内容词去转写对——「」不是必须
            junk = re.sub(r"(做|来|上|放|加|换|插入?|开场|开头|结尾|这[个段句]|那[个段句]|时[候句]|口播|大字卡|图形卡|卡片|字卡|空镜|录屏|视频|图片|一句|一段|话)", " ", line)
            tried = []
            for wd in re.findall(r"[0-9]{2,}|[A-Za-z]{2,}|[\u4e00-\u9fff]{2,6}", junk):
                if len(tried) >= 3: break
                tried.append(wd)
                for w in _词窗(wd):
                    hits = [sg for sg in segs if norm(w) in norm(sg.get("text"))]
                    if len(hits) == 1:
                        anchor = w; sub = str(hits[0].get("text", ""))
                        note.append("按「%s」对到了这句,不对就改成你真说的词" % w)
                        break
                if anchor: break
            if not anchor:
                note.append("拿「%s」去转写里都没对上:用「」写出你确实说过的词,或写秒数" % "、".join(tried) if tried
                            else "没给时间也没带「词」,机器找不到这句:补一个")
        fx = ""
        if re.search(r"\d+(?:\.\d+)?\s*(?:%|天|年|月|个|万|亿|元|块|次|倍|岁|分钟)", line + " " + sub): fx = "数据卡"
        elif zone in ("空镜", "录屏"): fx = "推镜"
        rows.append(["%02d" % shotno, "", anchor, sub, zone, mat_cell, fx, "；".join(note)])
    if not rows: return {"error": "一句都没认出来:一行一镜地讲,带上「说过的词」或时间"}

    def esc(v):
        v = str(v).replace("\n", " ")
        return '"%s"' % v.replace('"', '""') if any(c in v for c in ',"') else v
    head = "镜号,时间码(成片·自动),锚点,字幕文本(校对版),画面内容,素材文件,动效包装,备注"
    csv_txt = head + "\n" + "\n".join(",".join(esc(c) for c in r) for r in rows) + "\n"
    return {"ok": True, "csv": csv_txt, "镜头数": len(rows), "要补": sum(1 for r in rows if r[7])}


def storyboard_save(proj, text, auto=True):
    """保存 分镜.csv;开着「保存自动算秒」且有转写,就顺手跑一次 ⚓——省掉再点一次按钮。"""
    proj = Path(proj)
    if not (text or "").strip():
        return {"error": "分镜表是空的,没东西可存(想清空回本步用「🗑 重置本步」)"}
    # 表头校验与 anchor_time.py 的 find_header 同规则:任一行的任一格里含「镜号」才算镜头表。
    # 之前是一段大白话也被存成 分镜.csv:步骤勾选亮起、⚓ 却报「没找到表头行」,两个显示互相打架。
    if not any("镜号" in c for l in text.splitlines() for c in re.split(r"[|,，;；\t]", l)):
        return {"error": "没保存——缺表头行。第一行照抄:镜号,时间码(成片·自动),锚点,字幕文本(校对版),画面内容,素材文件,动效包装,备注;一行写一镜。"
                         "不想手敲:上方讲述框讲几句按「⚡ 讲述转分镜」,表头自动带出"}
    step_snap(proj, ["分镜.csv"], "s1")
    # 浏览器 textarea 给的是 \n;不统一的话 Windows 会把 \r\n 再翻一次,CSV 里长出空行
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    with open(str(proj / "分镜.csv"), "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    out = {"ok": True}
    if not auto or not settings().get("自动算秒", True):
        out["自动算秒"] = {"skipped": "开关已关(① 素材卡片可打开)"}
    elif not (proj / "转写.json").exists():
        out["自动算秒"] = {"skipped": "还没转写,算不了秒数(② 转写完再存一次)"}
    else:
        r = action_anchors(proj, {})
        if r.get("error"): out["自动算秒"] = {"error": r["error"]}
        else:
            out["自动算秒"] = {"统计": r.get("统计"), "警告": r.get("警告") or [], "基准": r.get("基准")}
            out["统计"] = r.get("统计"); out["警告"] = r.get("警告") or []
    sb = proj / "分镜.csv"
    out["text"] = sb.read_text(encoding="utf-8") if sb.exists() else ""
    return out


def next_step(proj):
    """只看产物在不在、新不新,算出「下一步该点什么」。顺序与 ① 标签卡片从上到下完全一致:
    建项目 → 转写 → ①-A 文案定稿 → ①-B 分镜(含 ⚓ 算秒) → ①-D 对标点位 → ③-A 找点 → ③-D 出片 → ④ 交接。
    ①-C 上传对标素材是人手上的动作,引导只在登记过参考片后才催 ①-D 拆点位(没对标就不催)。"""
    proj = Path(proj)
    def f(n): return (proj / n).exists()
    def mt(n): return (proj / n).stat().st_mtime if f(n) else 0.0
    if not f("项目.json"):
        return {"tab": 0, "card": "projbar", "做": "粘贴口播视频绝对路径,建项目", "为什么": "每条口播一个项目目录", "进度": "0/6"}
    交在 = f("包装交接.md") or f("剪映交接.json") or f("剪映交接.md")
    done = sum(1 for x in (f("转写.json"), f("文案定稿.txt"), f("对标点位.json"), f("分镜.csv"),
                           f("rough.mp4"), 交在) if x)
    P = {"进度": "%d/6" % done}
    if not f("转写.json"):
        return dict(P, tab=1, card="s2", **{"做": "开始转写(开着自动转写时它自己会跑)",
                    "为什么": "文案识别、算秒数、点位表的口播列都要它"})
    try:
        if not (json.loads((proj / "转写.json").read_text(encoding="utf-8")).get("segments") or []):
            return dict(P, tab=1, card="s2", **{"做": "这条素材没识别到人声,先换模型重转或检查音频",
                        "为什么": "0 段转写会让后面每一步都空跑"})
    except Exception as e:
        print("[转写读不了] %s: %s" % (proj, e))
    if not f("文案定稿.txt"):
        return dict(P, tab=0, card="s1W", **{"做": "①-A 校对口播文案 → 确认定稿",
                    "为什么": "第③步烧的字幕以此为准,错字只有你能判"})
    if not f("分镜.csv"):
        return dict(P, tab=0, card=("s1D" if f("对标点位.json") else "s1"),
                    **{"做": ("①-B 补镜头:去 ①-D 点位表点「⬇ 按点位表补进分镜表」" if f("对标点位.json") else "①-B 写分镜镜头表"),
                       "为什么": "第④步插素材、加卡片都按分镜表执行;不学对标就自己列镜头"})
    if not f("分镜时间轴.json") or mt("分镜.csv") > mt("分镜时间轴.json"):
        return dict(P, tab=0, card="s1", **{"做": "⚓ 按锚点重算时间码",
                    "为什么": "分镜表改过了,秒数还是旧的(开着自动算秒本该自己跑)"})
    有对标 = bool([x for x in refs_state(proj)["items"] if x.get("kind") == "video"])
    if 有对标 and not f("对标点位.json"):
        return dict(P, tab=0, card="s1D", **{"做": "①-D 拆对标点位,再对着联系表改分类",
                    "为什么": "分镜已写完:用对标的切镜节奏检查哪些镜缺画面"})
    if not f("剪切点清单.json"):
        return dict(P, tab=2, card="s3a", **{"做": "③-A 找剪切点 → 到 ③-B 逐条审删/留",
                    "为什么": "口头禅、停顿、重录、念错都在这一步剪掉"})
    if not f("rough.mp4"):
        return dict(P, tab=2, card="s3d", **{"做": "③-D 执行粗剪出 rough.mp4", "为什么": "清单审完了就该出片"})
    if mt("剪切点清单.json") > mt("rough.mp4"):
        return dict(P, tab=2, card="s3d", **{"做": "③-D 重新执行粗剪", "为什么": "剪切点清单比成片新,现在这版是旧的"})
    if not 交在:
        return dict(P, tab=3, card="s4", **{"做": "生成交接包", "为什么": "把 rough + 分镜 + 对标点位交给第④步"})
    return dict(P, tab=3, card="s4", 完成=True, **{"做": "全齐了:可以发,或去第④步做精包装",
                "为什么": "转写·定稿·分镜·点位·粗剪·交接六样都在(交接=AI包或剪映产物任一)"})


def action_transcribe(proj, body):
    step_snap(proj, ["转写.json"], "s2")
    m = meta_of(proj)
    if not (m or {}).get("media"):
        return {"error": "还没绑素材:去① 素材卡片粘贴视频绝对路径,点「打开 / 新建项目」就会绑到当前项目"}
    cmd = [PY, SCRIPTS / "transcribe.py", m["media"], "--out", Path(proj) / "转写.json",
           "--model", body.get("model", "small"), "--lang", body.get("lang", "zh")]
    return start_job(proj, cmd, label="转写", timeout=2400)

def make_project(media, name=""):
    m, err = resolve_media_input(media)
    if err: return None, err
    nm = re.sub(r'[\\/:*?"<>|]', "", name or m.stem) or "未命名"
    d = PROJ_ROOT / nm; i = 2
    while (d / "项目.json").exists() and (meta_of(d) or {}).get("media") != str(m.resolve()):
        d = PROJ_ROOT / (nm + "-" + str(i)); i += 1
    d.mkdir(parents=True, exist_ok=True)
    (d / "项目.json").write_text(json.dumps({"media": str(m.resolve()), "name": d.name},
                                            ensure_ascii=False, indent=1), encoding="utf-8")
    return d, ""
def action_delete_project(proj):
    """整个项目目录送进系统回收站(回收站里右键还原即可找回)。
    安全阀:只删「项目」文件夹里面的真项目;任务在跑不许删;路径越界拒绝;失败原因全部打印并回传。"""
    rp = Path(proj)
    try:
        root = PROJ_ROOT.resolve(); rp = rp.resolve()
    except Exception as e:
        print("[删除项目] 路径解析失败: %r" % (e,), flush=True)
        return {"error": "路径不合法: %s" % e}
    if rp == root:
        return {"error": "不能删整个「项目」总目录,只能删里面的单个项目"}
    if root not in rp.parents:
        return {"error": "这个目录不在工作台的「项目」文件夹里,拒绝删除"}
    if not (rp / "项目.json").exists():
        return {"error": "这个目录里没有 项目.json,不是工作台项目,拒绝删除"}
    if job_view(str(rp)).get("status") in ("排队中", "运行中"):
        return {"error": "这个项目还有任务在排队或在跑,先点「停止任务」再删"}
    try:
        from send2trash import send2trash
    except ImportError as e:
        print("[删除项目] 缺 send2trash 库: %r" % (e,), flush=True)
        return {"error": "缺少 send2trash 库(python -m pip install send2trash),为防误删不直接抹掉文件"}
    try:
        send2trash(str(rp))
    except Exception as e:
        print("[删除项目] 送回收站失败: %r" % (e,), flush=True)
        return {"error": "送进回收站失败: %s(可能被别的程序占用,先关掉预览或正在播它的播放器)" % e}
    print("[删除项目] %s → 系统回收站" % rp, flush=True)
    return {"ok": True, "name": rp.name}

def action_refstyle(proj, body):
    """本地量化对标:把参考片的节奏/明暗/配色/响度/语速算成参数,存 对标风格.json。"""
    proj = Path(proj)
    refp = (body.get("path") or "").strip()
    if not refp:
        vids = [x for x in refs_state(proj)["items"] if x.get("kind") == "video"]
        if not vids: return {"error": "先登记一条参考视频(量化对标只吃视频,截图算不出节奏)"}
        refp = vids[0].get("path") or str(proj / "参考" / vids[0]["name"])
    if not Path(refp).exists(): return {"error": "参考片不存在: " + refp}
    cmd = [PY, SCRIPTS / "ref_style.py", refp, "--out", proj / "对标风格.json",
           "--thr", str(body.get("thr", 0.25))]
    if body.get("speech"): cmd.append("--speech")
    tj = proj / "转写.json"
    if tj.exists(): cmd += ["--compare", tj]
    def done():
        sug = style_suggest(proj)
        if sug:
            (proj / "剪辑参数.json").write_text(json.dumps(sug, ensure_ascii=False, indent=1), encoding="utf-8")
    return start_job(proj, cmd, label="量化对标" + ("(含语速)" if body.get("speech") else ""),
                     on_done=done, timeout=2400)

def ref_video_path(proj, body):
    """按「量化对标」同一套规则定用哪条参考片:优先手填路径,否则取登记的第一条视频。"""
    proj = Path(proj)
    refp = (body.get("path") or "").strip()
    if not refp:
        vids = [x for x in refs_state(proj)["items"] if x.get("kind") == "video"]
        if not vids: return None, "先登记一条参考视频(点位拆解只吃视频,截图算不出切点)"
        refp = vids[0].get("path") or str(proj / "参考" / vids[0]["name"])
    if not Path(refp).exists(): return None, "参考片不存在: " + refp
    return refp, ""


def load_engine():
    """按需导入 ref_shotmap:改分类/写分镜直接调引擎函数,不起子进程。失败必须报原因,不许静默。"""
    if str(SCRIPTS) not in sys.path: sys.path.insert(0, str(SCRIPTS))
    try:
        import ref_shotmap
        return ref_shotmap, ""
    except Exception as e:
        return None, "ref_shotmap 引擎导入失败(看 scripts/ref_shotmap.py 是否被动过): %s" % e


def action_refmap(proj, body):
    """①-D 拆对标点位:切点 -> 分段 -> 抽帧 -> 猜分类 -> 联系表 + 对标点位.csv + 素材需求.csv。"""
    proj = Path(proj)
    refp, err = ref_video_path(proj, body)
    if err: return {"error": err}
    cmd = [PY, SCRIPTS / "ref_shotmap.py", refp, "--proj", proj,
           "--thr", str(body.get("thr") or "0.25"),
           "--per-sheet", str(body.get("per_sheet") or 24)]
    if body.get("max"): cmd += ["--max", str(body["max"])]
    if not body.get("frames", True): cmd.append("--no-frames")
    tj = proj / "转写.json"
    if tj.exists(): cmd += ["--own", tj]
    return start_job(proj, cmd, label="拆对标点位", timeout=1800)


def refmap_state(proj):
    """给①-D 读数:统计 + 每镜(带缩略图URL) + 联系表URL + 素材需求清单路径 + 可选分类表。"""
    proj = Path(proj); f = proj / "对标点位.json"
    E, err = load_engine()
    st = {"has": False, "types": list(getattr(E, "TYPES", ())) if E else [],
          "默认处理方式": dict(getattr(E, "DO", {})) if E else {}}
    if err: st["错误"] = err
    if not f.exists(): return st
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        st["错误"] = "对标点位.json 读不了: %s" % e
        return st
    q = quote(str(proj), safe="")
    rows = []
    for r in d.get("点位") or []:
        rr = dict(r)
        rr["帧URL"] = "/media?dir=%s&name=shotmap&f=%s" % (q, quote(str(r.get("帧图") or ""), safe=""))
        rows.append(rr)
    st.update({"has": True, "对标源": d.get("对标源"), "对标时长": d.get("对标时长"),
               "分析窗口秒": d.get("分析窗口秒"), "统计": d.get("统计") or {}, "点位": rows,
               "联系表": [{"名": n, "URL": "/media?dir=%s&name=shotmap&f=%s" % (q, quote(n, safe=""))}
                        for n in (d.get("联系表") or []) if (proj / "对标点位" / n).exists()],
               "素材需求": str(proj / "素材需求.csv"), "点位CSV": str(proj / "对标点位.csv"),
               "帧目录": str(proj / "对标点位")})
    return st


def refmap_save(proj, rows):
    """把界面改的人工列写回 对标点位.json;分类变了就连带刷新功能/来源/降级,并重出两张 CSV。"""
    E, err = load_engine()
    if err: return {"error": err}
    proj = Path(proj); f = proj / "对标点位.json"
    if not f.exists(): return {"error": "还没有点位表,先点「拆对标点位」"}
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        return {"error": "对标点位.json 读不了: %s" % e}
    by = {str(r.get("镜号")): r for r in (d.get("点位") or [])}
    if not by: return {"error": "点位表里没有行"}
    bad = []
    n = 0
    for inc in rows or []:
        tgt = by.get(str(inc.get("镜号")))
        if not tgt: continue
        my = str(inc.get("我的分类") or "").strip()
        if my and my not in E.TYPES:
            bad.append(str(inc.get("镜号")) + ":" + my); continue
        old_my = tgt.get("我的分类") or ""
        payload_do = str(inc.get("处理方式") or "").strip()
        for c in ("画面需要(你来填)", "关键词候选"):
            if c in inc: tgt[c] = str(inc[c] or "").strip()
        if my and my != old_my:
            E.apply_class(tgt, my)                       # 功能/来源/降级/处理方式 跟着换
            if payload_do and payload_do != E.DO.get(old_my, ""):
                tgt["处理方式"] = payload_do              # 你单独挑过的(如「跳过不学」)保留
        elif payload_do:
            tgt["处理方式"] = payload_do
        n += 1
    if bad: return {"error": "不认识的分类: " + "、".join(bad[:5])}
    step_snap(proj, ["对标点位.json", "对标点位.csv", "素材需求.csv"], "s1")
    allrows = d.get("点位") or []
    needs = E.emit_tables(allrows, proj)
    cnt = {}
    for r in allrows:
        k = r.get("我的分类") or r.get("机器分类") or "待定"
        cnt[k] = cnt.get(k, 0) + 1
    st = d.get("统计") or {}
    st["分类分布"] = cnt; st["需要外部素材"] = needs
    d["统计"] = st
    f.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "改了几行": n, "需要外部素材": needs, "统计": st}


def refmap_storyboard(proj, body):
    """按(人工核对过的)点位表往 分镜.csv 追加镜头;秒数交给「⚓ 按锚点重算时间码」。"""
    E, err = load_engine()
    if err: return {"error": err}
    step_snap(proj, ["分镜.csv"], "s1")
    r, e2 = E.append_storyboard(proj, only_needs=not body.get("all"), force=bool(body.get("force")))
    if e2: return {"error": e2}
    out = {"ok": True, "追加": r["追加"], "跳过口播镜": r["跳过口播镜"], "警告": r.get("警告") or []}
    if not settings().get("自动算秒", True):
        out["自动算秒"] = {"skipped": "开关已关,自己点一次「⚓ 按锚点重算时间码」"}
    elif not (Path(proj) / "转写.json").exists():
        out["自动算秒"] = {"skipped": "还没转写,算不了秒数——转完再点一次"}
    else:
        r2 = action_anchors(proj, {})
        out["自动算秒"] = ({"error": r2["error"]} if r2.get("error")
                        else {"统计": r2.get("统计"), "警告": r2.get("警告") or [], "基准": r2.get("基准")})
        if r2.get("警告"): out["警告"] = (out["警告"] + r2["警告"])[:40]
    sb = Path(proj) / "分镜.csv"
    if sb.exists(): out["text"] = sb.read_text(encoding="utf-8-sig")
    return out


def _pipeline(proj, body):
    """转写完成后的自动接力:找点 -> 出片。失败就把原因写进日志,不静默。"""
    r = action_findcuts(proj, {"pause": body.get("pause"), "keepsil": body.get("keepsil"),
                               "fillers": body.get("fillers", "")})
    if r.get("error"):
        _log(job_key(proj), "[自动找点失败] " + r["error"]); return
    r2 = action_render(proj, {"subs": body.get("subs", True), "audio": body.get("audio", True),
                              "fast": body.get("fast", False), "zoom": body.get("zoom")})
    if r2.get("error"): _log(job_key(proj), "[自动出片失败] " + r2["error"])


def run_backup():
    """出片后自动备份小文件(文本成果最耗时,也最容易被误删)。失败只提示,不影响出片。"""
    try:
        r = subprocess.run([PY, SCRIPTS / "backup_small.py", "--quiet"], capture_output=True,
                           text=True, encoding="utf-8", errors="replace", timeout=120)
        if r.returncode: return {"error": (r.stderr or r.stdout)[-200:]}
        return {"ok": True}
    except Exception as e:
        return {"error": str(e)}

def action_batch(body):
    """日更批量:一次丢多条素材,每条建项目并排队跑完整链路。"""
    files = []
    for x in (body.get("paths") or body.get("files") or []):
        x = str(x).strip().strip('"')
        if not x: continue
        q = Path(x)
        if q.is_dir():
            files += sorted([str(f) for f in q.iterdir()
                             if f.suffix.lower() in VIDEO_EXT and f.is_file()])
        else:
            files.append(str(q))
    if not files: return {"error": "没有收到素材:填绝对路径(一行一条)或一个素材文件夹路径"}
    ok, skip = [], []
    for f in files:
        m = Path(str(f).strip())
        if m.suffix.lower() not in VIDEO_EXT:
            skip.append(m.name + "(不是视频)"); continue
        d, err = make_project(m)
        if not d: skip.append(m.name + "(" + err + ")"); continue
        cmd = [PY, SCRIPTS / "transcribe.py", meta_of(d)["media"], "--out", d / "转写.json",
               "--model", body.get("model", "small")]
        r = start_job(d, cmd, label="一键成片:转写",
                      on_done=(lambda dd=d, bb=body: _pipeline(dd, bb)), timeout=3600)
        (ok if r.get("ok") else skip).append(d.name if r.get("ok") else d.name + "(" + r.get("error", "") + ")")
    return {"ok": True, "已排队": ok, "跳过": skip}

def backup_cuts(proj):
    cur = Path(proj) / "剪切点清单.json"
    if cur.exists():
        shutil.copyfile(cur, Path(proj) / "剪切点清单.prev.json")

def style_suggest(proj):
    """读 对标风格.json 的「建议」;没有就返回空,沿用手动值。"""
    f = Path(proj) / "对标风格.json"
    if not f.exists(): return {}
    try: return json.loads(f.read_text(encoding="utf-8")).get("建议") or {}
    except Exception: return {}

def action_findcuts(proj, body):
    step_snap(proj, ["剪切点清单.json"], "s3")
    backup_cuts(proj)
    tj = Path(proj) / "转写.json"
    if not tj.exists(): return {"error": "先完成第②步转写"}
    cmd = [PY, SCRIPTS / "find_cuts.py", tj, "--out", Path(proj) / "剪切点"]
    extra = body.get("fillers", "").strip()
    if extra: cmd += ["--fillers", extra]
    sense = {"紧节奏(短视频)": "tight", "紧节奏(智能剪口播)": "tight", "自然口播": "natural", "高级感(留呼吸)": "calm"}.get(
        body.get("preset", ""), body.get("preset", "") or "natural")
    if sense not in ("tight", "natural", "calm"): sense = "natural"
    cmd += ["--sense", sense]
    sug = style_suggest(proj)
    pause = body.get("pause") or sug.get("停顿剪阈值秒") or 1.0
    keepsil = body.get("keepsil") or sug.get("剪后留呼吸秒") or 0.45
    cmd += ["--pause", str(pause), "--keepsil", str(keepsil)]
    p = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode: return {"error": (p.stderr or p.stdout)[-800:]}
    tmpj = Path(proj) / "剪切点.剪切点.json"; tmpc = Path(proj) / "剪切点.剪切点.csv"
    cj = Path(proj) / "剪切点清单.json"; cc = Path(proj) / "剪切点清单.csv"
    # 保留人工决定:重跑找点不覆盖用户改过的删/留,手动标记的补删点自动带回
    if tmpj.exists() and cj.exists():
        try:
            oldd = json.loads(cj.read_text(encoding="utf-8"))
            old_cuts = oldd.get("cuts", [])
            # 只有同一档位才沿用旧「执行」;换档(自然→高级感)必须让新档的默认值生效,
            # 否则上一档的机器默认会把这一档的从严判定顶回去(C0584 高级感切换失效事故)。
            # 真正被人工改过的行(带「人工」标记)任何档位都沿用。
            同档 = oldd.get("档位") == sense
            old_map = {(c.get("类型"), c.get("文字")): c for c in old_cuts}
            manual = [c for c in old_cuts if c.get("类型") in ("手动标记", "手动补剪")]
            newd = json.loads(tmpj.read_text(encoding="utf-8"))
            have = {c.get("文字") for c in newd.get("cuts", [])}
            for c in newd.get("cuts", []):
                o = old_map.get((c.get("类型"), c.get("文字")))
                if o and (o.get("人工") or 同档):
                    c["执行"] = o.get("执行", c.get("执行"))
                    if o.get("人工"): c["人工"] = "1"   # 人工标记要一路带着走,否则下次重跑就认不出来
            for c in manual:
                if c.get("文字") not in have: newd.setdefault("cuts", []).append(c)
            newd["cuts"].sort(key=lambda c: c["开始"])
            for i, c in enumerate(newd["cuts"], 1): c["序号"] = i
            newd["档位"] = sense
            tmpj.write_text(json.dumps(newd, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception: pass
    if tmpj.exists():
        try:
            nd = json.loads(tmpj.read_text(encoding="utf-8"))
            if nd.get("档位") != sense:
                nd["档位"] = sense
                tmpj.write_text(json.dumps(nd, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as ex:
            print("档位标记写入失败(不影响清单,但换档时无法判断该不该沿用旧删留):", ex)
        tmpj.replace(cj)
    if tmpc.exists(): tmpc.replace(cc)
    return {"ok": True, "file": str(cj)}

def sense_from(body):
    """把界面「节奏预设」的中文名或英文档位归一成 tight/natural/calm;没选=自然档"""
    v = (body.get("preset") or "").strip()
    return {"紧节奏(短视频)": "tight", "紧节奏(智能剪口播)": "tight", "自然口播": "natural", "高级感(留呼吸)": "calm"}.get(v, v or "natural")


def action_render(proj, body):
    cj = Path(proj) / "剪切点清单.json"
    if not cj.exists(): return {"error": "先完成第③步找点"}
    plan = json.loads(cj.read_text(encoding="utf-8"))
    if not plan.get("cuts"): return {"error": "剪切点清单是空的(0条)。先点「找剪切点」再粗剪——防止把未剪的整片或空壳错渲出来"}
    if not plan.get("duration"):
        tj = Path(proj) / "转写.json"
        if tj.exists():
            plan["duration"] = json.loads(tj.read_text(encoding="utf-8")).get("duration", 0)
            cj.write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    mode = body.get("submode") or ("burn" if body.get("subs", True) else "off")
    mode = {"烧": "burn", "轴": "axis", "不": "off"}.get(mode, mode)
    if mode not in ("burn", "axis", "off"): mode = "burn"
    cmd = [PY, SCRIPTS / "render_cut.py", cj, "--out", Path(proj) / "rough.mp4",
           "--subs", {"burn": "auto", "axis": "axis", "off": "off"}[mode]]
    if not body.get("audio", True): cmd += ["--audio", "off"]
    if body.get("repair"): cmd += ["--repair", "on"]
    if body.get("fast"): cmd += ["--fast"]
    if body.get("repair"): cmd += ["--repair", "on"]
    cmd += ["--zoom", str(body.get("zoom") or 1)]   # 缺省=1(关闭):用户要求画面绝不缩放;想防跳脸可手动填1.06
    # tight=智能剪口播档:接缝呼吸补齐下限 0——找点已整段剪秃,再补齐等于把呼吸塞回去
    breath = {"tight": "0.0", "natural": "0.30", "calm": "0.35"}.get(sense_from(body), "0.30")
    cmd += ["--breath", breath]
    LABEL = {"burn": "字幕已烧进画面", "axis": "字幕未烧,只出时间轴(交给第④步做动画)", "off": "本条不出字幕"}[mode]

    def done():
        (Path(proj) / "渲染记录.json").write_text(json.dumps(
            {"字幕": LABEL, "模式": mode, "时间": time.strftime("%Y-%m-%d %H:%M:%S")},
            ensure_ascii=False, indent=1), encoding="utf-8")
        b = run_backup()
        _log(job_key(proj), "[自动备份] " + ("文本成果已存进工作流的「备份」目录" if b.get("ok") else "失败:" + b.get("error", "")))
    return start_job(proj, cmd, label="粗剪出片·" + {"burn": "烧字幕", "axis": "只出时间轴", "off": "无字幕"}[mode],
                     on_done=done, timeout=5400)

def fmt_t(t):
    t = float(t); mm = int(t // 60); return f"{mm:02d}:{t - mm*60:04.1f}"

def run_anchors(proj):
    """跑 anchor_time.py:分镜表的口播锚点 -> 成片时间码。返回 (日志, 报告dict, 返回码)"""
    cmd = [str(PY), str(SCRIPTS / "anchor_time.py"), str(proj)]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    rep_f = Path(proj) / "分镜时间轴.json"
    data = None
    if rep_f.exists():
        try: data = json.loads(rep_f.read_text(encoding="utf-8"))
        except Exception: data = None
    return ((p.stdout or "") + (p.stderr or "")).strip(), data, p.returncode

def action_anchors(proj, body):
    sb = Path(proj) / "分镜.csv"
    if not sb.exists(): return {"error": "①-B 还没有分镜表:先写镜头表(每行的「锚点」列或「字幕文本」列至少有一个能定位)"}
    if not (Path(proj) / "转写.json").exists(): return {"error": "先完成第②步转写,锚点要靠逐词时间戳定位"}
    log, data, rc = run_anchors(proj)
    if rc != 0: return {"error": log[-600:] or "锚点换算失败"}
    st = (data or {}).get("统计") or {}
    return {"ok": True, "log": log, "统计": st, "警告": (data or {}).get("警告", []),
            "基准": (data or {}).get("换算基准", ""), "总时长": (data or {}).get("成片总时长")}

def _handoff_ai(proj, body):
    proj = Path(proj)
    m = meta_of(proj)
    tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成第②步转写"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    rough = proj / "rough.mp4"
    lines = ["# 包装交接包(口播工作台生成)", "",
             f"- 粗剪成片: {rough if rough.exists() else str(m['media']) + '(尚未粗剪,先跑第③步)'}",
             f"- 素材总时长: {data.get('duration', 0):.1f}s",
             f"- 语言: {data.get('language', 'zh')}  模型: {data.get('model', '')}", "",
             "## 字幕文本(以实际口播转写为准,第④步上字幕用)", "",
             "| 时间码 | 文本 |", "|---|---|"]
    slf = slim_path(proj)
    if slf.exists():
        tgt = json.loads(slf.read_text(encoding="utf-8")).get("target")
        if tgt: lines.insert(4, f"- 成片时长要求: {tgt} 秒(超出部分必须继续删整段保核心,不能只靠剪停顿)")
    for s in data["segments"]:
        lines.append(f"| {fmt_t(s['start'])}–{fmt_t(s['end'])} | {s['text']} |")
    refs = refs_state(proj)
    if refs["items"]:
        lines += ["", "## 对标风格参考(第④步执行前必看)", "",
                  "AI 执行协议(对标精读,整段贴给豆包/Kimi/DeepSeek 等任意对话 AI),不许只答整体风格):先通看参考片说出它靠什么留人,再对每个要迁移的设计元素逐条回答六件事——"
                  "①内容与外观(字体/字重/颜色/描边/底衬) ②空间位置(占画面哪块、与主体什么关系) ③入场(怎么出现、落在哪个词或哪声音效上) "
                  "④存续期行为(停留时在动什么:逐字点亮/呼吸/位移) ⑤生命周期(活不活得过镜头切换、谁替换它) ⑥退场(消失方式与时长);"
                  "并一句话说明这个选择替观众完成了什么(立人设/对比两个说法/累积证据/放大情绪/让流程可读/把注意力交给下一句)。"
                  "动效名字只是起点,要看路径、缩放与透明度变化、速度、有没有过冲回弹。结论先给「本片照搬哪几项、放弃哪几项及理由」,"
                  "与现有视觉系统冲突处以参考为准,差异一句话告知用户;然后照旧走风格预览门,不许直接渲染。", ""]
        for it in refs["items"]:
            lp = it.get("path") or (Path(refs["folder"]) / it["name"])
            lines.append(f"- {it['kind']} | {lp} | {it.get('note','') or '未写说明:默认整体风格对标'}")
    rmf = proj / "对标点位.json"
    if rmf.exists():
        try:
            rd = json.loads(rmf.read_text(encoding="utf-8"))
            rrows = rd.get("点位") or []
            rst = rd.get("统计") or {}
            lines += ["", "## 对标点位表(对标每一镜在干什么;只有标「外部素材」的才真要一条画面)", "",
                      "- 拆解范围: 对标前 %ss | 共 %s 镜 | 每分钟切镜 %s | 需要外部素材 %s 个" % (
                          rd.get("分析窗口秒"), rst.get("镜头数"), rst.get("每分钟切镜"), rst.get("需要外部素材")),
                      "- 分类分布: " + " / ".join("%s %d" % (k, v) for k, v in (rst.get("分类分布") or {}).items()),
                      "- **禁止**为了填这些位置去网上下载别人的成片片段。缺素材一律按「处理方式」降级:" +
                      " 自制字卡 / 自制图形卡 / punch-in推镜+音效顶住切点 / 用户自己录屏或手机空镜。",
                      "- 待找清单(逐条,含关键词与来源建议): %s" % (proj / "素材需求.csv"), "",
                      "| 镜 | 对标时间 | 秒 | 最终分类 | 对标在干什么 | 对标处你在说什么 | 要放什么画面 | 关键词 | 怎么处理 |",
                      "|---|---|---|---|---|---|---|---|---|"]
            for r in rrows[:150]:
                lines.append("| %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
                    r.get("镜号", ""), r.get("时间码", ""), r.get("时长", ""),
                    r.get("我的分类") or r.get("机器分类", ""), str(r.get("功能猜测", ""))[:34],
                    str(r.get("对标处口播", ""))[:26], str(r.get("画面需要(你来填)", ""))[:20],
                    str(r.get("关键词候选", ""))[:18], str(r.get("处理方式", ""))[:24]))
            if rd.get("联系表"):
                lines += ["", "缩略图联系表(要看对标画面就看这些): " +
                          "、".join(str(proj / "对标点位" / n) for n in rd["联系表"])]
        except Exception as e:
            lines += ["", "! 对标点位.json 读不了,第④步按无点位表处理: " + str(e)]
    ast = assets_state(proj)
    if ast["items"]:
        lines += ["", "## 已提供素材清单(第④步直接用,勿再生成)", ""]
        for it in ast["items"]:
            lp = it.get("path") or (Path(ast["folder"]) / it["name"])
            lines.append(f"- {it['kind']} | {it.get('shot','') or '未标镜号'} | {lp}")
    wd = proj / "文案定稿.txt"
    if wd.exists():
        lines += ["", "## 文案定稿(用户亲自校对确认,字幕以此为准)", "", wd.read_text(encoding="utf-8").strip()]
    sb = proj / "分镜.csv"
    if sb.exists():
        alog, ax, arc = run_anchors(proj)
        if arc != 0:
            lines += ["", "## 分镜镜头表(第①步整理结果,图片/视频/动效按此插入)", "",
                      "> ! 锚点换算失败,时间码可能是旧的:" + alog[-300:], "",
                      sb.read_text(encoding="utf-8").strip()]
        else:
            st = (ax or {}).get("统计") or {}
            lines += ["", "## 分镜镜头表(时间码已由锚点自动换算,**勿手改秒数**;要挪位置就改锚点词再重算)", ""]
            if ax:
                lines += ["- 换算基准: %s | 成片总时长 %.1fs | 时间轴: %s" % (
                    ax.get("换算基准", "?"), float(ax.get("成片总时长") or 0), ax.get("轴", "?")),
                    "- 精确 %s / 待确认 %s / 未换算 %s" % (st.get("精确", 0), st.get("待确认", 0), st.get("未换算", 0))]
            lines += ["", sb.read_text(encoding="utf-8").strip()]
            if ax and ax.get("镜"):
                lines += ["", "### 锚点命中明细(第④步按「成片」列落位;每镜同时给源片时刻,便于回原片找画面)", "",
                          "| 镜号 | 锚点 | 实际命中词 | 成片 | 源片 | 状态 |", "|---|---|---|---|---|---|"]
                for r in ax["镜"]:
                    if "成片起" not in r: continue
                    lines.append("| %s | %s | %s | %s–%s | %s | %s |" % (
                        r.get("镜号", ""), r.get("锚点", ""), r.get("命中", ""),
                        fmt_t(r["成片起"]), fmt_t(r["成片止"]),
                        fmt_t(r["源起"]) if r.get("源起") is not None else "?", r.get("状态", "")))
            if ax and ax.get("警告"):
                lines += ["", "**需要你确认(%d 条,交接前处理掉;不做则第④步按现值执行)**" % len(ax["警告"])]
                lines += ["- " + w for w in ax["警告"]]
    rec = Path(proj) / "渲染记录.json"
    rj = json.loads(rec.read_text(encoding="utf-8")) if rec.exists() else {}
    tl = proj / "字幕时间轴.json"
    lines += ["", "## 字幕归属(先看这条,别叠两层)", ""]
    if rj.get("模式") == "axis":
        lines += ["- **底层画面没有字幕**:字幕由第④步负责做动画。",
                  "- 逐字时间轴:`%s`(每行含每个字的起止秒,已按成片轴换算 + 静音开口校正)" % (tl if tl.exists() else "缺,先回③重跑一次"),
                  "- 硬要求:**不要自行重新断句、不要重新估时间**,直接按 JSON 里的 起/止 驱动入场;",
                  "  字体/字号/下沿/配色照 JSON 里的 字体、字号px、下沿比例、字色、强调色 用,保持和直出版一致。" % ()]
    elif rj.get("模式") == "off":
        lines += ["- 本次渲染**不出字幕**,画面干净。第④步若要加字,自行按分镜与文案定稿处理。"]
    elif rj.get("模式") == "burn":
        lines += ["- **底层画面已经烧好字幕(思源宋体/无描边无阴影/逐字点亮)**:",
                  "  第④步**禁止再加一层字幕**,否则会双层叠字糊掉;",
                  "  要改字幕样式或换成动画字幕,请回③把字幕模式改成「只出时间轴」再重渲,不要在这里盖。",
                  "- 本步只做增量包装:花字、人名条、金句卡、B-roll、封面、竖屏裁切。"]
    else:
        lines += ["- 没找到 渲染记录.json:不确定字幕是否已烧。先看一眼 rough.mp4 有没有字,再决定第④步要不要加字幕。"]
    lines += ["", "## 第④步说明", "",
              "这一步是可选精包装:把本文件整段贴给你常用的对话 AI(豆包/Kimi/DeepSeek 等均可),让它按分镜表逐镜给花字/人名条/金句卡建议;",
              "你也可以忽略 AI、直接在剪映里手动补,功能不受影响;不做第④步,粗剪本身就能发。"]
    _ids = _ideas_lines(proj)
    if _ids:
        lines += ["", "## 你的包装要求(①-B 想法箱原话,逐条处理:照做,或不照做必须写一句理由,不许无视)", ""]
        lines += ["- " + x for x in _ids]
        lines += ["", "(以上是人亲自提的意图,优先级高于执行方自己的审美偏好;与画面/字幕冲突时按此调整并在交付说明里讲一句)"]
    out = proj / "包装交接.md"
    out.write_text("\n".join(lines), encoding="utf-8")
    return {"ok": True, "file": str(out)}

ASSET_EXT = {"jpg","jpeg","png","webp","gif","bmp","mp4","mov","m4v","avi","mkv","mp3","wav","m4a"}

def action_handoff(proj, body):
    """按目标分发:ai=包装交接.md(老行为不变);jianying=调 jy_handoff.py 建剪映草稿,
    建不成自动降级出 剪映交接.md 操作脚本;both=先 ai 后剪映。"""
    to = (body or {}).get("to") or "ai"
    if to == "ai":
        return _handoff_ai(proj, body)
    out = {}
    if to == "both":
        out["AI交接"] = _handoff_ai(proj, body)
    if to in ("jianying", "both"):
        r2 = handoff_jianying(proj, body or {})
        out["剪映交接"] = r2
        if r2.get("error"):
            out["error"] = r2["error"]
    return out


def handoff_jianying(proj, body):
    """④ 剪映交接子进程调用。前置没齐直接人话报错;时间轴旧了先补跑一次 ⚓(和AI交接同规则)。
    失败绝不静默:脚本没出 RESULT 行就把退出码和日志尾巴端出来。"""
    proj = Path(proj)
    if not (proj / "rough.mp4").exists():
        return {"error": "③-D 还没出片,剪映交接做不了:先把粗剪 rough.mp4 跑出来"}
    if not (proj / "分镜.csv").exists():
        return {"error": "①-B 还没有分镜表:先写镜头表再交接剪映"}
    tl = proj / "分镜时间轴.json"
    if not tl.exists() or (proj / "分镜.csv").stat().st_mtime > tl.stat().st_mtime:
        r = action_anchors(proj, {})
        if r.get("error"):
            return {"error": "算分镜秒数失败,剪映交接暂停: " + (r["error"] or "")[-160:]}
    cmd = [str(PY), str(SCRIPTS / "jy_handoff.py"), str(proj)]
    if body.get("draft_root"):
        cmd += ["--draft-root", str(body["draft_root"])]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=180)
    except Exception as e:
        print("[剪映交接起进程失败] %s: %s" % (proj, e))
        return {"error": "剪映交接脚本没跑起来: %s" % e}
    log = ((p.stdout or "") + (p.stderr or "")).strip()
    res = None
    for line in reversed(log.splitlines()):
        if line.startswith("RESULT "):
            try:
                res = json.loads(line[7:])
            except Exception as e:
                print("[剪映交接RESULT解析失败] %s: %s" % (proj, e))
            break
    if res is None:
        print("[剪映交接无结果] rc=%s %s" % (p.returncode, log[-200:]))
        return {"error": "剪映交接没返回结果(退出码%s): %s" % (p.returncode, (log[-200:] or "无输出"))}
    res["日志尾"] = log[-300:]
    return res


def assets_state(proj):
    proj = Path(proj); folder = proj / "素材"; items = []
    if folder.exists():
        for f in sorted(folder.iterdir()):
            if f.suffix.lower().lstrip(".") in ASSET_EXT:
                kind = "video" if f.suffix.lower() in (".mp4", ".mov", ".m4v", ".avi", ".mkv") else ("audio" if f.suffix.lower() in (".mp3", ".wav", ".m4a") else "image")
                items.append({"name": f.name, "src": "folder", "kind": kind, "size_kb": f.stat().st_size // 1024})
    reg = proj / "素材登记.json"
    if reg.exists():
        for r in json.loads(reg.read_text(encoding="utf-8")):
            if Path(r["path"]).exists():
                kind = "video" if Path(r["path"]).suffix.lower() in (".mp4", ".mov", ".m4v") else "image"
                items.append({"name": Path(r["path"]).name, "src": "external", "kind": kind, "path": r["path"],
                              "shot": r.get("shot", ""), "note": r.get("note", "")})
    return {"folder": str(folder), "items": items}

REF_EXT = {"jpg","jpeg","png","webp","gif","mp4","mov","m4v"}

def refs_state(proj):
    proj = Path(proj); folder = proj / "参考"; items = []
    if folder.exists():
        for f in sorted(folder.iterdir()):
            if f.suffix.lower().lstrip(".") in REF_EXT:
                kind = "video" if f.suffix.lower() in (".mp4",".mov",".m4v") else "image"
                items.append({"name": f.name, "src": "folder", "kind": kind})
    reg = proj / "参考登记.json"
    if reg.exists():
        for i, r in enumerate(json.loads(reg.read_text(encoding="utf-8"))):
            if Path(r["path"]).exists():
                kind = "video" if Path(r["path"]).suffix.lower() in (".mp4",".mov",".m4v") else "image"
                items.append({"name": Path(r["path"]).name, "src": "external", "idx": i, "kind": kind,
                              "path": r["path"], "note": r.get("note","")})
    return {"folder": str(folder), "items": items}

def poster_file(proj, name):
    d = Path(proj) / ".封面"; d.mkdir(exist_ok=True)
    safe = "".join(ch for ch in name if ch not in '\\/:*?"<>|')
    return d / (safe + ".jpg")

def make_poster(src, dst):
    """ffmpeg 抽一帧做封面:先试第1秒,失败回退首帧(短视频/异常时间戳)"""
    for ss in (["-ss", "1"], []):
        r = subprocess.run(["ffmpeg", "-y", "-v", "error"] + ss + ["-i", str(src),
                        "-frames:v", "1", "-vf", "scale=320:-2", str(dst)], capture_output=True, text=True)
        if r.returncode == 0 and dst.exists() and dst.stat().st_size > 500:
            return True
        dst.unlink(missing_ok=True)
    return False

def resolve_media(proj, kind, fname, abspath):
    proj = Path(proj)
    if abspath:
        reg = proj / ("参考登记.json" if kind == "ref" else "素材登记.json")
        lst = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else []
        for r in lst:
            if str(Path(r["path"]).resolve()) == str(Path(abspath).resolve()):
                return Path(r["path"])
        return None
    safe = Path(fname or "").name
    base = proj / ("参考" if kind == "ref" else "素材")
    fp = base / safe
    return fp if fp.exists() and str(fp.resolve()).startswith(str(base.resolve())) else None

SCOPE_FILES = {
    "storyboard": ["分镜.csv"],
    "script": ["文案定稿.txt", "script_state.json"],
    "transcribe": ["转写.json"],
    "style": ["对标风格.json", "剪辑参数.json", "字幕.ass", "字幕.srt", "字幕时间轴.json"],
    "cuts": ["剪切点清单.json", "剪切点清单.csv", "剪切点清单.prev.json", "剪切点清单_1分钟版.json",
             "rough_预览.mp4", "字幕.ass", "字幕.srt", "字幕时间轴.json", "渲染记录.json",
             "auto_edit_request.json", "auto_edit_result.json", "rough.mp4", "rough_1分钟.mp4",
             "精简取舍.json", "剪切点.剪切点.json", "剪切点.剪切点.csv"],
    "handoff": ["包装交接.md", "剪映交接.json", "剪映交接.md", "风格预览", "1分钟版决策.md"],
    "shotmap": ["对标点位.json", "对标点位.csv", "素材需求.csv", "对标点位"],
    "textstyle": ["对标文字.json", "文字效果报告.md", "文字方案.json", "文字效果执行卡.md", "对标文字块"],
}
SCOPE_FILES["all"] = [x for k in ("storyboard","script","transcribe","style","shotmap","textstyle","cuts","handoff") for x in SCOPE_FILES[k]]

def trash_paths(proj):
    tr = Path(proj) / ".trash"; tr.mkdir(exist_ok=True)
    idx = tr / "index.json"
    stack = json.loads(idx.read_text(encoding="utf-8")) if idx.exists() else []
    return tr, idx, stack

def step_snap(proj, files, scope):
    """关键修改前给现状拍快照,支持每步连续撤回;同一步最多留 15 版,旧的自动清理"""
    proj = Path(proj)
    exist = [f for f in files if (proj / f).exists()]
    if not exist: return
    try:
        tr, idx, stack = trash_paths(proj)
        snap = tr / ("step-%s-%d" % (scope, int(time.time() * 1000)))
        snap.mkdir()
        for f in exist:
            shutil.copyfile(proj / f, snap / f)
        stack.append({"type": "step", "scope": scope, "snap": snap.name, "files": exist})
        # 每 scope 只留最近 15 版
        mine = [e for e in stack if e.get("type") == "step" and e.get("scope") == scope]
        for old in mine[:-15]:
            shutil.rmtree(tr / old["snap"], ignore_errors=True)
            stack.remove(old)
        idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass

def step_undo(proj, scope):
    proj = Path(proj); tr, idx, stack = trash_paths(proj)
    pos = next((i for i in range(len(stack) - 1, -1, -1)
                if stack[i].get("type") == "step" and stack[i].get("scope") == scope), None)
    if pos is None: return {"error": "这一步还没有可撤回的修改"}
    e = stack.pop(pos)
    snap = tr / e["snap"]; restored = []
    for n in e["files"]:
        src = snap / n
        if not src.exists(): continue
        if (proj / n).exists():
            (tr / ("conflict-" + e["snap"])).mkdir(exist_ok=True)
            shutil.move(str(proj / n), str(tr / ("conflict-" + e["snap"]) / n))
        shutil.move(str(src), str(proj / n)); restored.append(n)
    idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    shutil.rmtree(snap, ignore_errors=True)
    left = sum(1 for x in stack if x.get("type") == "step" and x.get("scope") == scope)
    return {"ok": True, "restored": restored, "left": left}

def action_reset(proj, scope):
    if scope not in SCOPE_FILES: return {"error": "未知范围"}
    proj = Path(proj); tr, idx, stack = trash_paths(proj)
    names = [n for n in SCOPE_FILES[scope] if (proj / n).exists()]
    if not names: return {"error": "这一步还没有产物,无需重置"}
    import time as _t
    snap = tr / ("reset-" + _t.strftime("%Y%m%d-%H%M%S"))
    snap.mkdir()
    for n in names:
        shutil.move(str(proj / n), str(snap / n))
    stack.append({"scope": scope, "snap": snap.name, "files": names})
    idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "moved": names, "n": len(stack)}

def action_undo_reset(proj):
    proj = Path(proj); tr, idx, stack = trash_paths(proj)
    pos = next((i for i in range(len(stack) - 1, -1, -1) if stack[i].get("type") != "step"), None)
    if pos is None: return {"error": "没有可撤回的重置"}
    top = stack.pop(pos)
    snap = tr / top["snap"]; restored = []
    for n in top["files"]:
        src = snap / n
        if not src.exists(): continue
        if (proj / n).exists():
            cf = tr / ("conflict-" + top["snap"]); cf.mkdir(exist_ok=True)
            shutil.move(str(proj / n), str(cf / n))
        shutil.move(str(src), str(proj / n)); restored.append(n)
    idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    shutil.rmtree(snap, ignore_errors=True)
    return {"ok": True, "restored": restored, "left": len(stack)}

FILL_SET = {"嗯", "呃", "额", "那个", "就是说", "怎么说呢", "对吧", "其实吧", "反正就是"}

def script_state_path(proj): return Path(proj) / "script_state.json"

def load_state(proj, 空=None):
    """读 script_state.json:末尾有垃圾字符也取回第一份完整对象,彻底读不了就退回空进度。
    返回 (状态dict, 提示语)。①-A 每次写回都会顺手把垃圾尾巴清掉(自愈)。"""
    f = script_state_path(proj)
    空 = dict(空 if 空 is not None else {"questions": [], "draft": "", "final": "", "mode": "wenan"})
    if not f.exists(): return 空, ""
    raw = (f.read_text(encoding="utf-8") or "").lstrip()
    try:
        st = json.loads(raw)
    except Exception as e:
        try:
            st, end = json.JSONDecoder().raw_decode(raw)
            余 = len(raw[end:].strip())
            if not isinstance(st, dict): raise ValueError("内容不是对象")
            提 = "script_state.json 末尾多了 %d 个字符,已按前面部分读取;这次保存会写干净" % 余 if 余 \
                else "script_state.json 有格式问题(%s),已按能读的部分恢复" % e
            print("[①-A 状态文件] " + 提)
            return st, 提
        except Exception as e2:
            提 = "script_state.json 读不了(%s):①-A 的删/留问答进度丢了,文案定稿不受影响" % e2
            print("[①-A 状态文件] " + 提)
            return 空, 提
    if not isinstance(st, dict):
        提 = "script_state.json 内容不是对象(是 %s),已按空进度继续" % type(st).__name__
        print("[①-A 状态文件] " + 提)
        return 空, 提
    return st, ""


def script_state(proj):
    """①-A 的问答进度 + 定稿状态;文件坏了也要能出页面,并把原因带到界面上。"""
    st, 提 = load_state(proj)
    if 提: st["文件警告"] = 提
    st.setdefault("adds", [])
    st["has_final"] = (Path(proj) / "文案定稿.txt").exists()
    return st


def script_save_draft(proj, text):
    """切走自动存文案草稿(G1需求:做一半切走要存住,回来还在,再切走再存)。
    只动 draft 字段,不碰问答进度;文件损坏自愈沿用 load_state。"""
    st, 提 = load_state(proj)
    st["draft"] = str(text or "")
    try:
        script_state_path(proj).write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        print("[草稿保存失败] %r" % e)
        return {"error": "草稿没存上:" + repr(e)[:120]}
    out = {"ok": True}
    if 提: out["提示"] = 提
    return out


def script_analyze(proj):
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    segs = data["segments"]
    norm = lambda s: re.sub(r"[^\w\u4e00-\u9fff]", "", s)
    qs = []
    # 1) 口头禅 & 连续重复词(词级)
    for si, seg in enumerate(segs):
        ws = seg["words"]
        for wi, w in enumerate(ws):
            txt = w["word"]
            if txt in FILL_SET:
                qs.append({"id": len(qs), "type": "口头禅", "time": w["start"], "text": txt,
                           "why": "填充词", "answer": "删", "del_words": [[si, wi]]})
            if wi and ws[wi - 1]["word"] == txt and w["start"] - ws[wi - 1]["end"] < 0.35:
                qs.append({"id": len(qs), "type": "重复词", "time": w["start"], "text": txt,
                           "why": "上一词刚说过" + txt, "answer": "删", "del_words": [[si, wi]]})
    # 2) 整句重录(句级:窗口内相似/包含)
    import difflib
    consumed = set()
    for i in range(len(segs)):
        if i in consumed: continue
        a = norm(segs[i]["text"])
        if len(a) < 4: continue
        for j in range(i + 1, min(i + 5, len(segs))):
            if segs[j]["start"] - segs[i]["end"] > 15: break
            b = norm(segs[j]["text"])
            if len(b) < 4: continue
            sim = difflib.SequenceMatcher(None, a, b).ratio()
            if a in b or b in a or sim >= 0.6:
                drop = i if len(a) <= len(b) else j
                keep = j if drop == i else i
                consumed.add(i); consumed.add(j)
                qs.append({"id": len(qs), "type": "整句重录", "time": segs[drop]["start"],
                           "text": segs[drop]["text"], "why": f"与 {segs[keep]['start']:.1f}s 的「{segs[keep]['text'][:18]}…」相似,建议删前者",
                           "answer": "删", "del_segs": [drop]})
                break
    st = {"questions": qs, "draft": "", "final": "", "mode": "wenan", "sub": "auto", "media_dur": data.get("duration", 0)}
    script_state_path(proj).write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "n": len(qs)}

def build_draft(proj, st):
    data = json.loads((Path(proj) / "转写.json").read_text(encoding="utf-8"))
    del_segs = set(); del_words = set()
    for q in st["questions"]:
        if q["answer"] != "删": continue
        for si in q.get("del_segs", []): del_segs.add(si)
        for si, wi in q.get("del_words", []): del_words.add((si, wi))
    entries = []
    for si, seg in enumerate(data["segments"]):
        if si in del_segs: continue
        ws = seg["words"]
        if ws and all((si, wi) in del_words for wi in range(len(ws))): continue
        txt = "".join(w["word"] for wi, w in enumerate(ws) if (si, wi) not in del_words)
        if txt.strip(): entries.append([float(seg["start"]), txt])
    for a in st.get("adds", []):
        txt = (a.get("text") or "").strip()
        if not txt: continue
        try: ts = float(a.get("time", 0))
        except Exception: ts = 0.0
        entries.append([ts, txt])
    entries.sort(key=lambda x: x[0])
    st["draft"] = "\n".join(e[1] for e in entries)
    return entries

def script_apply(proj):
    proj = Path(proj)
    st, _ = load_state(proj)
    entries = build_draft(proj, st)
    script_state_path(proj).write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "lines": len(entries)}

def script_add(proj, t, text):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "adds": []})
    st.setdefault("adds", [])
    text = (text or "").strip()
    if not text: return {"error": "补的文案不能为空"}
    if not (proj / "转写.json").exists() and not st["adds"]:
        return {"error": "先完成②转写"}
    try: ts = float(t)
    except Exception: return {"error": "补句时间无效,请先定位到这句的播放时间"}
    st["adds"].append({"time": ts, "text": text})
    build_draft(proj, st)
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "n": len(st["adds"])}

def script_del_add(proj, idx):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "adds": []})
    adds = st.get("adds", [])
    try: i = int(idx)
    except Exception: return {"error": "序号无效"}
    if i < 0 or i >= len(adds): return {"error": "序号越界"}
    adds.pop(i)
    build_draft(proj, st)
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "n": len(adds)}

def script_answer(proj, qid, action):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "adds": []})
    for q in st.get("questions") or []:
        if q["id"] == int(qid): q["answer"] = action
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True}

def script_final(proj, text, sub):
    proj = Path(proj)
    step_snap(proj, ["文案定稿.txt", "script_state.json"], "s1")
    (proj / "文案定稿.txt").write_text(text, encoding="utf-8")
    f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "mode": "wenan"})
    st.update({"final": text[:120], "mode": "wenan", "sub": sub, "final_at": time.strftime("%m-%d %H:%M")})
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True}

def script_mode(proj, mode, sub=None):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "mode": mode})
    st["mode"] = mode
    if sub: st["sub"] = sub
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True}


# 繁→简安全对照:只放无歧义的(著/髮發/乾/後 这类一形多义的故意排除,避免机器改错字)
TRAD = {"蘭": "兰", "贊": "赞", "們": "们", "國": "国", "際": "际", "體": "体", "廣": "广", "東": "东",
        "車": "车", "馬": "马", "鳥": "鸟", "魚": "鱼", "龍": "龙", "風": "风", "雲": "云", "電": "电",
        "書": "书", "畫": "画", "學": "学", "實": "实", "對": "对", "時": "时", "來": "来", "說": "说",
        "話": "话", "語": "语", "認": "认", "為": "为", "於": "于", "與": "与", "這": "这", "經": "经",
        "過": "过", "還": "还", "裏": "里", "裡": "里", "間": "间", "織": "织", "紙": "纸", "錢": "钱",
        "銀": "银", "鋼": "钢", "鐵": "铁", "鋁": "铝", "優": "优", "備": "备", "頭": "头", "顏": "颜",
        "顯": "显", "術": "术", "藝": "艺", "節": "节", "簡": "单", "複": "复", "變": "变", "讓": "让",
        "產": "产", "業": "业", "員": "员", "數": "数", "據": "据", "關": "关", "開": "开", "閉": "闭",
        "問": "问", "題": "题", "類": "类", "樣": "样", "確": "确", "義": "义", "習": "习", "慣": "惯",
        "營": "营", "銷": "销", "贊": "赞", "應": "应", "態": "态", "滿": "满", "燈": "灯", "發": "发",
        "紀": "纪", "約": "约", "縮": "缩", "網": "网", "絡": "络", "細": "细", "結": "结", "給": "给",
        "統": "统", "規": "规", "則": "则", "覺": "觉", "議": "议", "記": "记", "設": "设", "計": "计"}

def script_check(proj):
    """定稿体检:1) 繁体混入(可一键改) 2) 机器低置信词(只能你人工看)"""
    proj = Path(proj); wd = proj / "文案定稿.txt"; tj = proj / "转写.json"
    out = {"繁体": [], "低置信": [], "说明": []}
    if wd.exists():
        txt = wd.read_text(encoding="utf-8")
        hits = {}
        for i, line in enumerate(txt.splitlines(), 1):
            for ch in line:
                if ch in TRAD:
                    h = hits.setdefault(ch, {"字": ch, "建议": TRAD[ch], "次数": 0, "行": []})
                    h["次数"] += 1
                    if len(h["行"]) < 3: h["行"].append(i)
        out["繁体"] = sorted(hits.values(), key=lambda x: -x["次数"])
        if not out["繁体"]: out["说明"].append("没发现繁体字混入")
    else:
        out["说明"].append("还没有文案定稿:先在①-A 确认定稿")
    if tj.exists():
        try:
            data = json.loads(tj.read_text(encoding="utf-8"))
            low = {}
            for seg in data.get("segments", []):
                for w in seg.get("words", []):
                    p = float(w.get("p", 1))
                    t = (w.get("word") or "").strip()
                    if p < 0.62 and len(t) >= 2 and t not in low:
                        low[t] = {"词": t, "置信": round(p, 2), "时间": round(float(w["start"]), 1)}
            out["低置信"] = sorted(low.values(), key=lambda x: x["置信"])[:40]
            if not out["低置信"]: out["说明"].append("没有低置信词(阈值 0.62)")
        except Exception as e:
            out["说明"].append("读转写失败:" + str(e))
    out["可自动修"] = sum(h["次数"] for h in out["繁体"])
    return out

def script_fix_trad(proj):
    """只替换安全对照表里的繁体字,改前备份 文案定稿.prev.txt"""
    proj = Path(proj); wd = proj / "文案定稿.txt"
    if not wd.exists(): return {"error": "还没有文案定稿"}
    txt = wd.read_text(encoding="utf-8")
    n = 0
    for a, b in TRAD.items():
        c = txt.count(a)
        if c: txt = txt.replace(a, b); n += c
    if not n: return {"error": "没有可自动替换的繁体字(其余错字得你自己看)"}
    (proj / "文案定稿.prev.txt").write_text(wd.read_text(encoding="utf-8"), encoding="utf-8")
    wd.write_text(txt, encoding="utf-8")
    return {"ok": True, "n": n, "备份": "文案定稿.prev.txt"}


def autojob_state(proj):
    req = Path(proj) / "auto_edit_request.json"
    res = Path(proj) / "auto_edit_result.json"
    return {"request": json.loads(req.read_text(encoding="utf-8")) if req.exists() else None,
            "result": json.loads(res.read_text(encoding="utf-8")) if res.exists() else None}

def slim_path(proj): return Path(proj) / "精简取舍.json"

def slim_state(proj):
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    segs = [{"i": i, "start": round(sg["start"], 2), "end": round(sg["end"], 2), "text": sg["text"]}
            for i, sg in enumerate(data["segments"])]
    return {"target": st.get("target"), "removed": st.get("removed", []), "segments": segs,
            "duration": data.get("duration", 0), "window": st.get("window")}

def slim_save(proj, target, removed, window=...):
    proj = Path(proj); f = slim_path(proj)
    step_snap(proj, ["精简取舍.json"], "s3")
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    if target is not None:
        try: v = int(float(target))
        except Exception: return {"error": "目标时长无效"}
        if not (3 <= v <= 3600): return {"error": "目标时长要在 3~3600 秒之间"}
        st["target"] = v
    if removed is not None:
        st["removed"] = sorted(set(int(x) for x in removed))
    if window is not ...:
        if window is None:
            st.pop("window", None); st["removed"] = []
        else:
            st["window"] = [float(window[0]), float(window[1])]
    f.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "target": st.get("target"), "removed": len(st.get("removed", []))}

def slim_apply(proj):
    proj = Path(proj); tj = proj / "转写.json"
    step_snap(proj, ["剪切点清单.json", "精简取舍.json"], "s3")
    if not tj.exists(): return {"error": "先完成②转写"}
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    rm = st.get("removed", [])
    if not rm: return {"error": "还没有勾选要删的句子"}
    data = json.loads(tj.read_text(encoding="utf-8")); segs = data["segments"]
    dur = data.get("duration", 0)
    win = st.get("window")
    backup_cuts(proj)
    cf = proj / "剪切点清单.json"
    old = json.loads(cf.read_text(encoding="utf-8")) if cf.exists() else {}
    new = [c for c in old.get("cuts", []) if c.get("类型") != "精简删句"]
    inwin = lambda i: True
    if win:
        w0, w1 = float(win[0]), float(win[1])
        new = [c for c in new if c.get("开始", 0) >= w0 - 0.05 and c.get("结束", 9e9) <= w1 + 0.05]
        if w0 > 0.05:
            new.append({"类型": "精简删句", "开始": 0.0, "结束": round(w0 - 0.03, 3), "时长": round(w0 - 0.03, 3),
                        "文字": "定点截取掐头", "理由": f"⚓ 只保留 {w0:.1f}s→{w1:.1f}s,窗口前整段移除", "执行": "删"})
        if dur - w1 > 0.05:
            new.append({"类型": "精简删句", "开始": round(w1 + 0.03, 3), "结束": dur, "时长": round(dur - w1 - 0.03, 3),
                        "文字": "定点截取去尾", "理由": f"⚓ 只保留 {w0:.1f}s→{w1:.1f}s,窗口后整段移除", "执行": "删"})
        inwin = lambda i: segs[i]["start"] >= w0 - 0.05 and segs[i]["end"] <= w1 + 0.05
    for i in rm:
        if not inwin(i): continue
        if 0 <= i < len(segs):
            cs = round(segs[i]["start"] + 0.03, 3); ce = round(segs[i]["end"] - 0.03, 3)
            if ce - cs >= 0.05:
                new.append({"类型": "精简删句", "开始": cs, "结束": ce, "时长": round(ce - cs, 3),
                            "文字": segs[i]["text"][:24], "理由": f"凑时长:整段移除(目标 {st.get('target','?')} 秒)", "执行": "删"})
    new.sort(key=lambda c: c["开始"])
    for i, c in enumerate(new, 1): c["序号"] = i
    payload = {"media": old.get("media", (meta_of(proj) or {}).get("media", "")),
               "duration": data.get("duration", 0), "cuts": new}
    cf.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    ivs = sorted([(c["开始"], c["结束"]) for c in new if c.get("执行") == "删"])
    merged = []
    for a, b in ivs:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    dur = data.get("duration", 0)
    saved = sum(min(b, dur) - a for a, b in merged if b > a)
    pad = 0.0                              # 粗剪会把每个接缝的气口补到 0.30s,估算必须算进去
    for a, b in merged:
        if b <= a: continue
        prev = [x for x in segs if x["end"] <= a + 0.02]
        nxt = [x for x in segs if x["start"] >= b - 0.02]
        if not prev or not nxt: continue
        need = 0.30 - max(0.0, a - prev[-1]["end"]) - max(0.0, nxt[0]["start"] - b)
        if need > 0.02: pad += need
    return {"ok": True, "n": len(rm), "est": round(max(0, dur - saved + pad), 1),
            "pad": round(pad, 1), "target": st.get("target")}

def slim_suggest(proj):
    """自动凑目标时长建议:启发式打分,低分句勾为删,人来复核"""
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    target = st.get("target")
    if not target: return {"error": "先填目标秒数并保存"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    segs = data["segments"]
    n = len(segs)
    def score(i, sg):
        txt = (sg.get("text") or "").strip()
        dur = sg["end"] - sg["start"]
        sc = 0.0
        if i < 2: sc += 2.5                      # 开头钩子
        if i >= n - 2: sc += 1.5                 # 收尾句
        if re.search(r"\d", txt): sc += 1.5      # 带数据
        if re.search(r"[但却其实竟然结果原来秘密为什么怎么办]", txt): sc += 1.0
        sc += min(len(txt) / 20.0, 1.0)          # 信息量
        if re.match(r"^(然后|就是说|对|嗯|呃|那)", txt): sc -= 1.5
        if dur < 0.8: sc -= 1.0                  # 碎片句
        return sc
    scored = sorted(range(n), key=lambda i: score(i, segs[i]))
    removed, est = [], data.get("duration", 0)
    for i in scored:
        if est <= target: break
        removed.append(i)
        est -= segs[i]["end"] - segs[i]["start"]
    removed.sort()
    st["removed"] = removed
    build_draft = None  # 精简与文案草稿无关,占位防误删
    f.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "n": len(removed), "est": round(est, 1), "target": target}

def slim_take(proj, t):
    """定点起播截取:以打入点为起点,自动向后取满目标时长,按句界对齐,窗口外整段勾删"""
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    target = st.get("target")
    if not target: return {"error": "先在「成片时长要求」填目标秒数"}
    try: t0 = float(t)
    except Exception: return {"error": "打入点无效:先把视频播到起点位置再按按钮"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    segs = data["segments"]
    i0 = next((i for i, sg in enumerate(segs) if sg["end"] > t0), None)
    if i0 is None: return {"error": "打入点已在片尾之后"}
    i1, total = i0 - 1, 0.0
    for i in range(i0, len(segs)):
        i1 = i; total += segs[i]["end"] - segs[i]["start"]
        if total >= target: break
    if i1 + 1 < len(segs):
        nd = segs[i1+1]["end"] - segs[i1+1]["start"]
        if abs(total + nd - target) < abs(total - target):
            i1 += 1; total += nd
    st["window"] = [round(segs[i0]["start"], 2), round(segs[i1]["end"], 2)]
    st["removed"] = [i for i in range(len(segs)) if not (i0 <= i <= i1)]
    f.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "start": round(segs[i0]["start"], 1), "end": round(segs[i1]["end"], 1),
            "est": round(total, 1), "target": target, "kept": i1 - i0 + 1}

def read_cuts(proj):
    f = Path(proj) / "剪切点清单.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {"cuts": []}

# ---------- 卡密激活(阶段2:零服务器;执法=水印+吊销,详见 scripts/gen_keys.py 头注) ----------
import hashlib
卡密表 = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"          # 32字符,去 I O 0 1
授权文件 = WF / "license.json"
黑名单文件 = WF / "黑名单.txt"                        # 随更新包分发,一行一码
便携标记 = WF / "便携版标记.txt"                      # 存在=正式发货版,必须激活;自用/体验副本没有这文件

def 卡密校验(s):
    x = re.sub(r"[^0-9A-Za-z]", "", str(s or "")).upper()
    if len(x) != 16 or not x.startswith("DXXK"): return False
    体, 检 = x[4:15], x[15]
    if any(c not in 卡密表 for c in 体 + 检): return False
    return 卡密表[sum((i + 1) * 卡密表.index(c) for i, c in enumerate(体)) % 32] == 检

def 规范卡密(s):
    x = re.sub(r"[^0-9A-Za-z]", "", str(s or "")).upper()
    return "%s-%s-%s-%s" % (x[:4], x[4:8], x[8:12], x[12:16]) if len(x) == 16 else x

def 机器指纹():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
        v = winreg.QueryValueEx(k, "MachineGuid")[0]
        return hashlib.sha256(("fp|" + str(v)).encode()).hexdigest()[:16]
    except Exception as e:
        print("[license] MachineGuid 读不到,退回 MAC+主机名: %r" % e)
        try:
            import uuid
            return hashlib.sha256(("fp2|%s|%s" % (uuid.getnode(), os.environ.get("COMPUTERNAME", ""))).encode()).hexdigest()[:16]
        except Exception as e2:
            print("[license] 指纹兜底也失败: %r" % e2)
            return "unknown"

def feedback_pack(dst=None):
    """🎫 反馈单:把排障材料打成一个 zip 存到桌面,由用户自愿发给作者;绝不自动上传(隐私铁律)。
    只装"看问题"的东西:诊断报告/日志尾部/授权状态/项目元数据清单——不带字幕文案、分镜内容、任何媒体文件。"""
    import zipfile
    名 = "点心工作台-反馈单-" + time.strftime("%Y%m%d-%H%M%S") + ".zip"
    if dst is None:
        桌 = Path.home() / "Desktop"
        dst = (桌 / 名) if 桌.exists() else (WF / 名)
    def 尾(f, n行=400):
        f = Path(f)
        if not f.exists(): return ""
        try:
            ls = f.read_text(encoding="utf-8", errors="replace").splitlines()
            return "\n".join(ls[-n行:])
        except Exception as e:
            print("[反馈单读文件失败 %s] %r" % (f, e))
            return ""
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("环境诊断.json", json.dumps(run_doctor(), ensure_ascii=False, indent=1))
        z.writestr("授权状态.json", json.dumps(lic_status(), ensure_ascii=False, indent=1))
        if 授权文件.exists():
            z.writestr("license原文.json", 尾(授权文件, 50))
        z.writestr("运行日志尾.txt", 尾(LOGF, 300))
        z.writestr("启动日志尾.txt", 尾(WF / "启动日志.txt", 120))
        z.writestr("说明自检.txt", 尾(WF / "工作台" / "说明自检.txt", 50))
        清 = ["版本: %s" % VERSION, "打包时间: " + time.strftime("%Y-%m-%d %H:%M:%S"), ""]
        try:
            for d in sorted(Path(ROOT).iterdir()):
                if not d.is_dir() or d.name == ".trash": continue
                清.append("【项目】%s" % d.name)
                pj = d / "项目.json"
                if pj.exists():
                    清.append("  项目.json: " + pj.read_text(encoding="utf-8-sig")[:400].replace("\n", " "))
                for f in sorted(d.iterdir()):
                    if f.is_file():
                        清.append("  %s  %d KB" % (f.name, f.stat().st_size // 1024))
                清.append("")
        except Exception as e:
            清.append("[项目清单扫描失败] %r" % e)
        z.writestr("项目清单.txt", "\n".join(清))
    print("[反馈单] 已生成 %s" % dst)
    return {"ok": True, "文件": str(dst)}


def 需要激活():
    return 便携标记.exists()

def 黑名单集():
    if not 黑名单文件.exists(): return set()
    try:
        return {规范卡密(x) for x in 黑名单文件.read_text(encoding="utf-8-sig").splitlines() if x.strip() and not x.strip().startswith("#")}
    except Exception as e:
        print("[license] 黑名单读不了: %r" % e)
        return set()

def _读授权():
    if not 授权文件.exists(): return {}
    try:
        return json.loads(授权文件.read_text(encoding="utf-8"))
    except Exception as e:
        print("[license] 授权文件读不了(按未激活处理): %r" % e)
        return {}

def lic_status():
    if not 需要激活():
        return {'模式': '免激活', '版本': VERSION}
    d = _读授权(); k = str(d.get('卡密', ''))
    黑 = 黑名单集()
    到期 = str(d.get('更新到期', ''))
    录 = str(d.get('机器指纹') or '')
    换机 = False
    if k:
        本 = 机器指纹()
        # 老记录没写指纹、或本机指纹读不到时不误伤(按原样认,不把正版用户锁在门外)
        换机 = bool(录) and 录 != 'unknown' and 本 != 'unknown' and 录 != 本
        if 换机:
            print('[license] 授权记录绑在别的机器(卡密 %s…),本机按未激活处理' % k[:9])
    return {'模式': '正式', '版本': VERSION, '已激活': bool(k) and not 换机,
            '已吊销': bool(k) and k in 黑, '换机': 换机,
            '卡密': (k[:9] + '…' + k[-4:]) if len(k) >= 19 else k,
            '更新到期': 到期, '更新已过期': bool(到期) and 到期 < time.strftime('%Y-%m-%d')}


def lic_bind(key, contact):
    k = 规范卡密(key)
    if not 卡密校验(k):
        return {'error': '卡密不对(末位是校验位,打错或编造都过不了):请回到购买凭证里复制'}
    if k in 黑名单集():
        return {'error': '这张卡密已被吊销(外传被查到)。如果你是真实购买者,请联系作者说明情况'}
    本 = 机器指纹()
    旧 = _读授权()
    旧fp = str(旧.get('机器指纹') or '')
    if 旧.get('卡密') == k and (not 旧fp or 旧fp == 'unknown' or 旧fp == 本):
        return {'ok': True, '提示': '本机已激活,无需重复'}
    改绑 = 旧.get('卡密') == k
    d = {'卡密': k, '机器指纹': 本, '联系方式': str(contact or '').strip()[:40],
         '激活时间': time.strftime('%Y-%m-%d %H:%M'),
         '更新到期': time.strftime('%Y-%m-%d', time.localtime(time.time() + 183 * 86400))}
    授权文件.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    print('[license] 已激活 %s 指纹=%s %s' % (k, 本, '换机改绑' if 改绑 else '首次绑定'))
    return {'ok': True, '更新到期': d['更新到期'],
            '提示': '已把这张卡密改绑到本机(原来那台机器下次启动要重新输码)' if 改绑 else '激活成功'}


def _trans_group(n):
    if any(k in n for k in ("叠化", "闪白", "闪黑", "叠加", "黑场", "淡入", "淡出")): return "基础"
    if "模糊" in n: return "模糊"
    if any(k in n for k in ("3D", "空间", "立体", "立方", "纵深", "穿越")): return "3D/空间"
    if "旋转" in n or "拨盘" in n: return "旋转"
    if any(k in n for k in ("擦除", "翻页", "卷", "遮罩")): return "擦除/翻页"
    if any(k in n for k in ("故障", "电视", "信号", "色差", "色块", "扫描")): return "故障/VHS"
    if any(k in n for k in ("抖", "晃", "撕", "裂", "分割", "对比", "压缩")): return "冲击/分屏"
    if any(k in n for k in ("动漫", "卡通", "漫画", "爆彩")): return "动漫"
    if any(k in n for k in ("移", "推", "拉", "流动", "滑", "伸缩", "缩放")): return "动态/推拉"
    if any(k in n for k in ("闪", "光", "星", "爱心", "泡泡", "珠光", "彩", "云", "雪")): return "光效/自然"
    return "其他"


def transitions_api():
    """给界面「转场速查」用:从 jianying-editor 技能读全部免费转场并分组;本机没技能时给内置常用款。"""
    try:
        import csv as _csv
    except Exception as e:
        return {"error": "csv 模块都读不了: %s" % e}
    names, src = [], "内置常用款(本机没检测到 jianying-editor 技能)"
    cands = [os.environ.get("JY_SKILL_ROOT", ""),
             os.path.expanduser(os.path.join("~", ".codex", "skills", "jianying-editor"))]
    glob0 = os.path.expanduser(os.path.join("~", ".codex", "plugins", "cache"))
    if os.path.isdir(glob0):
        try:
            for root0, dirs0, _f0 in os.walk(glob0):
                if os.path.relpath(root0, glob0).count(os.sep) >= 5:
                    dirs0[:] = []
                for d in list(dirs0):
                    if d == "jianying-editor":
                        cands.append(os.path.join(root0, d))
                        dirs0.remove(d)
        except Exception as e:
            print("[api/transitions 扫插件缓存失败] %s" % e)
    for c in filter(None, cands):
        f = os.path.join(c, "data", "transitions.csv")
        if not os.path.exists(f):
            continue
        try:
            with open(f, encoding="utf-8-sig", newline="") as fh:
                names = [x for x in ((row.get("identifier") or "").strip() for row in _csv.DictReader(fh)) if x]
            if names:
                src = "jianying-editor 技能"
        except Exception as e:
            print("[api/transitions 转场表读失败] %s" % e)
        if names:
            break
    if not names:
        names = list(TRANS_FALLBACK)
    uniq = sorted(set(names), key=lambda x: (len(x), x))
    groups = {}
    for n in uniq:
        groups.setdefault(_trans_group(n), []).append(n)
    order = ["基础", "模糊", "动态/推拉", "冲击/分屏", "旋转", "3D/空间", "擦除/翻页",
             "故障/VHS", "光效/自然", "动漫", "其他"]
    分组 = {k: groups[k] for k in order if k in groups}
    return {"总数": len(uniq), "分组": 分组, "来源": src}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _json(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n)) if n else {}

    def do_GET(self):
        try:
            self._GET()
        except Exception as e:
            self._boom("GET", e)

    def do_POST(self):
        try:
            self._POST()
        except Exception as e:
            self._boom("POST", e)

    def _boom(self, how, e):
        """处理请求时炸了:原因既回给浏览器也打到工作台窗口。
        以前异常直接掐断连接,前端只看到 Failed to fetch,查不到哪一步——静默失败最贵。"""
        if isinstance(e, (ConnectionAbortedError, ConnectionResetError, BrokenPipeError)):
            return          # 浏览器刷新/关页掐掉的连接,不是故障,别在窗口刷假警报
        print("[%s 处理异常] %s" % (how, e), flush=True)
        slog("接口异常", "", "%s: %s" % (how, str(e)[:160]))
        for _ln in traceback.format_exc(limit=5).splitlines():
            print("   " + _ln, flush=True)
        try:
            self._json(500, {"error": "%s 出错: %s(详细堆栈已打到工作台黑窗口)" % (how, e)})
        except Exception as e2:
            print("[错误响应也没发出去] %r" % (e2,))

    def _GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path in ("/", "/index.html"):
            b = (ROOT / "index.html").read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.send_header("Cache-Control", "no-store")   # 不缓存界面:改完 index.html 刷新就是新版
            self.end_headers(); self.wfile.write(b)
        elif u.path == "/confetti.min.js":
            f = ROOT / "confetti.min.js"
            if not f.exists(): return self.send_error(404)
            b = f.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/javascript; charset=utf-8")
            self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        elif u.path == "/api/browse":
            self._json(200, browse_roots() if not q.get("dir") else browse_dir(q["dir"]))
        elif u.path == "/api/transitions":
            self._json(200, transitions_api())
        elif u.path == "/api/projects":
            ps = []
            if PROJ_ROOT.exists():
                for d in sorted(PROJ_ROOT.iterdir()):
                    m = meta_of(d)
                    if m: ps.append({"dir": str(d), "media": m["media"]})
            self._json(200, ps)
        elif u.path == "/api/job":
            self._json(200, job_view(q.get("dir", "")))
        elif u.path == "/api/queue":
            self._json(200, queue_view())
        elif u.path == "/api/scriptcheck":
            self._json(200, script_check(q.get("dir", "")))
        elif u.path == "/api/config":
            self._json(200, settings())
        elif u.path == "/api/refmap":
            self._json(200, refmap_state(q.get("dir", "")))
        elif u.path == "/api/refstyle":
            f = Path(q.get("dir", "")) / "对标风格.json"
            self._json(200, json.loads(f.read_text(encoding="utf-8")) if f.exists() else {})
        elif u.path == "/api/textstyle":
            self._json(200, textstyle_state(q.get("dir", "")))
        elif u.path == "/api/voicesummary":
            self._json(200, voice_summary(q.get("dir", "")))
        elif u.path == "/api/textmd":
            允许 = {"文字效果报告.md", "文字效果执行卡.md"}
            fn = q.get("f", "文字效果报告.md")
            if fn not in 允许: fn = "文字效果报告.md"
            fp = Path(q.get("dir", "")) / fn
            b = fp.read_bytes() if fp.exists() else "# 还没有生成,先跑①-E对应按钮".encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        elif u.path == "/api/script":
            self._json(200, script_state(q["dir"]))
        elif u.path == "/api/trash":
            tr, idx, stack = trash_paths(q["dir"])
            self._json(200, {"stack": stack})
        elif u.path == "/api/medcheck":
            self._json(200, media_check())
        elif u.path == "/api/doctor":
            self._json(200, run_doctor())
        elif u.path == "/api/update_check":
            self._json(200, update_check())
        elif u.path == "/api/refs":
            self._json(200, refs_state(q["dir"]))
        elif u.path == "/api/assets":
            self._json(200, assets_state(q["dir"]))
        elif u.path == "/api/autojob":
            self._json(200, autojob_state(q["dir"]))
        elif u.path == "/api/cuts":
            self._json(200, read_cuts(q["dir"]))
        elif u.path == "/api/slim":
            self._json(200, slim_state(q["dir"]))
        elif u.path == "/api/poster":
            fp = resolve_media(q["dir"], q.get("kind", "ref"), q.get("f", ""), q.get("path", ""))
            if not fp: return self.send_error(404)
            dst = poster_file(q["dir"], fp.name)
            if not (dst.exists() and dst.stat().st_mtime >= fp.stat().st_mtime):
                if not make_poster(fp, dst): return self.send_error(404)
            b = dst.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(b))); self.send_header("Cache-Control", "max-age=3600")
            self.end_headers(); self.wfile.write(b)
        elif u.path == "/api/undo":
            cur = Path(proj) / "剪切点清单.json"; prev = Path(proj) / "剪切点清单.prev.json"
            if not prev.exists(): return self._json(400, {"error": "没有可撤回的操作"})
            shutil.move(str(prev), str(cur))
            return self._json(200, {"ok": True})
        if u.path in ("/manifest.webmanifest", "/app_192.png", "/app_512.png"):
            类 = {".png": "image/png", ".webmanifest": "application/manifest+json"}[os.path.splitext(u.path)[1]]
            try:
                b = (ROOT / u.path.lstrip("/")).read_bytes()
                self.send_response(200); self.send_header("Content-Type", 类)
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            except Exception as e:
                print("[PWA资源送不出 %s] %r" % (u.path, e)); self.send_error(404)
            return
        if u.path == "/app.ico":
            try:
                b = (ROOT / "app.ico").read_bytes()
                self.send_response(200); self.send_header("Content-Type", "image/x-icon")
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            except Exception as e:
                print("[app.ico 送不出] %r" % e); self.send_error(404)
            return
        if u.path == "/api/license":
            return self._json(200, lic_status())
        if u.path == "/api/ideas":
            f2 = Path(q["dir"]) / "包装想法.txt"
            self._json(200, {"text": f2.read_text(encoding="utf-8-sig") if f2.exists() else ""})
        if u.path == "/api/storyboard":
            f = Path(q["dir"]) / "分镜.csv"
            tpl = (WF / "分镜镜头表模板.md").read_text(encoding="utf-8") if not f.exists() else f.read_text(encoding="utf-8")
            self._json(200, {"text": tpl, "saved": f.exists()})
        elif u.path == "/api/status":
            proj = Path(q.get("dir", "")); m = meta_of(proj)   # 没带 dir 也要能回引导信息,不该 500
            tj = proj / "转写.json"
            data = json.loads(tj.read_text(encoding="utf-8")) if tj.exists() else None
            rg = proj / "rough.mp4"; cf = proj / "剪切点清单.json"; fp = proj / "rough_预览.mp4"
            self._json(200, {"meta": m, "files": {
                "转写": bool(data), "剪切点": cf.exists(),
                "rough": rg.exists(), "交接": any((proj / x).exists() for x in ("包装交接.md", "剪映交接.json", "剪映交接.md")),
                "对标": (proj / "对标风格.json").exists(), "点位": (proj / "对标点位.json").exists(), "文字": (proj / "对标文字.json").exists(), "字幕": (proj / "字幕.ass").exists(),
                "预览": (proj / "rough_预览.mp4").exists(),
                "rough_v": int(rg.stat().st_mtime) if rg.exists() else 0,
                "预览_v": int(fp.stat().st_mtime) if fp.exists() else 0,
                "清单_v": int(cf.stat().st_mtime) if cf.exists() else 0},
                "对标建议": style_suggest(proj), "下一步": next_step(proj),
                "后端待重启": backend_stale(),
                "segmentCount": len(data["segments"]) if data else 0,
                "duration": data.get("duration", 0) if data else 0})
        elif u.path == "/media":
            proj = Path(q.get("dir", "")); m = meta_of(proj) or {}
            name = q.get("name")
            if name == "ref":
                safe = Path(q.get("f", "")).name
                path = str(proj / "参考" / safe)
            elif name == "refabs":
                rl = Path(proj) / "参考登记.json"
                lst = json.loads(rl.read_text(encoding="utf-8")) if rl.exists() else []
                try: path = lst[int(q.get("i","-1"))]["path"]
                except Exception: path = None
            elif name == "shotmap":
                safe = Path(q.get("f", "")).name
                path = str(proj / "对标点位" / safe)
            elif name == "textcrop":
                safe = Path(q.get("f", "")).name
                path = str(proj / "对标文字块" / safe)
            elif name == "asset":
                safe = Path(q.get("f", "")).name
                path = str(proj / "素材" / safe)
            else:
                path = {"source": m.get("media"), "rough": str(proj / "rough.mp4"), "fast": str(proj / "rough_预览.mp4")}.get(name)
            if not path or not Path(path).exists():
                self.send_error(404); return
            self._stream(Path(path))
        else:
            if u.path.startswith("/api/"):
                # 页面是新的、后端是旧的(改完文件没重启)时,以前回 HTML 报错页,
                # 前端 r.json() 直接炸 "Unexpected token <" 看不出原因——这里必须回人能读的错
                return self._json(404, {"error": "接口不存在: %s — 页面读到的是新文件,但后台还是旧版工作台;跑一次 停止工作台.cmd 再跑 启动工作台.cmd 就恢复" % u.path})
            self.send_error(404)

    def _stream(self, fp):
        size = fp.stat().st_size; rng = self.headers.get("Range", "")
        m = re.match(r"bytes=(\d+)-(\d*)", rng)
        start = int(m.group(1)) if m else 0
        end = int(m.group(2)) if m and m.group(2) else size - 1
        end = min(end, size - 1); length = end - start + 1
        ext = fp.suffix.lower()
        ctype = {"mp4": "video/mp4", "mov": "video/mp4", "m4v": "video/mp4", "mp3": "audio/mpeg", "wav": "audio/wav", "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp", "gif": "image/gif"}.get(ext.lstrip("."), "application/octet-stream")
        self.send_response(206 if m else 200)
        self.send_header("Accept-Ranges", "bytes"); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        if m: self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        with fp.open("rb") as f:
            f.seek(start); rem = length
            while rem > 0:
                chunk = f.read(min(65536, rem))
                if not chunk: break
                self.wfile.write(chunk); rem -= len(chunk)

    def _upload(self, u):
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        proj = Path(q.get("dir", ""))
        if not (proj / "项目.json").exists():
            return self._json(400, {"error": "请先在上方选择或新建项目"})
        target = q.get("target", "asset")
        if target == "media":
            folder = proj / "素材"
            allow = {e.lstrip(".") for e in VIDEO_EXT}
        else:
            folder = proj / ("参考" if target == "ref" else "素材")
            allow = REF_EXT if target == "ref" else ASSET_EXT
        name = Path(unquote(q.get("name", ""))).name
        name = re.sub(r'[\\/:*?"<>|]', "", name).strip()
        ext = name.lower().rsplit(".", 1)[-1] if "." in name else ""
        if not name or ext not in allow:
            return self._json(400, {"error": "不支持的文件类型:" + (name or "(空文件名)")})
        folder.mkdir(parents=True, exist_ok=True)
        dest = folder / name; i = 2
        while dest.exists():
            dest = folder / (Path(name).stem + "-" + str(i) + "." + ext); i += 1
        remain = int(self.headers.get("Content-Length", 0))
        if not remain:
            return self._json(400, {"error": "空文件,上传取消"})
        with open(dest, "wb") as f:
            while remain:
                chunk = self.rfile.read(min(1048576, remain))
                if not chunk: break
                f.write(chunk); remain -= len(chunk)
        if remain:
            dest.unlink(missing_ok=True)
            return self._json(400, {"error": "上传中断,请重试"})
        if target == "media":
            b = bind_copied_media(proj, dest)
            if b.get("error"):
                dest.unlink(missing_ok=True)
                return self._json(400, {"error": b["error"]})
            return self._json(200, {"ok": True, "name": dest.name, "media": b["new"]})
        return self._json(200, {"ok": True, "name": dest.name})

    def _apply_update(self):
        """POST 原始 zip 字节:装更新包。有剪辑在跑/排队时拒绝——引擎正被子进程调用,不能换。"""
        余 = int(self.headers.get("Content-Length", 0))
        if not 余:
            return self._json(400, {"error": "没收到文件内容"})
        if 余 > 200 * 1048576:
            return self._json(400, {"error": "文件超过 200MB——这不是小更新包(小包由作者「造更新包」产出,一般几百 KB)"})
        buf = bytearray()
        while 余 > 0:
            c = self.rfile.read(min(1048576, 余))
            if not c:
                break
            buf += c; 余 -= len(c)
        if 余:
            return self._json(400, {"error": "传输中断,没动任何文件,请重试"})
        if queue_view()["在跑/排队"]:
            return self._json(400, {"error": "有剪辑任务在跑或排队,等它跑完再装更新包"})
        结 = apply_update(bytes(buf))
        if 结.get("ok"):
            结["提示"] = "关掉工作台再像平时一样重新打开,新版即生效"
        return self._json(200, 结)

    def _apply_from_url(self):
        body = self._body()
        if queue_view()["在跑/排队"]:
            return self._json(400, {"error": "有剪辑任务在跑或排队,等它跑完再更新"})
        结 = apply_update_from_url(body.get("地址", ""))
        if 结.get("ok"):
            结["提示"] = "关掉工作台再像平时一样重新打开,新版即生效"
        return self._json(200, 结)

    def _POST(self):
        u = urlparse(self.path)
        if u.path == "/api/upload": return self._upload(u)
        if u.path == "/api/apply_update": return self._apply_update()
        if u.path == "/api/apply_from_url": return self._apply_from_url()
        body = self._body()
        proj = body.get("dir", "")
        if u.path == "/api/blank":
            return self._json(200, create_blank_project())
        if u.path == "/api/relink":
            return self._json(200, relink_media(proj, body.get("media", "")))
        if u.path == "/api/adopt":
            return self._json(200, adopt_media(proj))
        if u.path == "/api/project":
            r = create_project(body.get("media", ""), body.get("name", ""), body)
            if r.get("error"): return self._json(400, {"error": r["error"]})
            return self._json(200, r)
        if u.path == "/api/config":
            return self._json(200, save_settings(body))
        if u.path == "/api/action":
            fn = {"transcribe": action_transcribe, "findcuts": action_findcuts,
                  "render": action_render, "handoff": action_handoff,
                  "anchors": action_anchors, "refstyle": action_refstyle,
                  "refmap": action_refmap, "sample": action_sample,
                  "textstyle": action_textstyle}.get(body.get("action"))
            if not fn: return self._json(400, {"error": "参数不全"})
            if not proj and body.get("action") != "sample": return self._json(400, {"error": "参数不全"})
            return self._json(200, fn(proj, body))
        if u.path == "/api/script":
            act = body.get("act")
            if act == "analyze": return self._json(200, script_analyze(proj))
            if act == "answer": return self._json(200, script_answer(proj, body.get("qid"), body.get("action", "删")))
            if act == "apply":  return self._json(200, script_apply(proj))
            if act == "final":  return self._json(200, script_final(proj, body.get("text", ""), body.get("sub", "auto")))
            if act == "mode":   return self._json(200, script_mode(proj, body.get("mode"), body.get("sub")))
            if act == "draft":  return self._json(200, script_save_draft(proj, body.get("text", "")))
            if act == "add":    return self._json(200, script_add(proj, body.get("time"), body.get("text")))
            if act == "del_add": return self._json(200, script_del_add(proj, body.get("idx")))
            return self._json(400, {"error": "未知act"})
        if u.path == "/api/scriptfix":
            return self._json(200, script_fix_trad(proj))
        if u.path == "/api/backup":
            return self._json(200, run_backup())
        if u.path == "/api/cancel":
            return self._json(200, cancel_job(proj))
        if u.path == "/api/batch":
            return self._json(200, action_batch(body))
        if u.path == "/api/reset":
            return self._json(200, action_reset(proj, body.get("scope", "")))
        if u.path == "/api/projdel":
            return self._json(200, action_delete_project(proj))
        if u.path == "/api/undo_reset":
            return self._json(200, action_undo_reset(proj))
        if u.path == "/api/refmap":
            act = body.get("act")
            if act == "save": return self._json(200, refmap_save(proj, body.get("rows") or []))
            if act == "sb":   return self._json(200, refmap_storyboard(proj, body))
            return self._json(400, {"error": "未知act"})
        if u.path == "/api/refs":
            projp = Path(proj); srcf = Path(body.get("path", ""))
            if not srcf.exists(): return self._json(400, {"error": "文件不存在"})
            reg = projp / "参考登记.json"
            lst = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else []
            if any(x["path"] == str(srcf.resolve()) for x in lst): return self._json(200, {"ok": True, "dup": True})
            lst.append({"path": str(srcf.resolve()), "note": body.get("note", "")})
            reg.write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/assets":
            projp = Path(proj); srcf = Path(body.get("path", ""))
            if not srcf.exists(): return self._json(400, {"error": "文件不存在"})
            reg = projp / "素材登记.json"
            lst = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else []
            if any(x["path"] == str(srcf.resolve()) for x in lst): return self._json(200, {"ok": True, "dup": True})
            lst.append({"path": str(srcf.resolve()), "shot": body.get("shot", ""), "note": body.get("note", "")})
            reg.write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/open":
            fp = resolve_media(proj, body.get("kind", "ref"), body.get("f", ""), body.get("path", ""))
            if not fp: return self._json(400, {"error": "文件不在本项目登记范围内"})
            os.startfile(str(fp))
            return self._json(200, {"ok": True})
        if u.path == "/api/slim":
            return self._json(200, slim_save(proj, body.get("target"), body.get("removed"), body.get("window", ...)))
        if u.path == "/api/undo_step":
            return self._json(200, step_undo(proj, body.get("scope", "")))
        if u.path == "/api/slim_take":
            return self._json(200, slim_take(proj, body.get("t")))
        if u.path == "/api/slim_suggest":
            return self._json(200, slim_suggest(proj))
        if u.path == "/api/slim_apply":
            return self._json(200, slim_apply(proj))
        if u.path == "/api/textplan":
            return self._json(200, textplan_run(proj, body))
        if u.path == "/api/autojob":
            m = meta_of(proj) or {}
            req = {"instruction": body.get("instruction", "").strip(),
                   "media": m.get("media", ""), "transcript": str(Path(proj) / "转写.json"),
                   "cuts_out": str(Path(proj) / "剪切点清单.json"),
                   "created": time.strftime("%Y-%m-%d %H:%M:%S")}
            (Path(proj) / "auto_edit_request.json").write_text(json.dumps(req, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/cuts":
            step_snap(proj, ["剪切点清单.json"], "s3")
            backup_cuts(proj)
            f = Path(proj) / "剪切点清单.json"
            old = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
            prev_map = {(c.get("类型"), c.get("文字")): c for c in old.get("cuts", [])}
            rows = []
            for c in body.get("cuts", []):
                p = prev_map.get((c.get("类型"), c.get("文字")))
                if p and (c.get("执行") != p.get("执行") or p.get("人工")):
                    c["人工"] = "1"            # 人耳裁决过,重跑找点/换档位都不许覆盖
                rows.append(c)
            payload = {"media": (meta_of(proj) or {}).get("media", old.get("media", "")),
                       "duration": old.get("duration", 0), "档位": old.get("档位", ""), "cuts": rows}
            f.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/undo":
            cur = Path(proj) / "剪切点清单.json"; prev = Path(proj) / "剪切点清单.prev.json"
            if not prev.exists(): return self._json(400, {"error": "没有可撤回的操作"})
            shutil.move(str(prev), str(cur))
            return self._json(200, {"ok": True})
        if u.path == "/api/feedback":
            return self._json(200, feedback_pack())
        if u.path == "/api/license":
            if body.get("act") == "bind":
                return self._json(200, lic_bind(body.get("key", ""), body.get("contact", "")))
            return self._json(400, {"error": "未知的授权操作"})
        if u.path == "/api/ideas":
            return self._json(200, ideas_save(proj, body.get("text", "")))
        if u.path == "/api/ideas_map":
            return self._json(200, ideas_map(proj, body))
        if u.path == "/api/sbdraft":
            return self._json(200, sb_draft_from_text(proj, body.get("text", "")))
        if u.path == "/api/storyboard":
            return self._json(200, storyboard_save(proj, body.get("text", ""),
                                                   auto=body.get("auto_anchor", True)))
        self._json(404, {"error": "no route"})

BR_LIMIT = 400

def browse_roots():
    """「挑素材」窗首页:能枚举的盘符 + 快捷位置(项目文件夹/桌面/下载)。
    光驱读卡器抽风不能拖垮整页:哪盘试不到就跳过并打印原因。"""
    drives = []
    for i in range(65, 91):
        d = "%s:\\" % chr(i)
        try:
            if os.path.exists(d): drives.append(d)
        except Exception as e:
            print("[浏览盘符] %s: %r" % (d, e), flush=True)
    hs = Path.home()
    quick = [("📁 项目文件夹", str(PROJ_ROOT)), ("🖥 桌面", str(hs / "Desktop")),
             ("📥 下载", str(hs / "Downloads"))]
    return {"盘": drives, "快捷": [{"名": n, "路径": p} for n, p in quick if Path(p).is_dir()]}

def browse_dir(d):
    """给「挑素材」窗列一个文件夹:上级/子文件夹/视频(带大小)。只读,不写不开。
    太多截断时 截断=True 让前端提示跳精确路径;读不动就明确回原因,不许静默空白。"""
    p = Path(d)
    try:
        if not p.is_dir(): return {"error": "这不是当前存在的文件夹: %s" % d}
        subs, vids, trunc = [], [], False
        for f in sorted(p.iterdir(), key=lambda x: str(x.name).lower()):
            try:
                if f.is_dir():
                    if f.name.startswith(("$", ".")): continue
                    if len(subs) >= BR_LIMIT: trunc = True; continue
                    subs.append({"名": f.name, "路径": str(f)})
                elif f.suffix.lower() in VIDEO_EXT and f.is_file():
                    if len(vids) >= BR_LIMIT: trunc = True; continue
                    vids.append({"名": f.name, "路径": str(f),
                                 "MB": round(f.stat().st_size / 1048576.0, 1)})
            except (PermissionError, OSError) as e:
                print("[浏览条目] %s: %r" % (f, e), flush=True)
        up = str(p.parent) if str(p.parent) != str(p) else ""
        return {"路径": str(p), "上级": up, "文件夹": subs, "视频": vids, "截断": trunc}
    except Exception as e:
        print("[browse_dir] %s: %r" % (d, e), flush=True)
        slog("浏览失败", "", "%s: %s" % (d, str(e)[:120]))
        return {"error": "这个文件夹读不动: %s (%s)" % (d, e)}

# ―――― ①-E 文字效果分析 / 口播体检 / 文字执行卡(2026-10-21 新增) ――――
TEXTSTYLE_EXT = {"jpg", "jpeg", "png", "webp", "bmp", "mp4", "mov", "m4v", "avi", "mkv", "webm"}

def _textstyle_source(proj, body):
    """①-E 分析对象怎么选:显式路径优先;没有就用登记的第一条参考视频;没视频退第一条参考截图。"""
    proj = Path(proj)
    refp = (body.get("path") or "").strip()
    if refp:
        if not Path(refp).exists():
            return None, "文件不存在: " + refp
        return refp, ""
    items = refs_state(proj)["items"]
    for kind in ("video", "image"):
        hit = [x for x in items if x.get("kind") == kind]
        if hit:
            v = hit[0]
            return v.get("path") or str(proj / "参考" / v["name"]), ""
    return None, "先登记一条对标视频或截图(①-C 里那套素材,文字效果分析也吃它)"

def action_textstyle(proj, body):
    """①-E 主按钮:本机 OCR 读对标里的文字,量位置/大小/颜色/描边/动效,出 对标文字.json + 文字效果报告.md。"""
    refp, err = _textstyle_source(proj, body)
    if err:
        return {"error": err}
    if Path(refp).suffix.lower().lstrip(".") not in TEXTSTYLE_EXT:
        return {"error": "文字效果分析只认视频和图片(gif 动不了),当前: %s" % Path(refp).suffix}
    def _num(v, lo, hi, dft):
        try:
            x = float(v)
        except Exception:
            return dft
        return max(lo, min(hi, x))
    cmd = [PY, SCRIPTS / "text_style.py", refp, "--out", str(Path(proj) / "对标文字.json"),
           "--proj", str(proj), "--dur", _num(body.get("dur"), 5, 300, 90),
           "--fps", _num(body.get("fps"), 0.5, 4, 1.5)]
    st = _num(body.get("start"), 0, 600, 0)
    if st:
        cmd += ["--start", st]
    return start_job(proj, cmd, label="文字效果分析", timeout=2400)

def textstyle_state(proj):
    """读 对标文字.json,把每块截图挂成图片地址,喂界面①-E 的表。"""
    proj = Path(proj)
    f = proj / "对标文字.json"
    st = {"has": False}
    if not f.exists():
        return st
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        return {"has": True, "错误": "读不了 对标文字.json:%s(重跑一次分析)" % e}
    q = quote(str(proj), safe="")
    for b in d.get("文字块") or []:
        s = b.get("截图")
        b["截图URL"] = ("/media?dir=%s&name=textcrop&f=%s" % (q, quote(s, safe=""))) if s else ""
    return {"has": True, "对标源": d.get("对标源"), "分析时间": d.get("分析时间"),
            "输入类型": d.get("输入类型"), "统计": d.get("统计") or {},
            "文字块": d.get("文字块") or [], "样式分组": d.get("样式分组") or [],
            "提示": d.get("提示") or []}

FILL_WORDS = ["嗯", "呃", "额", "那个", "就是说", "怎么说呢", "对吧", "其实", "反正", "然后", "那么"]

def voice_summary(proj):
    """口播体检机器人:从 转写.json 本机总结「自己说的」的形式(语速/口癖/口头禅/句长/开头钩子)。
    语义级深总结它不装懂:给出可直接贴给对话 AI 的提示词。"""
    proj = Path(proj)
    tj = proj / "转写.json"
    if not tj.exists():
        return {"错误": "先完成第②步转写,体检才有话说"}
    try:
        d = json.loads(tj.read_text(encoding="utf-8"))
    except Exception as e:
        return {"错误": "转写.json 读不了:%s(去②重新转写)" % e}
    import statistics as _st
    segs = d.get("segments") or []
    if not segs:
        return {"错误": "转写里没有语音段,体检做不了(先检查这条片子有没有声音)"}
    def clen(s):
        return len(re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]", "", s))
    句 = [x for x in (re.sub(r"\s+", "", s.get("text") or "") for s in segs) if x]
    full = "".join(句)
    chars = clen(full)
    dur = float(d.get("duration") or (segs[-1].get("end") or 1))
    gaps = [round(segs[i + 1]["start"] - segs[i]["end"], 3) for i in range(len(segs) - 1)
            if (segs[i + 1].get("start") or 0) - (segs[i].get("end") or 0) >= 0]
    lens = [clen(x) for x in 句]
    over = sorted([(n, 句[i]) for i, n in enumerate(lens) if n > 30], reverse=True)[:3]
    tics = {w: full.count(w) for w in FILL_WORDS if full.count(w) > 0}
    cnt = {}
    cjk = re.sub(r"[^\u4e00-\u9fa5]", "@", full)
    for L in (2, 3, 4):
        for i in range(len(cjk) - L + 1):
            w = cjk[i:i + L]
            if "@" in w:
                continue
            cnt[w] = cnt.get(w, 0) + 1
    freq = sorted([(v, k) for k, v in cnt.items() if v >= 3], reverse=True)
    keep = []
    for v, k in freq:
        if not any(k in kk for _, kk in keep):
            keep.append((k, v))
    top = keep[:8]
    hook = 句[0] if 句 else ""
    if any(x in hook for x in ("?", "？", "吗", "为什么", "凭什么")):
        htype = "疑问/悬念型开头(钩子结构合格)"
    elif re.search(r"\d", hook):
        htype = "数字型开头(钩子结构合格)"
    elif any(x in hook for x in ("千万别", "别再", "停止")):
        htype = "警告祈使型开头(钩子结构合格)"
    else:
        htype = "陈述型开头——想爆建议改写成疑问/数字/警告(可点旁边的爆款开头工具)"
    lines = ["[%s] %s" % (fmt_t(s.get("start", 0)), s.get("text", "")) for s in segs]
    prompt = ("下面是我的完整口播转写(带时间码)。请作为短视频文案督导总结:1)一句话核心;2)三个关键词;"
              "3)最强的一句和最弱的一句;4)开头3秒钩子够不够,怎么改;5)哪几句冗余可以删。\n" + "\n".join(lines))
    return {"总字数": chars, "时长秒": round(dur, 1), "字每分钟": round(chars / max(0.1, dur) * 60, 1),
            "句数": len(句), "平均句长": int(_st.mean(lens)) if lens else 0,
            "超长句": [{"字数": n, "原句": s[:40]} for n, s in over],
            "口头禅": [{"词": k, "次数": v} for k, v in sorted(tics.items(), key=lambda x: -x[1])],
            "高频词": [{"词": k, "次数": v} for k, v in top],
            "长停顿次数": len([g for g in gaps if g > 0.8]),
            "句间停顿中位": round(_st.median(gaps), 3) if gaps else 0,
            "开头钩子": {"首句": hook[:38], "类型": htype},
            "AI深度总结提示词": prompt}

def textplan_run(proj, body):
    """①-E 融合:对标测出来的那套字效 + 用户要上屏的文案 → 逐句文字执行卡(剪映操作)。"""
    proj = Path(proj)
    text = (body.get("文案") or "").strip()
    if not text:
        return {"错误": "先把要上屏的文字粘贴进来"}
    style = None
    来源 = "没有对标文字分析——用安全默认(画面正中/中字高/白字黑描边/0.3s渐显渐隐)"
    f = proj / "对标文字.json"
    if f.exists():
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            return {"错误": "对标文字.json 读不了:%s(重跑一次文字效果分析)" % e}
        blocks = d.get("文字块") or []
        pick = str(body.get("样式") or "auto")
        b = None
        if pick == "auto":
            if blocks:
                b = max(blocks, key=lambda x: x.get("持续秒") or 0)
        elif pick.startswith("T"):
            b = next((x for x in blocks if x.get("编号") == pick), None)
        if b:
            style = b
            来源 = "对标 %s「%s」%.1f~%.1fs,%s" % (b.get("编号"), (b.get("文字") or "")[:10],
                                                b.get("首现") or 0, b.get("末现") or 0, b["位置"]["锚位"])
    rate = 260.0
    fs = proj / "对标风格.json"
    if fs.exists():
        try:
            sp = (json.loads(fs.read_text(encoding="utf-8")).get("语速") or {}).get("字每分钟")
            if isinstance(sp, (int, float)) and sp > 0:
                rate = float(sp)
        except Exception as e:
            print("[对标语速读不了,用默认260字/分] %r" % e)
    sentences = [s.strip() for s in re.split(r"[。！？!?；;\n]+", text) if s.strip()]
    cards = []
    t = 0.0
    for i, s in enumerate(sentences, 1):
        n = len(re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]", "", s))
        sec = round(max(1.0, n / rate * 60), 1)
        ops = []
        if style:
            c = style.get("颜色") or {}
            mo = style.get("动效") or {}
            sz = style.get("大小") or {}
            pos = style.get("位置") or {}
            ops.append("字体颜色取 %s%s" % (c.get("文字色", "白色"),
                       (";描边取 %s" % c["描边"]["颜色"]) if c.get("描边") else ";没测出描边就不加"))
            ops.append("字号:字高≈%spx(占屏高%.1f%%),先打文案再拖字号对高度" % (
                sz.get("字高px(按1920高换算)", "—"), sz.get("字高占屏%", 0)))
            if (pos.get("中心Y%") or 50) > 75:
                ops.append("对标位置在%s——发抖音底部会被标题条挡,建议改放画面正中(Y=0)" % pos.get("锚位"))
            else:
                ops.append("位置:%s(剪映 X=%d Y=%d)" % (
                    pos.get("锚位"),
                    round(((pos.get("中心X%") or 50) - 50) / 100 * 1080),
                    round((50 - (pos.get("中心Y%") or 50)) / 100 * 1920)))
            ops.append("动效:入场「%s」%s,出场「%s」" % (
                mo.get("入场"), ("(%s)" % mo["依据"]) if mo.get("依据") else "", mo.get("出场")))
            if (mo.get("滚动") or "无") != "无":
                ops.append("注意:对标是%s字幕(%.1f%%屏/秒)——逐句上屏别照抄滚动,改成渐显渐隐更稳" % (
                    mo["滚动"], mo.get("滚动速度%屏每秒") or 0))
            ED = {"卡拉OK": "动画-出现-卡拉OK,或两层字:白底+红字带横向位置关键帧从左推到右",
                  "发光": "花字→发光(外圈渐暗的那种)", "疑似3D": "动画入先试「翻转」,置信低看截图定",
                  "闪烁": "不透明度关键帧100→0→100循环", "抖动": "特效-动态-抖动",
                  "呼吸": "缩放关键帧循环", "变色": "拆两段文案换色", "倾斜": "旋转参数照抄(%s)" % (style.get("位置", {}).get("倾角deg") or ""),
                  "打字机": "动画入-打字机", "擦除": "动画入-显影/擦除", "模糊": "清晰度关键帧0→100",
                  "阴影": "花字-阴影 %s" % ((c.get("阴影") or {}).get("颜色") or ""),
                  "底色块": "背景-单色块 %s" % (c.get("底色块") or ""), "渐变": "花字-渐变填充 %s" % ("/".join(c.get("渐变") or []))}
            for e in (mo.get("附加效果") or []):
                nm = e.get("效果", "")
                line = next((v for k, v in ED.items() if k in nm), None)
                if line:
                    ops.append("对标附加字效[%s]→%s" % (nm, line))
            fg = style.get("字体猜测") or {}
            if fg:
                ops.append("字体:对标像「%s」的无衬线,剪映里拿截图比对候选(字体名机器定不死)" % (c.get("字重猜测") or "中"))
        else:
            ops.append("安全默认:白字黑描边、字高约6%屏、放画面正中(Y=0)、渐显0.3s+渐隐0.3s")
        cards.append({"行": i, "文本": s, "起": round(t, 1), "止": round(t + sec, 1),
                      "估秒": sec, "剪映操作": ops})
        t += sec
    out = {"样式来源": 来源, "语速字每分钟": rate, "句数": len(cards), "合计秒": round(t, 1),
           "卡片": cards, "生成时间": time.strftime("%Y-%m-%d %H:%M:%S")}
    (proj / "文字方案.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    L = ["# 文字效果执行卡(工作台①-E 融合生成)", "",
         "- 样式来源:%s" % 来源,
         "- 时长依据:%.0f 字/分(对标语速或默认),每句停留按字数估算;真正对轨时在剪映里跟着口播拖" % rate,
         "- 共 %d 句,约 %.1f 秒" % (len(cards), t), "",
         "| # | 文本 | 估停留 | 相对窗口 | 剪映操作 |", "|---|---|---|---|---|"]
    for c in cards:
        L.append("| %d | %s | %.1fs | %.1f~%.1fs | %s |" % (
            c["行"], c["文本"], c["估秒"], c["起"], c["止"], ";".join(c["剪映操作"])))
    (proj / "文字效果执行卡.md").write_text("\n".join(L), encoding="utf-8")
    return {"ok": True, "句数": len(cards), "合计秒": round(t, 1), "样式来源": 来源,
            "md": str(proj / "文字效果执行卡.md")}

def check_ui_help():
    """界面说明自检:新增可点控件/输入项漏挂 HELP/IDHELP 字典时警告(规则见 ../AGENTS.md)"""
    try:
        h = (ROOT / "index.html").read_text(encoding="utf-8")
        mh = re.search(r"var HELP=\{(.*?)\n\};", h, re.S)
        mi = re.search(r"var IDHELP=\{(.*?)\n\};", h, re.S)
        if not mh: return ["index.html 缺少 HELP 说明字典"]
        keys = set(re.findall(r'"([^"]+)":', mh.group(1)))
        id_list = re.findall(r'"(\w+)":', mi.group(1)) if mi else []
        keys_id = set(id_list)
        def covered(o):
            g = re.search(r"getElementById\('([^']+)'\)", o)
            if g: return "pick:" + g.group(1) in keys
            hits = []
            for m in re.finditer(r"(^|[^.\w])([A-Za-z0-9_]+)\(\s*['\"]?([^'\"\)\]]*)", o):
                name, arg = m.group(2), m.group(3)
                hits.append(name + ((":" + arg) if arg else ""))
            return any((x in keys) or (x.split(":")[0] in keys) for x in hits)
        w = []
        for m in re.finditer(r'<(\w+)[^>]*onclick="([^"]+)"', h):
            o = m.group(2).replace("&quot;", '"')
            if not covered(o): w.append("控件缺说明: <%s> %s" % (m.group(1), o[:50]))
        for attrs in re.findall(r'<(?:input|select|textarea)([^>]*)>', h):
            mi2 = re.search(r'id="([^"]+)"', attrs)
            if not mi2: continue
            i = mi2.group(1)
            if re.search(r"\bhidden\b", attrs): continue   # 隐藏的 file input 按规则不挂提示
            if i not in keys_id: w.append("输入项缺提示: " + i)
        for i in sorted(set(x for x in id_list if id_list.count(x) > 1)):
            w.append("IDHELP 重复键(后者覆盖前者,请合并): " + i)
        return w
    except Exception as e:
        return ["说明自检异常: " + str(e)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=9527)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    PROJ_ROOT.mkdir(exist_ok=True)
    reap_interrupted()
    def running(port):
        try:
            return urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=1).getcode() == 200
        except Exception:
            return False
    if running(a.port):
        url = f"http://127.0.0.1:{a.port}"
        print(f"检测到工作台已在运行,直接打开浏览器: {url}")
        print("若浏览器没有弹出,请手动访问上面的地址。此窗口可直接关闭。")
        if not a.no_browser: webbrowser.open(url)
        return
    srv = None; port = a.port
    for p in range(a.port, a.port + 10):
        if running(p):
            print(f"端口 {p} 上已有工作台在运行,直接打开: http://127.0.0.1:{p}")
            if not a.no_browser: webbrowser.open(f"http://127.0.0.1:{p}")
            return
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p), H); port = p; break
        except OSError:
            continue
    if srv is None:
        print("启动失败:端口全部被占用或被系统保留。请关闭旧的工作台黑窗口后重试。")
        input("按回车退出...")
        sys.exit(1)
    url = f"http://127.0.0.1:{port}"
    print(f"口播剪辑工作台已启动: {url}")
    warns = check_ui_help()
    rep = ROOT / "说明自检.txt"
    if warns:
        print("[警告] 界面说明自检发现 %d 处遗漏(补齐规则见 ../AGENTS.md):" % len(warns))
        for x in warns: print("  - " + x)
        rep.write_text("有遗漏 \n" + "\n".join(warns), encoding="utf-8")
    else:
        rep.write_text("全部控件已挂说明 ✓", encoding="utf-8")
    print("若浏览器没有自动弹出,请手动把上面的地址粘贴到浏览器。")
    print("剪辑期间请保持本窗口开着(关闭窗口=工作台停止)。")
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n工作台已停止。")

if __name__ == "__main__":
    main()
