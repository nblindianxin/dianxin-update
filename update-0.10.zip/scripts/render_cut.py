# -*- coding: utf-8 -*-
r'''第③步后半:按确认后的剪切点执行粗剪,一遍出「画面+音频+字幕」成片。
用法: python render_cut.py 剪切点.json [--out rough.mp4] [--crf 18] [--subs auto|off]
        [--style 对标风格.json] [--zoom 1.06] [--audio on|off] [--fast]
        [--repair on]  音频修复:先拼出成片音频,交 ClearVoice 去噪去混响,再进链路(缺依赖自动回退并说明)
 [--chain full] 音频处理链:默认 off=直通(铁律18:口播声音绝对不变),full 才走旧处理链
        [--gpu auto|off] 默认 auto:探测 h264_nvenc 可用就走 GPU 编码,不可用回退 libx264
能力(本机 ffmpeg + 可选本地 AI,不联网上传素材):
  字幕烧录 auto:吃同目录 转写.json + 文案定稿.txt + 对标风格.json,时间用本次真实保留区间换算
  音频链(--chain full 才启用):高通 -> 轻降噪 -> 压限 -> 响度归一;默认直通不改声音;响度用**两遍测量法**(先测整片真实响度,
          再以 linear=true 一次性对齐目标,长片不漂;测量失败自动退回单遍并打印原因)
  跳剪防跳脸:剪切点两侧保留段奇偶交替裁切放大(默认 1.00/1.06,--zoom 1 关闭),消掉"画面一顿一顿"
  --fast:出低清快审版(720p/CRF30,文件名带 _预览),终审后再出高清,省一半等待'''
import argparse, json, os, re, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
PY = sys.executable
sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)  # GBK→UTF-8;行缓冲=print 一行工作台见一行(管道默认8KB攒批,不修就"在跑但看不见")

# 音频链(修复与否都走同一条;loudnorm 参数单独拼)
AUDIO_FC = ("highpass=f=80,afftdn=nr=10:nf=-25,"
            "acompressor=threshold=-18dB:ratio=3:attack=20:release=250:makeup=1")


def probe_size(media):
    p = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=width,height", "-of", "csv=p=0:s=x", media],
                       capture_output=True, text=True)
    m = re.search(r"(\d+)x(\d+)", p.stdout or "")
    return (int(m.group(1)), int(m.group(2))) if m else (1080, 1920)


_NV = None
def nvenc_ok():
    """真探测:编一帧 256x256 黑帧走 h264_nvenc,成功才算可用。帧尺寸不能太小:
    NVENC 硬件有最小尺寸限制,用 64x64 会报"Frame Dimension less than the
    minimum"导致误判不可用(2026-10-15 驱动升级后实测踩到)。只查 encoders
    列表挡不住缺驱动/缺 API 版本两种情况。"""
    global _NV
    if _NV is None:
        try:
            r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-f", "lavfi", "-i",
                                "color=c=black:s=256x256:r=25:d=0.4", "-c:v", "h264_nvenc",
                                "-f", "null", "-"], capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=60)
            _NV = (r.returncode == 0)
            if not _NV:
                print("GPU 编码探测不通过,回退 CPU(原因: " +
                      ((r.stderr or "").strip().splitlines() or ["无输出"])[-1][:120] + ")")
        except Exception as e:
            _NV = False
            print("GPU 编码探测异常,回退 CPU:", e)
    return _NV


def pick_video_args(gpu, crf, fast):
    if gpu == "auto" and nvenc_ok():
        cq = "30" if fast else str(min(51, int(float(crf)) + 2))  # nvenc 的 cq≈crf+2 才与 x264 同观感
        return (["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq",
                 "-rc", "vbr", "-cq", cq, "-b:v", "0"], "h264_nvenc(GPU)")
    return (["-c:v", "libx264", "-preset", ("veryfast" if fast else "medium"),
             "-crf", ("30" if fast else crf)], "libx264(CPU)")


def _lnv(x, lo, hi):
    """loudnorm 各参数合法域检查:-inf/NaN/越界返回 None(不许把非法值塞进滤镜)。"""
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return f if f == f and lo <= f <= hi else None


def parse_loudnorm(err):
    """从 ffmpeg stderr 抠 loudnorm 的 JSON 测量块;失败返回 None 并打印原因(禁止静默降级)。"""
    try:
        m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", err or "", re.S)
        if not m:
            print("响度测量: 输出里没找到 JSON 块,回退单遍模式")
            return None
        d = json.loads(m.group(0))
        need = ("input_i", "input_tp", "input_lra", "input_thresh")
        # 偏移字段:ffmpeg≥7 叫 target_offset,旧版叫 target_thresh,两个都认
        if all(k in d for k in need) and ("target_offset" in d or "target_thresh" in d):
            return d
        print("响度测量: JSON 字段不全(%s),回退单遍模式" % [k for k in need if k not in d])
    except Exception as e:
        print("响度测量 JSON 解析失败,回退单遍模式:", e)
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("plan"); ap.add_argument("--out", default=None)
    ap.add_argument("--crf", default="18"); ap.add_argument("--subs", default="auto", choices=["auto", "off", "axis"],
                    help="auto=烧进画面;axis=只出 字幕.ass/.srt/字幕时间轴.json 不烧(给第④步做动画);off=完全不做")
    ap.add_argument("--style", default=None); ap.add_argument("--zoom", default="1.06")
    ap.add_argument("--audio", default="on", choices=["on", "off"])
    ap.add_argument("--chain", default="off", choices=["off", "full"],
                    help="off=音频直通(铁律18:不降噪/不高通/不压限/不改响度,口播声音绝对不变);"
                         "full=旧处理链 高通+降噪+压限+响度归一(用户点名才开)")
    ap.add_argument("--repair", default="off", choices=["on", "off"],
                    help="on=拼出成片音频后用 ClearVoice 去噪/去混响再进链;依赖缺失自动回退常规链并打印原因")
    ap.add_argument("--gpu", default="auto", choices=["auto", "off"], help="编码走 h264_nvenc 探测,off=强制 CPU")
    ap.add_argument("--breath", default="0.30", help="接缝处两侧呼吸合计不足多少秒就补齐(默认0.30;句中刀不补)")
    ap.add_argument("--xfade", default="0.05", help="接缝音频交叉淡化秒数(默认0.05=50ms;0=硬接)")
    ap.add_argument("--fast", action="store_true", help="低清快审版")
    ap.add_argument("--font", default=None, help="字幕字体,默认 Noto Serif SC(思源宋体)")
    ap.add_argument("--outline", default="0", help="描边像素,默认 0=不加描边")
    ap.add_argument("--shadow", default="0", help="阴影像素,默认 0=不加阴影")
    ap.add_argument("--box", default="0", help="1=半透明底条(亮背景又不想描边时用)")
    a = ap.parse_args()
    plan = json.loads(Path(a.plan).read_text(encoding="utf-8"))
    media, duration = plan["media"], float(plan["duration"] or 0)
    if not Path(media).exists(): sys.exit("找不到素材: %s" % media)
    if not duration:
        pr = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                             "-of", "csv=p=0", media], capture_output=True, text=True)
        try: duration = float(pr.stdout.strip())
        except ValueError: sys.exit("清单缺少时长且 ffprobe 读不到素材时长,中止")
    if not plan.get("cuts"): print("提示: 清单为空,未剪任何区间,将输出整片副本")
    print("粗剪启动:素材 %s,清单 %d 条(下面逐行播报进度)" % (Path(media).name, len(plan.get("cuts", []))))

    # ---- 对标参数 ----
    sty = {}
    sp = Path(a.style) if a.style else Path(a.plan).with_name("对标风格.json")
    if sp.exists():
        sty = (json.loads(sp.read_text(encoding="utf-8")).get("建议") or {})
    LUFS = float(sty.get("响度目标LUFS") or -16.0)
    LRA = float(sty.get("响度范围LU") or 11)
    TP = float(sty.get("峰值上限dB") or -1.5)
    ZOOM = float(a.zoom) if a.zoom else float((sty or {}).get("跳剪交替变焦") or 1.12)
    W, H = probe_size(media)
    if sty.get("画幅") == "横屏" and H > W: W, H = H, W

    # ---- 静音检测:边界吸附 + 气口补齐 ----
    print("① 全片静音扫描开始(边解码边测,这一步可能持续几十秒~几分钟,期间没有新行=正常)…")
    sil = []
    try:
        sd = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", media, "-af",
                             "silencedetect=noise=-32dB:d=0.08", "-f", "null", "-"],
                            capture_output=True, text=True, encoding="utf-8", errors="replace")
        starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", sd.stderr)]
        ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", sd.stderr)]
        sil = list(zip(starts, ends))
    except Exception as e:
        print("静音检测跳过(用原始边界):", e)
    if not sil: print("警告: 未检测到任何静音段,吸附与气口补齐不生效")

    def _in_sil(t): return any(sa <= t <= sb for sa, sb in sil)

    def snap_pair(x, y):
        if not sil: return x, y
        aa = x
        if not _in_sil(x):
            c = [sb for sa, sb in sil if sb < x and x - sb <= 0.25]
            if c: aa = max(c)
        bb = y
        if not _in_sil(y):
            c = [sa for sa, sb in sil if sa > y and sa - y <= 0.25]
            if c: bb = min(c)
        if bb - aa < 0.05: return x, y
        return aa, bb

    raw = sorted([(float(c["开始"]), float(c["结束"])) for c in plan["cuts"]
                  if c.get("执行", "删") == "删"], key=lambda x: x[0])
    dels = [snap_pair(x, y) for x, y in raw]
    merged = []
    for s, e in dels:
        if merged and s <= merged[-1][1] + 0.01:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    dels = [(s, e) for s, e in merged]

    # 保留区间 = 全程减删除段
    keep, cursor = [], 0.0
    for s, e in dels:
        if s > cursor: keep.append((cursor, min(s, duration)))
        cursor = max(cursor, e)
    if cursor < duration: keep.append((cursor, duration))
    elif not keep: keep = [(0.0, cursor)]

    # 孤碎片吸收:短于 MIN_KEEP 的保留段是删句后的半截尾音/呼吸残留,
    # 景别和两侧不一致会造成画面"忽大忽小"闪跳,一律并入删除
    MIN_KEEP = 0.40
    frags = [k for k in keep if k[1] - k[0] < MIN_KEEP]
    if frags:
        keep = [k for k in keep if k[1] - k[0] >= MIN_KEEP]
        print("吸收孤碎片: %d 段(<%.2fs): %s" % (len(frags), MIN_KEEP,
              ", ".join("%.2f-%.2f" % (a, b) for a, b in frags)))
    if not keep:
        sys.exit("过滤后没有可保留区间,检查剪切点清单")

    MIN_BREATH = float(a.breath or 0.30)

    def _edge_sil(t, side):
        best = 0.0
        for sa, sb in sil:
            if side == "r":
                if sa <= t <= sb: best = max(best, t - sa)
                elif sb <= t and t - sb < 0.05: best = max(best, t - sa)
            else:
                if sa <= t <= sb: best = max(best, sb - t)
                elif sa >= t and sa - t < 0.05: best = max(best, sb - t)
        return best

    pads = [0.0] * len(keep)
    硬缝 = 0
    for j in range(len(keep) - 1):
        r_, l_ = _edge_sil(keep[j][1], "r"), _edge_sil(keep[j + 1][0], "l")
        # 两侧都不是静音 = 刀落在连续语音中间。补时长=凭空插一段静音+末帧冻结,听感就是"卡顿";
        # 这类接缝只做各 30ms 淡入淡出(下面滤镜里已有),绝不插洞。2026-10-16 改(C0584 成片 27s)。
        if r_ <= 0.02 and l_ <= 0.02:
            硬缝 += 1
            continue
        need = MIN_BREATH - r_ - l_
        if need > 0.02: pads[j] = need
    if 硬缝: print("句中硬缝: %d 处(两侧都是语音,不插气口洞,改用交叉淡化过渡)" % 硬缝)
    if any(pads): print("气口补齐: %d 个接缝,共补 %.2fs" % (sum(1 for x in pads if x > 0), sum(pads)))

    # ---- 交叉淡化:前一段尾巴与后一段开头重叠 X 秒互相淡入淡出(焊接口),既不插静音也不硬顶一下 ----
    X = max(0.0, float(a.xfade or 0))
    n = len(keep)
    ov = [0.0] * n
    if X > 0 and n > 1:
        for i in range(n - 1):
            cap = min((keep[i][1] - keep[i][0]) * 0.35, (keep[i + 1][1] - keep[i + 1][0]) * 0.35)
            ov[i] = round(max(0.01, min(X, cap)), 3)     # 极短段兜底:至少 10ms,不让链断开
    成片秒 = sum(e - s for s, e in keep) + sum(pads) - sum(ov)
    print("保留 %d 段,删除 %d 段,交叉淡化 %d 处(每处%.0fms),预计成片 %.1fs"
          % (n, len(dels), sum(1 for x in ov if x > 0), X * 1000, 成片秒))

    # ---- 字幕:用真实保留区间(含补齐气口)换算成片时间轴 ----
    ass_path = None
    if a.subs in ("auto", "axis"):
        try:
            import make_subs
            tj = Path(a.plan).with_name("转写.json")
            wd = Path(a.plan).with_name("文案定稿.txt")
            if tj.exists():
                acc, mapping = 0.0, []
                for i, (s, e) in enumerate(keep):
                    # 段长要扣掉这一头被"吃进"下一段的重叠秒数,字幕成片轴才跟画面一致
                    mapping.append((s, e, acc)); acc += (e - s) + pads[i] - ov[i]
                ass, srt, st, info, tl = make_subs.build(
                    str(tj), final=str(wd) if wd.exists() else None,
                    style=str(sp) if sp.exists() else None, mapping=mapping, size=(W, H), sil=sil,
                    media=media,
                    over={"字体": a.font, "描边": a.outline, "阴影": a.shadow, "底条": a.box})
                Path(a.plan).with_name("字幕.srt").write_text(srt, encoding="utf-8")
                Path(a.plan).with_name("字幕时间轴.json").write_text(tl, encoding="utf-8")
                if a.subs == "auto":
                    ass_path = Path(a.plan).with_name("字幕.ass")
                    ass_path.write_text(ass, encoding="utf-8")
                else:
                    Path(a.plan).with_name("字幕.ass").write_text(ass, encoding="utf-8")
                    ass_path = None
                print("字幕: %s 行 | %s | 版式来源:%s | %s | %s | %s" % (
                    info["行数"], info["文字来源"], st.get("_geo", ""),
                    ("起音校正 %d 行 / 换气校正 %d 行" % (st.get("贴起音", 0), st.get("贴开口", 0))) if sil else "未做校正",
                    ("半透明底条" if st.get("底条") else "描边0 阴影0"),
                    ("已烧进画面" if ass_path else "只出时间轴,画面保持干净(字幕交给第④步)")))
            else:
                print("字幕: 未找到 转写.json,跳过烧录")
        except Exception as ex:
            print("字幕跳过(不影响粗剪):", ex); ass_path = None

    # ---- 分段滤镜 ----
    parts_v, parts_a, labels = [], [], []
    for i, (s, e) in enumerate(keep):
        _o = ov[i]
        zoom = ZOOM if (ZOOM > 1.001 and i % 2 == 1) else 1.0
        # setsar=1 必须每段都做:源若是非方形像素(SAR≠1:1),加了 scale 的段会变 1:1,
        # 两段 SAR 不一致 concat 直接报 -22 Invalid argument。
        # 画面少留 _o 秒:与音频交叉淡化后的总长对齐,音画不漂
        vf = f"trim=start={s:.3f}:end={e - _o:.3f},setpts=PTS-STARTPTS,setsar=1"
        if zoom > 1.001:
            vf += (f",crop=w=trunc(iw/{zoom}/2)*2:h=trunc(ih/{zoom}/2)*2:x=(iw-ow)/2:y=(ih-oh)/2"
                   f",scale={W}:{H}:flags=lanczos,setsar=1")
        if pads[i] > 0.02: vf += f",tpad=stop_mode=clone:stop_duration={pads[i]:.3f}"
        parts_v.append(f"[0:v]{vf}[v{i}];")
        _seg = e - s
        # 有交叉淡化时不再做段内淡入淡出(交给 acrossfade 塑形),只保留全片首尾各 30ms 防爆音
        _fin = ",afade=t=in:st=0:d=0.03" if (X <= 0 or i == 0) else ""
        _fout = f",afade=t=out:st={_seg - 0.03:.3f}:d=0.03" if (_seg > 0.2 and (X <= 0 or i == n - 1)) else ""
        _pad = f",apad=pad_dur={pads[i]:.3f}" if pads[i] > 0.02 else ""
        parts_a.append(f"[0:a]atrim=start={s:.3f}:end={e:.3f},asetpts=PTS-STARTPTS"
                       f"{_fin}{_fout}{_pad}[a{i}];")
        labels.append(f"[v{i}][a{i}]")
    if X > 0 and n > 1:
        _cf, _prev = "", "[a0]"
        for i in range(1, n):
            _nx = "outa" if i == n - 1 else "x%d" % i
            _cf += (f"{_prev}[a{i}]acrossfade=d={ov[i - 1]:.3f}:c1=tri:c2=tri[{_nx}]"
                    + ("" if i == n - 1 else ";"))
            _prev = f"[{_nx}]"
        a_concat = "".join(parts_a) + _cf
    else:
        a_concat = "".join(parts_a) + "".join(f"[a{i}]" for i in range(n)) + f"concat=n={n}:v=0:a=1[outa]"

    # ---- 音频修复(可选):拼成片音频 -> ClearVoice -> 作为主命令的音轨输入 ----
    final_wav = None
    if a.repair == "on":
        if a.audio == "off":
            print("提示: --repair 依赖音频链,但 --audio off,本次跳过修复")
        else:
            tmp1 = Path(a.plan).with_name("_修复输入.wav")
            tmp2 = Path(a.plan).with_name("_修复输出.wav")
            t0 = time.time()
            try:
                r1 = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", media,
                                     "-filter_complex", a_concat, "-map", "[outa]",
                                     "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(tmp1)],
                                    capture_output=True, text=True, encoding="utf-8", errors="replace")
                if r1.returncode != 0 or not tmp1.exists():
                    raise RuntimeError("拼成片音频失败: " + (r1.stderr or "")[-200:])
                r2 = subprocess.run([PY, str(Path(__file__).resolve().parent / "vocal_repair.py"),
                                     str(tmp1), str(tmp2)],
                                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                                    timeout=5400)
                log2 = ((r2.stdout or "") + "\n" + (r2.stderr or "")).strip()
                if r2.returncode == 0 and tmp2.exists():
                    final_wav = str(tmp2)
                    print("音频修复: ClearVoice 完成,用时 %.0fs" % (time.time() - t0))
                else:
                    tmp1.unlink(missing_ok=True)
                    print("音频修复跳过(不影响粗剪,走常规音频链)。返回码 %s,末尾日志:\n%s"
                          % (r2.returncode, "\n".join(log2.splitlines()[-6:])))
            except Exception as ex:
                tmp1.unlink(missing_ok=True); tmp2.unlink(missing_ok=True)
                print("音频修复跳过(异常,走常规音频链):", ex)

    # ---- 响度两遍测量:源=修复后 wav(若有),否则按纯音频 graph 现测 ----
    LN2 = f"loudnorm=I={LUFS}:TP={TP}:LRA={LRA}"
    if a.audio == "on" and a.chain == "full":
        base_ln = LN2
        if final_wav:
            cmd_m = ["ffmpeg", "-hide_banner", "-nostats", "-i", final_wav, "-af",
                     base_ln + ":print_format=json", "-vn", "-f", "null", "-"]
        else:
            cmd_m = ["ffmpeg", "-hide_banner", "-nostats", "-i", media, "-filter_complex",
                     a_concat + ";[outa]" + AUDIO_FC + "," + base_ln + ":print_format=json[lnm]",
                     "-map", "[lnm]", "-f", "null", "-"]
        if os.environ.get("RENDER_CUT_DEBUG"):
            print("测量命令>>>", " | ".join(cmd_m)[-400:])
            print("测量命令参数数:", len(cmd_m))
        try:
            pm = subprocess.run(cmd_m, capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=900)
            d = parse_loudnorm(pm.stderr or "") if pm.returncode == 0 else None
            if pm.returncode != 0:
                print("响度测量命令失败,回退单遍模式:",
                      ((pm.stderr or "").strip().splitlines() or ["无输出"])[-1][:150])
            if d and all(_lnv(x, *rg) is not None for x, rg in (
                    (d["input_i"], (-99.0, 0.0)), (d["input_tp"], (-99.0, 0.0)),
                    (d["input_lra"], (0.0, 50.0)), (d["input_thresh"], (-99.0, 0.0)),
                    (d.get("target_offset") or d.get("target_thresh"), (-99.0, 99.0)))):
                LN2 = (f"{base_ln}:measured_I={d['input_i']}:measured_TP={d['input_tp']}"
                       f":measured_LRA={d['input_lra']}:measured_thresh={d['input_thresh']}"
                       f":offset={d.get('target_offset') or d.get('target_thresh')}:linear=true")
                print("响度: 两遍测量法(实测 %.1f LUFS -> 目标 %.1f,线性对齐)"
                      % (float(d["input_i"]), LUFS))
            elif d:
                print("响度测量数值越界(%s,整段可能是纯静音或被修复模型判定为非语音),"
                      "回退单遍模式" % d["input_i"])
        except Exception as e:
            print("响度测量异常,回退单遍模式:", e)

    # ---- 拼 filter_complex ----
    if final_wav:
        fc = "".join(parts_v) + "".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[outv]"
        fc += ";[1:a]" + ((AUDIO_FC + "," + LN2 + ",") if a.chain == "full" else "") + "aresample=48000[outa2]"
        amap = "[outa2]"
        inputs = ["-i", media, "-i", final_wav]
    else:
        fc = ("".join(parts_v) + "".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[outv];"
              + a_concat)
        amap = "[outa]"
        if a.audio == "on" and a.chain == "full":
            fc += ";[outa]" + AUDIO_FC + "," + LN2 + ",aresample=48000[outa2]"
            amap = "[outa2]"
        inputs = ["-i", media]
    vcur = "[outv]"
    if ass_path:
        esc = str(ass_path).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
        fc += ";[outv]subtitles=filename='%s'[vsub]" % esc
        vcur = "[vsub]"
    if a.fast:
        fc += ";%sscale=-2:720[vscale]" % vcur
        vcur = "[vscale]"
    out = Path(a.out) if a.out else Path(a.plan).with_name("rough.mp4")
    if a.fast: out = out.with_name(out.stem + "_预览.mp4")
    # 原子写:先落 .part,ffmpeg 成功且时长验尸通过才改名成正名。
    # 中途被杀/断电只留下 .part,绝不会出现"看起来成功的半截成片"。
    tmpout = out.with_name(out.stem + ".part" + out.suffix)
    venc, vname = pick_video_args(a.gpu, a.crf, a.fast)
    cmd = ["ffmpeg", "-y"] + inputs + ["-filter_complex", fc, "-map", vcur, "-map", amap] + \
          venc + ["-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(tmpout)]
    if os.environ.get("RENDER_CUT_DEBUG"):
        print("FC>>>" + fc[:1200] + "<<<FC")
    print(("执行 ffmpeg 出低清预览..." if a.fast else "执行 ffmpeg 粗剪...") + "(编码器: %s,这一步最慢,几分钟没有新输出属正常,别关工作台)" % vname)
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if final_wav:
        Path(final_wav).unlink(missing_ok=True)
    if r.returncode != 0:
        tmpout.unlink(missing_ok=True)
        sys.exit("ffmpeg 失败:\n" + (r.stderr or "")[-2000:])
    try:
        pd = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                             "-of", "csv=p=0", str(tmpout)], capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
        dur = float((pd.stdout or "").strip())
    except Exception as e:
        dur = 0.0
        print("成片验尸失败(按不通过处理):", e)
    if not (dur > 0):   # nan 也要拦:nan<=0 是 False,会放半截文件过关
        tmpout.unlink(missing_ok=True)
        sys.exit("渲染产物时长读不出来(0 秒),已丢弃半成品,不落成片名")
    os.replace(tmpout, out)
    print("完成: %s | 时长 %.2fs | 用时 %.0fs" % (out.resolve(), dur, time.time() - t0))
    if a.audio == "on":
        if a.chain == "full":
            print("  音频链: 高通80Hz + 轻降噪 + 压限 + 响度 %.1f LUFS%s"
                  % (LUFS, "(两遍)" if "measured_I" in LN2 else "(单遍)"))
        else:
            print("  音频链: 直通(铁律18:不降噪/不高通/不压限/不改响度;要处理链加 --chain full)")
    if ZOOM > 1.001: print("  跳剪交替变焦: %.2f(奇数段放大)" % ZOOM)


if __name__ == "__main__":
    main()