# -*- coding: utf-8 -*-
"""AI剪辑工作台 · 原生窗口壳(不依赖 Chrome/Edge 窗口)
原理:pywebview 用系统自带 WebView2 开原生窗口;设独立 AppUserModelID + WM_SETICON
让任务栏显示我们自己的声波点图标。WebView2 不可用时自动退回浏览器(Chrome优先Edge)。
"""
import ctypes, os, sys, time, threading
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.chdir(HERE)
URL = "http://127.0.0.1:9527/"
TITLE = "口播剪辑工作台"

def port_up():
    import socket
    s = socket.socket()
    try:
        s.settimeout(0.4)
        s.connect(("127.0.0.1", 9527))
        return True
    except Exception:
        return False
    finally:
        s.close()

def start_backend():
    import subprocess
    log = open(HERE / "启动日志.txt", "ab")
    DET = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    subprocess.Popen([sys.executable, "-u", str(HERE / "workbench.py"), "--no-browser"],
                     cwd=str(HERE), stdout=log, stderr=subprocess.STDOUT, creationflags=DET)
    for _ in range(80):
        time.sleep(0.5)
        if port_up():
            return True
    return False

def browser_fallback():
    import subprocess
    exe = None
    for c in (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
              r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"):
        if os.path.isfile(c):
            exe = c
            break
    if not exe:
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                               r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe")
            exe = winreg.QueryValue(k, None)
        except Exception as e:
            print("[壳] 找不到浏览器:", e)
            exe = None
    if exe and os.path.isfile(exe):
        subprocess.Popen([exe, "--app=" + URL])
        return True
    return False

def set_icon(hwnd, ico):
    u = ctypes.windll.user32
    LR = 0x00000010 | 0x00000040 | 0x00008000  # LOADFROMFILE | DEFAULTSIZE | SHARED
    h = u.LoadImageW(0, str(ico), 1, 0, 0, LR)  # 1=IMAGE_ICON
    if h:
        u.SendMessageW(hwnd, 0x0080, 1, h)  # WM_SETICON ICON_BIG
        u.SendMessageW(hwnd, 0x0080, 0, h)  # ICON_SMALL

def icon_later():
    if not (HERE / "app.ico").exists():
        return
    u = ctypes.windll.user32
    for _ in range(60):
        time.sleep(0.25)
        h = u.FindWindowW(None, TITLE)
        if h:
            set_icon(h, HERE / "app.ico")
            return

def main():
    if not port_up() and not start_backend():
        ctypes.windll.user32.MessageBoxW(0, "后端启动失败:双击「启动工作台.cmd」看具体报错,或按顶栏 🎫 反馈联系作者。", "AI剪辑工作台", 0x10)
        return 1
    try:
        import webview
    except Exception as e:
        print("[壳] pywebview 不可用,退回浏览器: %r" % e)
        return 0 if browser_fallback() else 1
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DianXin.Workbench")
    except Exception as e:
        print("[壳] AUMID 设不上(不影响开窗): %r" % e)
    threading.Thread(target=icon_later, daemon=True).start()
    webview.create_window(TITLE, URL, width=1280, height=860, min_size=(900, 600), text_select=True)
    try:
        webview.start(gui="edgechromium", debug=False)
    except Exception as e:
        print("[壳] WebView2 开窗失败,退回浏览器: %r" % e)
        browser_fallback()
    return 0

if __name__ == "__main__":
    sys.exit(main())
