# -*- coding: utf-8 -*-
"""本地量化对标:把参考片的"节奏/明暗/配色/响度/语速"算成可执行参数,输出 对标风格.json。
全程本机 ffmpeg/ffprobe,不联网、不上传、不花钱。
用法: python ref_style.py 参考片.mp4 [--out 对标风格.json] [--speech] [--compare 本片转写.json]"""
import argparse, json, re, statistics, subprocess, sys, tempfile
from pathlib import Path
import sys as _sys
_sys.stdout.reconfigure(encoding="utf-8", errors="replace")   # Windows 控制台默认 GBK,统一 UTF-8 供上层解码

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm"}


def run(cmd):
    return subprocess.run([str(x) for x in cmd], capture_output=True, text=True,
                          encoding="utf-8", errors="replace")


def probe(src):
    p = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
             "stream=width,height,r_frame_rate", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=0", src])
    w = h = 0; fps = 0.0; dur = 0.0
    m = re.search(r"width\s*=\s*(\d+)", p.stdout); w = int(m.group(1)) if m else 0
    m = re.search(r"height\s*=\s*(\d+)", p.stdout); h = int(m.group(1)) if m else 0
    m = re.search(r"r_frame_rate\s*=\s*(\d+)/(\d+)", p.stdout)
    if m and int(m.group(2)): fps = int(m.group(1)) / int(m.group(2))
    m = re.search(r"duration\s*=\s*([\d.]+)", p.stdout); dur = float(m.group(1)) if m else 0.0
    return w, h, fps, dur


def scene_cuts(src, thr, cap):
    """切点=画面发生明显变化的时刻(转场/插卡/跳剪都会触发),用它反推对标的视觉密度。"""
    p = run(["ffmpeg", "-hide_banner", "-nostats", "-i", src, "-t", cap, "-an", "-vf",
             "fps=8,scale=96:-2,select='gt(scene,%s)',showinfo" % thr, "-f", "null", "-"])
    ts = [float(x) for x in re.findall(r"pts_time:([\d.]+)", (p.stdout or "") + (p.stderr or ""))]
    out, last = [], -1.0
    for t in sorted(ts):                       # 相邻重复命中合并(一次转场常被连续判多次)
        if t - last > 0.35: out.append(round(t, 2))
        last = t
    return out


def brightness(src, cap):
    p = run(["ffmpeg", "-hide_banner", "-nostats", "-i", src, "-t", cap, "-an", "-vf",
             "fps=1,scale=64:64,signalstats,metadata=print:file=-", "-f", "null", "-"])
    ys = [int(x) for x in re.findall(r"YAVG=(\d+)", p.stdout or "") if 0 < int(x) < 256]
    if not ys: return None
    ys.sort()
    return {"亮度均值": round(sum(ys) / len(ys) / 255, 3), "亮度中位": round(statistics.median(ys) / 255, 3),
            "暗部p5": round(ys[max(0, int(len(ys) * 0.05))] / 255, 3),
            "亮部p95": round(ys[min(len(ys) - 1, int(len(ys) * 0.95))] / 255, 3),
            "动态范围": round((ys[min(len(ys) - 1, int(len(ys) * 0.95))] - ys[max(0, int(len(ys) * 0.05))]) / 255, 3),
            "采样帧": len(ys)}


def palette(src, cap, n=10):
    """抽帧缩到16x16原始像素流,纯 Python 统计主色:不需要 PIL/联网。"""
    side = 16
    p = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(src), "-t", str(cap), "-an",
              "-vf", "fps=1/2,scale=%d:%d" % (side, side), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
             capture_output=True)
    data = p.stdout or b""
    if len(data) < side * side * 3: return []
    buckets = {}
    for off in range(0, len(data) - side * side * 3 + 1, side * side * 3):
        blk = data[off:off + side * side * 3]
        for i in range(0, len(blk), 3):
            r, g, b = blk[i], blk[i + 1], blk[i + 2]
            key = (r >> 5, g >> 5, b >> 5)
            a = buckets.setdefault(key, [0, 0, 0, 0])
            a[0] += 1; a[1] += r; a[2] += g; a[3] += b
    top = sorted(buckets.values(), key=lambda a: -a[0])[:n * 3]
    cols = []
    for a in top:
        r, g, b = a[1] // a[0], a[2] // a[0], a[3] // a[0]
        mx, mn = max(r, g, b), min(r, g, b)
        sat = 0 if mx == 0 else (mx - mn) / mx
        cols.append({"hex": "#%02X%02X%02X" % (r, g, b), "占比": round(a[0] / sum(x[0] for x in buckets.values()), 3),
                     "饱和度": round(sat, 2)})
    return cols


def loudness(src, cap):
    p = run(["ffmpeg", "-hide_banner", "-nostats", "-i", src, "-t", cap, "-vn",
             "-af", "ebur128=peak=true", "-f", "null", "-"])
    txt = (p.stderr or "") + (p.stdout or "")
    def g(pat):
        m = re.findall(pat, txt)
        return round(float(m[-1]), 2) if m else None
    return {"LUFS": g(r"I:\s*(-?[\d.]+)\s*LUFS"), "LRA": g(r"LRA:\s*(-?[\d.]+)\s*LU"),
            "真峰值": g(r"Peak:\s*(-?[\d.]+)\s*dBFS")}


def speech(media, tj):
    """有转写就读,没有就现场跑一遍本机 faster-whisper(离线,免费)。"""
    tj = Path(tj)
    if not tj.exists():
        tr = run([sys.executable, str(Path(__file__).parent / "transcribe.py"), str(media), "--out", str(tj)])
        if not tj.exists():
            return {"错误": "语速分析失败(转写未生成): " + ((tr.stderr or tr.stdout or "")[-200:])}
    d = json.loads(tj.read_text(encoding="utf-8"))
    segs = d.get("segments", [])
    if not segs: return {"错误": "参考片没有语音,语速/停顿无法对标"}
    chars = sum(len(re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]", "", s.get("text", ""))) for s in segs)
    dur = float(d.get("duration") or segs[-1]["end"] or 1)
    gaps = [round(segs[i + 1]["start"] - segs[i]["end"], 3) for i in range(len(segs) - 1)]
    gaps = [g for g in gaps if g >= 0]
    srt = sorted(gaps)
    def pct(p):
        return srt[min(len(srt) - 1, int(len(srt) * p))] if srt else 0.0
    return {"字数": chars, "字每分钟": round(chars / dur * 60, 1), "段数": len(segs),
            "句间停顿中位": round(statistics.median(srt), 3) if srt else 0,
            "句间停顿p85": round(pct(0.85), 3), "句间停顿p95": round(pct(0.95), 3),
            "长停顿占比": round(len([g for g in gaps if g > 0.8]) / len(gaps), 2) if gaps else 0,
            "语速_转写模型": d.get("model", "")}


def clamp(v, lo, hi): return max(lo, min(hi, v))


def suggest(st, w, h, cuts_per_min):
    vert = h > w
    font = round((0.055 if vert else 0.062) * h)
    perline = int(clamp(round(w * 0.86 / max(font, 1)), 6, 16))
    sp = st.get("语速", {})
    p50 = sp.get("句间停顿中位"); p85 = sp.get("句间停顿p85")
    pause = round(clamp((p85 + 0.1) if p85 else 1.0, 0.7, 1.6) * 20) / 20
    keepsil = round(clamp(p50 * 0.9 if p50 else 0.45, 0.25, 0.55) * 20) / 20
    lu = (st.get("响度") or {}).get("LUFS")
    loud_i = round(clamp(lu if lu else -16.0, -18.0, -14.0), 1)
    accent = next((c["hex"] for c in st.get("主色", [])
                  if c["饱和度"] > 0.45 and int(c["hex"][1:3], 16) + int(c["hex"][3:5], 16) + int(c["hex"][5:7], 16) > 300), "#FFD84D")
    return {"停顿剪阈值秒": pause, "剪后留呼吸秒": keepsil, "响度目标LUFS": loud_i,
            "峰值上限dB": -1.5, "响度范围LU": (lambda v: v if v and v >= 6 else 11)((st.get("响度") or {}).get("LRA")),
            "跳剪交替变焦": 1.12 if (cuts_per_min or 0) >= 12 else 1.06,
            "字幕字号px": font, "每行字数": perline,
            "字幕下沿留白比例": round(0.20 if vert else 0.08, 3),   # 2026-11-02 规则17 v2:竖屏20%(旧写0.18会把字幕压进遮挡区)
            "字幕颜色": "#FFFFFF", "强调色": accent,
            "画幅": "竖屏" if vert else "横屏", "目标切镜密度": cuts_per_min}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ref")
    ap.add_argument("--out", default=None, help="默认 参考片同目录/对标风格.json")
    ap.add_argument("--speech", action="store_true", help="做语速/停顿对标(需要转写,较慢)")
    ap.add_argument("--compare", default=None, help="本片转写.json,给差值诊断")
    ap.add_argument("--thr", type=float, default=0.4, help="场景变化阈值,0.3 敏感 0.5 只看大转场")
    ap.add_argument("--max", type=float, default=180, help="最多分析前多少秒(默认180,省时)")
    a = ap.parse_args()
    src = Path(a.ref)
    if not src.exists(): sys.exit("找不到参考片: %s" % src)
    if src.suffix.lower() not in VIDEO_EXT: sys.exit("对标量化只支持视频: %s" % src.suffix)
    out = Path(a.out) if a.out else src.with_name("对标风格.json")
    w, h, fps, dur = probe(src)
    cap = str(min(a.max, dur or a.max))
    st = {"对标源": str(src.resolve()), "时长": round(dur, 2), "画幅": [w, h], "帧率": round(fps, 2),
          "分析窗口秒": float(cap)}
    print("切镜密度...", flush=True)
    cuts = scene_cuts(src, a.thr, cap)
    st["切镜"] = {"切点数": len(cuts), "每分钟切镜": round(len(cuts) / max(float(cap), 1) * 60, 1),
                 "平均镜头秒": round(float(cap) / len(cuts), 2) if cuts else None, "切点": cuts[:80],
                 "场景阈值": a.thr}
    print("明暗...", flush=True); st["明暗"] = brightness(src, cap)
    print("主色...", flush=True); st["主色"] = palette(src, cap)
    print("响度...", flush=True); st["响度"] = loudness(src, cap)
    if a.speech:
        print("语速(需转写,最慢的一步)...", flush=True)
        st["语速"] = speech(src, src.with_name(src.stem + ".对标转写.json"))
    st["建议"] = suggest(st, w or 1080, h or 1920, (st.get("切镜") or {}).get("每分钟切镜"))
    if a.compare:
        cj = Path(a.compare)
        if cj.exists():
            d = json.loads(cj.read_text(encoding="utf-8"))
            segs = d.get("segments", [])
            ch = sum(len(re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]", "", s.get("text", ""))) for s in segs)
            du = float(d.get("duration") or 1)
            mine = {"字每分钟": round(ch / du * 60, 1), "段数": len(segs)}
            ref = st.get("语速", {}).get("字每分钟")
            tips = []
            if ref:
                if mine["字每分钟"] < ref * 0.9: tips.append("你比对标慢 %.0f%%:先收紧停顿(降 剪后留呼吸),别急着删内容" % ((1 - mine["字每分钟"] / ref) * 100))
                elif mine["字每分钟"] > ref * 1.1: tips.append("你比对标快 %.0f%%:信息密度已够,包装别再叠加快节奏动效" % ((mine["字每分钟"] / ref - 1) * 100))
            if (st.get("明暗") or {}).get("亮度均值") is not None:
                tips.append("参考片亮度均值 %.2f:按它决定字幕用白字还是深底压字" % st["明暗"]["亮度均值"])
            st["本片对照"] = {"语速": mine, "对标语速": ref, "结论": tips}
    out.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    s = st["建议"]
    print("\n对标参数已落盘: %s" % out)
    print("  切镜 %.1f 次/分(平均镜头 %ss) | 亮度 %.2f | LUFS %s | 语速 %s 字/分" % (
        s["目标切镜密度"] or 0, (st.get("切镜") or {}).get("平均镜头秒") or 0,
        (st.get("明暗") or {}).get("亮度均值") or 0, (st.get("响度") or {}).get("LUFS"),
        (st.get("语速") or {}).get("字每分钟") or "未测"))
    print("  回填建议: 停顿剪阈值 %.2fs / 留呼吸 %.2fs / 响度 %.1f LUFS / 跳剪变焦 %.2f / 字号 %dpx(每行%d字)" % (
        s["停顿剪阈值秒"], s["剪后留呼吸秒"], s["响度目标LUFS"], s["跳剪交替变焦"], s["字幕字号px"], s["每行字数"]))


if __name__ == "__main__":
    main()
