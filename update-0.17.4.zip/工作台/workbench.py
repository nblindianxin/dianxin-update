﻿# -*- coding: utf-8 -*-
"""口播剪辑工作台。启动: python workbench.py(自动开浏览器, http://127.0.0.1:8765)
依赖同套件 ../scripts 下三个脚本 + faster-whisper + ffmpeg,均为本机已有。"""
import argparse, io, json, os, re, shutil, subprocess, sys, threading, time, traceback, webbrowser, urllib.request
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote, quote

ROOT = Path(__file__).resolve().parent
WF = ROOT.parent
SCRIPTS = WF / "scripts"
PROJ_ROOT = ROOT / "项目"
VERSION = "0.17.4(发版 2026-11-20, 任务日志不再只存内存:每次任务的日志同时落盘到 工作台/任务日志/ 按项目分文件,关掉工作台重开也能看到上次为什么失败(日志框会标注来源是磁盘留存);反馈单新增 任务日志尾.txt,只带命令与报错行、OCR正文文案一句不外带;写盘与进包前先抹掉疑似密钥,该目录已进 .gitignore 不进仓库)"     # 顶栏显示,随 /api/queue 下发;发包时同步打 git tag 对账
STATEF = ROOT / "任务状态.json"   # 在跑任务的活体记录:工作台没了而 ffmpeg 还活着时由启动收尸用
LOGF = ROOT / "运行日志.jsonl"    # 售后证据:入队/开始/结束/取消/接口异常逐条落盘(纯本地,不外发)
INTERRUPTED = []                  # 本次启动清理掉的上次中断任务(给前端弹提醒)
PY = sys.executable
JOBS = {}                       # 任务状态表(带锁):key=项目目录
_QUEUE = []                     # 待跑任务(简单列表即可,单工作线程串行消费)
_LOCK = threading.Lock()
_WORKER = [None]
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm"}

启动时刻 = time.time()

更新源 = WF / "更新源.txt"      # 发版时随包更新:第1行=版本号或版本信息URL,第2行=下载页,第3行起=更新日志
# ―― 联网自动更新:作者发版推 Gitee(主)/GitHub(备),客户查更新先走 Gitee raw 境内直连(2026-10-30 起) ――
UPDATE检查仓库 = "nblindianxin/dianxin-update"
UPDATE_CHECK_URL = "https://cdn.jsdelivr.net/gh/" + UPDATE检查仓库 + "@main/update.txt"
Gitee更新仓库 = "lin-dianxin/dianxin-update"   # 国内镜像发布仓:作者国内直推不用代理,客户查更新优先它的 raw(2026-10-28 立)
更新源可信用户 = UPDATE检查仓库.split("/")[0]
更新源可信前缀 = ("https://cdn.jsdelivr.net/gh/" + 更新源可信用户 + "/",
                "https://raw.githubusercontent.com/" + 更新源可信用户 + "/",
                "https://github.com/" + 更新源可信用户 + "/",
                "https://gitee.com/" + Gitee更新仓库 + "/raw/")

def 可信更新地址(u):
    """只认作者这一个仓库的 https 直链——别的一律拒绝,防止有人伪造下载地址远程装代码。"""
    return isinstance(u, str) and u.startswith(更新源可信前缀)

更新镜像基址 = ("https://gitee.com/" + Gitee更新仓库 + "/raw/master",
              "https://cdn.jsdelivr.net/gh/" + UPDATE检查仓库 + "@main",
              "https://raw.githubusercontent.com/" + UPDATE检查仓库 + "/main")

def _镜像替换(url):
    """把一个可信镜像地址换算成所有可信镜像的同一尾路径,供检查/下载逐个重试(某个镜像被墙就换下一个)。"""
    for b in 更新镜像基址:
        if url.startswith(b):
            尾 = url[len(b):]
            return [bb + 尾 for bb in 更新镜像基址]
    return [url]

def 版本解析(s):
    """'0.2(2026-10-18,...)' → (0,2);取开头数字段按数字比大小(0.10 必须大于 0.9,不能按字符串比)。"""
    import re as _re
    m = _re.match(r"\s*v?(\d+(?:\.\d+)*)", str(s or ""))
    return tuple(int(x) for x in m.group(1).split(".")) if m else ()

def 是开发者源():
    """识别作者开发机:发卡台账与发卡脚本同框=开发仓库。
    发货副本(安装包/便携版/体验副本)两个都不带(发货红线:自用不发货),不会把客户误判成作者。
    2026-10-26 起这只当身份标记,不再关掉更新:开发机与客户机同走一条路——
    打开自动查版本、有新版照样弹「一键更新」直接装(刚发完版本机=发布源,状态是「已是最新」,不弹卡)。
    要连「作者开发源」这个标记都不显示、彻底按客户机演练:设环境变量 DIANXIN_AS_CUSTOMER=1 再启动。"""
    if (os.environ.get("DIANXIN_AS_CUSTOMER") or "").strip():
        return False
    return (WF / "卡密台账.csv").exists() and (WF / "scripts" / "gen_keys.py").exists()

def 检查候选列表():
    """查更新的镜像顺序:Gitee raw 第一(境内直连,2026-10-30 起不再先等 jsDelivr 超时),
    jsDelivr/GitHub raw 降为兜底;UPDATE_CHECK_URL 若不在镜像表内则排最后(兼容钩子,置空=离线)。"""
    候 = [b + "/update.txt" for b in 更新镜像基址]
    if UPDATE_CHECK_URL and UPDATE_CHECK_URL not in 候:
        候.append(UPDATE_CHECK_URL)
    return 候


def update_check():
    """检查更新:按镜像顺序联网读作者发布源(先 Gitee raw,失败自动换 jsDelivr/GitHub raw),全不可达或已关闭则回退本机 更新源.txt。
    只读一个小文本,不动用户任何文件;联网失败静默回退,绝不弹假更新。UPDATE_CHECK_URL 置空=只用本机(自检/离线)。
    作者开发机与客户机同走这一条(2026-10-26):打开自动查、有新版弹「一键更新」直接装,没有「开发者工作台」短路;
    正常情况下本机就是刚发完的最新版,状态=「已是最新」,不会弹卡打扰。"""
    try:
        开发源 = 是开发者源()
        文 = None; 基 = ""
        if UPDATE_CHECK_URL:
            候选 = 检查候选列表()
            import urllib.request
            for u in 候选:
                if not 可信更新地址(u):
                    continue
                try:
                    req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
                    with urllib.request.urlopen(req, timeout=15) as r:
                        文 = r.read().decode("utf-8-sig", "replace")
                    基 = u[:u.rindex("/update.txt")]
                    break
                except Exception as e:
                    print("[更新源该镜像不可达,试下一个] %s -> %r" % (u[:48], e))
        if 文 is None:
            基 = ""
            if not 更新源.exists():
                return {"有更新": False, "状态": "未配置", "当前": VERSION,
                        "说明": "更新源.txt 不存在——作者发新版时会带上它,现在按本机版本用"}
            字 = 更新源.read_bytes()
            try:
                文 = 字.decode("utf-8-sig")
            except UnicodeDecodeError:
                文 = 字.decode("gbk", "replace")
        raw = [x.strip() for x in 文.splitlines()]
        最新 = raw[0] if raw else ""
        文2 = raw[1] if len(raw) > 1 else ""
        if 基 and 可信更新地址(文2):
            地址 = 文2   # 发布方用「带版本号的固定文件名」(0.7.2 起):CDN 不会按同名刷出旧缓存,根死循环
        elif 基:
            地址 = 基 + "/update.zip"
        else:
            地址 = 文2
        日志 = "\n".join(x for x in raw[2:] if x)
        if not 版本解析(最新):
            return {"有更新": False, "状态": "更新源读不懂", "当前": VERSION,
                    "说明": "第一行没有版本号(现在:" + (最新[:30] or "空") + ")"}
        有 = 版本解析(最新) > 版本解析(VERSION)
        一键 = bool(有 and 可信更新地址(地址))
        结 = {"有更新": 有, "状态": "有新版可装" if 有 else "已是最新", "当前": VERSION,
               "最新": 最新, "地址": 地址, "日志": 日志, "可一键": 一键,
               "本机身份": "作者开发源" if 开发源 else "客户副本"}
        if 开发源 and 有:
            结["说明"] = ("本机是作者开发源,发布源却比本机新——多半上次发版中断回滚了,或这台机器在用旧副本;"
                          "点「一键更新」会用发布包覆盖本地引擎文件(旧文件先备份进 备份\\更新前-*),项目/素材/卡密都不动")
        return 结
    except Exception as e:
        print("[检查更新失败] %r" % e)
        return {"有更新": False, "状态": "检查失败", "当前": VERSION, "说明": repr(e)[:150]}

# —— 增量更新:装 scripts/make_update.py 产的小「更新包」,客户不用重下 500MB 大包 ——
补丁根白名单 = {"更新源.txt", "黑名单.txt", "功能总览.md", "工作流说明.md", "给AI看的改造说明书.md",
              "分镜镜头表模板.md", "Getting_Started.md", "LICENSE-NOTES.txt", "动效包装协议.md",
              "客户-AI助手接入说明.md", "风格档.json"}
补丁禁止段 = {"项目", "备份", "__pycache__", "Getting_Started", ".runtime",
              "license.json", "任务状态.json", "运行日志.jsonl", "说明自检.txt", "启动日志.txt"}

def 更新包准入(n):
    """更新包 zip 里一个成员能否落盘:None=放行,否则给拒绝理由(防恶意/手改的包写到别处)。"""
    seg = str(n).split("/")
    if "\\" in n or ":" in n or n.startswith("/") or any(s in ("", ".", "..") for s in seg):
        return "路径不是干净的相对路径: %s" % n[:40]
    if any(s in 补丁禁止段 for s in seg):
        return "禁止触碰项目数据/运行区: %s" % n[:40]
    if len(seg) == 1:
        return None if n in 补丁根白名单 else "根文件不在白名单: %s" % n[:40]
    if seg[0] == "scripts":
        return None if (len(seg) == 2 and n.endswith(".py")) else "scripts 只允许根级 .py: %s" % n[:40]
    if seg[0] == "工作台":
        return None
    return "位置不认识,拒绝写入: %s" % n[:40]

def apply_update(数据, 根=None, 严格升版=False):
    """装更新包(zip 字节):整包校验→旧文件备份→就地覆盖。任何校验不过,一个文件都不碰;
    备份/写入全部读进内存后才动手,zip 中途损坏不会半装。根默认 WF,自检可传临时目录。"""
    import io as _io, zipfile as _zip
    根 = Path(根) if 根 else WF
    try:
        zf = _zip.ZipFile(_io.BytesIO(数据))
    except Exception as e:
        print("[更新包读不了] %r" % e)
        return {"error": "不是能打开的 zip 更新包: " + repr(e)[:120]}
    名 = [n for n in zf.namelist() if not n.endswith("/")]
    if "补丁清单.json" not in 名:
        zf.close()
        return {"error": "不是官方更新包(缺补丁清单.json)——请找作者重发"}
    件 = [n for n in 名 if n != "补丁清单.json"]
    歪 = []
    for n in 件:
        r = 更新包准入(n)
        if r:
            歪.append(r)
    if 歪:
        zf.close()
        return {"error": "更新包里有不能写的东西:" + "; ".join(歪[:3])}
    try:
        信息 = json.loads(zf.read("补丁清单.json").decode("utf-8-sig"))
        存 = {n: zf.read(n) for n in 件}
    except Exception as e:
        zf.close()
        print("[更新包内容坏了] %r" % e)
        return {"error": "更新包内容读不出来(zip 可能截断): " + repr(e)[:120]}
    zf.close()
    if not 存:
        return {"error": "更新包里没有任何文件"}
    if 根 == WF and 版本解析(信息.get("版本")) and 版本解析(信息.get("版本")) <= 版本解析(VERSION):
        print("[更新包版本不比本机新] 包 %s ≤ 本机 %s——照常装(修复场景)" % (信息.get("版本"), VERSION))
    if 严格升版 and not (版本解析(信息.get("版本")) > 版本解析(VERSION)):
        本机简 = str(VERSION).split("(")[0]
        print("[一键更新拒装] 包 %s ≤ 本机 %s——发布源CDN缓存没刷新,不动本机文件" % (信息.get("版本"), VERSION))
        return {"error": "下载到的更新包(v%s)不比本机(v%s)新——发布源的CDN缓存还没刷新,拉下来还是旧包,已拒装且本机文件一个没动。你多半已经更新到位了,关掉工作台一小时后再打开,卡片自消;急用就找作者要「更新包.zip」,点顶栏「装更新包」手动装" % (信息.get("版本") or "?", 本机简)}
    印戳 = time.strftime("%Y-%m-%d_%H%M%S")
    备份根 = 根 / "备份" / ("更新前-" + 印戳)
    写 = []
    try:
        for n, b in 存.items():
            dst = 根.joinpath(*n.split("/"))
            if dst.exists():
                bk = 备份根.joinpath(*n.split("/"))
                bk.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, bk)
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(b)
            写.append(n)
    except Exception as e:
        print("[更新包装到一半] 已写 %d/%d 后炸: %r" % (len(写), len(存), e))
        return {"error": "安装中断(第 %d/%d 个): %r——旧文件已备份在 备份\\更新前-*,把这条发给作者" % (len(写), len(存), e)}
    slog("更新包已装", "", "%d 个文件 → 版本 %s" % (len(写), 信息.get("版本", "?")))
    return {"ok": True, "个数": len(写), "版本": 信息.get("版本", ""), "日志": 信息.get("日志", ""),
            "备份": str(备份根)}

def apply_update_from_url(url):
    """从可信地址下载更新包交给 apply_update 走全量校验。非可信源直接拒;某个镜像下载失败自动换下一个可信镜像重试。"""
    if not 可信更新地址(url):
        print("[更新拒绝] 下载地址不在作者可信仓库:", str(url)[:120])
        return {"error": "下载地址不是作者的可信仓库,拒绝自动更新"}
    import urllib.request
    最后错 = None
    for cu in _镜像替换(url):
        if not 可信更新地址(cu):
            continue
        try:
            req = urllib.request.Request(cu, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=90) as r:
                数据 = r.read(64 * 1024 * 1024 + 1)
            if len(数据) > 64 * 1024 * 1024:
                return {"error": "更新包过大(>64MB),拒绝下载"}
            return apply_update(数据, 严格升版=True)
        except Exception as e:
            print("[镜像下载失败,试下一个] %s -> %r" % (cu[:48], e))
            最后错 = e
    return {"error": "下载更新包失败(所有可信镜像都连不上):" + repr(最后错)[:120]}


def 重启自身命令(argv=None, exe=None):
    """纯函数:拼出「和本次启动同一个 python、同一串参数」的重启命令——
    --no-browser 这类参数不能丢,丢了壳/浏览器行为就变;自检空跑与真重启共用这一个口径。"""
    a = list(sys.argv if argv is None else argv)
    return [exe or sys.executable, "-u"] + [str(x) for x in a if str(x)]

def 自动重启后():
    """装完更新包自动把后端换血(2026-10-26 修「永远弹一键更新」死循环):
    用户的「重启」往往只是重开窗口——旧 pythonw 进程还占着 9527,壳见端口通的就只重开窗口,
    内存里版本号永远旧的,更新卡片永远弹。做法:拉起一个独立助手小进程→睡 2 秒(等这次网页回复发完)
    →只杀本进程(不带 /t,助手是它的孩子不受牵连)→按原命令原目录重新拉起。
    窗口壳(网页)一直在:前端轮询到「新后端带上了新版本号」自己刷新。失败如实返回 (False, 原因),绝不假成功。
    ROOT 就是工作台目录,日志也沿用壳用的 启动日志.txt。"""
    import subprocess as _sp
    try:
        助手 = ("import time,sys,json,subprocess,os\n"
                "pid=int(sys.argv[1]);命令=json.loads(sys.argv[2]);目录=sys.argv[3];日志=sys.argv[4]\n"
                "time.sleep(2.0)\n"
                "subprocess.call(['taskkill','/f','/pid',str(pid)],creationflags=0x08000000)\n"
                "time.sleep(1.5)\n"
                "句=open(日志,'ab')\n"
                "subprocess.Popen(命令,cwd=目录,stdout=句,stderr=subprocess.STDOUT,creationflags=0x00000008|0x00000200)\n")
        命令 = 重启自身命令()
        脚本 = Path(str(命令[2]))
        if not 脚本.is_absolute():
            命令[2] = str((ROOT / 命令[2]).resolve())
        目录 = str(Path(命令[2]).parent)
        参数 = [sys.executable, "-c", 助手, str(os.getpid()),
                json.dumps(命令, ensure_ascii=False), 目录, str(ROOT / "启动日志.txt")]
        _sp.Popen(参数, creationflags=0x08000000)
        return True, ""
    except Exception as e:
        print("[自动重启拉起失败] %r" % e)
        return False, repr(e)[:120]

def backend_stale():
    """workbench.py 比本进程启动时间还新 = 代码改了但没重启,界面是新的、后端行为还是旧的。
    这种情况必须明说,否则人会以为改动被撤销了。"""
    try:
        return (ROOT / "workbench.py").stat().st_mtime > 启动时刻 + 1
    except Exception as e:
        print("[版本检查失败] %s" % e)
        return False


def meta_of(proj):
    f = Path(proj) / "项目.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None

def job_key(proj): return str(Path(proj))

def slog(动作, 项目="", 详情=""):
    """运行日志:一行一条 JSON,是反馈单/售后判定的底料。写不进必须喊出来,不许静默。"""
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": time.strftime("%Y-%m-%d %H:%M:%S"), "动作": 动作,
                                "项目": Path(项目).name if 项目 else "",
                                "详情": str(详情)[:300]}, ensure_ascii=False) + "\n")
        if LOGF.exists() and LOGF.stat().st_size > 2097152:      # 超 2MB 留最近一半
            keep = LOGF.read_text(encoding="utf-8").splitlines()[-3000:]
            LOGF.write_text("\n".join(keep) + "\n", encoding="utf-8")
    except Exception as e:
        print("[运行日志写不进] %r" % (e,), flush=True)

def server_running():
    """有没有别的活工作台在跑(按页面签名认,不认"端口有响应"——别的程序占了 9527 不算)。"""
    for p in range(9527, 9537):
        try:
            raw = urllib.request.urlopen("http://127.0.0.1:%d/" % p, timeout=0.5).read(2000)
            if "口播剪辑工作台".encode("utf-8") in raw: return True
        except Exception:
            continue
    return False


def reap_interrupted():
    """启动收尸:只在确认没有别的工作台实例活着时才动手(活实例的任务记录归它,杀=误伤,删=丢账)。
    记录怎么坏都不许把启动卡死:pid 解析失败就跳过杀进程,中断照常上报。"""
    global INTERRUPTED
    if not STATEF.exists(): return []
    if server_running():
        print("[收尸跳过] 另一个工作台实例在跑,任务记录归它管", flush=True)
        return []
    st = {}
    try:
        st = json.loads(STATEF.read_text(encoding="utf-8"))
    except Exception as e:
        print("[任务状态文件读不了,按中断处理] %r" % (e,), flush=True)
    STATEF.unlink(missing_ok=True)
    pid = 0
    try:
        pid = int(st.get("pid") or 0)
    except Exception as e:
        print("[状态里 pid 字段非法,不杀任何进程] %r" % (e,), flush=True)
    proj = str(st.get("项目", "") or "未知项目")
    nm = str(st.get("名", ""))
    if pid and nm:
        row = ""
        try:
            r = subprocess.run(["tasklist", "/FI", "PID eq %d" % pid, "/NH"], capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=10)
            row = r.stdout or ""
        except Exception as e:
            print("[进程探测失败] %r" % (e,), flush=True)
        if nm.split(".")[0].lower() in row.lower():
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=15)
                slog("收尸", proj, "杀掉上次遗留进程 %s(%s)" % (pid, nm))
            except Exception as e:
                slog("收尸失败", proj, repr(e))
        else:
            slog("启动", proj, "记录里的进程 %s 不在或名字对不上,不杀" % pid)
    INTERRUPTED.append(Path(proj).name + "(" + str(st.get("步", "")) + ")")
    slog("启动", proj, "发现上次中断任务")
    print("[启动提醒] 上次任务被中断: " + "、".join(INTERRUPTED), flush=True)
    return INTERRUPTED


# 任务日志落盘(2026-11-20 补的洞):以前日志只在内存,任务失败后一关窗口,
# 失败原因就永久没了——售后只能靠 运行日志.jsonl 的入队/结束时间戳倒推。
LOGDIR = ROOT / "任务日志"


def _脱密(行):
    """日志从内存挪到磁盘,先抹掉疑似密钥:以后谁加云端参数顺手把码 print 出来,不至于留在文件里。"""
    s2 = str(行)
    s2 = re.sub(r"(?i)(api[_-]?key|access[_-]?key|secret|token|sk|pk)([_\s-]*[=:]\s*)\S{4,}",
                lambda m: m.group(1) + m.group(2) + "***", s2)
    s2 = re.sub(r"sk-[A-Za-z0-9_\-]{6,}", "sk-***", s2)
    return s2


def _joblog_of(k):
    名 = re.sub(r"[^\w\u4e00-\u9fa5.\-]", "_", Path(str(k)).name) or "项目"
    return LOGDIR / (名 + ".log")


def _logd(k, line):
    """追加一行到本项目的任务日志。写不进必须喊出来(静默降级是最贵的 bug)。"""
    try:
        LOGDIR.mkdir(exist_ok=True)
        f = _joblog_of(k)
        if f.exists() and f.stat().st_size > 400000:          # 超 400KB 只留最近 1500 行
            尾 = f.read_text(encoding="utf-8", errors="replace").splitlines()[-1500:]
            f.write_text("\n".join(尾) + "\n", encoding="utf-8")
        with open(f, "a", encoding="utf-8") as fh:
            fh.write(_脱密(line) + "\n")
        return True
    except Exception as e:
        print("[任务日志写不进] %s: %r" % (k, e), flush=True)
        try:
            slog("任务日志写不进", str(k), repr(e))
        except Exception as e2:
            print("[任务日志的失败也记不上] %r" % e2, flush=True)
        return False


def _log(k, line):
    with _LOCK:
        j = JOBS.get(k)
        if not j: return
        j["log"].append(line)
        if len(j["log"]) > 300: j["log"] = j["log"][-300:]
    _logd(k, line)                                            # 内存留一份,磁盘再留一份

def _worker():
    while True:
        job = None
        with _LOCK:                      # 只在真的取任务时持锁,空闲时绝不霸锁
            if _QUEUE: job = _QUEUE.pop(0)
        if job is None:
            time.sleep(0.35); continue
        k = job["key"]
        with _LOCK:
            j = JOBS.get(k)
            if not j: continue
            if j.get("cancel"): j["status"] = "已取消"; continue
            j["status"] = "运行中"; j["started"] = time.time()
        ok = True
        for cmd in job["cmds"]:
            with _LOCK:
                if JOBS[k].get("cancel"): ok = False
            if not ok: break
            _log(k, "$ " + " ".join(str(c) for c in cmd))
            try:
                pr = subprocess.Popen([str(c) for c in cmd], stdout=subprocess.PIPE,
                                      stderr=subprocess.STDOUT, text=True,
                                      encoding="utf-8", errors="replace")
                with _LOCK: JOBS[k]["proc"] = pr
                try:
                    STATEF.write_text(json.dumps({"pid": pr.pid, "项目": k, "步": job.get("label", ""),
                                                  "名": Path(str(cmd[0])).name}, ensure_ascii=False),
                                      encoding="utf-8")
                except Exception as e: _log(k, "[任务状态写不进] " + repr(e))
                slog("任务开始", k, job.get("label", ""))
                try:
                    # 2026-10-19 改流式逐行读:旧写法 communicate 要等引擎整个跑完才一次性吐,
                    # 粗剪 1~5 分钟里日志框全空,人以为点了没反应。现在引擎印一行,日志框进一行。
                    for ln in (pr.stdout or []):
                        _log(k, ln.rstrip("\n"))
                    pr.wait(timeout=job.get("timeout", 3600))
                except subprocess.TimeoutExpired:
                    pr.kill()
                    try: pr.wait(timeout=10)
                    except Exception: pass
                    _log(k, "[超时中止] 单步超过 %d 秒,已杀掉进程" % job.get("timeout", 3600))
                    ok = False
                if pr.returncode != 0 and ok: ok = False
            except Exception as e:
                _log(k, "[异常] " + str(e)); ok = False
            finally:
                with _LOCK: JOBS[k]["proc"] = None
                try: STATEF.unlink(missing_ok=True)
                except Exception as e: _log(k, "[任务状态清不掉] " + repr(e))
            if not ok: break
        with _LOCK:
            j = JOBS.get(k) or {}
            j["ended"] = time.time()
            if j.get("cancel"): j["status"] = "已取消"
            else: j["status"] = "完成" if ok else "失败"
        slog("任务结束", k, j.get("status", ""))
        _用 = round(time.time() - (j.get("started") or time.time()), 1)
        _logd(k, "[%s] ==== 结束:%s | 用时 %s 秒 ====" % (time.strftime("%H:%M:%S"), j.get("status", ""), _用))
        if ok and job.get("on_done"):
            try: job["on_done"]()
            except Exception as e: _log(k, "[收尾异常] " + str(e))

def _ensure_worker():
    with _LOCK:
        if _WORKER[0] and _WORKER[0].is_alive(): return
        _WORKER[0] = threading.Thread(target=_worker, daemon=True)
        _WORKER[0].start()

def start_job(proj, cmds, label="", on_done=None, timeout=3600):
    """cmds: 一条命令,或按顺序跑的命令列表。排队串行跑,不再互相抢 CPU。"""
    if cmds and isinstance(cmds[0], (str, Path)): cmds = [cmds]
    k = job_key(proj)
    with _LOCK:
        cur = JOBS.get(k)
        if cur and cur.get("status") in ("排队中", "运行中"):
            return {"error": "这个项目已有任务在跑(等它完成或点「停止任务」)"}
        JOBS[k] = {"status": "排队中", "log": [], "label": label, "cancel": False,
                   "proc": None, "started": 0}
        _QUEUE.append({"key": k, "cmds": cmds, "on_done": on_done, "timeout": timeout})
        pos = len(_QUEUE)
    _logd(k, "\n[%s] ==== 新任务 | %s | 步骤:%s ====" % (
        time.strftime("%Y-%m-%d %H:%M:%S"), Path(k).name, label or "任务"))   # 先写头再起线程,防 "$ 命令" 抢行
    _ensure_worker()
    slog("入队", k, label)
    if pos > 1: _log(k, "[排队] 前面还有 %d 个任务" % (pos - 1))
    return {"ok": True, "排队位": pos}

def job_view(proj):
    k = job_key(proj)
    with _LOCK:
        j = JOBS.get(k)
        if j:
            return {"status": j["status"], "label": j.get("label", ""), "log": list(j["log"][-60:]),
                    "已用秒": round(time.time() - j["started"], 1) if j.get("started") else 0,
                    "排队在前": max(0, len(_QUEUE) - (0 if j["status"] != "排队中" else 1)),
                    "日志来源": "实时"}
    # 内存里没这个项目的任务(刚重启过/从没点过):回读本机磁盘留存的最近一段
    f = _joblog_of(k)
    if f.exists():
        try:
            尾 = f.read_text(encoding="utf-8", errors="replace").splitlines()[-60:]
        except Exception as e:
            print("[任务日志读不出] %s: %r" % (f, e), flush=True)
            尾 = ["[任务日志读不出] " + repr(e) + " ——" + str(f)]
        return {"status": "空闲", "log": 尾, "已用秒": 0, "排队在前": 0,
                "日志来源": "本机磁盘:工作台/任务日志/" + f.name + "(重启不丢)"}
    return {"status": "空闲", "log": []}

def queue_view():
    with _LOCK:
        run = [{"项目": Path(k).name, "状态": v["status"], "步": v.get("label", "")}
               for k, v in JOBS.items() if v.get("status") in ("运行中", "排队中")]
        run.sort(key=lambda x: x["状态"] != "运行中")
        return {"在跑/排队": run, "队列长度": len(_QUEUE), "版本": VERSION,
                "待重启": backend_stale(), "上次中断": list(INTERRUPTED)}

def cancel_job(proj):
    k = job_key(proj)
    with _LOCK:
        j = JOBS.get(k)
        if not j or j["status"] not in ("排队中", "运行中"): return {"error": "该项目没有进行中的任务"}
        j["cancel"] = True; pr = j.get("proc")
    if pr:
        try: pr.kill()
        except Exception: pass
    _log(k, "[已请求停止] 正在终止当前进程")
    slog("取消", k, "用户点了停止")
    return {"ok": True}

CFG_PATH = ROOT / "工作台设置.json"
CFG_DEFAULT = {"自动转写": True, "自动算秒": True, "豆包理解": False}
ARK_文本 = ("豆包密钥", "豆包模型", "豆包地址")

def settings(带密钥=False):
    """读工作台全局开关;文件坏了不拦路,回默认值并把原因打出来(不许静默)。
    豆包密钥默认不回显:调用方(包括反馈单/诊断/页面)只拿得到「已填(尾4位)」,
    真值只有 ark_请求/sb_ai_draft 自己取——密钥不进日志、不进反馈单。"""
    out = dict(CFG_DEFAULT)
    out["豆包地址"] = ARK_默认地址
    out["豆包密钥"] = ""
    out["豆包模型"] = ""
    d = {}
    if CFG_PATH.exists():
        try:
            d = json.loads(CFG_PATH.read_text(encoding="utf-8"))
            if not isinstance(d, dict): raise ValueError("内容不是对象")
        except Exception as e:
            print("[设置读不了] %s: %s —— 本次按默认值跑" % (CFG_PATH, e))
            d = {}
        for k in CFG_DEFAULT:
            if k in d: out[k] = bool(d[k])
        for k in ARK_文本:
            v = str(d.get(k) or "").strip()
            if v: out[k] = v
    密 = out.get("豆包密钥") or ""
    if 密 and not 带密钥:
        out["豆包密钥已填"] = "已填(尾 %s)" % 密[-4:]
        out["豆包密钥"] = ""
    elif 密:
        out["豆包密钥已填"] = "已填(尾 %s)" % 密[-4:]
    return out
def save_settings(body):
    """写 工作台设置.json。开关按 bool 存;文本项只在"这次给了非空值"时才覆盖
    (密钥框留空=不改,免得用户点个别的开关就把密钥清了)。返回值一律脱敏。"""
    cur = settings(带密钥=True)
    for k in CFG_DEFAULT:
        if k in body: cur[k] = bool(body[k])
    for k in ("豆包模型", "豆包地址"):
        if k in body:
            v = str(body[k] or "").strip()
            cur[k] = v or (ARK_默认地址 if k == "豆包地址" else "")
    if str(body.get("豆包密钥") or "").strip():
        cur["豆包密钥"] = str(body["豆包密钥"]).strip()
    try:
        CFG_PATH.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        print("[设置存不下] %s: %s" % (CFG_PATH, e))
        return {"error": "设置存不进 工作台设置.json(权限或磁盘?):%s" % e}
    回 = dict(cur)
    密 = 回.pop("豆包密钥", "")
    回["豆包密钥已填"] = ("已填(尾 %s)" % 密[-4:]) if 密 else ""
    return 回
def need_transcribe(proj):
    """该不该自动转写:没转写过 + 这项目没任务在跑 + 素材路径还在。返回 (该不该, 原因)。"""
    proj = Path(proj)
    if not (proj / "项目.json").exists(): return False, "不是项目目录"
    if (proj / "转写.json").exists(): return False, "已经转写过"
    if job_view(proj).get("status") in ("排队中", "运行中"): return False, "该项目已有任务在跑"
    if not (meta_of(proj) or {}).get("media"): return False, "项目里没记素材路径"
    if not Path(meta_of(proj)["media"]).exists(): return False, "素材文件不在原位置"
    return True, ""

def adopt_media(proj):
    """收编素材:把项目引用的外部原片复制进项目\素材,并把 项目.json 改指副本。
    原文件保留不动,项目从此自带素材;之后删原片也不断线。"""
    d = Path(proj)
    meta = meta_of(d)
    if not meta: return {"error": "当前项目目录无效,先在顶栏重选一个项目"}
    if not meta.get("media"): return {"error": "还没绑素材,谈不上收编:先在① 粘贴视频绝对路径"}
    src = Path(meta["media"])
    if not src.exists():
        return {"error": "素材已经断线了(原位置找不到): %s。先回原文件夹核对名字/位置,重新绑一次再收编" % src}
    if d.resolve() in src.resolve().parents:
        return {"ok": True, "skipped": "素材本来就在项目文件夹里,不用收编"}
    dest = d / "素材" / src.name; i = 2
    while dest.exists():
        dest = d / "素材" / ("%s-%d%s" % (src.stem, i, src.suffix)); i += 1
    dest.parent.mkdir(exist_ok=True)
    try:
        shutil.copy2(src, dest)
    except Exception as e:
        print("[收编素材] 复制失败: %r" % (e,), flush=True)
        dest.unlink(missing_ok=True)
        return {"error": "复制失败(是不是磁盘空间不够?): %s" % e}
    meta["media"] = str(dest.resolve())
    (d / "项目.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "new": str(dest), "old": str(src), "复制MB": round(dest.stat().st_size / 1048576.0, 1)}

def bind_copied_media(proj, dest):
    """主素材拖入/上传的副本已落进项目「素材」文件夹后换绑:验项目+验副本+验是视频,写 项目.json。
    原文件本来就不动(浏览器只能传内容,传不了原位置)。"""
    d = Path(proj); m = Path(dest)
    meta = meta_of(d)
    if not meta: return {"error": "当前项目目录无效,先在顶栏重选一个项目"}
    if not m.exists(): return {"error": "副本没落盘: %s" % m}
    if m.suffix.lower() not in VIDEO_EXT:
        return {"error": "主素材只收视频(mp4/mov/m4v/avi/mkv/webm),这个不是: %s" % m.name}
    meta["media"] = str(m.resolve())
    (d / "项目.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "new": str(m), "复制MB": round(m.stat().st_size / 1048576.0, 1)}

def media_check():
    """素材体检:扫全部项目,报告每个项目的素材在原位/断线/未绑。只读,不动任何文件。"""
    rows = []
    if PROJ_ROOT.exists():
        for d in sorted(PROJ_ROOT.iterdir()):
            m = meta_of(d)
            if not m: continue
            media = m.get("media") or ""
            if not media: rows.append({"项目": d.name, "状态": "未绑素材", "路径": ""})
            elif Path(media).exists(): rows.append({"项目": d.name, "状态": "正常", "路径": media})
            else: rows.append({"项目": d.name, "状态": "断线", "路径": media})
    return {"rows": rows, "断线数": sum(1 for r in rows if r["状态"] == "断线")}

def run_doctor():
    """顶栏「🧯 诊断」后端:跑 scripts/doctor.py 检查,返回 JSON 给页面。
    诊断自己炸了也要把原因带回去,不许静默(AGENTS.md 铁律)。"""
    if str(SCRIPTS) not in sys.path: sys.path.insert(0, str(SCRIPTS))
    try:
        import doctor
        return doctor.report_json()
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": "诊断跑不起来: %r(更多在启动工作台的黑窗口里)" % e}

def relink_media(dir_, media):
    """重新连线:素材被挪/改名后,把项目里的路径纸条改成新位置。验存在+验视频+写回,复用绑定逻辑,0 复制。"""
    d = Path(dir_); old = (meta_of(d) or {}).get("media", "")
    r = bind_media(dir_, media)
    if not r.get("error"):
        r["relink"] = True; r["old"] = old; r["项目"] = d.name
        r["new"] = (meta_of(d) or {}).get("media", "")
    return r

def create_blank_project():
    """「＋新建项目」一键版:建 口播N 空项目(自动排号)并打开,不复制任何文件。
    空项目没绑素材,转写/剪辑会明确提示先绑,不会跑到一半崩。"""
    i = 1
    while (PROJ_ROOT / ("口播%d" % i)).exists(): i += 1
    d = PROJ_ROOT / ("口播%d" % i); d.mkdir()
    (d / "项目.json").write_text(json.dumps({"media": "", "name": d.name},
                                            ensure_ascii=False, indent=1), encoding="utf-8")
    return {"dir": str(d)}

SAMPLE_HINT = "样例项目:12 秒样片+自带转写(不占你的素材)。依次点 ③-A 找剪切点 → ③-B 审清单 → ③-D 执行粗剪,就能看全流程;玩完删掉这个项目即可"

def action_sample(proj=None, body=None):
    """载入样例项目(B2):复制 工作台\\Getting_Started\\sample 的样片和转写,建「样例演示」项目。
    缺文件必须报原因,不许静默。"""
    src = ROOT / "Getting_Started" / "sample"
    m, t = src / "样片.mp4", src / "转写.json"
    缺 = [x.name for x in (m, t) if not x.exists()]
    if 缺:
        return {"error": "缺样例文件:" + "、".join(缺) + "(应在 工作台\\Getting_Started\\sample);运行 python scripts\\export_trial.py 可再生"}
    nm = "样例演示"; d = PROJ_ROOT / nm; i = 2
    while d.exists(): d = PROJ_ROOT / ("%s-%d" % (nm, i)); i += 1
    d.mkdir(parents=True)
    shutil.copy2(m, d / "样片.mp4"); shutil.copy2(t, d / "转写.json")
    # 样例转写里 file 字段带着打包机的绝对路径,客户机照着找会撞"G1实炸:找不到素材"→改写指向项目内样片
    try:
        tj = json.loads((d / "转写.json").read_text(encoding="utf-8"))
        tj["file"] = str(d / "样片.mp4")
        (d / "转写.json").write_text(json.dumps(tj, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        return {"error": "样例转写路径改写失败:" + repr(e)[:100]}
    (d / "项目.json").write_text(json.dumps({"media": str(d / "样片.mp4"), "name": d.name},
                                            ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "dir": str(d), "提示": SAMPLE_HINT}

_INVIS = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\ufeff\t\r\n"))
_QUOTES = "\"\'“”‘’"

def clean_media_path(raw):
    """把粘进来的路径携带的"必是垃圾"洗掉:外层引号(Win11「复制文件地址」自带)、零宽/方向等不可见字符、
    file:// 前缀、首尾空格与结尾点号。只清洗,不猜用户心思;Windows 文件名本就不允许引号,剥了不会误伤。"""
    s = str(raw or "").strip().translate(_INVIS)
    if s[:8].lower() == "file:///": s = unquote(s[8:])
    elif s[:7].lower() == "file://": s = unquote(s[7:])
    s = s.strip().strip(_QUOTES + " ")
    if len(s) >= 3 and s[0] in "\\/" and s[2] == ":": s = s[1:]
    s = s.replace("/", "\\")
    if len(s) > 2: s = s.rstrip(" .")
    return s.strip()

def resolve_media_input(media, where=""):
    """粘贴素材路径的统一入口:先洗垃圾;允许粘文件夹(里面恰好 1 个视频自动认);
    找不到就指明断在哪一级。返回 (Path, 错误信息),错误信息为空表示可用。"""
    raw = str(media or "").strip()
    s = clean_media_path(raw)
    if s and s != raw:
        slog("路径清洗", where, "%r -> %r" % (raw, s))
    if not s:
        return None, "先粘贴视频绝对路径,如 E:\\视频\\口播1.mp4(也可以直接粘贴它所在的文件夹)"
    m = Path(s)
    if m.is_dir():
        vids = sorted(f for f in m.iterdir() if f.suffix.lower() in VIDEO_EXT and f.is_file())
        if len(vids) == 1:
            m = vids[0]
            slog("文件夹自动认片", where, m.name)
        elif len(vids) > 1:
            return None, "你粘的是文件夹,里面有 %d 个视频,请把要用的那条完整路径粘上:%s" % (
                len(vids), "、".join(v.name for v in vids[:5]))
        else:
            return None, "这个文件夹里没有视频(只收 mp4/mov/m4v/avi/mkv/webm): %s" % s
    if not m.exists():
        duankai = "连盘符/根目录都到不了,先检查盘符对不对、U盘/移动硬盘有没有拔走"
        pa = m
        while pa.parent != pa:
            pa = pa.parent
            if pa.exists():
                duankai = "「%s」是有的,但它里面找不到「%s」" % (pa, m.relative_to(pa))
                break
        slog("素材不存在", where, "原始粘贴: %r" % raw)
        return None, "素材文件不存在: %s(断点: %s)" % (m, duankai)
    return m, ""

def bind_media(dir_, media):
    """把粘贴的视频路径绑进当前空项目:自动剥引号/隐形字符、允许直接粘它所在文件夹、
    验是视频,更新 项目.json。成功返回 {"dir":...}。"""
    d = Path(dir_)
    if not (d / "项目.json").exists(): return {"error": "当前项目目录无效,先在下拉里重选一个"}
    m, err = resolve_media_input(media, d.name)
    if err: return {"error": err}
    if m.suffix.lower() not in VIDEO_EXT:
        return {"error": "那不是视频文件,只收 mp4/mov/m4v/avi/mkv/webm: %s" % m.name}
    meta = meta_of(d) or {"name": d.name}
    meta["media"] = str(m.resolve())
    (d / "项目.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"dir": str(d)}
def create_project(media, name="", body=None):
    """建项目;开关开着就顺手把转写排进队列(固定 small,不会偷偷联网下模型)。"""
    body = body or {}
    if body.get("dir"):
        bind = bind_media(body["dir"], media)
        if bind.get("error"): return {"error": bind["error"]}
        d = Path(bind["dir"]); out = {"dir": str(d), "绑定": True}
    else:
        d, err = make_project(media, name)
        if not d: return {"error": err}
        out = {"dir": str(d)}
    if body.get("no_auto"):
        out["自动转写"] = {"skipped": "自检调用,不真跑转写"}
        return out
    if not settings().get("自动转写", True):
        out["自动转写"] = {"skipped": "「建项目自动转写」开关是关的(① 素材卡片可打开)"}
        return out
    ok, why = need_transcribe(d)
    if not ok:
        out["自动转写"] = {"skipped": why or "不需要"}
        return out
    out["自动转写"] = action_transcribe(d, {"model": "small"})
    return out

_T2S = None
def _norm_cn(x):
    """去标点空格+小写+繁转简:对词匹配的统一口径(和 ⚓ 的简繁归一同一方向)。"""
    global _T2S
    v = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]", "", str(x or "")).lower()
    if _T2S is None:
        try:
            from opencc import OpenCC
            _T2S = OpenCC("t2s")
        except Exception as e:
            print("[简繁归一不可用,只能同体对词] %s" % e)
            _T2S = False
    if _T2S:
        try:
            v = _T2S.convert(v)
        except Exception as e:
            print("[繁转简失败,降级同体匹配] %s" % e)
            _T2S = False
    return v

def _词窗(wd):
    """长词整体对不上就剥尾巴/掐头再试:安心结果砸→安心的结果。最多4个窗,宁短不歪。"""
    ws = [wd]
    if len(wd) > 4:
        for cut in (1, 2):
            if len(wd) - cut >= 4: ws.append(wd[:-cut])
        ws.append(wd[:4])
    seen, out = set(), []
    for w in ws:
        if w and w not in seen: seen.add(w); out.append(w)
    return out


def _ideas_lines(proj):
    f = Path(proj) / "包装想法.txt"
    if not f.exists(): return []
    return [x.strip() for x in f.read_text(encoding="utf-8-sig").splitlines() if x.strip()]

def ideas_save(proj, text):
    """①-B 包装想法箱:人话原样存,永不自动加工——加工发生在对镜头和交接两处。"""
    text = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
    (Path(proj) / "包装想法.txt").write_text(text, encoding="utf-8")
    return {"ok": True}

def ideas_map(proj, body):
    """想法箱逐行对分镜:剥动作词/类型词/动效词拿内容词去转写打分对句(反序、数字两种写法也算),
    再用源起定位落在第几镜。对不上的不硬编:明说试过哪些词,语义活交给对话 AI。"""
    proj = Path(proj)
    ls = _ideas_lines(proj)
    if not ls: return {"error": "想法箱是空的:先在①-B 下方「包装想法」写两句"}
    tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成第②步转写,想法才能对上句"}
    segs = (json.loads(tj.read_text(encoding="utf-8")) or {}).get("segments") or []
    if not segs: return {"error": "转写 0 段,对不了:回②检查音频"}
    shots = []
    tlf = proj / "分镜时间轴.json"
    if tlf.exists():
        try:
            shots = [r for r in (json.loads(tlf.read_text(encoding="utf-8-sig")).get("镜") or []) if "成片起" in r]
        except Exception as e:
            print("[时间轴读不了] %s: %s" % (proj, e))
    norm = _norm_cn
    def shot_of(t):
        best = None
        for r in sorted(shots, key=lambda x: float(x.get("源起") or x.get("成片起") or 0)):
            s0 = r.get("源起")
            s0 = float(s0) if s0 is not None else float(r.get("成片起", 0))
            if t >= s0 - 0.2: best = r
        return best
    out = []
    for line in ls:
        wd, sg, tried, tie = _sb_find_seg(line, segs, norm)
        if sg is None:
            out.append({"想法": line, "落在": "没对上(试过:%s)——语义活交给AI,或把原话加「」" % "、".join(tried)})
            continue
        t = float(sg.get("start", 0))
        r = shot_of(t)
        if r:
            out.append({"想法": line, "落在": "镜%s(对词「%s」)%s" % (r.get("镜号"), wd, ("注意:" + tie) if tie else "")})
        else:
            out.append({"想法": line, "落在": "对上句 %.1fs,但不在任何镜里——分镜表还没盖住这句" % t})
    return {"结果": out, "条数": len(out)}


# ---- ①-B「讲述转分镜」的三张词表:加说法只改这里(备注原因、界面提示都从这几张表派生) ----
_SB_ACTION = (r"然后|接着|这时|那会|开场|开头|结尾|插入|这[个段句些]|那[个段句些]|整[个段句]|"
              r"时[候句]|一句|一段|做|来|上|放|加|换|里|边|点|口播|话|效果|动效|特效|转场|就|是|在|要|会|能|把|拿|给|用|再|个")
_SB_ZONE = [("口播正面", ("口播", "坐讲", "真人", "对镜", "自己讲", "露脸", "出镜")),
            ("空镜", ("空镜", "外景", "风景", "空画面", "b-roll", "broll")),
            ("录屏", ("录屏", "屏幕", "软件操作", "演示", "界面")),
            ("图形卡", ("图形卡", "图示", "图标", "流程图", "对比图", "结构图", "信息图", "图表", "图形", "对比", "流程")),
            ("大字卡", ("大字卡", "金句", "满屏字", "大字幕", "标题字", "大字", "卡片", "字卡"))]
_SB_FX = [("转场:故障", ("故障", "vhs", "老电视", "信号不好", "信号断", "雪花", "色差", "扫描线")),
          ("转场:叠化", ("叠化", "溶解", "淡入", "淡出")),
          ("转场:闪白", ("闪白", "白闪")),
          ("转场:闪黑", ("闪黑", "黑场")),
          ("转场:模糊", ("模糊", "虚化")),
          ("转场:抖动", ("抖动", "震动", "晃一下", "抖一下")),
          ("推镜", ("推镜", "推近", "推镜头", "拉近", "放大", "punch")),
          ("定格", ("定格", "freeze")),
          ("变速", ("快进", "慢动作", "升格", "抽帧", "加速")),
          ("数字滚动", ("数字滚动", "滚动数字", "跳数", "计数"))]


def _sb_zone(line):
    """画面五类说法。先认「录屏:xxx」这种带冒号的写法(表里的标准口径);
    没带冒号就取最先说到的那个——素材名里正好含「空镜」「大字」这类词,不能把真意图抢走。"""
    low = str(line).lower()
    候选 = []
    for z, ws in _SB_ZONE:
        for k in ws:
            kk = k.lower()
            i = low.find(kk)
            while i >= 0:
                后 = low[i + len(kk):i + len(kk) + 1]
                权 = 2 if 后 in (":", "：") else 1
                候选.append((权, -i, len(kk), z))
                i = low.find(kk, i + 1)
    if not 候选:
        return "", False
    return max(候选)[3], True


def _sb_fx(line):
    """故障/叠化这类效果说法 → 动效包装列的协议词(剪映侧认 转场:名字,认不出的列进待补,不会静默丢)。"""
    low = str(line).lower()
    got = [name for name, ws in _SB_FX if any(w.lower() in low for w in ws)]
    return "|".join(got)


_SB_STRIP = None
def _sb_clean(line):
    """剥掉动作词+画面类型词+动效词,只留能拿去转写里对句的内容词。"""
    global _SB_STRIP
    if _SB_STRIP is None:
        ks = [re.escape(k) for _z, ws in _SB_ZONE for k in ws]
        ks += [re.escape(k) for _f, ws in _SB_FX for k in ws]
        ks.sort(key=len, reverse=True)
        _SB_STRIP = "(" + _SB_ACTION + "|" + "|".join(ks) + ")"
    return re.sub(_SB_STRIP, " ", str(line or ""))


def _sb_shot_lines(text):
    """换行/句号/分号必断(老规矩);逗号顿号只在两边都像独立镜头时才断——
    「初步水平用大字卡，1100做成图形卡，距离做故障效果」一口气写的也算三镜。"""
    out = []
    for raw in re.split(r"[\n。;；]+", str(text or "")):
        ln = raw.strip()
        if not ln:
            continue
        parts = re.split(r"[，,、]+|\s{2,}", ln)
        parts = [p.strip() for p in parts if p and p.strip()]
        if len(parts) > 1:
            ok = sum(1 for p in parts if _sb_looks_shot(p))
            if ok >= 2 and ok == len(parts):
                out += parts
                continue
        out.append(ln)
    return out


def _sb_looks_shot(p):
    """像一镜吗:说了画面类型 / 效果 / 带「」 / 带秒数或分秒。"""
    _z, zh = _sb_zone(p)
    return bool(zh or _sb_fx(p)
                or re.search(r'[\u300c\u300a\u201c"][^\u300d\u300b\u201d\"]{2,12}[\u300d\u300b\u201d\"]', p)
                or re.search(r"\d{1,2}[:：]\d{2}|\d+(?:\.\d+)?\s*(?:[sS]|秒)", p))


_CN0 = "零一二三四五六七八九"


def _cn_read(n):
    """1105 → 一千一百零五(只管到 99999,口播数字够用)。"""
    d = _CN0
    if n < 10:
        return d[n]
    if n < 100:
        t, o = divmod(n, 10)
        return ("十" if t == 1 else d[t] + "十") + (d[o] if o else "")
    if n < 1000:
        h, r = divmod(n, 100)
        return d[h] + "百" + ("" if not r else ("零" if r < 10 else "") + _cn_read(r))
    if n < 10000:
        q, r = divmod(n, 1000)
        return d[q] + "千" + ("" if not r else ("零" if r < 100 else "") + _cn_read(r))
    w, r = divmod(n, 10000)
    return d[w] + "万" + ("" if not r else ("零" if r < 1000 else "") + _cn_read(r))


def _cn_forms(t):
    """阿拉伯数字的汉字读法候选:1100 → 一千一百 + 一千一(口播常说省略式)。"""
    try:
        n = int(t)
    except Exception:
        return []
    if not 0 <= n <= 99999:
        return []
    out = {t}
    full = _cn_read(n)
    out.add(full)
    if n >= 100 and n % 100 == 0 and len(full) > 2:
        out.add(full[:-1])
    return [x for x in sorted(out) if len(x) >= 2]


def _cn_to_num(cn):
    """反向:人写「一千一」而转写成 1100 也能对上。认不出返回 None。"""
    vals = {c: i for i, c in enumerate(_CN0)}
    vals["两"] = 2
    units = {"十": 10, "百": 100, "千": 1000, "万": 10000}
    total, cur, last_u, seen = 0, 0, 1, False
    for ch in str(cn):
        if ch in vals:
            cur, seen = vals[ch], True
        elif ch in units:
            u = units[ch]
            if u == 10000:
                total = (total + (cur or 1)) * 10000
            else:
                total += (cur or 1) * u
            cur, last_u, seen = 0, u, True
        else:
            return None
    if not seen:
        return None
    if cur:
        total += cur * (last_u // 10 if last_u >= 100 else 10 if last_u == 10 else 1)
    return total


def _sb_grams(tok):
    """一个内容词 → 拿去对转写的候选串:原词 + 二~四字窗 + 数字的两种写法。
    拆窗是因为口播里词的顺序和写法都不一定跟你打的样:「初步水平」能对上「水平其实很初步」。"""
    t = str(tok).strip()
    out = [t]
    if re.fullmatch(r"[0-9]{2,6}", t):
        out += _cn_forms(t)
    elif re.fullmatch(r"[零一二三四五六七八九十百千万两]{2,6}", t):
        v = _cn_to_num(t)
        if v is not None:
            out.append(str(v))
    if re.fullmatch(r"[\u4e00-\u9fff]{3,8}", t):
        for n in (4, 3, 2):
            if len(t) >= n:
                out += [t[i:i + n] for i in range(len(t) - n + 1)]
    seen, res = set(), []
    for x in out:
        if x and x not in seen:
            seen.add(x); res.append(x)
    return res


def _sb_find_seg(line, segs, norm):
    """拿行里的内容词去给每段打分(命中串越长分越高),唯一最高才算对上,并列取最早那处并明说。
    对不上就返回空——绝不拿不相干的句子凑数。返回 (锚点词, 段, 试过的词, 说明)。"""
    pat = r"[0-9]{2,}|[A-Za-z]{2,}|[\u4e00-\u9fff]{2,8}"
    clean = re.findall(pat, _sb_clean(line))
    raw = re.findall(pat, re.sub(r'[\u300c\u300d\u300a\u300b\u201c\u201d"]', " ", str(line)))
    toks, seen = [], set()
    for w in clean + raw:
        if w not in seen:
            seen.add(w); toks.append(w)
    tried = (clean or raw)[:4]
    gramset, back, gs = [], {}, set()
    for t in toks:
        for g in _sb_grams(t):
            ng = norm(g)
            if ng and ng not in gs:
                gs.add(ng); gramset.append(ng); back[ng] = g
    if not gramset:
        return "", None, tried, ""
    best = []
    for sg in segs:
        nt = norm(sg.get("text"))
        hits = [x for x in gramset if x in nt]
        if not hits:
            continue
        longest = max(hits, key=len)
        best.append((sum(len(x) for x in hits), back[longest], sg))
    if not best:
        return "", None, tried, ""
    top = max(x[0] for x in best)
    ties = [x for x in best if x[0] == top]
    if len(ties) > 1:
        return ties[0][1], ties[0][2], tried, "「%s」这类词在转写里有%d处,先取最早那处;不对就照原话说更长一段或用「」框出来" % (ties[0][1], len(ties))
    return best[0][1], best[0][2], tried, ""


# ---- ①-B「用AI理解我说的话」:可选的云端理解层,任意 OpenAI 兼容接口(默认关;不填密钥=完全不联网) ----
ARK_默认地址 = "https://ark.cn-beijing.volces.com/api/v3"


def _AI本地(址):
    """接口地址是不是本机服务(Ollama/LM Studio)。本机服务没有密钥这回事。
    讲述转分镜、助手、发请求三处必须共用这一把尺,免得再漏一处把本地档卡死。"""
    址 = str(址 or "")
    return ("127.0.0.1" in 址) or ("localhost" in 址) or 址.startswith("http://[::1]")


def ark_请求(路径, 载荷=None, GET=False, 超时=75):
    """走任意 OpenAI 兼容接口(火山方舟/Kimi/DeepSeek/Claude兼容层/本地Ollama·LMStudio等)。任何失败都把原因带回调用方并打印日志——不许静默降级。
    返回 (解析后的 dict 或 None, 错误文字)。密钥只在内存里拼头,绝不写进日志。"""
    st = settings(带密钥=True)
    密钥 = st.get("豆包密钥") or ""
    base = (st.get("豆包地址") or ARK_默认地址).rstrip("/")
    if not 密钥 and not _AI本地(base):
        return None, "没填AI密钥(①-B 那行第一个格)"
    url = base + 路径
    头 = {"Content-Type": "application/json"}
    if 密钥: 头["Authorization"] = "Bearer " + 密钥   # 本地服务不填密钥就不带头,别把空Bearer发给Ollama
    try:
        体 = None if GET else json.dumps(载荷 or {}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=体, headers=头, method="GET" if GET else "POST")
        with urllib.request.urlopen(req, timeout=超时) as r:
            return json.loads(r.read().decode("utf-8", "replace")), ""
    except Exception as e:
        if hasattr(e, "code"):
            try:
                原 = e.read().decode("utf-8", "replace")[:300]
            except Exception as e2:
                print("[AI接口HTTP正文读不了] %r" % (e2,)); 原 = ""
            print("[AI接口HTTP %s] %s" % (e.code, 原[:160]))
            return None, "AI接口返回 HTTP %s:%s" % (e.code, 原)
        print("[AI接口连不上] %s: %s" % (e.__class__.__name__, e))
        return None, "连不上AI接口:%s(%s)" % (e.__class__.__name__, str(e)[:90])


def ark_models(body):
    """「拉模型」:列这个接口账号能用的全部模型(不分厂商),顺便验密钥对不对。拉不到就明说原因,手填也照常能用。"""
    d, err = ark_请求("/models", GET=True)
    if err: return {"error": err}
    名 = []
    for x in (d.get("data") or []):
        if isinstance(x, dict) and x.get("id"): 名.append(str(x["id"]))
    if not 名:
        return {"error": "接口回了但模型列表是空的(这账号可能没开模型权限):" + json.dumps(d, ensure_ascii=False)[:160]}
    return {"ok": True, "模型": sorted(名), "总数": len(名)}


助手知识缓存 = {"mt": 0.0, "条目": []}


def 助手知识():
    """知识库=界面速查表(HELP/IDHELP)+各步骤标题+随包改造说明书,现捞现用。
    单一来源:界面文案改了知识自动跟着改——绝不另写一份手册,口径漂移是最阴的bug。"""
    try:
        h = ROOT / "index.html"
        mt = h.stat().st_mtime
        if 助手知识缓存["mt"] == mt and 助手知识缓存["条目"]:
            return 助手知识缓存["条目"]
        s = h.read_text(encoding="utf-8")
        条目 = []
        显示名 = {}
        for m in re.finditer(r'<button[^>]*?onclick="([A-Za-z0-9_]+)\([^)]*\)"[^>]*>(.*?)</button>', s, re.S):
            fn, label = m.group(1), re.sub(r"<[^>]+>", "", m.group(2))
            label = re.sub(r"^[^\u4e00-\u9fffa-zA-Z0-9「]+", "", label).strip()
            if label and fn not in 显示名: 显示名[fn] = label[:20]
        for 名, pat in (("按钮", r"var HELP=\{(.*?)\n\};"), ("输入框", r"var IDHELP=\{(.*?)\n\};")):
            mb = re.search(pat, s, re.S)
            if mb:
                for ln in mb.group(1).splitlines():
                    m = re.match(r'\s*"([^"]{2,40})":"(.*)",?\s*$', ln)
                    if m:
                        k = m.group(1)
                        叫法 = 显示名.get(k) or 显示名.get(k.split(":")[0]) or k
                        条目.append((名 + "「" + 叫法 + "」(内部名" + k + ")", m.group(2)))
        for m in re.finditer(r"<h3>(.*?)</h3>", s, re.S):
            t = re.sub(r"<[^>]+>", " ", m.group(1))
            t = re.sub(r"\s+", " ", t).strip()
            if len(t) > 6: 条目.append(("流程步骤", t))
        sm = ROOT.parent / "给AI看的改造说明书.md"
        if sm.exists():
            文 = sm.read_text(encoding="utf-8-sig")
            for sec in re.split(r"\n(?=## )", 文):
                题 = (sec.splitlines() or [""])[0].lstrip("# ").strip()
                内 = sec.strip()
                if 题 and len(内) > 20 and any(k in 题 for k in ("一、", "二、", "三、", "四、", "五、")):
                    条目.append(("说明书·" + 题[:18], 内[:1200]))
        if not 条目:
            print("[助手知识现捞] index.html 解析出 0 条——检查 HELP/IDHELP 字典格式是否变了")
            return 助手知识缓存["条目"]
        助手知识缓存["mt"] = mt; 助手知识缓存["条目"] = 条目
        return 条目
    except Exception as e:
        print("[助手知识现捞失败] %r —— 本次沿用上次缓存(可能为空)" % (e,))
        return 助手知识缓存["条目"]


def 助手检索(问题, 限=4200):
    """按字面重合度挑最相关的手册条目塞进上下文;没一条过线就回空,不硬凑。"""
    try:
        条目 = 助手知识()
        def bg(t):
            t = re.sub(r"\s", "", str(t))
            return set(t[i:i+2] for i in range(len(t)-1))
        qb = bg(问题)
        qs = set(re.sub(r"[\s，。？！,.?!]", "", str(问题)))
        if not qb or not 条目: return ""
        打分 = []
        for 题, 文 in 条目:
            eb = bg(题) | bg(文)
            es = set(str(题) + str(文))
            二字 = len(qb & eb)
            ov = 二字 + 0.5 * len(qs & es)           # 二字组为主,单字半权:短句也够灵敏
            if 二字 >= 1 and ov >= 2.5: 打分.append((ov / (1 + 0.004 * len(文)), 题, 文))  # 没一个完整二字组=查无依据
        打分.sort(key=lambda x: -x[0])
        out, 总 = [], 0
        for _, 题, 文 in 打分[:12]:
            块 = "· " + 题 + ":" + 文
            总 += len(块)
            if 总 > 限: break
            out.append(块)
        return "\n".join(out)
    except Exception as e:
        print("[助手检索炸了] %r" % (e,)); return ""


def ai_chat(body):
    """⑤ AI助手抽屉:纯问答,只动嘴不动手——不读写文件、不替用户按按钮。
    用 ①-B 同一套设置(密钥/接口地址/模型名),但不看「用AI理解」开关:人主动发才联网。
    每次按问题从界面速查表/流程/说明书里检索最相关条目进系统提示,让它答得准本工作台的真实操作。
    历史由浏览器内存保存,关页即散,不落盘。"""
    st = settings(带密钥=True)
    址 = (st.get("豆包地址") or ARK_默认地址)
    本机 = _AI本地(址)   # 本地服务(Ollama/LM Studio)不需要密钥;外网地址照旧必须填
    if not (st.get("豆包密钥") or "") and not 本机:
        return {"退回": "没填AI密钥(①-B 那行第一个格),助手不联网"}
    模型 = (st.get("豆包模型") or "").strip()
    if not 模型: return {"退回": "没填模型名(①-B 点「拉模型」选一个)"}
    if 本机 and _la_exe() and not _la_服务在():
        if not _la_起服务():
            return {"退回": "本地模型服务(Ollama)自动拉起失败——重新打开工作台再问,或到 ①-B 改填云端地址+密钥"}
    史 = [{"role": str(m.get("role") or "user"), "content": str(m.get("content") or "")[:4000]}
          for m in (body.get("消息") or [])[-20:] if isinstance(m, dict) and m.get("content")]
    if not 史: return {"退回": "没带问题来"}
    知 = 助手检索(史[-1]["content"])
    if not 知:
        return {"退回": "手册里没检索到和你这个问题相关的内容——这个我答不准,不瞎编。换个问法,或问工作台界面上有的功能;剪辑经验类问题请去问通用AI"}
    本机问 = 本机
    统 = ("你是「AI剪辑工作台」内置的专属客服助教,只帮用户解决这个软件的使用、剪辑流程与排障问题。版本:%s。"
           "规则:1)优先依据下面【工作台手册节选】作答,引用按钮时说「」里的界面叫法,括号里的内部名不要念给用户;节选没覆盖的直说不确定,绝不编功能;"
           "2)只出主意给步骤,绝不代改文件、代按按钮;3)回答短,分点,能照着做;4)排障类问题先让用户复述状态栏/日志原文再判断;"
           "5)剪辑专业问题(节奏/包装/字幕)也可以答,但要讲清这是经验之谈,不是软件功能。"
           "\n\n【工作台手册节选】\n%s\n\n[当前项目] %s\n[分镜表摘录] %s\n[最近日志摘录] %s\n") % (
           VERSION, 知 or "(本次没检索到相关条目——直说不确定,别编)", str(body.get("项目") or "未选项目"),
           str(body.get("分镜") or "")[:1500], str(body.get("日志") or "")[-1500:])
    体 = {"model": 模型, "temperature": 0.4, "max_tokens": 1200,
           "messages": [{"role": "system", "content": 统}] + 史}
    if 本机:
        体["keep_alive"] = "30m"      # 本地服务:模型驻留内存,否则每次冷加载慢十倍(实测51s→5s)
        体["num_ctx"] = 4096          # 手册节选+上下文约1.5k字,默认2048会截
    d, err = ark_请求("/chat/completions", 体, 超时=240 if 本机 else 90)
    if err: return {"退回": err}
    try:
        文 = ((d.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    except Exception as e:
        print("[助手应答读不懂] %r" % (e,)); 文 = ""
    if not 文: return {"退回": "AI回了空或格式不认识(前120字):" + str(d)[:120]}
    return {"回复": 文.strip(), "用量": d.get("usage") or {}, "本机": 本机}


# ---- ①-C 一键装本地AI:机器级长任务(独立线程+状态轮询),失败必须带原因 ----
LOCALAI = {"跑": False, "取消": False, "完成": False, "错": "", "进": "", "步": [], "proc": None}
LA_LOCK = threading.Lock()
LA_固定摘要 = {"v0.40.13": "9e3c76e54e7184c68e88a2378b909bf59bbe454f83c076cb4f4a717e946ae719"}
LA_镜像 = ["https://gh-proxy.com/", "https://ghproxy.net/", ""]   # 空串=GitHub 官方直连,放最后


def 本地AI选型(显存MB):
    """按显存定档,客户不用自己懂模型。返回 (模型名, 档位说明)。"""
    if 显存MB >= 10000:
        return ("modelscope.cn/Qwen/Qwen3-8B-GGUF:Q4_K_M", "显存%dMB:装8B,最聪明,约5.1GB" % 显存MB)
    if 显存MB >= 6000:
        return ("modelscope.cn/Qwen/Qwen3-4B-GGUF:Q4_K_M", "显存%dMB:装4B,聪明但一次要等几十秒,约2.5GB" % 显存MB)
    if 显存MB >= 3000:
        return ("modelscope.cn/Qwen/Qwen2.5-1.5B-Instruct-GGUF:Q4_K_M",
                "显存%dMB:装1.5B,快但只照手册直答,约1GB;想更聪明建议走云端免费额度" % 显存MB)
    return ("modelscope.cn/Qwen/Qwen2.5-1.5B-Instruct-GGUF:Q4_K_M",
            "没查到N卡显存:装1.5B保底,能跑但慢;追求体验建议走云端免费额度")


def _la_显存():
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=12, encoding="utf-8", errors="replace")
        值 = [int(x) for x in re.findall(r"\d+", r.stdout or "") if int(x) > 0]
        return max(值) if 值 else 0
    except Exception as e:
        print("[查显存失败] %r" % (e,)); return 0


def _la_exe():
    q = shutil.which("ollama")
    if q: return q
    for c in (os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"),
              r"C:\Program Files\Ollama\ollama.exe"):
        if os.path.exists(c): return c
    return ""


def _la_服务在():
    try:
        with urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=2) as f:
            return f.status == 200
    except Exception:
        return False


def _la_去掉开机自启():
    """Ollama 安装器默认往 Windows「启动」文件夹放快捷方式——由工作台接管启动后删掉它:
    以后只有打开工作台才起服务,不再占开机。删不到也不报错(可能本来就没有)。"""
    try:
        appdata = os.environ.get("APPDATA") or ""
        if not appdata: return False
        lnk = os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "Ollama.lnk")
        if os.path.exists(lnk):
            os.remove(lnk)
            slog("本地AI", "", "已删掉 Ollama 开机自启快捷方式,改为打开工作台时自动起服务")
            return True
    except Exception as e:
        print("[去掉开机自启失败] %r" % (e,))
    return False


def _la_起服务(轮=10, 隔=1.0):
    """本地模型服务没在跑时代用户拉起来:后台无窗口起 ollama serve,轮询到在线才算成。已在跑直接 True。"""
    if _la_服务在(): return True
    exe = _la_exe()
    if not exe: return False
    try:
        subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=(0x08000000 if os.name == "nt" else 0))
    except Exception as e:
        print("[起本地模型服务失败] %r" % (e,)); return False
    for _ in range(轮):
        time.sleep(隔)
        if _la_服务在(): return True
    print("[起本地模型服务超时] 等了 %s 秒 11434 还没在线" % (轮 * 隔,)); return False


def assistant_boot():
    """打开工作台时后台调用一次:先去掉 Ollama 开机自启;若助手配的是本地地址且服务没在跑,代拉起(云端地址不动服务)。"""
    删了 = _la_去掉开机自启()
    try:
        st = settings()
        址 = (st.get("豆包地址") or ARK_默认地址)
        if ("127.0.0.1" in 址 or "localhost" in 址) and _la_exe() and not _la_服务在():
            if _la_起服务():
                slog("本地AI", "", "打开工作台,已自动拉起本地模型服务(11434)")
            else:
                print("[本地AI] 助手配的是本地地址,但 Ollama 服务没起来——重新打开工作台,或点①-C「一键装本地AI」修复")
    except Exception as e:
        print("[助手启动自检失败] %r" % (e,))
    return 删了


def _la_sha(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 22), b""): h.update(blk)
    return h.hexdigest()


def _la_step(名, 状态, 详情=""):
    with LA_LOCK:
        for i, x in enumerate(LOCALAI["步"]):
            if x[0] == 名:
                LOCALAI["步"][i] = [名, 状态, 详情]; return
        LOCALAI["步"].append([名, 状态, 详情])


def localai_plan():
    """只读体检:显卡/Ollama/服务/选型,不装任何东西。"""
    显 = _la_显存(); exe = _la_exe()
    模型, 说明 = 本地AI选型(显)
    return {"ok": True, "显存MB": 显, "已装Ollama": bool(exe), "服务在跑": _la_服务在(),
            "模型": 模型, "档位": 说明, "磁盘GB": round(shutil.disk_usage(os.environ.get("SystemDrive", "C:") + "\\")[2] / 2**30, 1)}


def localai_start():
    if LOCALAI["跑"]: return {"退回": "已经在装了,看进度别急"}
    盘 = localai_plan()
    if 盘["已装Ollama"] and 盘["服务在跑"] and 盘["显存MB"] < 3000:
        pass   # 允许重装换档,但选型会保底
    if 盘["磁盘GB"] < 8:
        return {"退回": "C盘剩余只有 %.1fGB,装本地AI至少需要 8GB 空闲——先腾地方或走云端免费额度" % 盘["磁盘GB"]}
    with LA_LOCK:
        LOCALAI.update({"跑": True, "取消": False, "完成": False, "错": "", "进": "", "步": [], "proc": None})
    threading.Thread(target=localai_run, daemon=True).start()
    return {"ok": True}


def localai_cancel():
    with LA_LOCK:
        if not LOCALAI["跑"]: return {"退回": "没在装,不用取消"}
        LOCALAI["取消"] = True
        pr = LOCALAI.get("proc")
    if pr:
        try: pr.kill()
        except Exception as e: print("[取消杀进程失败] %r" % (e,))
    return {"ok": True}


def _la_取版本信息():
    """优先 GitHub API 拿最新版+官方SHA;拿不到退回固定档(作者机验证过的)。"""
    try:
        req = urllib.request.Request("https://api.github.com/repos/ollama/ollama/releases/latest",
                                     headers={"User-Agent": "dianxin-workbench"})
        with urllib.request.urlopen(req, timeout=20) as f:
            d = json.loads(f.read().decode("utf-8", "replace"))
        for a in (d.get("assets") or []):
            if a.get("name") == "OllamaSetup.exe":
                消 = (a.get("digest") or "").replace("sha256:", "")
                if 消: return d.get("tag_name") or "?", 消
    except Exception as e:
        print("[查最新版失败,退回固定档] %r" % (e,))
    for v, 消 in LA_固定摘要.items(): return v, 消
    return "", ""


def localai_run():
    import hashlib  # noqa
    错终 = ""
    try:
        盘 = localai_plan()
        _la_step("查电脑", "✓", 盘["档位"] + " | C盘剩 %.1fGB" % 盘["磁盘GB"])
        exe = _la_exe()
        if not exe:
            版, 消 = _la_取版本信息()
            if not 版: raise RuntimeError("拿不到 Ollama 版本号和官方校验值(网络受限?),没法安全安装——重试或走云端")
            tmpdir = os.path.join(os.environ.get("TEMP", "."), "AI剪辑工作台")
            os.makedirs(tmpdir, exist_ok=True)
            路径 = os.path.join(tmpdir, "OllamaSetup.exe")
            下好 = False
            for i, 镜 in enumerate(LA_镜像):
                if LOCALAI["取消"]: raise RuntimeError("已取消")
                _la_step("下载Ollama", "进", "第%d条线路(约1.6GB,别关工作台)" % (i + 1))
                LOCALAI["进"] = "下载 Ollama 安装包中…(1.6GB,速度看网速)"
                已有 = 路径 if os.path.exists(路径) else ""
                r = subprocess.run(["curl.exe", "-L", "-C", "-", "--retry", "3", "--max-time", "5400",
                                    "-o", 路径, 镜 + "https://github.com/ollama/ollama/releases/download/%s/OllamaSetup.exe" % 版],
                                   capture_output=True, text=True, timeout=5600, encoding="utf-8", errors="replace")
                if LOCALAI["取消"]: raise RuntimeError("已取消")
                if r.returncode != 0 or not os.path.exists(路径):
                    _la_step("下载Ollama", "✗", "第%d条线路断了,换下一条" % (i + 1)); continue
                实 = _la_sha(路径)
                if 实 != 消:
                    _la_step("校验", "✗", "文件与官方SHA256不一致(线路%d),弃用重下" % (i + 1))
                    try: os.remove(路径)
                    except Exception: pass
                    continue
                _la_step("下载Ollama", "✓", "第%d条线路完成" % (i + 1))
                _la_step("校验", "✓", "SHA256 与官方发布逐字节一致")
                下好 = True
                break
            if not 下好: raise RuntimeError("三条下载线路都没拿到完整安装包——检查网络,或走云端免费额度")
            _la_step("安装", "进", "静默安装中,可能弹一次UAC,点『是』")
            LOCALAI["进"] = "正在安装 Ollama(如弹 UAC 请点『是』)…"
            rs = subprocess.run([路径, "/VERYSILENT", "/NORESTART", "/SP-", "/SUPPRESSMSGBOXES"], timeout=900)
            if rs.returncode not in (0,): raise RuntimeError("安装器返回码 %s" % rs.returncode)
            _la_step("安装", "✓")
            try: os.remove(路径)
            except Exception as e: print("[安装包清理失败无所谓] %r" % (e,))
            exe = _la_exe()
            if not exe: raise RuntimeError("装完找不到 ollama.exe——重启电脑后再按一次这按钮")
        _la_step("Ollama", "✓", exe)
        if not _la_服务在():
            _la_step("起服务", "进", "本地服务没在跑,试着拉起来")
            subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            for _ in range(30):
                time.sleep(2)
                if _la_服务在(): break
            if not _la_服务在(): raise RuntimeError("Ollama 服务起不来——重启电脑再按一次,或走云端")
        _la_step("起服务", "✓", "http://127.0.0.1:11434 在线")
        _la_去掉开机自启()
        模型, 说明 = 本地AI选型(_la_显存())
        _la_step("拉模型", "进", 说明)
        LOCALAI["进"] = "下载模型中(约1-5GB,这步最慢,别关工作台)…"
        pr = subprocess.Popen([exe, "pull", 模型], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, encoding="utf-8", errors="replace")
        with LA_LOCK: LOCALAI["proc"] = pr
        尾 = ""
        for ln in (pr.stdout or []):
            尾 = ln.strip() or 尾
            if 尾: LOCALAI["进"] = "拉模型:" + 尾[-90:]
            if LOCALAI["取消"] and pr.poll() is None:
                pr.kill(); raise RuntimeError("已取消")
        if pr.wait() != 0: raise RuntimeError("ollama pull 返回码 %s:%s" % (pr.returncode, 尾[-120:]))
        with LA_LOCK: LOCALAI["proc"] = None
        _la_step("拉模型", "✓", 模型)
        save_settings({"豆包地址": "http://127.0.0.1:11434/v1", "豆包模型": 模型})
        _la_step("填设置", "✓", "①-B 已指向本地模型")
        with LA_LOCK:
            LOCALAI["完成"] = True; LOCALAI["进"] = ""
        slog("一键装本地AI", "", "完成: %s" % 模型)
    except RuntimeError as e:
        错终 = str(e)
    except Exception as e:
        错终 = "%r" % (e,)
        print("[一键装本地AI炸了] %s" % 错终, flush=True)
    if 错终:
        with LA_LOCK:
            LOCALAI["错"] = 错终
        for x in LOCALAI["步"]:
            if x[1] == "进": x[1] = "✗"
        slog("一键装本地AI失败", "", 错终[:160])
    with LA_LOCK:
        LOCALAI["跑"] = False


AI_系统 = (
    "你是短视频剪辑分镜的翻译官。人只随口说想怎么剪,你把它翻成一行一镜的施工图。\n"
    "只输出 CSV,不要解释、不要代码围栏。三列,英文逗号分隔:画面内容,动效包装,锚点\n"
    "1) 一行=一个镜头(画面不换)。**只输出他提到的那几个镜头**——他说了三镜就三行,"
    "不许给口播每句话都配画面,不许自己加镜头。\n"
    "2) 画面内容=这镜观众看到什么。能落到标准词就写:口播正面/空镜:xxx/录屏/图形卡/大字卡;"
    "要更具体就在词后面补一句(如「图形卡:1100到1200 分数区间条」);拿不准的照抄他的原话,别硬套。\n"
    "3) 动效包装=转场或卡片说法,写「转场:名字」(如 转场:故障、转场:叠化)或 数据卡/推镜/定格/数字滚动;没有留空。\n"
    "4) 锚点=这一镜对应口播里的哪句话,**逐字摘自下面口播原文里的 3~10 个字**(照抄,不许改字)。"
    "绝对禁止写行号、序号、编号、引号、整句复述、时间码。摘不出来就这一格留空。\n"
    "5) 不许写秒数、不许解释、不许新增他没提到的人名/数据/卖点。\n"
    "口播原文(每行一句,没有编号,直接从里面摘字):\n")


# (2026-11-19)这里原先硬编码一份 7 项名单,和《动效包装协议.md》对不上——已删,改由 _动效可写码() 现场解析协议第二节


def sb_ai_draft(proj, text):
    """①-B「用AI理解我说的话」:整段大白话 + 全片口播原文一起交给所配 AI(任意 OpenAI 兼容接口),只要它填画面/动效/锚点三格。
    它的秒数一概不信(时间码留空,⚓ 算);它给的锚点必须真在转写里,不在就用本机词表引擎重定位,
    还定位不上就写进备注,不硬编。没开/没密钥(本机服务免密钥)/断网/答得不像表 → 返回 {"退回": 原因},
    调用方落回本机词表引擎并显示原因,绝不静默换脑。"""
    import csv as _csv
    st = settings(带密钥=True)
    if not st.get("豆包理解"): return {"退回": "没开「用AI理解」开关"}
    if not st.get("豆包密钥") and not _AI本地(st.get("豆包地址")):
        return {"退回": "没填AI密钥(本机服务不用填:地址里带 127.0.0.1 即可)"}
    模型 = (st.get("豆包模型") or "").strip()
    if not 模型: return {"退回": "没填模型名(点「拉模型」选一个)"}
    proj = Path(proj)
    tj = proj / "转写.json"
    if not tj.exists(): return {"退回": "还没转写,没法给它看原话"}
    segs = (json.loads(tj.read_text(encoding="utf-8")) or {}).get("segments") or []
    if not segs: return {"退回": "转写是 0 段"}
    段文 = "\n".join(str(s.get("text", "")) for s in segs)   # 不编号:小模型会抄编号当锚点(2026-11-15 实测)
    问 = ("我说的怎么剪(原样,可能很口语):\n" + str(text or "").strip() +
          "\n\n全片口播逐句(编号|文字):\n" + 段文)
    体 = {"model": 模型, "temperature": 0.2, "max_tokens": 1600,
          "messages": [{"role": "system", "content": AI_系统}, {"role": "user", "content": 问}]}
    本机 = _AI本地(st.get("豆包地址"))
    if 本机 and _la_exe() and not _la_服务在():
        if not _la_起服务():
            return {"退回": "本机模型服务(Ollama)没起来——重新打开工作台,或到 ①-C 点「一键装本地AI」修;"
                            "也可以改填云端接口地址+密钥"}
    if 本机:
        体["keep_alive"] = "30m"      # 本机服务:模型驻内存,否则冷加载慢十倍,像按钮没反应
        体["num_ctx"] = 4096          # 全片口播原文+镜头话容易超默认窗口
    d, err = ark_请求("/chat/completions", 体, 超时=240 if 本机 else 120)
    if err: return {"退回": err}
    try:
        文 = str(((d.get("choices") or [{}])[0].get("message") or {}).get("content") or "")
    except Exception as e:
        print("[AI应答读不懂] %r %s" % (e, str(d)[:200])); 文 = ""
    文 = re.sub(r"^\s*```[a-zA-Z]*|```\s*$", "", 文).strip()
    if not 文: return {"退回": "AI回了空或格式不认识(前120字):" + str(d)[:120]}
    norm = _norm_cn
    作者说了口播 = any(k in str(text or "") for k in _SB_ZONE[0][1])   # 只看人原话,AI 自己填的"口播正面"不算
    st2 = assets_state(proj)
    pool, seen = [], set()
    for it in st2.get("items") or []:
        pth = it.get("path") or os.path.join(st2.get("folder", ""), it.get("name", ""))
        stem = norm(Path(it.get("name", "")).stem)
        if stem and stem not in seen:
            seen.add(stem); pool.append((stem, pth))
    rows, 数 = [], 0
    for 行 in _csv.reader(io.StringIO(文)):
        if not 行 or not any(str(c).strip() for c in 行): continue
        if any("画面内容" in str(c) for c in 行): continue
        画 = str(行[0] or "").strip()
        动 = str(行[1] or "").strip() if len(行) > 1 else ""
        锚 = str(行[2] or "").strip() if len(行) > 2 else ""
        数 += 1
        note = []
        zone, zh = _sb_zone(画)
        if not zh: zone = 画 or "口播正面"
        fx = _sb_fx(画 + " " + 动) or 动
        sg = None
        if 锚:
            for s in segs:
                if norm(锚) and norm(锚) in norm(s.get("text")): sg = s; break
        if sg is None and (画 or 锚):
            aw, sg2, _试, tie = _sb_find_seg(画 + " " + 锚, segs, norm)
            if sg2 is not None:
                if 锚: note.append("AI给的锚点「%s」不在口播里,本机改用「%s」定位" % (锚, aw))
                锚 = aw; sg = sg2
                if tie: note.append(tie)
            elif 锚:
                note.append("AI给的锚点「%s」在口播里找不到,本机也没定位上:这镜算不出秒数,"
                            "把锚点改成你真说过的词" % 锚)
        字幕 = str(sg.get("text", "")) if sg is not None else ""
        mat = ""
        pm = re.search(r"[A-Za-z]:[^\s,;，；|、]+?\.(?:mp4|mov|png|jpe?g|wav|mp3)", 画)
        if pm: mat = pm.group(0)
        else:
            for stem, path in pool:
                if stem in norm(画): mat = path; break
        # 小模型常把画面类型写进动效列(实测 1.5B:画面内容=口播正面、动效列=图形卡)
        # ——列串位就搬回来,别让用户对着错格猜;作者真说了"口播/露脸"时不搬,两边都说了以画面列为准。
        _z2, _zh2 = _sb_zone(fx)
        _默认档 = zone == "口播正面" and not 作者说了口播    # AI 拿"口播正面"当默认填,不等于你要它
        if _zh2 and (not _sb_zone(zone)[1] or _默认档):
            note.append("动效列里的「%s」是画面类型,已搬回画面内容列" % _z2)
            zone, fx = _z2, ""
        # 动效列只准写协议白名单的说法;名单唯一真源=《动效包装协议.md》第二节(闸不再自备清单)
        _类名 = _协议类型名(fx)
        if _类名.startswith("转场:"):
            if _类名.split(":", 1)[1] not in _转场可写码():
                note.append("AI写的转场「%s」不在协议白名单里(那是剪辑软件私有转场名,渲染方做不出来),已挪进备注,第④步别当指令执行"
                            % _类名.split(":", 1)[1][:12])
                fx = ""
        elif fx and _类名 not in _动效可写码():
            note.append("AI写的动效「%s」不在协议白名单里,已挪进备注,第④步别当指令执行" % fx[:20])
            fx = ""
        rows.append(["%02d" % 数, "", 锚, 字幕, zone, mat, fx, "；".join(note)])
    if not rows: return {"退回": "AI回的内容里一行像表格的都没有(前120字):" + 文[:120]}
    # 质检闸:字幕文本那格空 = 这一镜定位不到你说过的话。半数以上定位不上,或它擅自把镜头数
    # 撑到你说的两倍以上,就是这次理解不合格——明说原因退回本机词表,绝不把垃圾表填进分镜框。
    空 = sum(1 for r in rows if not r[3])
    讲 = len(_sb_shot_lines(text)) or 1
    因 = ""
    if 空 >= max(2, (len(rows) + 1) // 2):
        因 = "有 %d/%d 行定位不到你说过的话(锚点是编的)" % (空, len(rows))
    elif len(rows) > max(3, 讲 * 2):   # 下限 3:你说一镜它合理拆两三行不算错,别误伤
        因 = "你只说了 %d 镜,它交回 %d 行(给每句话都配了画面)" % (讲, len(rows))
    if 因:
        print("[AI理解不合格退回] %s | 模型=%s" % (因, 模型))
        return {"退回": "AI 这次没看懂(%s),已改用本机词表。本机那个小模型只够问答,干不了结构化翻译:"
                        "要它当翻译官就换 4B 以上本地模型,或填云端接口(豆包/DeepSeek/Kimi 都行)" % 因}

    def esc(v):
        v = str(v).replace("\n", " ")
        return '"%s"' % v.replace('"', '""') if any(c in v for c in ',"') else v
    头 = "镜号,时间码(成片·自动),锚点,字幕文本(校对版),画面内容,素材文件,动效包装,备注"
    return {"ok": True, "csv": 头 + "\n" + "\n".join(",".join(esc(c) for c in r) for r in rows) + "\n",
            "镜头数": 数, "要补": sum(1 for r in rows if r[7]), "来源": "AI",
            "模型": d.get("model") or 模型, "用量": d.get("usage") or {}}


def sb_draft_from_text(proj, text):
    """①-B「讲述转分镜」:随口讲的 → 规范分镜草稿(只回文本,不落盘——
    审没审、存不存、⚓ 算秒,都由人按下一次保存说了算)。
    能认:一镜一行(句号/逗号/顿号分隔的一口气写法也拆);「说过的词」或反序内容词→锚点+对口播原话;
    时间(按原片秒)→取那句;画面五类说法;故障/叠化这类效果说法→动效包装列;素材库文件名/绝对路径。
    认不出的一律不丢,原因写进备注列等人补。"""
    proj = Path(proj)
    tj = proj / "转写.json"
    if not tj.exists(): return {"error": "还没转写,没法对原话:先完成第②步再讲述"}
    segs = (json.loads(tj.read_text(encoding="utf-8")) or {}).get("segments") or []
    if not segs: return {"error": "转写是 0 段,对不了词:回第②步换模型重转"}
    total = max(float(s.get("end", 0)) for s in segs)

    norm = _norm_cn

    st = assets_state(proj)
    pool, seen = [], set()
    for it in st.get("items") or []:
        pth = it.get("path") or os.path.join(st.get("folder", ""), it.get("name", ""))
        stem = norm(Path(it.get("name", "")).stem)
        if stem and stem not in seen:
            seen.add(stem); pool.append((stem, pth))
    rows, shotno = [], 0
    for raw in _sb_shot_lines(text):
        line = re.sub(r"^\s*(?:第\s*\d+\s*[个镜行条]?[：:、,\.]?\s*|\d{1,2}[\.\)、]\s*)", "", raw).strip()
        if not line: continue
        shotno += 1
        note = []
        qm = re.search(r'[\u300c\u300a\u201c"]([^\u300d\u300b\u201d"]{2,12})[\u300d\u300b\u201d"]', line)
        anchor = qm.group(1) if qm else ""
        tsec = None
        tm = re.search(r"(\d{1,2})[:：](\d{2})", line)
        sm = re.search(r"(\d+(?:\.\d+)?)\s*(?:[sS]|秒)", line)
        if tm: tsec = int(tm.group(1)) * 60 + int(tm.group(2))
        elif sm: tsec = float(sm.group(1))
        zone, zh = _sb_zone(line)
        if not zh:
            # 格式不吞人话:他怎么说的就怎么留在画面内容列,交给第④步的 AI 或他自己理解,
            # 机器只负责把它钉在第几秒(锚点/字幕文本照常对),不再武断写成"口播正面"。
            原 = re.sub(r"\s+", " ", re.sub(r'[\u300c\u300d\u300a\u300b\u201c\u201d"]', "", line)).strip()
            zone = 原[:40] or "口播正面"
            note.append("没套上画面五类词:你的原话留在画面内容列,机器只负责定位到秒,画面怎么给由第④步AI或你自己定")
        fx = _sb_fx(line)
        mat = ""
        pm = re.search(r"[A-Za-z]:[^\s,;，；|、]+?\.(?:mp4|mov|png|jpe?g|wav|mp3)", line)
        if pm:
            mat = pm.group(0)
            if not os.path.exists(mat): note.append("这路径的文件不存在")
        else:
            for stem, path in pool:
                if stem in norm(line): mat = path; break
        mat_cell = mat
        if not mat and zone in ("空镜", "录屏"):
            kw = re.search(r"(?:空镜|录屏)[:：]?\s*([^\s,，;；「」()（）]{2,10})", line)
            mat_cell = "待生成:" + (kw.group(1) if kw else zone)
        sub = ""
        if anchor:
            for sg in segs:
                if norm(anchor) in norm(sg.get("text")):
                    sub = str(sg.get("text", "")); break
            if not sub: note.append("锚点词在转写里没找到(没说过?打错字?)")
        elif tsec is not None:
            if tsec > total + 1:
                note.append("时间%.1fs超出素材总长%.1fs,对不上句" % (tsec, total))
            else:
                hit = None
                for sg in segs:
                    if float(sg.get("start", 0)) <= tsec + 0.4: hit = sg
                    else: break
                if hit:
                    sub = str(hit.get("text", ""))
                    anchor = norm(sub)[:6]
                    note.append("按%.1fs取的这句,锚点用开头6字,不对就改成你真说的词" % tsec)
        else:
            # 模糊兜底:内容词打分对句(剥掉动作/画面/动效词,允许语序颠倒与数字两种写法)
            aw, sg, tried, tie = _sb_find_seg(line, segs, norm)
            if sg is not None:
                anchor = aw; sub = str(sg.get("text", ""))
                note.append(tie if tie else "按「%s」对到了这句,不对就改成你真说的词" % aw)
            else:
                note.append("拿「%s」去转写里都没对上:用「」写出你确实说过的词,或写秒数" % "、".join(tried)
                            if tried else "没给时间也没带「词」,机器找不到这句:补一个")
        if not fx:
            if re.search(r"\d+(?:\.\d+)?\s*(?:%|天|年|月|个|万|亿|元|块|次|倍|岁|分钟)", line + " " + sub): fx = "数据卡"
            elif zone in ("空镜", "录屏"): fx = "推镜"
        rows.append(["%02d" % shotno, "", anchor, sub, zone, mat_cell, fx, "；".join(note)])
    if not rows: return {"error": "一句都没认出来:一行一镜地讲,带上「说过的词」或时间"}

    def esc(v):
        v = str(v).replace("\n", " ")
        return '"%s"' % v.replace('"', '""') if any(c in v for c in ',"') else v
    head = "镜号,时间码(成片·自动),锚点,字幕文本(校对版),画面内容,素材文件,动效包装,备注"
    csv_txt = head + "\n" + "\n".join(",".join(esc(c) for c in r) for r in rows) + "\n"
    return {"ok": True, "csv": csv_txt, "镜头数": len(rows), "要补": sum(1 for r in rows if r[7])}

SB_HEAD_FALLBACK = "镜号,时间码(成片·自动),锚点(口播词),字幕文本,画面内容,素材文件,动效/包装,备注"

def sb_header_row():
    """规范表头行:取 分镜镜头表模板.md 里含「镜号」的首个表格行;读不到用内置兜底。缺表头保存时自动补。"""
    try:
        for ln in (WF / "分镜镜头表模板.md").read_text(encoding="utf-8").splitlines():
            ls = ln.strip()
            if ls.startswith("|") and "镜号" in ls:
                return ls.strip("|").replace(" | ", ",").strip()
    except Exception as e:
        print("[分镜表头提取失败,用兜底表头] %r" % e)
    return SB_HEAD_FALLBACK

def storyboard_save(proj, text, auto=True):
    """保存 分镜.csv;开着「保存自动算秒」且有转写,就顺手跑一次 ⚓——省掉再点一次按钮。
    防呆:把随口讲的话直接贴进这张表(整行没一个英文逗号、只有一格)会被拒存——
    表是一格一列的施工图,说话请走上方讲述框按「⚡ 讲述转分镜」,别让脏表混进第④步。"""
    proj = Path(proj)
    if not (text or "").strip():
        return {"error": "分镜表是空的,没东西可存(想清空回本步用「🗑 重置本步」)"}
    _原文 = text.strip()  # 保存用户原始输入,给自动转分镜用
    # 表头校验与 anchor_time.py 的 find_header 同规则:任一行的任一格里含「镜号」才算镜头表。
    # 缺表头不再拒存让用户照抄:框里灰字只是占位提示(不可修改),保存时机器自动补一行表头,
    # ⚓ 与步骤勾选从此不会一个亮一个红;补没补由返回值说清楚,界面提示用户。
    补表头 = False
    if not any("镜号" in c for l in text.splitlines() for c in re.split(r"[|,，;；\t]", l)):
        text = sb_header_row() + "\n" + text
        补表头 = True
    # 逐行查格子数:csv 只认英文逗号,所以中文逗号连着写的一句话会整行挤进第1格。
    # 智能降级:如果所有内容行都是自然语言(没有一行有英文逗号分列),自动走「讲述转分镜」。
    import csv as _csv
    第 = 0
    自然行 = []   # (行号, 内容)
    格式行 = 0    # 已分列的行数
    for 行 in _csv.reader(io.StringIO(text.replace("\r\n", "\n"))):
        第 += 1
        if not any(str(c).strip() for c in 行): continue
        if any("镜号" in str(c) for c in 行): continue
        if len(行) <= 1:
            自然行.append((第, 行[0].strip() if 行 else ""))
        else:
            格式行 += 1
    if 自然行 and 格式行 == 0:
        # 全是自然语言——不报错,告诉前端"该走AI转了"
        return {"need_ai": True, "raw": _原文}
    elif 自然行:
        # 混合:有已格式的也有自然语言的——报错(让用户处理)
        第1, 内1 = 自然行[0]
        话 = _sb_looks_shot(内1) if 内1 else False
        return {"error": "没保存——第%d行整行只有一格(%s),但其他行已分列;"
                         "%s" % (第1, 内1[:36] + ("…" if len(内1) > 36 else ""),
                                 "请把自然语言的那几行剪切到上方讲述框,按「⚡ 讲述转分镜」转好再贴回来。"
                                 if 话 else "一行至少要写满镜号和后面几列(列之间用英文逗号分开)。")}
    step_snap(proj, ["分镜.csv"], "s1")
    # 浏览器 textarea 给的是 \n;不统一的话 Windows 会把 \r\n 再翻一次,CSV 里长出空行
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    with open(str(proj / "分镜.csv"), "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    out = {"ok": True}
    if 补表头: out["已自动补表头"] = True
    if not auto or not settings().get("自动算秒", True):
        out["自动算秒"] = {"skipped": "开关已关(① 素材卡片可打开)"}
    elif not (proj / "转写.json").exists():
        out["自动算秒"] = {"skipped": "还没转写,算不了秒数(② 转写完再存一次)"}
    else:
        r = action_anchors(proj, {})
        if r.get("error"): out["自动算秒"] = {"error": r["error"]}
        else:
            out["自动算秒"] = {"统计": r.get("统计"), "警告": r.get("警告") or [], "基准": r.get("基准")}
            out["统计"] = r.get("统计"); out["警告"] = r.get("警告") or []
    sb = proj / "分镜.csv"
    out["text"] = sb.read_text(encoding="utf-8") if sb.exists() else ""
    return out
def next_step(proj):
    """只看产物在不在、新不新,算出「下一步该点什么」。顺序与 ① 标签卡片从上到下完全一致:
    建项目 → 转写 → ①-A 文案定稿 → ①-B 分镜(含 ⚓ 算秒) → ①-D 对标点位 → ③-A 找点 → ③-D 出片 → ④ 交接。
    ①-C 上传对标素材是人手上的动作,引导只在登记过参考片后才催 ①-D 拆点位(没对标就不催)。"""
    proj = Path(proj)
    def f(n): return (proj / n).exists()
    def mt(n): return (proj / n).stat().st_mtime if f(n) else 0.0
    if not f("项目.json"):
        return {"tab": 0, "card": "projbar", "做": "粘贴口播视频绝对路径,建项目", "为什么": "每条口播一个项目目录", "进度": "0/6"}
    交在 = f("包装交接.md")   # 0.14 起剪映交接下线:老项目残留的 剪映交接.* 不再算交接完成
    done = sum(1 for x in (f("转写.json"), f("文案定稿.txt"), f("对标点位.json"), f("分镜.csv"),
                           f("rough.mp4"), 交在) if x)
    P = {"进度": "%d/6" % done}
    if not f("转写.json"):
        return dict(P, tab=1, card="s2", **{"做": "开始转写(开着自动转写时它自己会跑)",
                    "为什么": "文案识别、算秒数、点位表的口播列都要它"})
    try:
        if not (json.loads((proj / "转写.json").read_text(encoding="utf-8")).get("segments") or []):
            return dict(P, tab=1, card="s2", **{"做": "这条素材没识别到人声,先换模型重转或检查音频",
                        "为什么": "0 段转写会让后面每一步都空跑"})
    except Exception as e:
        print("[转写读不了] %s: %s" % (proj, e))
    if not f("文案定稿.txt"):
        return dict(P, tab=0, card="s1W", **{"做": "①-A 校对口播文案 → 确认定稿",
                    "为什么": "第③步烧的字幕以此为准,错字只有你能判"})
    if not f("分镜.csv"):
        return dict(P, tab=0, card=("s1D" if f("对标点位.json") else "s1"),
                    **{"做": ("①-B 补镜头:去 ①-D 点位表点「⬇ 按点位表补进分镜表」" if f("对标点位.json") else "①-B 写分镜镜头表"),
                       "为什么": "第④步插素材、加卡片都按分镜表执行;不学对标就自己列镜头"})
    if not f("分镜时间轴.json") or mt("分镜.csv") > mt("分镜时间轴.json"):
        return dict(P, tab=0, card="s1", **{"做": "⚓ 按锚点重算时间码",
                    "为什么": "分镜表改过了,秒数还是旧的(开着自动算秒本该自己跑)"})
    有对标 = bool([x for x in refs_state(proj)["items"] if x.get("kind") == "video"])
    if 有对标 and not f("对标点位.json"):
        return dict(P, tab=0, card="s1D", **{"做": "①-D 拆对标点位,再对着联系表改分类",
                    "为什么": "分镜已写完:用对标的切镜节奏检查哪些镜缺画面"})
    if not 有对标 and not f("风格档.json") and not f("剪切点清单.json") and not 交在:
        return dict(P, tab=0, card="s1c", **{"做": "①-C 没对标就套一个风格档(信息流强节奏/自然口播/高级感人设)",
                    "为什么": "不选档第④步就没风格依据,AI 只能给你行业平均"})
    if not f("剪切点清单.json"):
        return dict(P, tab=2, card="s3a", **{"做": "③-A 找剪切点 → 到 ③-B 逐条审删/留",
                    "为什么": "口头禅、停顿、重录、念错都在这一步剪掉"})
    if not f("rough.mp4"):
        return dict(P, tab=2, card="s3d", **{"做": "③-D 执行粗剪出 rough.mp4", "为什么": "清单审完了就该出片"})
    if mt("剪切点清单.json") > mt("rough.mp4"):
        return dict(P, tab=2, card="s3d", **{"做": "③-D 重新执行粗剪", "为什么": "剪切点清单比成片新,现在这版是旧的"})
    if not 交在:
        return dict(P, tab=3, card="s4", **{"做": "生成交接包", "为什么": "把 rough + 分镜 + 对标点位交给第④步"})
    return dict(P, tab=3, card="s4", 完成=True, **{"做": "全齐了:可以发,或去第④步做精包装",
                "为什么": "转写·定稿·分镜·点位·粗剪·交接六样都在(交接=包装交接.md)"})


def action_transcribe(proj, body):
    step_snap(proj, ["转写.json"], "s2")
    m = meta_of(proj)
    if not (m or {}).get("media"):
        return {"error": "还没绑素材:去① 素材卡片粘贴视频绝对路径,点「打开 / 新建项目」就会绑到当前项目"}
    cmd = [PY, SCRIPTS / "transcribe.py", m["media"], "--out", Path(proj) / "转写.json",
           "--model", body.get("model", "small"), "--lang", body.get("lang", "zh")]
    return start_job(proj, cmd, label="转写", timeout=2400)

def make_project(media, name=""):
    m, err = resolve_media_input(media)
    if err: return None, err
    nm = re.sub(r'[\\/:*?"<>|]', "", name or m.stem) or "未命名"
    d = PROJ_ROOT / nm; i = 2
    while (d / "项目.json").exists() and (meta_of(d) or {}).get("media") != str(m.resolve()):
        d = PROJ_ROOT / (nm + "-" + str(i)); i += 1
    d.mkdir(parents=True, exist_ok=True)
    (d / "项目.json").write_text(json.dumps({"media": str(m.resolve()), "name": d.name},
                                            ensure_ascii=False, indent=1), encoding="utf-8")
    return d, ""
def action_delete_project(proj):
    """整个项目目录送进系统回收站(回收站里右键还原即可找回)。
    安全阀:只删「项目」文件夹里面的真项目;任务在跑不许删;路径越界拒绝;失败原因全部打印并回传。"""
    rp = Path(proj)
    try:
        root = PROJ_ROOT.resolve(); rp = rp.resolve()
    except Exception as e:
        print("[删除项目] 路径解析失败: %r" % (e,), flush=True)
        return {"error": "路径不合法: %s" % e}
    if rp == root:
        return {"error": "不能删整个「项目」总目录,只能删里面的单个项目"}
    if root not in rp.parents:
        return {"error": "这个目录不在工作台的「项目」文件夹里,拒绝删除"}
    if not (rp / "项目.json").exists():
        return {"error": "这个目录里没有 项目.json,不是工作台项目,拒绝删除"}
    if job_view(str(rp)).get("status") in ("排队中", "运行中"):
        return {"error": "这个项目还有任务在排队或在跑,先点「停止任务」再删"}
    try:
        from send2trash import send2trash
    except ImportError as e:
        print("[删除项目] 缺 send2trash 库: %r" % (e,), flush=True)
        return {"error": "缺少 send2trash 库(python -m pip install send2trash),为防误删不直接抹掉文件"}
    try:
        send2trash(str(rp))
    except Exception as e:
        print("[删除项目] 送回收站失败: %r" % (e,), flush=True)
        return {"error": "送进回收站失败: %s(可能被别的程序占用,先关掉预览或正在播它的播放器)" % e}
    print("[删除项目] %s → 系统回收站" % rp, flush=True)
    return {"ok": True, "name": rp.name}

def action_refstyle(proj, body):
    """本地量化对标:把参考片的节奏/明暗/配色/响度/语速算成参数,存 对标风格.json。
    用哪条参考片交给 pick_ref_video(手填 > 界面★指定 > 第一条)。"""
    proj = Path(proj)
    refp, 来源, 错 = pick_ref_video(proj, body)
    if 错:
        if (proj / "风格档.json").exists():
            错 += ";没对标也能干:本项目已套风格档「%s」,第④步有风格依据" % ((json.loads((proj / "风格档.json").read_text(encoding="utf-8")).get("名称")) or "?")
        return {"error": 错}
    if not Path(refp).exists(): return {"error": "参考片不存在: " + refp}
    print("[量化对标用哪条] %s [%s]" % (refp, 来源), flush=True)
    cmd = [PY, SCRIPTS / "ref_style.py", refp, "--out", proj / "对标风格.json",
           "--thr", str(body.get("thr", 0.25))]
    if body.get("speech"): cmd.append("--speech")
    tj = proj / "转写.json"
    if tj.exists(): cmd += ["--compare", tj]
    def done():
        sug = style_suggest(proj)
        if sug:
            (proj / "剪辑参数.json").write_text(json.dumps(sug, ensure_ascii=False, indent=1), encoding="utf-8")
    return start_job(proj, cmd, label="量化对标" + ("(含语速)" if body.get("speech") else ""),
                     on_done=done, timeout=2400)

def ref_video_path(proj, body):
    """老契约(路径, 错误)不动,内部转调 pick_ref_video,让拆点位/文字分析共用同一套选片规则。"""
    p, _来源, 错 = pick_ref_video(proj, body)
    return (p, "") if p else (None, 错)


def load_engine():
    """按需导入 ref_shotmap:改分类/写分镜直接调引擎函数,不起子进程。失败必须报原因,不许静默。"""
    if str(SCRIPTS) not in sys.path: sys.path.insert(0, str(SCRIPTS))
    try:
        import ref_shotmap
        return ref_shotmap, ""
    except Exception as e:
        return None, "ref_shotmap 引擎导入失败(看 scripts/ref_shotmap.py 是否被动过): %s" % e


def action_refmap(proj, body):
    """①-D 拆对标点位:切点 -> 分段 -> 抽帧 -> 猜分类 -> 联系表 + 对标点位.csv + 素材需求.csv。"""
    proj = Path(proj)
    refp, err = ref_video_path(proj, body)
    if err: return {"error": err}
    cmd = [PY, SCRIPTS / "ref_shotmap.py", refp, "--proj", proj,
           "--thr", str(body.get("thr") or "0.25"),
           "--per-sheet", str(body.get("per_sheet") or 24)]
    if body.get("max"): cmd += ["--max", str(body["max"])]
    if not body.get("frames", True): cmd.append("--no-frames")
    tj = proj / "转写.json"
    if tj.exists(): cmd += ["--own", tj]
    return start_job(proj, cmd, label="拆对标点位", timeout=1800)


def refmap_state(proj):
    """给①-D 读数:统计 + 每镜(带缩略图URL) + 联系表URL + 素材需求清单路径 + 可选分类表。"""
    proj = Path(proj); f = proj / "对标点位.json"
    E, err = load_engine()
    st = {"has": False, "types": list(getattr(E, "TYPES", ())) if E else [],
          "默认处理方式": dict(getattr(E, "DO", {})) if E else {}}
    if err: st["错误"] = err
    if not f.exists(): return st
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        st["错误"] = "对标点位.json 读不了: %s" % e
        return st
    q = quote(str(proj), safe="")
    rows = []
    for r in d.get("点位") or []:
        rr = dict(r)
        rr["帧URL"] = "/media?dir=%s&name=shotmap&f=%s" % (q, quote(str(r.get("帧图") or ""), safe=""))
        rows.append(rr)
    st.update({"has": True, "对标源": d.get("对标源"), "对标时长": d.get("对标时长"),
               "分析窗口秒": d.get("分析窗口秒"), "统计": d.get("统计") or {}, "点位": rows,
               "联系表": [{"名": n, "URL": "/media?dir=%s&name=shotmap&f=%s" % (q, quote(n, safe=""))}
                        for n in (d.get("联系表") or []) if (proj / "对标点位" / n).exists()],
               "素材需求": str(proj / "素材需求.csv"), "点位CSV": str(proj / "对标点位.csv"),
               "帧目录": str(proj / "对标点位")})
    return st


def refmap_save(proj, rows):
    """把界面改的人工列写回 对标点位.json;分类变了就连带刷新功能/来源/降级,并重出两张 CSV。"""
    E, err = load_engine()
    if err: return {"error": err}
    proj = Path(proj); f = proj / "对标点位.json"
    if not f.exists(): return {"error": "还没有点位表,先点「拆对标点位」"}
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        return {"error": "对标点位.json 读不了: %s" % e}
    by = {str(r.get("镜号")): r for r in (d.get("点位") or [])}
    if not by: return {"error": "点位表里没有行"}
    bad = []
    n = 0
    for inc in rows or []:
        tgt = by.get(str(inc.get("镜号")))
        if not tgt: continue
        my = str(inc.get("我的分类") or "").strip()
        if my and my not in E.TYPES:
            bad.append(str(inc.get("镜号")) + ":" + my); continue
        old_my = tgt.get("我的分类") or ""
        payload_do = str(inc.get("处理方式") or "").strip()
        for c in ("画面需要(你来填)", "关键词候选"):
            if c in inc: tgt[c] = str(inc[c] or "").strip()
        if my and my != old_my:
            E.apply_class(tgt, my)                       # 功能/来源/降级/处理方式 跟着换
            if payload_do and payload_do != E.DO.get(old_my, ""):
                tgt["处理方式"] = payload_do              # 你单独挑过的(如「跳过不学」)保留
        elif payload_do:
            tgt["处理方式"] = payload_do
        n += 1
    if bad: return {"error": "不认识的分类: " + "、".join(bad[:5])}
    step_snap(proj, ["对标点位.json", "对标点位.csv", "素材需求.csv"], "s1")
    allrows = d.get("点位") or []
    needs = E.emit_tables(allrows, proj)
    cnt = {}
    for r in allrows:
        k = r.get("我的分类") or r.get("机器分类") or "待定"
        cnt[k] = cnt.get(k, 0) + 1
    st = d.get("统计") or {}
    st["分类分布"] = cnt; st["需要外部素材"] = needs
    d["统计"] = st
    f.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "改了几行": n, "需要外部素材": needs, "统计": st}


def refmap_storyboard(proj, body):
    """按(人工核对过的)点位表往 分镜.csv 追加镜头;秒数交给「⚓ 按锚点重算时间码」。"""
    E, err = load_engine()
    if err: return {"error": err}
    step_snap(proj, ["分镜.csv"], "s1")
    r, e2 = E.append_storyboard(proj, only_needs=not body.get("all"), force=bool(body.get("force")))
    if e2: return {"error": e2}
    out = {"ok": True, "追加": r["追加"], "跳过口播镜": r["跳过口播镜"], "警告": r.get("警告") or []}
    if not settings().get("自动算秒", True):
        out["自动算秒"] = {"skipped": "开关已关,自己点一次「⚓ 按锚点重算时间码」"}
    elif not (Path(proj) / "转写.json").exists():
        out["自动算秒"] = {"skipped": "还没转写,算不了秒数——转完再点一次"}
    else:
        r2 = action_anchors(proj, {})
        out["自动算秒"] = ({"error": r2["error"]} if r2.get("error")
                        else {"统计": r2.get("统计"), "警告": r2.get("警告") or [], "基准": r2.get("基准")})
        if r2.get("警告"): out["警告"] = (out["警告"] + r2["警告"])[:40]
    sb = Path(proj) / "分镜.csv"
    if sb.exists(): out["text"] = sb.read_text(encoding="utf-8-sig")
    return out


def _pipeline(proj, body):
    """转写完成后的自动接力:找点 -> 出片。失败就把原因写进日志,不静默。"""
    r = action_findcuts(proj, {"pause": body.get("pause"), "keepsil": body.get("keepsil"),
                               "fillers": body.get("fillers", "")})
    if r.get("error"):
        _log(job_key(proj), "[自动找点失败] " + r["error"]); return
    r2 = action_render(proj, {"subs": body.get("subs", True), "audio": body.get("audio", True),
                              "fast": body.get("fast", False), "zoom": body.get("zoom")})
    if r2.get("error"): _log(job_key(proj), "[自动出片失败] " + r2["error"])


def run_backup():
    """出片后自动备份小文件(文本成果最耗时,也最容易被误删)。失败只提示,不影响出片。"""
    try:
        r = subprocess.run([PY, SCRIPTS / "backup_small.py", "--quiet"], capture_output=True,
                           text=True, encoding="utf-8", errors="replace", timeout=120)
        if r.returncode: return {"error": (r.stderr or r.stdout)[-200:]}
        return {"ok": True}
    except Exception as e:
        return {"error": str(e)}

def action_batch(body):
    """日更批量:一次丢多条素材,每条建项目并排队跑完整链路。"""
    files = []
    for x in (body.get("paths") or body.get("files") or []):
        x = str(x).strip().strip('"')
        if not x: continue
        q = Path(x)
        if q.is_dir():
            files += sorted([str(f) for f in q.iterdir()
                             if f.suffix.lower() in VIDEO_EXT and f.is_file()])
        else:
            files.append(str(q))
    if not files: return {"error": "没有收到素材:填绝对路径(一行一条)或一个素材文件夹路径"}
    ok, skip = [], []
    for f in files:
        m = Path(str(f).strip())
        if m.suffix.lower() not in VIDEO_EXT:
            skip.append(m.name + "(不是视频)"); continue
        d, err = make_project(m)
        if not d: skip.append(m.name + "(" + err + ")"); continue
        cmd = [PY, SCRIPTS / "transcribe.py", meta_of(d)["media"], "--out", d / "转写.json",
               "--model", body.get("model", "small")]
        r = start_job(d, cmd, label="一键成片:转写",
                      on_done=(lambda dd=d, bb=body: _pipeline(dd, bb)), timeout=3600)
        (ok if r.get("ok") else skip).append(d.name if r.get("ok") else d.name + "(" + r.get("error", "") + ")")
    return {"ok": True, "已排队": ok, "跳过": skip}

def backup_cuts(proj):
    cur = Path(proj) / "剪切点清单.json"
    if cur.exists():
        shutil.copyfile(cur, Path(proj) / "剪切点清单.prev.json")

def style_suggest(proj):
    """风格建议来源两级:① 对标量化算出的 对标风格.json;② 没对标就退到项目套的 风格档.json。
    两样都没有才返回空(=沿用界面手动值)。读不了必须打印原因,不许静默。"""
    f = Path(proj) / "对标风格.json"
    if f.exists():
        try:
            s = json.loads(f.read_text(encoding="utf-8")).get("建议") or {}
            if s: return s
        except Exception as e:
            print("[对标风格.json 读不了] %s: %r" % (f, e))
    return stylepack_suggest(proj)


def stylepack_suggest(proj):
    """项目套过风格档就给那档的「建议」数值,没套返回空。"""
    f = Path(proj) / "风格档.json"
    if not f.exists(): return {}
    try:
        return json.loads(f.read_text(encoding="utf-8")).get("建议") or {}
    except Exception as e:
        print("[项目风格档.json 读不了] %s: %r" % (f, e))
        return {}


FAB_STYLE = WF / "风格档.json"          # 出厂风格档库(随包更新,内容作者维护)
必备包装键 = ("切镜", "转场", "包装", "字幕", "调色", "音频")


def style_packs():
    """读出厂风格档库 -> {档名: 内容}。库缺失/坏/空一律打印原因并回空dict。"""
    if not FAB_STYLE.exists():
        print("[风格档库缺失] 找不到 %s" % FAB_STYLE)
        return {}
    try:
        d = json.loads(FAB_STYLE.read_text(encoding="utf-8"))
    except Exception as e:
        print("[风格档库读不了] %s: %r" % (FAB_STYLE, e))
        return {}
    出 = {}
    for x in d.get("风格档") or []:
        名 = str(x.get("名称") or "").strip()
        if not 名:
            print("[风格档跳过一条] 缺「名称」: %s" % str(x)[:60]); continue
        if not (x.get("建议") or {}):
            print("[风格档跳过一条] %s 缺「建议」数值" % 名); continue
        缺 = [k for k in 必备包装键 if not x.get(k)]
        if 缺:
            print("[风格档警告] %s 缺字段: %s" % (名, "、".join(缺)))
        出[名] = x
    if not 出: print("[风格档库是空的] %s" % FAB_STYLE)
    return 出


def stylepack_state(proj):
    """界面用:出厂有哪几档(带简介) + 本项目现在套的哪档(带回填数值) + 对标在不在。"""
    库 = style_packs()
    简介 = {}
    for 名, x in 库.items():
        简介[名] = {"适用": x.get("适用") or "", "不适用": x.get("不适用") or "", "说明": x.get("说明") or "",
                   "档位": x.get("档位") or "natural",
                   "切镜": x.get("切镜") or {}, "转场": x.get("转场") or {},
                   "包装码": [str(b.get("码") or "?") for b in (x.get("包装") or [])],
                   "建议": x.get("建议") or {}}
    cur = {}
    f = Path(proj) / "风格档.json"
    if f.exists():
        try:
            cur = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            print("[项目风格档.json 读不了] %s: %r" % (f, e))
    return {"可选": list(库.keys()), "简介": 简介,
            "已套": cur.get("名称") or "", "档位": cur.get("档位") or "",
            "套用时间": cur.get("套用时间") or "", "建议": cur.get("建议") or {},
            "包装码": [str(b.get("码") or "?") for b in (cur.get("包装") or [])],
            "对标在": bool((Path(proj) / "对标风格.json").exists())}


def action_stylepack(proj, body):
    """①-C 无对标的替代入口:把一档出厂风格档整套写进项目 风格档.json,并回填 剪辑参数.json。
    档名不存在/库读不了都明着报错回界面,绝不静默退回默认档。"""
    proj = Path(proj)
    名 = str(body.get("档") or "").strip()
    库 = style_packs()
    if not 库: return {"error": "风格档库读不了(缺文件或 JSON 坏了): %s" % FAB_STYLE}
    if not 名: return {"error": "没说要套哪档;可选: " + "、".join(库)}
    if 名 not in 库: return {"error": "没这个档: %s;可选: %s" % (名, "、".join(库))}
    内 = 库[名]
    写 = {"名称": 名, "来源": "出厂风格档", "套用时间": time.strftime("%Y-%m-%d %H:%M:%S"),
          "档位": 内.get("档位") or "natural", "建议": 内.get("建议") or {},
          "说明": 内.get("说明") or "", "适用": 内.get("适用") or "", "不适用": 内.get("不适用") or ""}
    for k in 必备包装键:
        值 = 内.get(k)
        if k == "包装":
            写[k] = 值 if isinstance(值, list) else []
        else:
            写[k] = 值 if isinstance(值, dict) else {}
    写["禁止"] = 内.get("禁止") or []
    (proj / "风格档.json").write_text(json.dumps(写, ensure_ascii=False, indent=1), encoding="utf-8")
    step_snap(proj, ["风格档.json"], "s1")
    if 写["建议"]:
        (proj / "剪辑参数.json").write_text(json.dumps(写["建议"], ensure_ascii=False, indent=1), encoding="utf-8")
    有对标 = (proj / "对标风格.json").exists()
    return {"ok": True, "档": 名, "档位": 写["档位"], "建议": 写["建议"],
            "提示": ("项目里已有量化对标的参数:对标优先,风格档只进交接包做包装补充" if 有对标
                     else "已套:第③步节奏数值与第④步包装都按这档走")}


def _风格档段(proj):
    """把项目套的风格档渲染成交接包一段 markdown;读不了回错误行(不许静默省略)。"""
    f = Path(proj) / "风格档.json"
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        return ["", "! 风格档.json 读不了,第④步按无风格依据处理: " + repr(e)[:200]]
    L = ["", "## 风格档(本项目没登记对标视频,第④步就按这一档执行)", "",
         "- 档名: %s | 节奏档: %s | 套用: %s" % (d.get("名称") or "(没写档名)", d.get("档位") or "?", d.get("套用时间") or "?"),
         "- 这档要的效果: " + (d.get("说明") or "(库里没写)"),
         "- 适用: %s | 不适用: %s" % (d.get("适用") or "?", d.get("不适用") or "?"),
         "",
         "**执行协议(不许只答整体风格,也不许发明下面没有的效果):** 逐镜按「包装」表决定上不上卡;"
         "全片一套字幕、一套转场语言,同一档内所有选择必须一致;要偏离本档任何一条,交付说明里必须写一句为什么;"
         "白名单外的效果一律按《动效包装协议》的降级链处理。", ""]
    q = d.get("切镜") or {}
    if q: L += ["- 切镜节奏: 每分钟 %s 次 | 平均镜头 %s 秒 | 缺画面时: %s" % (
        q.get("每分钟切镜") or "?", q.get("平均镜头秒") or "?", q.get("缺画面时") or "?")]
    z = d.get("转场") or {}
    if z: L += ["- 转场: 默认「%s」| 允许 %s | 上限 %s | 禁止 %s" % (
        z.get("默认") or "硬切", "、".join(z.get("允许") or []) or "无", z.get("上限") or "?", z.get("禁止") or "?")]
    mc = d.get("字幕") or {}
    if mc: L += ["- 字幕: %s | 每行 %s | 样式 %s" % (mc.get("位置") or "?", mc.get("每行") or "?", mc.get("样式") or "?")]
    t = d.get("调色") or {}
    if t: L += ["- 调色: %s | 颗粒 %s | 禁止 %s" % (t.get("倾向") or "?", t.get("颗粒") or "不用", t.get("禁止") or "?")]
    y = d.get("音频") or {}
    if y: L += ["- 音频: %s | 人声 %s" % (y.get("BGM") or "?", y.get("人声") or "直通不动")]
    包 = d.get("包装") or []
    if 包:
        L += ["", "| 码(必须在白名单里) | 用在 | 参数 | 密度上限 |", "|---|---|---|---|"]
        for b in 包:
            L.append("| %s | %s | %s | %s |" % (b.get("码") or "?", b.get("用在") or "?",
                                                b.get("参数") or "?", b.get("密度") or "?"))
    禁 = d.get("禁止") or []
    if 禁: L += ["", "- 本档明令不做: " + " / ".join(禁)]
    s = d.get("建议") or {}
    if s:
        L += ["- 机器已按本档回填的剪辑数值: 停顿剪阈值 %ss / 剪后留呼吸 %ss / 目标切镜 %s 次每分钟 / 跳剪变焦 %s" % (
            s.get("停顿剪阈值秒") or "?", s.get("剪后留呼吸秒") or "?",
            s.get("目标切镜密度") or "?", s.get("跳剪交替变焦") or "?")]
    return L + [""]


def ref_pick_path(proj):
    return Path(proj) / "对标源.json"


def pick_ref_video(proj, body):
    """定这一片用哪条参考视频:手填路径 > 界面★指定的对标源 > 登记列表第一条视频。
    返回 (路径, 来源, 错误)。指定过但文件没了就明说并退回默认。"""
    proj = Path(proj)
    指 = str((body or {}).get("path") or "").strip()
    if 指: return 指, "手填", ""
    f = ref_pick_path(proj)
    if f.exists():
        p = ""
        try:
            p = json.loads(f.read_text(encoding="utf-8")).get("path") or ""
        except Exception as e:
            print("[对标源.json 读不了] %s: %r" % (f, e))
        if p and Path(p).exists(): return p, "界面指定", ""
        if p:
            print("[对标源登记的文件没了] %s → 退回默认第一条视频" % p)
            try: f.unlink()
            except Exception as e: print("[清对标源失败] %r" % e)
    项 = refs_state(proj)
    vids = [x for x in 项["items"] if x.get("kind") == "video"]
    if not vids: return "", "", "先登记一条参考视频(只吃视频,截图算不出节奏与切点)"
    p = vids[0].get("path") or str(Path(项["folder"]) / vids[0]["name"])
    return p, "默认第一条", ""


def action_refpick(proj, body):
    """①-C 库里囤了多条参考片时,由人点名这一片用哪条做对标(以前只吃「登记的第一条」,顺序一变就用错片)。
    path 传空=取消指定,退回默认第一条视频。"""
    proj = Path(proj)
    p = str(body.get("path") or "").strip()
    f = ref_pick_path(proj)
    if not p:
        if f.exists():
            try: f.unlink()
            except Exception as e: return {"error": "取消指定失败: %r" % e}
        return {"ok": True, "对标源": "", "提示": "已取消指定,回到默认:登记列表第一条视频"}
    if not Path(p).exists(): return {"error": "文件不存在: " + p}
    项 = refs_state(proj)
    认 = ""
    for x in 项["items"]:
        if x.get("kind") != "video": continue
        全 = str(x.get("path") or (Path(项["folder"]) / x["name"]))
        if os.path.normcase(str(Path(全))) == os.path.normcase(str(Path(p))): 认 = 全; break
    if not 认: return {"error": "这条不在本项目的对标参考里,先在 ①-C 登记: " + p}
    f.write_text(json.dumps({"path": 认, "时间": time.strftime("%Y-%m-%d %H:%M:%S")},
                            ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "对标源": Path(认).name, "提示": "量化对标与拆点位都改用这一条"}


def action_findcuts(proj, body):
    step_snap(proj, ["剪切点清单.json"], "s3")
    backup_cuts(proj)
    tj = Path(proj) / "转写.json"
    if not tj.exists(): return {"error": "先完成第②步转写"}
    cmd = [PY, SCRIPTS / "find_cuts.py", tj, "--out", Path(proj) / "剪切点"]
    extra = body.get("fillers", "").strip()
    if extra: cmd += ["--fillers", extra]
    sense = {"紧节奏(短视频)": "tight", "紧节奏(智能剪口播)": "tight", "自然口播": "natural", "高级感(留呼吸)": "calm"}.get(
        body.get("preset", ""), body.get("preset", "") or "natural")
    if sense not in ("tight", "natural", "calm"): sense = "natural"
    cmd += ["--sense", sense]
    sug = style_suggest(proj)
    pause = body.get("pause") or sug.get("停顿剪阈值秒") or 1.0
    keepsil = body.get("keepsil") or sug.get("剪后留呼吸秒") or 0.45
    cmd += ["--pause", str(pause), "--keepsil", str(keepsil)]
    p = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode: return {"error": (p.stderr or p.stdout)[-800:]}
    tmpj = Path(proj) / "剪切点.剪切点.json"; tmpc = Path(proj) / "剪切点.剪切点.csv"
    cj = Path(proj) / "剪切点清单.json"; cc = Path(proj) / "剪切点清单.csv"
    # 保留人工决定:重跑找点不覆盖用户改过的删/留,手动标记的补删点自动带回
    if tmpj.exists() and cj.exists():
        try:
            oldd = json.loads(cj.read_text(encoding="utf-8"))
            old_cuts = oldd.get("cuts", [])
            # 只有同一档位才沿用旧「执行」;换档(自然→高级感)必须让新档的默认值生效,
            # 否则上一档的机器默认会把这一档的从严判定顶回去(C0584 高级感切换失效事故)。
            # 真正被人工改过的行(带「人工」标记)任何档位都沿用。
            同档 = oldd.get("档位") == sense
            old_map = {(c.get("类型"), c.get("文字")): c for c in old_cuts}
            manual = [c for c in old_cuts if c.get("类型") in ("手动标记", "手动补剪")]
            newd = json.loads(tmpj.read_text(encoding="utf-8"))
            have = {c.get("文字") for c in newd.get("cuts", [])}
            for c in newd.get("cuts", []):
                o = old_map.get((c.get("类型"), c.get("文字")))
                if o and (o.get("人工") or 同档):
                    c["执行"] = o.get("执行", c.get("执行"))
                    if o.get("人工"): c["人工"] = "1"   # 人工标记要一路带着走,否则下次重跑就认不出来
            for c in manual:
                if c.get("文字") not in have: newd.setdefault("cuts", []).append(c)
            newd["cuts"].sort(key=lambda c: c["开始"])
            for i, c in enumerate(newd["cuts"], 1): c["序号"] = i
            newd["档位"] = sense
            tmpj.write_text(json.dumps(newd, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception: pass
    if tmpj.exists():
        try:
            nd = json.loads(tmpj.read_text(encoding="utf-8"))
            if nd.get("档位") != sense:
                nd["档位"] = sense
                tmpj.write_text(json.dumps(nd, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as ex:
            print("档位标记写入失败(不影响清单,但换档时无法判断该不该沿用旧删留):", ex)
        tmpj.replace(cj)
    if tmpc.exists(): tmpc.replace(cc)
    return {"ok": True, "file": str(cj)}

def sense_from(body):
    """把界面「节奏预设」的中文名或英文档位归一成 tight/natural/calm;没选=自然档"""
    v = (body.get("preset") or "").strip()
    return {"紧节奏(短视频)": "tight", "紧节奏(智能剪口播)": "tight", "自然口播": "natural", "高级感(留呼吸)": "calm"}.get(v, v or "natural")


def action_render(proj, body):
    cj = Path(proj) / "剪切点清单.json"
    if not cj.exists(): return {"error": "先完成第③步找点"}
    plan = json.loads(cj.read_text(encoding="utf-8"))
    if not plan.get("cuts"): return {"error": "剪切点清单是空的(0条)。先点「找剪切点」再粗剪——防止把未剪的整片或空壳错渲出来"}
    if not plan.get("duration"):
        tj = Path(proj) / "转写.json"
        if tj.exists():
            plan["duration"] = json.loads(tj.read_text(encoding="utf-8")).get("duration", 0)
            cj.write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    mode = body.get("submode") or ("burn" if body.get("subs", True) else "off")
    mode = {"烧": "burn", "轴": "axis", "不": "off"}.get(mode, mode)
    if mode not in ("burn", "axis", "off"): mode = "burn"
    cmd = [PY, SCRIPTS / "render_cut.py", cj, "--out", Path(proj) / "rough.mp4",
           "--subs", {"burn": "auto", "axis": "axis", "off": "off"}[mode]]
    if not body.get("audio", True): cmd += ["--audio", "off"]
    if body.get("repair"): cmd += ["--repair", "on"]
    if body.get("fast"): cmd += ["--fast"]
    if body.get("repair"): cmd += ["--repair", "on"]
    cmd += ["--zoom", str(body.get("zoom") or 1)]   # 缺省=1(关闭):用户要求画面绝不缩放;想防跳脸可手动填1.06
    # tight=智能剪口播档:接缝呼吸补齐下限 0——找点已整段剪秃,再补齐等于把呼吸塞回去
    breath = {"tight": "0.0", "natural": "0.30", "calm": "0.35"}.get(sense_from(body), "0.30")
    cmd += ["--breath", breath]
    LABEL = {"burn": "字幕已烧进画面", "axis": "字幕未烧,只出时间轴(交给第④步做动画)", "off": "本条不出字幕"}[mode]

    def done():
        (Path(proj) / "渲染记录.json").write_text(json.dumps(
            {"字幕": LABEL, "模式": mode, "时间": time.strftime("%Y-%m-%d %H:%M:%S")},
            ensure_ascii=False, indent=1), encoding="utf-8")
        b = run_backup()
        _log(job_key(proj), "[自动备份] " + ("文本成果已存进工作流的「备份」目录" if b.get("ok") else "失败:" + b.get("error", "")))
    return start_job(proj, cmd, label="粗剪出片·" + {"burn": "烧字幕", "axis": "只出时间轴", "off": "无字幕"}[mode],
                     on_done=done, timeout=5400)

def fmt_t(t):
    t = float(t); mm = int(t // 60); return f"{mm:02d}:{t - mm*60:04.1f}"

def run_anchors(proj):
    """跑 anchor_time.py:分镜表的口播锚点 -> 成片时间码。返回 (日志, 报告dict, 返回码)"""
    cmd = [str(PY), str(SCRIPTS / "anchor_time.py"), str(proj)]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    rep_f = Path(proj) / "分镜时间轴.json"
    data = None
    if rep_f.exists():
        try: data = json.loads(rep_f.read_text(encoding="utf-8"))
        except Exception: data = None
    return ((p.stdout or "") + (p.stderr or "")).strip(), data, p.returncode

def action_anchors(proj, body):
    sb = Path(proj) / "分镜.csv"
    if not sb.exists(): return {"error": "①-B 还没有分镜表:先写镜头表(每行的「锚点」列或「字幕文本」列至少有一个能定位)"}
    if not (Path(proj) / "转写.json").exists(): return {"error": "先完成第②步转写,锚点要靠逐词时间戳定位"}
    log, data, rc = run_anchors(proj)
    if rc != 0: return {"error": log[-600:] or "锚点换算失败"}
    if data is None:
        return {"error": "锚点算完了但 分镜时间轴.json 读不出来(报告文件坏的):重跑一次 ⚓,还不行看启动日志"}
    镜 = data.get("镜") or []
    if not 镜:
        return {"error": "分镜表读到了,但一行镜头都没算出时间码——多半是表填歪了:每行要用英文逗号分成列,"
                         "且「锚点」或「字幕文本」至少一列能对上你说过的话。随口讲的话别写进这张表,"
                         "放上方讲述框按「⚡ 讲述转分镜」生成。"}
    st = (data or {}).get("统计") or {}
    return {"ok": True, "log": log, "统计": st, "警告": (data or {}).get("警告", []),
            "基准": (data or {}).get("换算基准", ""), "总时长": (data or {}).get("成片总时长")}
def _协议节选():
    """从工作流根的《动效包装协议.md》裁「书写语法+能力白名单」两节,嵌进 包装交接.md。
    返回 (正文, 问题):文件没了或节标题找不到就问题非空——交接包里必须写明,不许静默降级。"""
    pf = WF / "动效包装协议.md"
    if not pf.exists():
        return "", "工作流根没有《动效包装协议.md》(旧版安装或更新没装全)"
    try:
        raw = pf.read_text(encoding="utf-8")
    except Exception as e:
        print("[动效协议读取失败] %r" % e)
        return "", "《动效包装协议.md》读不出来:%r" % e
    a = raw.find("## 一、")
    b = raw.find("## 三、")
    if a < 0 or b < 0 or b <= a:
        return "", "《动效包装协议.md》里找不到「## 一、」或「## 三、」标题,裁不出语法与白名单"
    return raw[a:b].rstrip(), ""


def _handoff_ai(proj, body):
    proj = Path(proj)
    m = meta_of(proj)
    tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成第②步转写"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    rough = proj / "rough.mp4"
    lines = ["# 包装交接包(口播工作台生成)", "",
             f"- 粗剪成片: {rough if rough.exists() else str(m['media']) + '(尚未粗剪,先跑第③步)'}",
             f"- 素材总时长: {data.get('duration', 0):.1f}s",
             f"- 语言: {data.get('language', 'zh')}  模型: {data.get('model', '')}", "",
             "## 字幕文本(以实际口播转写为准,第④步上字幕用)", "",
             "| 时间码 | 文本 |", "|---|---|"]
    slf = slim_path(proj)
    if slf.exists():
        tgt = json.loads(slf.read_text(encoding="utf-8")).get("target")
        if tgt: lines.insert(4, f"- 成片时长要求: {tgt} 秒(超出部分必须继续删整段保核心,不能只靠剪停顿)")
    for s in data["segments"]:
        lines.append(f"| {fmt_t(s['start'])}–{fmt_t(s['end'])} | {s['text']} |")
    refs = refs_state(proj)
    if refs["items"]:
        lines += ["", "## 对标风格参考(第④步执行前必看)", "",
                  "AI 执行协议(对标精读,任何能读中文的 AI 均可执行(豆包/Kimi/DeepSeek/ChatGPT/Claude/本地大模型等,协议与执行方品牌无关)),不许只答整体风格):先通看参考片说出它靠什么留人,再对每个要迁移的设计元素逐条回答六件事——"
                  "①内容与外观(字体/字重/颜色/描边/底衬) ②空间位置(占画面哪块、与主体什么关系) ③入场(怎么出现、落在哪个词或哪声音效上) "
                  "④存续期行为(停留时在动什么:逐字点亮/呼吸/位移) ⑤生命周期(活不活得过镜头切换、谁替换它) ⑥退场(消失方式与时长);"
                  "并一句话说明这个选择替观众完成了什么(立人设/对比两个说法/累积证据/放大情绪/让流程可读/把注意力交给下一句)。"
                  "动效名字只是起点,要看路径、缩放与透明度变化、速度、有没有过冲回弹。结论先给「本片照搬哪几项、放弃哪几项及理由」,"
                  "与现有视觉系统冲突处以参考为准,差异一句话告知用户;然后照旧走风格预览门,不许直接渲染。", ""]
        指, 来源, _ = pick_ref_video(proj, {})
        if 指:
            lines += ["- 本片对标源(量化与拆点位实际用的是这条): %s [来源: %s]" % (指, 来源), ""]
        for it in refs["items"]:
            lp = it.get("path") or (Path(refs["folder"]) / it["name"])
            lines.append(f"- {it['kind']} | {lp} | {it.get('note','') or '未写说明:默认整体风格对标'}")
        if (proj / "风格档.json").exists():
            lines += _风格档段(proj)
            lines += ["(上面这档只是补充:登记过对标参考片的地方,一律以对标为准)", ""]
    elif (proj / "风格档.json").exists():
        lines += _风格档段(proj)
    else:
        lines += ["", "## 风格依据(缺!第④步动手前先补这一条)", "",
                  "- 本项目既没登记对标参考片(①-C),也没套风格档(①-C 那排档位按钮):先向用户要一条对标,或请其选一个风格档;",
                  "- 问不到就只出最保守方案:全程硬切 + 关键词词卡 + 下沿字幕(横屏底边留8%/竖屏留20%),"
                  "不加任何转场特效,并在交付说明里写明「无风格依据,按保守方案出」。"]
    rmf = proj / "对标点位.json"
    if rmf.exists():
        try:
            rd = json.loads(rmf.read_text(encoding="utf-8"))
            rrows = rd.get("点位") or []
            rst = rd.get("统计") or {}
            lines += ["", "## 对标点位表(对标每一镜在干什么;只有标「外部素材」的才真要一条画面)", "",
                      "- 拆解范围: 对标前 %ss | 共 %s 镜 | 每分钟切镜 %s | 需要外部素材 %s 个" % (
                          rd.get("分析窗口秒"), rst.get("镜头数"), rst.get("每分钟切镜"), rst.get("需要外部素材")),
                      "- 分类分布: " + " / ".join("%s %d" % (k, v) for k, v in (rst.get("分类分布") or {}).items()),
                      "- **禁止**为了填这些位置去网上下载别人的成片片段。缺素材一律按「处理方式」降级:" +
                      " 自制字卡 / 自制图形卡 / punch-in推镜+音效顶住切点 / 用户自己录屏或手机空镜。",
                      "- 待找清单(逐条,含关键词与来源建议): %s" % (proj / "素材需求.csv"), "",
                      "| 镜 | 对标时间 | 秒 | 最终分类 | 对标在干什么 | 对标处你在说什么 | 要放什么画面 | 关键词 | 怎么处理 |",
                      "|---|---|---|---|---|---|---|---|---|"]
            for r in rrows[:150]:
                lines.append("| %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
                    r.get("镜号", ""), r.get("时间码", ""), r.get("时长", ""),
                    r.get("我的分类") or r.get("机器分类", ""), str(r.get("功能猜测", ""))[:34],
                    str(r.get("对标处口播", ""))[:26], str(r.get("画面需要(你来填)", ""))[:20],
                    str(r.get("关键词候选", ""))[:18], str(r.get("处理方式", ""))[:24]))
            if rd.get("联系表"):
                lines += ["", "缩略图联系表(要看对标画面就看这些): " +
                          "、".join(str(proj / "对标点位" / n) for n in rd["联系表"])]
        except Exception as e:
            lines += ["", "! 对标点位.json 读不了,第④步按无点位表处理: " + str(e)]
    ast = assets_state(proj)
    if ast["items"]:
        lines += ["", "## 已提供素材清单(第④步直接用,勿再生成)", ""]
        for it in ast["items"]:
            lp = it.get("path") or (Path(ast["folder"]) / it["name"])
            lines.append(f"- {it['kind']} | {it.get('shot','') or '未标镜号'} | {lp}")
    wd = proj / "文案定稿.txt"
    if wd.exists():
        lines += ["", "## 文案定稿(用户亲自校对确认,字幕以此为准)", "", wd.read_text(encoding="utf-8").strip()]
    sb = proj / "分镜.csv"
    if sb.exists():
        alog, ax, arc = run_anchors(proj)
        if arc != 0:
            lines += ["", "## 分镜镜头表(第①步整理结果,图片/视频/动效按此插入)", "",
                      "> ! 锚点换算失败,时间码可能是旧的:" + alog[-300:], "",
                      sb.read_text(encoding="utf-8").strip()]
        else:
            st = (ax or {}).get("统计") or {}
            lines += ["", "## 分镜镜头表(时间码已由锚点自动换算,**勿手改秒数**;要挪位置就改锚点词再重算)", ""]
            if ax:
                lines += ["- 换算基准: %s | 成片总时长 %.1fs | 时间轴: %s" % (
                    ax.get("换算基准", "?"), float(ax.get("成片总时长") or 0), ax.get("轴", "?")),
                    "- 精确 %s / 待确认 %s / 未换算 %s" % (st.get("精确", 0), st.get("待确认", 0), st.get("未换算", 0))]
            lines += ["", sb.read_text(encoding="utf-8").strip()]
            if ax and ax.get("镜"):
                lines += ["", "### 锚点命中明细(第④步按「成片」列落位;每镜同时给源片时刻,便于回原片找画面)", "",
                          "| 镜号 | 锚点 | 实际命中词 | 成片 | 源片 | 状态 |", "|---|---|---|---|---|---|"]
                for r in ax["镜"]:
                    if "成片起" not in r: continue
                    lines.append("| %s | %s | %s | %s–%s | %s | %s |" % (
                        r.get("镜号", ""), r.get("锚点", ""), r.get("命中", ""),
                        fmt_t(r["成片起"]), fmt_t(r["成片止"]),
                        fmt_t(r["源起"]) if r.get("源起") is not None else "?", r.get("状态", "")))
            if ax and ax.get("警告"):
                lines += ["", "**需要你确认(%d 条,交接前处理掉;不做则第④步按现值执行)**" % len(ax["警告"])]
                lines += ["- " + w for w in ax["警告"]]
    rec = Path(proj) / "渲染记录.json"
    rj = json.loads(rec.read_text(encoding="utf-8")) if rec.exists() else {}
    tl = proj / "字幕时间轴.json"
    lines += ["", "## 字幕归属(先看这条,别叠两层)", ""]
    if rj.get("模式") == "axis":
        lines += ["- **底层画面没有字幕**:字幕由第④步负责做动画。",
                  "- 逐字时间轴:`%s`(每行含每个字的起止秒,已按成片轴换算 + 静音开口校正)" % (tl if tl.exists() else "缺,先回③重跑一次"),
                  "- 硬要求:**不要自行重新断句、不要重新估时间**,直接按 JSON 里的 起/止 驱动入场;",
                  "  字体/字号/下沿/配色照 JSON 里的 字体、字号px、下沿比例、字色、强调色 用,保持和直出版一致。" % ()]
    elif rj.get("模式") == "off":
        lines += ["- 本次渲染**不出字幕**,画面干净。第④步若要加字,自行按分镜与文案定稿处理。"]
    elif rj.get("模式") == "burn":
        lines += ["- **底层画面已经烧好字幕(思源宋体/无描边无阴影/逐字点亮)**:",
                  "  第④步**禁止再加一层字幕**,否则会双层叠字糊掉;",
                  "  要改字幕样式或换成动画字幕,请回③把字幕模式改成「只出时间轴」再重渲,不要在这里盖。",
                  "- 本步只做增量包装:花字、人名条、金句卡、B-roll、封面、竖屏裁切。"]
    else:
        lines += ["- 没找到 渲染记录.json:不确定字幕是否已烧。先看一眼 rough.mp4 有没有字,再决定第④步要不要加字幕。"]
    lines += ["", "## 第④步说明", "",
              "这一步是可选精包装:把本文件整段贴给任何能读中文的 AI(豆包/Kimi/DeepSeek/ChatGPT/Claude/本地大模型等均可),让它按分镜表逐镜给花字/人名条/金句卡建议;",
              "你也可以忽略 AI、直接在剪映里手动补,功能不受影响;不做第④步,粗剪本身就能发。"]
    协议文, 协议问题 = _协议节选()
    if 协议文:
        lines += ["", "## 动效白名单与书写语法(第④步执行方必读:「动效/包装」列照此语法执行;白名单外的效果按各条降级链处理,不许发明)", "",
                  协议文]
    else:
        print("[交接包缺协议] %s" % 协议问题)
        lines += ["", "## 动效白名单(缺失!第④步不许自创效果)", "",
                  "! 交接包没能嵌入《动效包装协议》:" + 协议问题,
                  "  补救:点顶栏「一键更新」装到最新版后重新生成交接包;装不了就按「动效包装」列原话执行,别发明新动效。"]
    lines += ["",
              "## 读分镜表的口径(必须照此理解)", "",
              "- 「画面内容」列只有五种标准词(口播正面/空镜/录屏/图形卡/大字卡)是机器认过的;"
              "**其余一格若是一整句大白话,那是作者原话,不是填错**——按语义自己推该上什么画面、字卡、动效,"
              "不许反问格式、不许因为看不懂就跳过这一镜。",
              "- 「备注」列是机器交代它做了什么、哪里没对上:锚点标了「按某某对到了这句」=机器猜的定位,和原话不符就以你的意思为准改锚点。",
              "- 秒数(时间码列)由锚点换算,已定的不许重估;要挪位置只改锚点词再重算。",
              "- 若本文件里有对标镜头拆解/点位表,请把它当作**切镜节奏与字卡密度的参照**,而不是照抄对标的内容:",
              "  对标告诉你「多久切一次、哪里该压一张卡」,你自己的分镜告诉你「这一镜要说什么」;两者矛盾时按你的,并在交付说明里写一句为什么。",
              "- 最终产出:与本表同表头的一行一镜 CSV(镜号,时间码(成片·自动),锚点,字幕文本(校对版),画面内容,素材文件,动效包装,备注),"
              "英文逗号分列;画面内容可写标准五词,也可写得更具体(如「图形卡:1100→1200 分数区间条」),动效包装写「转场:名字|秒」。"]
    _ids = _ideas_lines(proj)
    if _ids:
        lines += ["", "## 你的包装要求(①-B 想法箱原话,逐条处理:照做,或不照做必须写一句理由,不许无视)", ""]
        lines += ["- " + x for x in _ids]
        lines += ["", "(以上是人亲自提的意图,优先级高于执行方自己的审美偏好;与画面/字幕冲突时按此调整并在交付说明里讲一句)"]
    out = proj / "包装交接.md"
    out.write_text("\n".join(lines), encoding="utf-8")
    return {"ok": True, "file": str(out)}

ASSET_EXT = {"jpg","jpeg","png","webp","gif","bmp","mp4","mov","m4v","avi","mkv","mp3","wav","m4a"}

def action_handoff(proj, body):
    """④ 生成交接包:出 包装交接.md(给对话AI/HyperFrames 干活的工单)。
    剪映交接(本机建草稿工程)已于 0.14 下线——界面不再给入口,老页面误传直接拒。
    本步当场同步跑完、不占任务队列(顶栏「队列空闲」属正常)——开始与结果都记运行日志,售后可追溯。"""
    to = (body or {}).get("to") or "ai"
    if to != "ai":
        slog("交接包拒收", proj, "to=%s(剪映交接已下线)" % to)
        return {"退回": "剪映交接功能已下线,现在只出 AI 交接:生成 包装交接.md 贴给对话AI执行"}
    t0 = time.time()
    slog("交接包开始", proj, "目标=ai(同步执行,不占任务队列)")
    out = _handoff_ai(proj, body)
    错 = str(out.get("error") or "")
    slog("交接包结束", proj, "完成 %.1fs %s" % (time.time() - t0,
         ("失败:" + 错[:100]) if 错 else "包装交接.md 已出"))
    return out


def assets_state(proj):
    proj = Path(proj); folder = proj / "素材"; items = []
    if folder.exists():
        for f in sorted(folder.iterdir()):
            if f.suffix.lower().lstrip(".") in ASSET_EXT:
                kind = "video" if f.suffix.lower() in (".mp4", ".mov", ".m4v", ".avi", ".mkv") else ("audio" if f.suffix.lower() in (".mp3", ".wav", ".m4a") else "image")
                items.append({"name": f.name, "src": "folder", "kind": kind, "size_kb": f.stat().st_size // 1024})
    reg = proj / "素材登记.json"
    if reg.exists():
        for r in json.loads(reg.read_text(encoding="utf-8")):
            if Path(r["path"]).exists():
                kind = "video" if Path(r["path"]).suffix.lower() in (".mp4", ".mov", ".m4v") else "image"
                items.append({"name": Path(r["path"]).name, "src": "external", "kind": kind, "path": r["path"],
                              "shot": r.get("shot", ""), "note": r.get("note", "")})
    return {"folder": str(folder), "items": items}

REF_EXT = {"jpg","jpeg","png","webp","gif","mp4","mov","m4v"}

def refs_state(proj):
    """对标参考列表。附带标出哪一条是界面★指定的对标源(囤多条时得让人看清这一片到底在用哪条)。"""
    proj = Path(proj); folder = proj / "参考"; items = []
    指 = ""
    pf = ref_pick_path(proj)
    if pf.exists():
        try: 指 = json.loads(pf.read_text(encoding="utf-8")).get("path") or ""
        except Exception as e: print("[对标源.json 读不了] %r" % e)
    认 = os.path.normcase(str(Path(指))) if 指 else ""
    if folder.exists():
        for f in sorted(folder.iterdir()):
            if f.suffix.lower().lstrip(".") in REF_EXT:
                kind = "video" if f.suffix.lower() in (".mp4",".mov",".m4v") else "image"
                items.append({"name": f.name, "src": "folder", "kind": kind, "path": str(f),
                              "pick": bool(认) and os.path.normcase(str(f)) == 认})
    reg = proj / "参考登记.json"
    if reg.exists():
        for i, r in enumerate(json.loads(reg.read_text(encoding="utf-8"))):
            if Path(r["path"]).exists():
                kind = "video" if Path(r["path"]).suffix.lower() in (".mp4",".mov",".m4v") else "image"
                items.append({"name": Path(r["path"]).name, "src": "external", "idx": i, "kind": kind,
                              "path": r["path"], "note": r.get("note",""),
                              "pick": bool(认) and os.path.normcase(str(Path(r["path"]))) == 认})
    return {"folder": str(folder), "items": items, "对标源": 指 if any(x.get("pick") for x in items) else ""}

def poster_file(proj, name):
    d = Path(proj) / ".封面"; d.mkdir(exist_ok=True)
    safe = "".join(ch for ch in name if ch not in '\\/:*?"<>|')
    return d / (safe + ".jpg")

def make_poster(src, dst):
    """ffmpeg 抽一帧做封面:先试第1秒,失败回退首帧(短视频/异常时间戳)"""
    for ss in (["-ss", "1"], []):
        r = subprocess.run(["ffmpeg", "-y", "-v", "error"] + ss + ["-i", str(src),
                        "-frames:v", "1", "-vf", "scale=320:-2", str(dst)], capture_output=True, text=True)
        if r.returncode == 0 and dst.exists() and dst.stat().st_size > 500:
            return True
        dst.unlink(missing_ok=True)
    return False

def resolve_media(proj, kind, fname, abspath):
    proj = Path(proj)
    if abspath:
        reg = proj / ("参考登记.json" if kind == "ref" else "素材登记.json")
        lst = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else []
        for r in lst:
            if str(Path(r["path"]).resolve()) == str(Path(abspath).resolve()):
                return Path(r["path"])
        return None
    safe = Path(fname or "").name
    base = proj / ("参考" if kind == "ref" else "素材")
    fp = base / safe
    return fp if fp.exists() and str(fp.resolve()).startswith(str(base.resolve())) else None


def action_remove_media(proj, kind, fname="", abspath=""):
    """素材库/对标参考单条删除(2026-10-28 新增:之前只能进不能删)。
    外部登记(登记表里的原文件)=只解除登记,不碰原文件;
    项目「素材」「参考」文件夹里的真文件=送系统回收站,右键还原可找回。
    安全阀:路径一律经 resolve_media 验证在本项目文件夹内;失败原因全部回传打印。"""
    projp = Path(proj)
    regname = "参考登记.json" if kind == "ref" else "素材登记.json"
    reg = projp / regname
    if abspath:
        target = str(Path(abspath).resolve())
        lst = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else []
        keep = [x for x in lst if str(Path(x["path"]).resolve()) != target]
        if len(keep) == len(lst):
            return {"error": "这个文件不在本项目登记列表里: %s" % target}
        reg.write_text(json.dumps(keep, ensure_ascii=False, indent=1), encoding="utf-8")
        try:
            poster_file(projp, Path(target).name).unlink(missing_ok=True)
        except Exception as e:
            print("[删除素材] 清封面缓存失败: %r" % (e,), flush=True)
        print("[删除素材] 解登记: %s" % target, flush=True)
        return {"ok": True, "mode": "解登记", "name": Path(target).name}
    fp = resolve_media(proj, kind, fname, "")
    if not fp:
        return {"error": "文件不在本项目文件夹里或已被删: %s" % fname}
    try:
        from send2trash import send2trash
    except ImportError as e:
        print("[删除素材] 缺 send2trash 库: %r" % (e,), flush=True)
        return {"error": "缺少 send2trash 库(python -m pip install send2trash),为防误删不直接抹掉文件"}
    try:
        send2trash(str(fp))
    except Exception as e:
        print("[删除素材] 送回收站失败: %r" % (e,), flush=True)
        return {"error": "送进回收站失败: %s(可能被播放器或预览占用,先关掉再删)" % e}
    # 登记表里若还留着这条路径(例如收编后的遗留记录),顺手删掉,防止悬空引用
    if reg.exists():
        try:
            lst = json.loads(reg.read_text(encoding="utf-8"))
            keep = [x for x in lst if str(Path(x["path"]).resolve()) != str(fp.resolve())]
            if len(keep) != len(lst):
                reg.write_text(json.dumps(keep, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            print("[删除素材] 同步登记表失败: %r" % (e,), flush=True)
    try:
        poster_file(projp, fp.name).unlink(missing_ok=True)
    except Exception as e:
        print("[删除素材] 清封面缓存失败: %r" % (e,), flush=True)
    print("[删除素材] %s → 系统回收站" % fp, flush=True)
    return {"ok": True, "mode": "回收站", "name": fp.name}

SCOPE_FILES = {
    "storyboard": ["分镜.csv"],
    "script": ["文案定稿.txt", "script_state.json"],
    "transcribe": ["转写.json"],
    "style": ["对标风格.json", "剪辑参数.json", "字幕.ass", "字幕.srt", "字幕时间轴.json"],
    "cuts": ["剪切点清单.json", "剪切点清单.csv", "剪切点清单.prev.json", "剪切点清单_1分钟版.json",
             "rough_预览.mp4", "字幕.ass", "字幕.srt", "字幕时间轴.json", "渲染记录.json",
             "auto_edit_request.json", "auto_edit_result.json", "rough.mp4", "rough_1分钟.mp4",
             "精简取舍.json", "剪切点.剪切点.json", "剪切点.剪切点.csv"],
    "handoff": ["包装交接.md", "风格预览", "1分钟版决策.md"],
    "shotmap": ["对标点位.json", "对标点位.csv", "素材需求.csv", "对标点位"],
    "textstyle": ["对标文字.json", "文字效果报告.md", "文字方案.json", "文字效果执行卡.md", "对标文字块"],
    "stylepack": ["风格档.json", "剪辑参数.json", "对标源.json"],
}
SCOPE_FILES["all"] = [x for k in ("storyboard","script","transcribe","style","stylepack","shotmap","textstyle","cuts","handoff") for x in SCOPE_FILES[k]]

def trash_paths(proj):
    tr = Path(proj) / ".trash"; tr.mkdir(exist_ok=True)
    idx = tr / "index.json"
    stack = json.loads(idx.read_text(encoding="utf-8")) if idx.exists() else []
    return tr, idx, stack

def step_snap(proj, files, scope):
    """关键修改前给现状拍快照,支持每步连续撤回;同一步最多留 15 版,旧的自动清理"""
    proj = Path(proj)
    exist = [f for f in files if (proj / f).exists()]
    if not exist: return
    try:
        tr, idx, stack = trash_paths(proj)
        snap = tr / ("step-%s-%d" % (scope, int(time.time() * 1000)))
        snap.mkdir()
        for f in exist:
            shutil.copyfile(proj / f, snap / f)
        stack.append({"type": "step", "scope": scope, "snap": snap.name, "files": exist})
        # 每 scope 只留最近 15 版
        mine = [e for e in stack if e.get("type") == "step" and e.get("scope") == scope]
        for old in mine[:-15]:
            shutil.rmtree(tr / old["snap"], ignore_errors=True)
            stack.remove(old)
        idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass

def step_undo(proj, scope):
    proj = Path(proj); tr, idx, stack = trash_paths(proj)
    pos = next((i for i in range(len(stack) - 1, -1, -1)
                if stack[i].get("type") == "step" and stack[i].get("scope") == scope), None)
    if pos is None: return {"error": "这一步还没有可撤回的修改"}
    e = stack.pop(pos)
    snap = tr / e["snap"]; restored = []
    for n in e["files"]:
        src = snap / n
        if not src.exists(): continue
        if (proj / n).exists():
            (tr / ("conflict-" + e["snap"])).mkdir(exist_ok=True)
            shutil.move(str(proj / n), str(tr / ("conflict-" + e["snap"]) / n))
        shutil.move(str(src), str(proj / n)); restored.append(n)
    idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    shutil.rmtree(snap, ignore_errors=True)
    left = sum(1 for x in stack if x.get("type") == "step" and x.get("scope") == scope)
    return {"ok": True, "restored": restored, "left": left}

def action_reset(proj, scope):
    if scope not in SCOPE_FILES: return {"error": "未知范围"}
    proj = Path(proj); tr, idx, stack = trash_paths(proj)
    names = [n for n in SCOPE_FILES[scope] if (proj / n).exists()]
    if not names: return {"error": "这一步还没有产物,无需重置"}
    import time as _t
    snap = tr / ("reset-" + _t.strftime("%Y%m%d-%H%M%S"))
    snap.mkdir()
    for n in names:
        shutil.move(str(proj / n), str(snap / n))
    stack.append({"scope": scope, "snap": snap.name, "files": names})
    idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "moved": names, "n": len(stack)}

def action_undo_reset(proj):
    proj = Path(proj); tr, idx, stack = trash_paths(proj)
    pos = next((i for i in range(len(stack) - 1, -1, -1) if stack[i].get("type") != "step"), None)
    if pos is None: return {"error": "没有可撤回的重置"}
    top = stack.pop(pos)
    snap = tr / top["snap"]; restored = []
    for n in top["files"]:
        src = snap / n
        if not src.exists(): continue
        if (proj / n).exists():
            cf = tr / ("conflict-" + top["snap"]); cf.mkdir(exist_ok=True)
            shutil.move(str(proj / n), str(cf / n))
        shutil.move(str(src), str(proj / n)); restored.append(n)
    idx.write_text(json.dumps(stack, ensure_ascii=False, indent=1), encoding="utf-8")
    shutil.rmtree(snap, ignore_errors=True)
    return {"ok": True, "restored": restored, "left": len(stack)}

FILL_SET = {"嗯", "呃", "额", "那个", "就是说", "怎么说呢", "对吧", "其实吧", "反正就是"}

def script_state_path(proj): return Path(proj) / "script_state.json"

def load_state(proj, 空=None):
    """读 script_state.json:末尾有垃圾字符也取回第一份完整对象,彻底读不了就退回空进度。
    返回 (状态dict, 提示语)。①-A 每次写回都会顺手把垃圾尾巴清掉(自愈)。"""
    f = script_state_path(proj)
    空 = dict(空 if 空 is not None else {"questions": [], "draft": "", "final": "", "mode": "wenan"})
    if not f.exists(): return 空, ""
    raw = (f.read_text(encoding="utf-8") or "").lstrip()
    try:
        st = json.loads(raw)
    except Exception as e:
        try:
            st, end = json.JSONDecoder().raw_decode(raw)
            余 = len(raw[end:].strip())
            if not isinstance(st, dict): raise ValueError("内容不是对象")
            提 = "script_state.json 末尾多了 %d 个字符,已按前面部分读取;这次保存会写干净" % 余 if 余 \
                else "script_state.json 有格式问题(%s),已按能读的部分恢复" % e
            print("[①-A 状态文件] " + 提)
            return st, 提
        except Exception as e2:
            提 = "script_state.json 读不了(%s):①-A 的删/留问答进度丢了,文案定稿不受影响" % e2
            print("[①-A 状态文件] " + 提)
            return 空, 提
    if not isinstance(st, dict):
        提 = "script_state.json 内容不是对象(是 %s),已按空进度继续" % type(st).__name__
        print("[①-A 状态文件] " + 提)
        return 空, 提
    return st, ""


def script_state(proj):
    """①-A 的问答进度 + 定稿状态;文件坏了也要能出页面,并把原因带到界面上。"""
    st, 提 = load_state(proj)
    if 提: st["文件警告"] = 提
    st.setdefault("adds", [])
    st["has_final"] = (Path(proj) / "文案定稿.txt").exists()
    return st


def script_save_draft(proj, text):
    """切走自动存文案草稿(G1需求:做一半切走要存住,回来还在,再切走再存)。
    只动 draft 字段,不碰问答进度;文件损坏自愈沿用 load_state。"""
    st, 提 = load_state(proj)
    st["draft"] = str(text or "")
    try:
        script_state_path(proj).write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        print("[草稿保存失败] %r" % e)
        return {"error": "草稿没存上:" + repr(e)[:120]}
    out = {"ok": True}
    if 提: out["提示"] = 提
    return out


def script_analyze(proj):
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    segs = data["segments"]
    norm = lambda s: re.sub(r"[^\w\u4e00-\u9fff]", "", s)
    qs = []
    # 1) 口头禅 & 连续重复词(词级)
    for si, seg in enumerate(segs):
        ws = seg["words"]
        for wi, w in enumerate(ws):
            txt = w["word"]
            if txt in FILL_SET:
                qs.append({"id": len(qs), "type": "口头禅", "time": w["start"], "text": txt,
                           "why": "填充词", "answer": "删", "del_words": [[si, wi]]})
            if wi and ws[wi - 1]["word"] == txt and w["start"] - ws[wi - 1]["end"] < 0.35:
                qs.append({"id": len(qs), "type": "重复词", "time": w["start"], "text": txt,
                           "why": "上一词刚说过" + txt, "answer": "删", "del_words": [[si, wi]]})
    # 2) 整句重录(句级:窗口内相似/包含)
    import difflib
    consumed = set()
    for i in range(len(segs)):
        if i in consumed: continue
        a = norm(segs[i]["text"])
        if len(a) < 4: continue
        for j in range(i + 1, min(i + 5, len(segs))):
            if segs[j]["start"] - segs[i]["end"] > 15: break
            b = norm(segs[j]["text"])
            if len(b) < 4: continue
            sim = difflib.SequenceMatcher(None, a, b).ratio()
            if a in b or b in a or sim >= 0.6:
                drop = i if len(a) <= len(b) else j
                keep = j if drop == i else i
                consumed.add(i); consumed.add(j)
                qs.append({"id": len(qs), "type": "整句重录", "time": segs[drop]["start"],
                           "text": segs[drop]["text"], "why": f"与 {segs[keep]['start']:.1f}s 的「{segs[keep]['text'][:18]}…」相似,建议删前者",
                           "answer": "删", "del_segs": [drop]})
                break
    st = {"questions": qs, "draft": "", "final": "", "mode": "wenan", "sub": "auto", "media_dur": data.get("duration", 0)}
    script_state_path(proj).write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "n": len(qs)}

def build_draft(proj, st):
    data = json.loads((Path(proj) / "转写.json").read_text(encoding="utf-8"))
    del_segs = set(); del_words = set()
    for q in st["questions"]:
        if q["answer"] != "删": continue
        for si in q.get("del_segs", []): del_segs.add(si)
        for si, wi in q.get("del_words", []): del_words.add((si, wi))
    entries = []
    for si, seg in enumerate(data["segments"]):
        if si in del_segs: continue
        ws = seg["words"]
        if ws and all((si, wi) in del_words for wi in range(len(ws))): continue
        txt = "".join(w["word"] for wi, w in enumerate(ws) if (si, wi) not in del_words)
        if txt.strip(): entries.append([float(seg["start"]), txt])
    for a in st.get("adds", []):
        txt = (a.get("text") or "").strip()
        if not txt: continue
        try: ts = float(a.get("time", 0))
        except Exception: ts = 0.0
        entries.append([ts, txt])
    entries.sort(key=lambda x: x[0])
    st["draft"] = "\n".join(e[1] for e in entries)
    return entries

def script_apply(proj):
    proj = Path(proj)
    st, _ = load_state(proj)
    entries = build_draft(proj, st)
    script_state_path(proj).write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "lines": len(entries)}

def script_add(proj, t, text):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "adds": []})
    st.setdefault("adds", [])
    text = (text or "").strip()
    if not text: return {"error": "补的文案不能为空"}
    if not (proj / "转写.json").exists() and not st["adds"]:
        return {"error": "先完成②转写"}
    try: ts = float(t)
    except Exception: return {"error": "补句时间无效,请先定位到这句的播放时间"}
    st["adds"].append({"time": ts, "text": text})
    build_draft(proj, st)
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "n": len(st["adds"])}

def script_del_add(proj, idx):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "adds": []})
    adds = st.get("adds", [])
    try: i = int(idx)
    except Exception: return {"error": "序号无效"}
    if i < 0 or i >= len(adds): return {"error": "序号越界"}
    adds.pop(i)
    build_draft(proj, st)
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, "n": len(adds)}

def script_answer(proj, qid, action):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "adds": []})
    for q in st.get("questions") or []:
        if q["id"] == int(qid): q["answer"] = action
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True}

def script_final(proj, text, sub):
    proj = Path(proj)
    step_snap(proj, ["文案定稿.txt", "script_state.json"], "s1")
    (proj / "文案定稿.txt").write_text(text, encoding="utf-8")
    f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "mode": "wenan"})
    st.update({"final": text[:120], "mode": "wenan", "sub": sub, "final_at": time.strftime("%m-%d %H:%M")})
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True}

def script_mode(proj, mode, sub=None):
    proj = Path(proj); f = script_state_path(proj)
    st, _ = load_state(proj, {"questions": [], "mode": mode})
    st["mode"] = mode
    if sub: st["sub"] = sub
    f.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True}


# 繁→简安全对照:只放无歧义的(著/髮發/乾/後 这类一形多义的故意排除,避免机器改错字)
TRAD = {"蘭": "兰", "贊": "赞", "們": "们", "國": "国", "際": "际", "體": "体", "廣": "广", "東": "东",
        "車": "车", "馬": "马", "鳥": "鸟", "魚": "鱼", "龍": "龙", "風": "风", "雲": "云", "電": "电",
        "書": "书", "畫": "画", "學": "学", "實": "实", "對": "对", "時": "时", "來": "来", "說": "说",
        "話": "话", "語": "语", "認": "认", "為": "为", "於": "于", "與": "与", "這": "这", "經": "经",
        "過": "过", "還": "还", "裏": "里", "裡": "里", "間": "间", "織": "织", "紙": "纸", "錢": "钱",
        "銀": "银", "鋼": "钢", "鐵": "铁", "鋁": "铝", "優": "优", "備": "备", "頭": "头", "顏": "颜",
        "顯": "显", "術": "术", "藝": "艺", "節": "节", "簡": "单", "複": "复", "變": "变", "讓": "让",
        "產": "产", "業": "业", "員": "员", "數": "数", "據": "据", "關": "关", "開": "开", "閉": "闭",
        "問": "问", "題": "题", "類": "类", "樣": "样", "確": "确", "義": "义", "習": "习", "慣": "惯",
        "營": "营", "銷": "销", "贊": "赞", "應": "应", "態": "态", "滿": "满", "燈": "灯", "發": "发",
        "紀": "纪", "約": "约", "縮": "缩", "網": "网", "絡": "络", "細": "细", "結": "结", "給": "给",
        "統": "统", "規": "规", "則": "则", "覺": "觉", "議": "议", "記": "记", "設": "设", "計": "计"}

def script_check(proj):
    """定稿体检:1) 繁体混入(可一键改) 2) 机器低置信词(只能你人工看)"""
    proj = Path(proj); wd = proj / "文案定稿.txt"; tj = proj / "转写.json"
    out = {"繁体": [], "低置信": [], "说明": []}
    if wd.exists():
        txt = wd.read_text(encoding="utf-8")
        hits = {}
        for i, line in enumerate(txt.splitlines(), 1):
            for ch in line:
                if ch in TRAD:
                    h = hits.setdefault(ch, {"字": ch, "建议": TRAD[ch], "次数": 0, "行": []})
                    h["次数"] += 1
                    if len(h["行"]) < 3: h["行"].append(i)
        out["繁体"] = sorted(hits.values(), key=lambda x: -x["次数"])
        if not out["繁体"]: out["说明"].append("没发现繁体字混入")
    else:
        out["说明"].append("还没有文案定稿:先在①-A 确认定稿")
    if tj.exists():
        try:
            data = json.loads(tj.read_text(encoding="utf-8"))
            low = {}
            for seg in data.get("segments", []):
                for w in seg.get("words", []):
                    p = float(w.get("p", 1))
                    t = (w.get("word") or "").strip()
                    if p < 0.62 and len(t) >= 2 and t not in low:
                        low[t] = {"词": t, "置信": round(p, 2), "时间": round(float(w["start"]), 1)}
            out["低置信"] = sorted(low.values(), key=lambda x: x["置信"])[:40]
            if not out["低置信"]: out["说明"].append("没有低置信词(阈值 0.62)")
        except Exception as e:
            out["说明"].append("读转写失败:" + str(e))
    out["可自动修"] = sum(h["次数"] for h in out["繁体"])
    return out

def script_fix_trad(proj):
    """只替换安全对照表里的繁体字,改前备份 文案定稿.prev.txt"""
    proj = Path(proj); wd = proj / "文案定稿.txt"
    if not wd.exists(): return {"error": "还没有文案定稿"}
    txt = wd.read_text(encoding="utf-8")
    n = 0
    for a, b in TRAD.items():
        c = txt.count(a)
        if c: txt = txt.replace(a, b); n += c
    if not n: return {"error": "没有可自动替换的繁体字(其余错字得你自己看)"}
    (proj / "文案定稿.prev.txt").write_text(wd.read_text(encoding="utf-8"), encoding="utf-8")
    wd.write_text(txt, encoding="utf-8")
    return {"ok": True, "n": n, "备份": "文案定稿.prev.txt"}


def autojob_state(proj):
    req = Path(proj) / "auto_edit_request.json"
    res = Path(proj) / "auto_edit_result.json"
    return {"request": json.loads(req.read_text(encoding="utf-8")) if req.exists() else None,
            "result": json.loads(res.read_text(encoding="utf-8")) if res.exists() else None}

def slim_path(proj): return Path(proj) / "精简取舍.json"

def slim_state(proj):
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    segs = [{"i": i, "start": round(sg["start"], 2), "end": round(sg["end"], 2), "text": sg["text"]}
            for i, sg in enumerate(data["segments"])]
    return {"target": st.get("target"), "removed": st.get("removed", []), "segments": segs,
            "duration": data.get("duration", 0), "window": st.get("window")}

def slim_save(proj, target, removed, window=...):
    proj = Path(proj); f = slim_path(proj)
    step_snap(proj, ["精简取舍.json"], "s3")
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    if target is not None:
        try: v = int(float(target))
        except Exception: return {"error": "目标时长无效"}
        if not (3 <= v <= 3600): return {"error": "目标时长要在 3~3600 秒之间"}
        st["target"] = v
    if removed is not None:
        st["removed"] = sorted(set(int(x) for x in removed))
    if window is not ...:
        if window is None:
            st.pop("window", None); st["removed"] = []
        else:
            st["window"] = [float(window[0]), float(window[1])]
    f.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "target": st.get("target"), "removed": len(st.get("removed", []))}

def slim_apply(proj):
    proj = Path(proj); tj = proj / "转写.json"
    step_snap(proj, ["剪切点清单.json", "精简取舍.json"], "s3")
    if not tj.exists(): return {"error": "先完成②转写"}
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    rm = st.get("removed", [])
    if not rm: return {"error": "还没有勾选要删的句子"}
    data = json.loads(tj.read_text(encoding="utf-8")); segs = data["segments"]
    dur = data.get("duration", 0)
    win = st.get("window")
    backup_cuts(proj)
    cf = proj / "剪切点清单.json"
    old = json.loads(cf.read_text(encoding="utf-8")) if cf.exists() else {}
    new = [c for c in old.get("cuts", []) if c.get("类型") != "精简删句"]
    inwin = lambda i: True
    if win:
        w0, w1 = float(win[0]), float(win[1])
        new = [c for c in new if c.get("开始", 0) >= w0 - 0.05 and c.get("结束", 9e9) <= w1 + 0.05]
        if w0 > 0.05:
            new.append({"类型": "精简删句", "开始": 0.0, "结束": round(w0 - 0.03, 3), "时长": round(w0 - 0.03, 3),
                        "文字": "定点截取掐头", "理由": f"⚓ 只保留 {w0:.1f}s→{w1:.1f}s,窗口前整段移除", "执行": "删"})
        if dur - w1 > 0.05:
            new.append({"类型": "精简删句", "开始": round(w1 + 0.03, 3), "结束": dur, "时长": round(dur - w1 - 0.03, 3),
                        "文字": "定点截取去尾", "理由": f"⚓ 只保留 {w0:.1f}s→{w1:.1f}s,窗口后整段移除", "执行": "删"})
        inwin = lambda i: segs[i]["start"] >= w0 - 0.05 and segs[i]["end"] <= w1 + 0.05
    for i in rm:
        if not inwin(i): continue
        if 0 <= i < len(segs):
            cs = round(segs[i]["start"] + 0.03, 3); ce = round(segs[i]["end"] - 0.03, 3)
            if ce - cs >= 0.05:
                new.append({"类型": "精简删句", "开始": cs, "结束": ce, "时长": round(ce - cs, 3),
                            "文字": segs[i]["text"][:24], "理由": f"凑时长:整段移除(目标 {st.get('target','?')} 秒)", "执行": "删"})
    new.sort(key=lambda c: c["开始"])
    for i, c in enumerate(new, 1): c["序号"] = i
    payload = {"media": old.get("media", (meta_of(proj) or {}).get("media", "")),
               "duration": data.get("duration", 0), "cuts": new}
    cf.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    ivs = sorted([(c["开始"], c["结束"]) for c in new if c.get("执行") == "删"])
    merged = []
    for a, b in ivs:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    dur = data.get("duration", 0)
    saved = sum(min(b, dur) - a for a, b in merged if b > a)
    pad = 0.0                              # 粗剪会把每个接缝的气口补到 0.30s,估算必须算进去
    for a, b in merged:
        if b <= a: continue
        prev = [x for x in segs if x["end"] <= a + 0.02]
        nxt = [x for x in segs if x["start"] >= b - 0.02]
        if not prev or not nxt: continue
        need = 0.30 - max(0.0, a - prev[-1]["end"]) - max(0.0, nxt[0]["start"] - b)
        if need > 0.02: pad += need
    return {"ok": True, "n": len(rm), "est": round(max(0, dur - saved + pad), 1),
            "pad": round(pad, 1), "target": st.get("target")}

def slim_suggest(proj):
    """自动凑目标时长建议:启发式打分,低分句勾为删,人来复核"""
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    target = st.get("target")
    if not target: return {"error": "先填目标秒数并保存"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    segs = data["segments"]
    n = len(segs)
    def score(i, sg):
        txt = (sg.get("text") or "").strip()
        dur = sg["end"] - sg["start"]
        sc = 0.0
        if i < 2: sc += 2.5                      # 开头钩子
        if i >= n - 2: sc += 1.5                 # 收尾句
        if re.search(r"\d", txt): sc += 1.5      # 带数据
        if re.search(r"[但却其实竟然结果原来秘密为什么怎么办]", txt): sc += 1.0
        sc += min(len(txt) / 20.0, 1.0)          # 信息量
        if re.match(r"^(然后|就是说|对|嗯|呃|那)", txt): sc -= 1.5
        if dur < 0.8: sc -= 1.0                  # 碎片句
        return sc
    scored = sorted(range(n), key=lambda i: score(i, segs[i]))
    removed, est = [], data.get("duration", 0)
    for i in scored:
        if est <= target: break
        removed.append(i)
        est -= segs[i]["end"] - segs[i]["start"]
    removed.sort()
    st["removed"] = removed
    build_draft = None  # 精简与文案草稿无关,占位防误删
    f.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "n": len(removed), "est": round(est, 1), "target": target}

def slim_take(proj, t):
    """定点起播截取:以打入点为起点,自动向后取满目标时长,按句界对齐,窗口外整段勾删"""
    proj = Path(proj); tj = proj / "转写.json"
    if not tj.exists(): return {"error": "先完成②转写"}
    f = slim_path(proj)
    st = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    target = st.get("target")
    if not target: return {"error": "先在「成片时长要求」填目标秒数"}
    try: t0 = float(t)
    except Exception: return {"error": "打入点无效:先把视频播到起点位置再按按钮"}
    data = json.loads(tj.read_text(encoding="utf-8"))
    segs = data["segments"]
    i0 = next((i for i, sg in enumerate(segs) if sg["end"] > t0), None)
    if i0 is None: return {"error": "打入点已在片尾之后"}
    i1, total = i0 - 1, 0.0
    for i in range(i0, len(segs)):
        i1 = i; total += segs[i]["end"] - segs[i]["start"]
        if total >= target: break
    if i1 + 1 < len(segs):
        nd = segs[i1+1]["end"] - segs[i1+1]["start"]
        if abs(total + nd - target) < abs(total - target):
            i1 += 1; total += nd
    st["window"] = [round(segs[i0]["start"], 2), round(segs[i1]["end"], 2)]
    st["removed"] = [i for i in range(len(segs)) if not (i0 <= i <= i1)]
    f.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "start": round(segs[i0]["start"], 1), "end": round(segs[i1]["end"], 1),
            "est": round(total, 1), "target": target, "kept": i1 - i0 + 1}

def read_cuts(proj):
    f = Path(proj) / "剪切点清单.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {"cuts": []}

# ---------- 卡密激活(阶段2:零服务器;执法=水印+吊销,详见 scripts/gen_keys.py 头注) ----------
import hashlib
卡密表 = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"          # 32字符,去 I O 0 1
授权文件 = WF / "license.json"
黑名单文件 = WF / "黑名单.txt"                        # 随更新包分发,一行一码
便携标记 = WF / "便携版标记.txt"                      # 存在=正式发货版,必须激活;自用/体验副本没有这文件

def 卡密校验(s):
    x = re.sub(r"[^0-9A-Za-z]", "", str(s or "")).upper()
    if len(x) != 16 or not x.startswith("DXXK"): return False
    体, 检 = x[4:15], x[15]
    if any(c not in 卡密表 for c in 体 + 检): return False
    return 卡密表[sum((i + 1) * 卡密表.index(c) for i, c in enumerate(体)) % 32] == 检

def 规范卡密(s):
    x = re.sub(r"[^0-9A-Za-z]", "", str(s or "")).upper()
    return "%s-%s-%s-%s" % (x[:4], x[4:8], x[8:12], x[12:16]) if len(x) == 16 else x

def 机器指纹():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
        v = winreg.QueryValueEx(k, "MachineGuid")[0]
        return hashlib.sha256(("fp|" + str(v)).encode()).hexdigest()[:16]
    except Exception as e:
        print("[license] MachineGuid 读不到,退回 MAC+主机名: %r" % e)
        try:
            import uuid
            return hashlib.sha256(("fp2|%s|%s" % (uuid.getnode(), os.environ.get("COMPUTERNAME", ""))).encode()).hexdigest()[:16]
        except Exception as e2:
            print("[license] 指纹兜底也失败: %r" % e2)
            return "unknown"

def feedback_pack(dst=None):
    """🎫 反馈单:把排障材料打成一个 zip 存到桌面,由用户自愿发给作者;绝不自动上传(隐私铁律)。
    只装"看问题"的东西:诊断报告/日志尾部/授权状态/项目元数据清单——不带字幕文案、分镜内容、任何媒体文件。
    任务日志里混着 OCR 读出来的文案,所以 任务日志尾.txt 只挑命令行与报错行,正文行不进包(见 关 白名单)。"""
    import zipfile
    名 = "AI剪辑工作台-反馈单-" + time.strftime("%Y%m%d-%H%M%S") + ".zip"
    if dst is None:
        桌 = Path.home() / "Desktop"
        dst = (桌 / 名) if 桌.exists() else (WF / 名)
    def 尾(f, n行=400):
        f = Path(f)
        if not f.exists(): return ""
        try:
            ls = f.read_text(encoding="utf-8", errors="replace").splitlines()
            return "\n".join(ls[-n行:])
        except Exception as e:
            print("[反馈单读文件失败 %s] %r" % (f, e))
            return ""
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("环境诊断.json", json.dumps(run_doctor(), ensure_ascii=False, indent=1))
        z.writestr("授权状态.json", json.dumps(lic_status(), ensure_ascii=False, indent=1))
        if 授权文件.exists():
            z.writestr("license原文.json", 尾(授权文件, 50))
        z.writestr("运行日志尾.txt", 尾(LOGF, 300))
        # 任务日志尾巴(2026-11-20):失败的具体报错行在这里,只留命令与报错类行——
        # 日志正文里有 OCR 出来的字幕文案,反馈单铁律是绝不外带创作内容,故按关键词白名单筛。
        try:
            关 = ("Traceback", "File \"", "Error", "error", "异常", "失败", "超时中止", "==== ", "$ ",
                  "写不进", "读不出", "读不了", "拒", "警告", "⚠", "缺", "不通过")
            段, 名目 = [], sorted(LOGDIR.glob("*.log")) if LOGDIR.exists() else []
            for f in 名目[-8:]:
                行 = [x[:200] for x in f.read_text(encoding="utf-8", errors="replace").splitlines()
                       if any(g in x for g in 关)]
                if 行:
                    段.append("===== %s | 只含命令行与报错行(正文文案不外带) =====" % f.name)
                    段.extend(行[-60:])
            z.writestr("任务日志尾.txt", _脱密("\n".join(段)[-60000:] or "暂无可外带的任务日志(只有正文行)"))
        except Exception as e:
            print("[反馈单任务日志没装上] %r" % e, flush=True)
            z.writestr("任务日志尾.txt", "任务日志读不出:%r" % e)
        z.writestr("启动日志尾.txt", 尾(WF / "启动日志.txt", 120))
        z.writestr("说明自检.txt", 尾(WF / "工作台" / "说明自检.txt", 50))
        清 = ["版本: %s" % VERSION, "打包时间: " + time.strftime("%Y-%m-%d %H:%M:%S"), ""]
        try:
            for d in sorted(Path(ROOT).iterdir()):
                if not d.is_dir() or d.name == ".trash": continue
                清.append("【项目】%s" % d.name)
                pj = d / "项目.json"
                if pj.exists():
                    清.append("  项目.json: " + pj.read_text(encoding="utf-8-sig")[:400].replace("\n", " "))
                for f in sorted(d.iterdir()):
                    if f.is_file():
                        清.append("  %s  %d KB" % (f.name, f.stat().st_size // 1024))
                清.append("")
        except Exception as e:
            清.append("[项目清单扫描失败] %r" % e)
        z.writestr("项目清单.txt", "\n".join(清))
    print("[反馈单] 已生成 %s" % dst)
    return {"ok": True, "文件": str(dst)}


免激活接口 = {"/api/license", "/api/apply_update", "/api/apply_from_url",
            "/api/restart_self", "/api/cancel", "/api/feedback", "/api/config"}

def 激活闸(路径, 状态):
    """卡密门的前端弹窗删一行 JS 就能绕过,这道后端闸才是真锁芯(2026-10-30 立):
    正式发货版未激活/已吊销时,除白名单(提交激活、装更新、取消任务、反馈、存配置)外
    一律拒执行。返回 None=放行,返回 dict=拒(带 未激活 标记供前端重新弹激活框)。
    自用/体验副本没有 便携版标记.txt=模式非"正式",不受影响。"""
    if not str(路径 or "").startswith("/api/") or 路径 in 免激活接口:
        return None
    if 状态.get("模式") != "正式":
        return None
    if 状态.get("已吊销"):
        return {"未激活": True, "error": "这张卡密已被吊销,任务不执行:请联系作者"}
    if not 状态.get("已激活"):
        return {"未激活": True, "error": "本机未激活:在激活框输入购买凭证里的卡密,再重新执行这个操作"}
    return None

def 需要激活():
    return 便携标记.exists()

def 黑名单集():
    if not 黑名单文件.exists(): return set()
    try:
        return {规范卡密(x) for x in 黑名单文件.read_text(encoding="utf-8-sig").splitlines() if x.strip() and not x.strip().startswith("#")}
    except Exception as e:
        print("[license] 黑名单读不了: %r" % e)
        return set()

def _读授权():
    if not 授权文件.exists(): return {}
    try:
        return json.loads(授权文件.read_text(encoding="utf-8"))
    except Exception as e:
        print("[license] 授权文件读不了(按未激活处理): %r" % e)
        return {}

def lic_status():
    if not 需要激活():
        return {'模式': '免激活', '版本': VERSION}
    d = _读授权(); k = str(d.get('卡密', ''))
    黑 = 黑名单集()
    到期 = str(d.get('更新到期', ''))
    录 = str(d.get('机器指纹') or '')
    换机 = False
    if k:
        本 = 机器指纹()
        # 老记录没写指纹、或本机指纹读不到时不误伤(按原样认,不把正版用户锁在门外)
        换机 = bool(录) and 录 != 'unknown' and 本 != 'unknown' and 录 != 本
        if 换机:
            print('[license] 授权记录绑在别的机器(卡密 %s…),本机按未激活处理' % k[:9])
    return {'模式': '正式', '版本': VERSION, '已激活': bool(k) and not 换机,
            '已吊销': bool(k) and k in 黑, '换机': 换机,
            '卡密': (k[:9] + '…' + k[-4:]) if len(k) >= 19 else k,
            '更新到期': 到期, '更新已过期': bool(到期) and 到期 < time.strftime('%Y-%m-%d')}


def lic_bind(key, contact):
    k = 规范卡密(key)
    if not 卡密校验(k):
        return {'error': '卡密不对(末位是校验位,打错或编造都过不了):请回到购买凭证里复制'}
    if k in 黑名单集():
        return {'error': '这张卡密已被吊销(外传被查到)。如果你是真实购买者,请联系作者说明情况'}
    本 = 机器指纹()
    旧 = _读授权()
    旧fp = str(旧.get('机器指纹') or '')
    if 旧.get('卡密') == k and (not 旧fp or 旧fp == 'unknown' or 旧fp == 本):
        return {'ok': True, '提示': '本机已激活,无需重复'}
    改绑 = 旧.get('卡密') == k
    d = {'卡密': k, '机器指纹': 本, '联系方式': str(contact or '').strip()[:40],
         '激活时间': time.strftime('%Y-%m-%d %H:%M'),
         '更新到期': time.strftime('%Y-%m-%d', time.localtime(time.time() + 183 * 86400))}
    授权文件.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    print('[license] 已激活 %s 指纹=%s %s' % (k, 本, '换机改绑' if 改绑 else '首次绑定'))
    return {'ok': True, '更新到期': d['更新到期'],
            '提示': '已把这张卡密改绑到本机(原来那台机器下次启动要重新输码)' if 改绑 else '激活成功'}


def _trans_group(n):
    if any(k in n for k in ("叠化", "闪白", "闪黑", "叠加", "黑场", "淡入", "淡出")): return "基础"
    if "模糊" in n: return "模糊"
    if any(k in n for k in ("3D", "空间", "立体", "立方", "纵深", "穿越")): return "3D/空间"
    if "旋转" in n or "拨盘" in n: return "旋转"
    if any(k in n for k in ("擦除", "翻页", "卷", "遮罩")): return "擦除/翻页"
    if any(k in n for k in ("故障", "电视", "信号", "色差", "色块", "扫描")): return "故障/VHS"
    if any(k in n for k in ("抖", "晃", "撕", "裂", "分割", "对比", "压缩")): return "冲击/分屏"
    if any(k in n for k in ("动漫", "卡通", "漫画", "爆彩")): return "动漫"
    if any(k in n for k in ("移", "推", "拉", "流动", "滑", "伸缩", "缩放")): return "动态/推拉"
    if any(k in n for k in ("闪", "光", "星", "爱心", "泡泡", "珠光", "彩", "云", "雪")): return "光效/自然"
    return "其他"


_协议码缓存 = None


def _协议码(刷新=False):
    """解析《动效包装协议.md》第二节能力白名单,返回 [(码, 是什么), ...]——全场唯一真源。
    分镜表「动效/包装」列能写什么、转场速查第一组列什么、AI 写的动效过不过闸,全部从这里派生。
    (2026-11-19 统一,起因:代码闸比协议宽 8 个词,写进分镜表的效果在第④步被悄悄降级成硬切。)"""
    global _协议码缓存
    if _协议码缓存 is not None and not 刷新:
        return _协议码缓存
    表 = []
    pf = WF / "动效包装协议.md"
    if not pf.exists():
        print("[协议白名单] 工作流根没有 动效包装协议.md: %s" % pf)
    else:
        try:
            raw = pf.read_text(encoding="utf-8")
            a = raw.find("## 二、"); b = raw.find("## 三、")
            if a < 0 or b < 0 or b <= a:
                print("[协议白名单] 找不到「## 二、」或「## 三、」标题,第二节裁不出来")
            else:
                for ln in raw[a:b].splitlines():
                    t = ln.strip()
                    if not t.startswith("|"):
                        continue
                    cs = [x.strip() for x in t.strip("|").split("|")]
                    if len(cs) < 2 or cs[0] in ("代码", "") or set(cs[0]) <= set("-: "):
                        continue
                    表.append((cs[0], cs[1]))
        except Exception as e:
            print("[协议白名单] 解析失败 %r" % e)
    if not 表:
        print("[协议白名单] 一条都没解析出来(协议文件坏了?),退回内置最小集;"
              "这会让第④步大量按降级链处理,请尽快恢复 动效包装协议.md")
        表 = [("叠化", "淡入淡出转场"), ("闪白", "白闪转场"), ("故障", "信号错位转场"),
             ("闪黑", "黑场转场"), ("模糊", "虚化转场"), ("抖动", "冲击转场"),
             ("推镜", "画面缓推/缓拉"), ("数据卡", "数字滚动到位"), ("定格", "冻帧"),
             ("变速", "快进慢动作"), ("音效", "单点音效"), ("BGM", "背景音乐")]
    _协议码缓存 = 表
    return 表


def _动效可写码():
    """分镜表「动效/包装」列允许裸写的类型名(=第二节全部码)。"""
    return {x[0] for x in _协议码()}


def 协议转场码(刷新=False):
    """第二节「是什么」里带"转场"二字的码——即 `转场:名字` 允许的名单。"""
    return [x[0] for x in _协议码(刷新) if "转场" in x[1]]


def _转场可写码():
    return set(协议转场码())


def _协议类型名(fx):
    """把列内写法剥成类型名:「转场:模糊|0.3s」→转场:模糊;「数据卡@300 数数0.8s」→数据卡;「推镜 110%」→推镜。
    剥完再对账,否则带参数的合法写法会被误判成超纲。"""
    s = str(fx or "").strip()
    s = re.split(r"[|@]", s, 1)[0]
    return s.split(" ", 1)[0].strip()


def transitions_api():
    """给界面「转场速查」用。词表第一顺位改挂《动效包装协议.md》白名单——分镜表里写下的转场名
    是要交给第④步渲染方(AI/HyperFrames)落地的,剪辑软件私有转场名它渲染不出来。
    jianying-editor 技能里的全量名仍列出来,但明确标成「只给你手动用」。
    (2026-11-19 修:旧版这里引用了没定义的 TRANS_FALLBACK,客户机没装 jianying-editor 技能时
     点「转场速查」直接 NameError——按项目规矩,静默兜底不算修完,必须真跑一条路径。)"""
    协 = 协议转场码()
    可落地 = {"✅ 协议白名单(交给 AI 包就认这些)": list(协)}
    try:
        import csv as _csv
    except Exception as e:
        print("[api/transitions csv 模块读不了] %r" % e)
        return {"总数": len(协), "分组": 可落地, "AI包认": 协,
                "来源": "《动效包装协议.md》白名单(本机连 csv 模块都用不上,没读技能表)",
                "提示": "上面这几个是渲染方能落地的;想用最炫的转场得手动进剪辑软件加"}
    names, src2 = [], "本机没检测到 jianying-editor 技能,只列了协议白名单"
    cands = [os.environ.get("JY_SKILL_ROOT", ""),
             os.path.expanduser(os.path.join("~", ".codex", "skills", "jianying-editor"))]
    glob0 = os.path.expanduser(os.path.join("~", ".codex", "plugins", "cache"))
    if os.path.isdir(glob0):
        try:
            for root0, dirs0, _f0 in os.walk(glob0):
                if os.path.relpath(root0, glob0).count(os.sep) >= 5:
                    dirs0[:] = []
                for d in list(dirs0):
                    if d == "jianying-editor":
                        cands.append(os.path.join(root0, d))
                        dirs0.remove(d)
        except Exception as e:
            print("[api/transitions 扫插件缓存失败] %s" % e)
    for c in filter(None, cands):
        f = os.path.join(c, "data", "transitions.csv")
        if not os.path.exists(f):
            continue
        try:
            with open(f, encoding="utf-8-sig", newline="") as fh:
                names = [x for x in ((row.get("identifier") or "").strip() for row in _csv.DictReader(fh)) if x]
            if names:
                src2 = "jianying-editor 技能"
        except Exception as e:
            print("[api/transitions 转场表读失败] %r" % e)
        if names:
            break
    uniq = sorted(set(names) - set(协), key=lambda x: (len(x), x))
    groups = {}
    for n in uniq:
        groups.setdefault(_trans_group(n), []).append(n)
    order = ["基础", "模糊", "动态/推拉", "冲击/分屏", "旋转", "3D/空间", "擦除/翻页",
             "故障/VHS", "光效/自然", "动漫", "其他"]
    分组 = dict(可落地)
    分组.update({"🖐 " + k + "(剪辑软件私有名,AI 包渲染不出来)": groups[k] for k in order if k in groups})
    return {"总数": len(协) + len(uniq), "分组": 分组, "AI包认": 协, "来源": src2,
            "提示": ("第一组是《动效包装协议.md》里的转场码,写进分镜表第④步能直接落地;"
                     "其余分组只在你手动进剪辑软件时用,交给 AI 会被按降级链处理(退成叠化或硬切)。")}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _json(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n)) if n else {}

    def do_GET(self):
        try:
            self._GET()
        except Exception as e:
            self._boom("GET", e)

    def do_POST(self):
        try:
            self._POST()
        except Exception as e:
            self._boom("POST", e)

    def _boom(self, how, e):
        """处理请求时炸了:原因既回给浏览器也打到工作台窗口。
        以前异常直接掐断连接,前端只看到 Failed to fetch,查不到哪一步——静默失败最贵。"""
        if isinstance(e, (ConnectionAbortedError, ConnectionResetError, BrokenPipeError)):
            return          # 浏览器刷新/关页掐掉的连接,不是故障,别在窗口刷假警报
        print("[%s 处理异常] %s" % (how, e), flush=True)
        slog("接口异常", "", "%s: %s" % (how, str(e)[:160]))
        for _ln in traceback.format_exc(limit=5).splitlines():
            print("   " + _ln, flush=True)
        try:
            self._json(500, {"error": "%s 出错: %s(详细堆栈已打到工作台黑窗口)" % (how, e)})
        except Exception as e2:
            print("[错误响应也没发出去] %r" % (e2,))

    def _GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path in ("/", "/index.html"):
            b = (ROOT / "index.html").read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.send_header("Cache-Control", "no-store")   # 不缓存界面:改完 index.html 刷新就是新版
            self.end_headers(); self.wfile.write(b)
        elif u.path == "/confetti.min.js":
            f = ROOT / "confetti.min.js"
            if not f.exists(): return self.send_error(404)
            b = f.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/javascript; charset=utf-8")
            self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        elif u.path == "/api/browse":
            self._json(200, browse_roots() if not q.get("dir") else browse_dir(q["dir"]))
        elif u.path == "/api/transitions":
            self._json(200, transitions_api())
        elif u.path == "/api/projects":
            ps = []
            if PROJ_ROOT.exists():
                for d in sorted(PROJ_ROOT.iterdir()):
                    m = meta_of(d)
                    if m: ps.append({"dir": str(d), "media": m["media"]})
            self._json(200, ps)
        elif u.path == "/api/job":
            self._json(200, job_view(q.get("dir", "")))
        elif u.path == "/api/queue":
            self._json(200, queue_view())
        elif u.path == "/api/scriptcheck":
            self._json(200, script_check(q.get("dir", "")))
        elif u.path == "/api/config":
            self._json(200, settings())
        elif u.path == "/api/refmap":
            self._json(200, refmap_state(q.get("dir", "")))
        elif u.path == "/api/refstyle":
            f = Path(q.get("dir", "")) / "对标风格.json"
            self._json(200, json.loads(f.read_text(encoding="utf-8")) if f.exists() else {})
        elif u.path == "/api/textstyle":
            self._json(200, textstyle_state(q.get("dir", "")))
        elif u.path == "/api/voicesummary":
            self._json(200, voice_summary(q.get("dir", "")))
        elif u.path == "/api/textmd":
            允许 = {"文字效果报告.md", "文字效果执行卡.md"}
            fn = q.get("f", "文字效果报告.md")
            if fn not in 允许: fn = "文字效果报告.md"
            fp = Path(q.get("dir", "")) / fn
            b = fp.read_bytes() if fp.exists() else "# 还没有生成,先跑①-E对应按钮".encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        elif u.path == "/api/script":
            self._json(200, script_state(q["dir"]))
        elif u.path == "/api/trash":
            tr, idx, stack = trash_paths(q["dir"])
            self._json(200, {"stack": stack})
        elif u.path == "/api/medcheck":
            self._json(200, media_check())
        elif u.path == "/api/doctor":
            self._json(200, run_doctor())
        elif u.path == "/api/update_check":
            self._json(200, update_check())
        elif u.path == "/api/refs":
            self._json(200, refs_state(q["dir"]))
        elif u.path == "/api/assets":
            self._json(200, assets_state(q["dir"]))
        elif u.path == "/api/autojob":
            self._json(200, autojob_state(q["dir"]))
        elif u.path == "/api/cuts":
            self._json(200, read_cuts(q["dir"]))
        elif u.path == "/api/slim":
            self._json(200, slim_state(q["dir"]))
        elif u.path == "/api/poster":
            fp = resolve_media(q["dir"], q.get("kind", "ref"), q.get("f", ""), q.get("path", ""))
            if not fp: return self.send_error(404)
            dst = poster_file(q["dir"], fp.name)
            if not (dst.exists() and dst.stat().st_mtime >= fp.stat().st_mtime):
                if not make_poster(fp, dst): return self.send_error(404)
            b = dst.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(b))); self.send_header("Cache-Control", "max-age=3600")
            self.end_headers(); self.wfile.write(b)
        elif u.path == "/api/undo":
            cur = Path(proj) / "剪切点清单.json"; prev = Path(proj) / "剪切点清单.prev.json"
            if not prev.exists(): return self._json(400, {"error": "没有可撤回的操作"})
            shutil.move(str(prev), str(cur))
            return self._json(200, {"ok": True})
        if u.path in ("/manifest.webmanifest", "/app_192.png", "/app_512.png"):
            类 = {".png": "image/png", ".webmanifest": "application/manifest+json"}[os.path.splitext(u.path)[1]]
            try:
                b = (ROOT / u.path.lstrip("/")).read_bytes()
                self.send_response(200); self.send_header("Content-Type", 类)
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            except Exception as e:
                print("[PWA资源送不出 %s] %r" % (u.path, e)); self.send_error(404)
            return
        if u.path == "/app.ico":
            try:
                b = (ROOT / "app.ico").read_bytes()
                self.send_response(200); self.send_header("Content-Type", "image/x-icon")
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            except Exception as e:
                print("[app.ico 送不出] %r" % e); self.send_error(404)
            return
        if u.path == "/api/license":
            return self._json(200, lic_status())
        if u.path == "/api/ideas":
            f2 = Path(q["dir"]) / "包装想法.txt"
            self._json(200, {"text": f2.read_text(encoding="utf-8-sig") if f2.exists() else ""})
        if u.path == "/api/storyboard":
            f = Path(q["dir"]) / "分镜.csv"
            try:
                tpl_md = (WF / "分镜镜头表模板.md").read_text(encoding="utf-8")
            except Exception as e:
                print("[分镜模板读取失败] %r" % e); tpl_md = ""
            # 旧版事故:曾把整篇模板(含「填写规则」)存成过 分镜.csv——那不是用户的镜头表。
            # 读回时挪档成 分镜-旧模板残留.csv(数据不丢),框回到灰字提示的空态,让用户从头写。
            if f.exists():
                try:
                    _t0 = f.read_text(encoding="utf-8-sig")
                    if "填写规则" in _t0 and "分镜镜头表模板" in _t0:
                        f.replace(f.with_name("分镜-旧模板残留.csv"))
                        print("[分镜旧模板残留已挪开] %s" % f)
                except Exception as e:
                    print("[分镜旧模板检测失败,按原样返回] %r" % e)
            if f.exists():
                self._json(200, {"text": f.read_text(encoding="utf-8"), "saved": True, "help": tpl_md})
            else:
                # 新表什么都不塞:可编辑框保持空白,灰字提示是 placeholder(改不了),表头保存时机器自动补;
                # 完整模板示例+7条填写规则走「📖 填写说明」灰色只读弹窗
                self._json(200, {"text": "", "saved": False, "help": tpl_md})
        elif u.path == "/api/status":
            proj = Path(q.get("dir", "")); m = meta_of(proj)   # 没带 dir 也要能回引导信息,不该 500
            tj = proj / "转写.json"
            data = json.loads(tj.read_text(encoding="utf-8")) if tj.exists() else None
            rg = proj / "rough.mp4"; cf = proj / "剪切点清单.json"; fp = proj / "rough_预览.mp4"
            self._json(200, {"meta": m, "files": {
                "转写": bool(data), "剪切点": cf.exists(),
                "rough": rg.exists(), "交接": (proj / "包装交接.md").exists(),
                "对标": (proj / "对标风格.json").exists(), "点位": (proj / "对标点位.json").exists(), "文字": (proj / "对标文字.json").exists(), "字幕": (proj / "字幕.ass").exists(),
                "预览": (proj / "rough_预览.mp4").exists(),
                "rough_v": int(rg.stat().st_mtime) if rg.exists() else 0,
                "预览_v": int(fp.stat().st_mtime) if fp.exists() else 0,
                "清单_v": int(cf.stat().st_mtime) if cf.exists() else 0},
                "对标建议": style_suggest(proj), "风格档": stylepack_state(proj), "下一步": next_step(proj),
                "后端待重启": backend_stale(),
                "segmentCount": len(data["segments"]) if data else 0,
                "duration": data.get("duration", 0) if data else 0})
        elif u.path == "/media":
            proj = Path(q.get("dir", "")); m = meta_of(proj) or {}
            name = q.get("name")
            if name == "ref":
                safe = Path(q.get("f", "")).name
                path = str(proj / "参考" / safe)
            elif name == "refabs":
                rl = Path(proj) / "参考登记.json"
                lst = json.loads(rl.read_text(encoding="utf-8")) if rl.exists() else []
                try: path = lst[int(q.get("i","-1"))]["path"]
                except Exception: path = None
            elif name == "shotmap":
                safe = Path(q.get("f", "")).name
                path = str(proj / "对标点位" / safe)
            elif name == "textcrop":
                safe = Path(q.get("f", "")).name
                path = str(proj / "对标文字块" / safe)
            elif name == "asset":
                safe = Path(q.get("f", "")).name
                path = str(proj / "素材" / safe)
            else:
                path = {"source": m.get("media"), "rough": str(proj / "rough.mp4"), "fast": str(proj / "rough_预览.mp4")}.get(name)
            if not path or not Path(path).exists():
                self.send_error(404); return
            self._stream(Path(path))
        else:
            if u.path.startswith("/api/"):
                # 页面是新的、后端是旧的(改完文件没重启)时,以前回 HTML 报错页,
                # 前端 r.json() 直接炸 "Unexpected token <" 看不出原因——这里必须回人能读的错
                return self._json(404, {"error": "接口不存在: %s — 页面读到的是新文件,但后台还是旧版工作台;跑一次 停止工作台.cmd 再跑 启动工作台.cmd 就恢复" % u.path})
            self.send_error(404)

    def _stream(self, fp):
        size = fp.stat().st_size; rng = self.headers.get("Range", "")
        m = re.match(r"bytes=(\d+)-(\d*)", rng)
        start = int(m.group(1)) if m else 0
        end = int(m.group(2)) if m and m.group(2) else size - 1
        end = min(end, size - 1); length = end - start + 1
        ext = fp.suffix.lower()
        ctype = {"mp4": "video/mp4", "mov": "video/mp4", "m4v": "video/mp4", "mp3": "audio/mpeg", "wav": "audio/wav", "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp", "gif": "image/gif"}.get(ext.lstrip("."), "application/octet-stream")
        self.send_response(206 if m else 200)
        self.send_header("Accept-Ranges", "bytes"); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        if m: self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        with fp.open("rb") as f:
            f.seek(start); rem = length
            while rem > 0:
                chunk = f.read(min(65536, rem))
                if not chunk: break
                self.wfile.write(chunk); rem -= len(chunk)

    def _upload(self, u):
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        proj = Path(q.get("dir", ""))
        if not (proj / "项目.json").exists():
            return self._json(400, {"error": "请先在上方选择或新建项目"})
        target = q.get("target", "asset")
        if target == "media":
            folder = proj / "素材"
            allow = {e.lstrip(".") for e in VIDEO_EXT}
        else:
            folder = proj / ("参考" if target == "ref" else "素材")
            allow = REF_EXT if target == "ref" else ASSET_EXT
        name = Path(unquote(q.get("name", ""))).name
        name = re.sub(r'[\\/:*?"<>|]', "", name).strip()
        ext = name.lower().rsplit(".", 1)[-1] if "." in name else ""
        if not name or ext not in allow:
            return self._json(400, {"error": "不支持的文件类型:" + (name or "(空文件名)")})
        folder.mkdir(parents=True, exist_ok=True)
        dest = folder / name; i = 2
        while dest.exists():
            dest = folder / (Path(name).stem + "-" + str(i) + "." + ext); i += 1
        remain = int(self.headers.get("Content-Length", 0))
        if not remain:
            return self._json(400, {"error": "空文件,上传取消"})
        with open(dest, "wb") as f:
            while remain:
                chunk = self.rfile.read(min(1048576, remain))
                if not chunk: break
                f.write(chunk); remain -= len(chunk)
        if remain:
            dest.unlink(missing_ok=True)
            return self._json(400, {"error": "上传中断,请重试"})
        if target == "media":
            b = bind_copied_media(proj, dest)
            if b.get("error"):
                dest.unlink(missing_ok=True)
                return self._json(400, {"error": b["error"]})
            return self._json(200, {"ok": True, "name": dest.name, "media": b["new"]})
        return self._json(200, {"ok": True, "name": dest.name})

    def _apply_update(self):
        """POST 原始 zip 字节:装更新包。有剪辑在跑/排队时拒绝——引擎正被子进程调用,不能换。"""
        余 = int(self.headers.get("Content-Length", 0))
        if not 余:
            return self._json(400, {"error": "没收到文件内容"})
        if 余 > 200 * 1048576:
            return self._json(400, {"error": "文件超过 200MB——这不是小更新包(小包由作者「造更新包」产出,一般几百 KB)"})
        buf = bytearray()
        while 余 > 0:
            c = self.rfile.read(min(1048576, 余))
            if not c:
                break
            buf += c; 余 -= len(c)
        if 余:
            return self._json(400, {"error": "传输中断,没动任何文件,请重试"})
        if queue_view()["在跑/排队"]:
            return self._json(400, {"error": "有剪辑任务在跑或排队,等它跑完再装更新包"})
        结 = apply_update(bytes(buf))
        if 结.get("ok"):
            成, 因 = 自动重启后()
            结["自动重启"] = 成
            结["提示"] = ("装好了,工作台正在自动重启,窗口一会儿自己刷新,不用手动关掉" if 成
                       else "装好了,但自动重启没拉起来:" + 因 + " ——请双击「停止工作台.cmd」,再像平时一样打开,新版即生效")
        return self._json(200, 结)

    def _apply_from_url(self):
        body = self._body()
        if queue_view()["在跑/排队"]:
            return self._json(400, {"error": "有剪辑任务在跑或排队,等它跑完再更新"})
        结 = apply_update_from_url(body.get("地址", ""))
        if 结.get("ok"):
            成, 因 = 自动重启后()
            结["自动重启"] = 成
            结["提示"] = ("装好了,工作台正在自动重启,窗口一会儿自己刷新,不用手动关掉" if 成
                       else "装好了,但自动重启没拉起来:" + 因 + " ——请双击「停止工作台.cmd」,再像平时一样打开,新版即生效")
        return self._json(200, 结)

    def _restart_self(self):
        """界面点「后端待重启」警告条:借装更新后同一套自动重启换血;有任务在跑拒装,和更新一个底线。"""
        if queue_view().get("在跑/排队"):
            return self._json(400, {"error": "有剪辑任务在跑或排队,先等它跑完再重启后端"})
        成, 因 = 自动重启后()
        if not 成:
            return self._json(400, {"error": "自动重启没拉起来:" + 因 + " ——请双击「停止工作台.cmd」,再像平时一样打开"})
        slog("手动重启后端", "", "界面点「后端待重启」警告条触发")
        return self._json(200, {"ok": True, "提示": "后端正在自动重启,页面会自己刷新"})

    def _POST(self):
        u = urlparse(self.path)
        拦 = 激活闸(u.path, lic_status())
        if 拦:
            slog("未激活拒执行", u.path, str(拦.get("error", ""))[:60])
            return self._json(403, 拦)
        if u.path == "/api/upload": return self._upload(u)
        if u.path == "/api/apply_update": return self._apply_update()
        if u.path == "/api/apply_from_url": return self._apply_from_url()
        if u.path == "/api/restart_self": return self._restart_self()
        body = self._body()
        proj = body.get("dir", "")
        if u.path == "/api/blank":
            return self._json(200, create_blank_project())
        if u.path == "/api/relink":
            return self._json(200, relink_media(proj, body.get("media", "")))
        if u.path == "/api/adopt":
            return self._json(200, adopt_media(proj))
        if u.path == "/api/project":
            r = create_project(body.get("media", ""), body.get("name", ""), body)
            if r.get("error"): return self._json(400, {"error": r["error"]})
            return self._json(200, r)
        if u.path == "/api/config":
            return self._json(200, save_settings(body))
        if u.path == "/api/action":
            fn = {"transcribe": action_transcribe, "findcuts": action_findcuts,
                  "render": action_render, "handoff": action_handoff,
                  "anchors": action_anchors, "refstyle": action_refstyle,
                  "refmap": action_refmap, "sample": action_sample,
                  "stylepack": action_stylepack, "refpick": action_refpick,
                  "textstyle": action_textstyle}.get(body.get("action"))
            if not fn: return self._json(400, {"error": "参数不全"})
            if not proj and body.get("action") != "sample": return self._json(400, {"error": "参数不全"})
            return self._json(200, fn(proj, body))
        if u.path == "/api/script":
            act = body.get("act")
            if act == "analyze": return self._json(200, script_analyze(proj))
            if act == "answer": return self._json(200, script_answer(proj, body.get("qid"), body.get("action", "删")))
            if act == "apply":  return self._json(200, script_apply(proj))
            if act == "final":  return self._json(200, script_final(proj, body.get("text", ""), body.get("sub", "auto")))
            if act == "mode":   return self._json(200, script_mode(proj, body.get("mode"), body.get("sub")))
            if act == "draft":  return self._json(200, script_save_draft(proj, body.get("text", "")))
            if act == "add":    return self._json(200, script_add(proj, body.get("time"), body.get("text")))
            if act == "del_add": return self._json(200, script_del_add(proj, body.get("idx")))
            return self._json(400, {"error": "未知act"})
        if u.path == "/api/scriptfix":
            return self._json(200, script_fix_trad(proj))
        if u.path == "/api/backup":
            return self._json(200, run_backup())
        if u.path == "/api/cancel":
            return self._json(200, cancel_job(proj))
        if u.path == "/api/batch":
            return self._json(200, action_batch(body))
        if u.path == "/api/reset":
            return self._json(200, action_reset(proj, body.get("scope", "")))
        if u.path == "/api/projdel":
            return self._json(200, action_delete_project(proj))
        if u.path == "/api/undo_reset":
            return self._json(200, action_undo_reset(proj))
        if u.path == "/api/refmap":
            act = body.get("act")
            if act == "save": return self._json(200, refmap_save(proj, body.get("rows") or []))
            if act == "sb":   return self._json(200, refmap_storyboard(proj, body))
            return self._json(400, {"error": "未知act"})
        if u.path == "/api/refs":
            if body.get("act") == "remove":
                return self._json(200, action_remove_media(proj, "ref", body.get("f", ""), body.get("path", "")))
            projp = Path(proj); srcf = Path(body.get("path", ""))
            if not srcf.exists(): return self._json(400, {"error": "文件不存在"})
            reg = projp / "参考登记.json"
            lst = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else []
            if any(x["path"] == str(srcf.resolve()) for x in lst): return self._json(200, {"ok": True, "dup": True})
            lst.append({"path": str(srcf.resolve()), "note": body.get("note", "")})
            reg.write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/assets":
            if body.get("act") == "remove":
                return self._json(200, action_remove_media(proj, "asset", body.get("f", ""), body.get("path", "")))
            projp = Path(proj); srcf = Path(body.get("path", ""))
            if not srcf.exists(): return self._json(400, {"error": "文件不存在"})
            reg = projp / "素材登记.json"
            lst = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else []
            if any(x["path"] == str(srcf.resolve()) for x in lst): return self._json(200, {"ok": True, "dup": True})
            lst.append({"path": str(srcf.resolve()), "shot": body.get("shot", ""), "note": body.get("note", "")})
            reg.write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/open":
            fp = resolve_media(proj, body.get("kind", "ref"), body.get("f", ""), body.get("path", ""))
            if not fp: return self._json(400, {"error": "文件不在本项目登记范围内"})
            os.startfile(str(fp))
            return self._json(200, {"ok": True})
        if u.path == "/api/slim":
            return self._json(200, slim_save(proj, body.get("target"), body.get("removed"), body.get("window", ...)))
        if u.path == "/api/undo_step":
            return self._json(200, step_undo(proj, body.get("scope", "")))
        if u.path == "/api/slim_take":
            return self._json(200, slim_take(proj, body.get("t")))
        if u.path == "/api/slim_suggest":
            return self._json(200, slim_suggest(proj))
        if u.path == "/api/slim_apply":
            return self._json(200, slim_apply(proj))
        if u.path == "/api/textplan":
            return self._json(200, textplan_run(proj, body))
        if u.path == "/api/autojob":
            m = meta_of(proj) or {}
            req = {"instruction": body.get("instruction", "").strip(),
                   "media": m.get("media", ""), "transcript": str(Path(proj) / "转写.json"),
                   "cuts_out": str(Path(proj) / "剪切点清单.json"),
                   "created": time.strftime("%Y-%m-%d %H:%M:%S")}
            (Path(proj) / "auto_edit_request.json").write_text(json.dumps(req, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/cuts":
            step_snap(proj, ["剪切点清单.json"], "s3")
            backup_cuts(proj)
            f = Path(proj) / "剪切点清单.json"
            old = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
            prev_map = {(c.get("类型"), c.get("文字")): c for c in old.get("cuts", [])}
            rows = []
            for c in body.get("cuts", []):
                p = prev_map.get((c.get("类型"), c.get("文字")))
                if p and (c.get("执行") != p.get("执行") or p.get("人工")):
                    c["人工"] = "1"            # 人耳裁决过,重跑找点/换档位都不许覆盖
                rows.append(c)
            payload = {"media": (meta_of(proj) or {}).get("media", old.get("media", "")),
                       "duration": old.get("duration", 0), "档位": old.get("档位", ""), "cuts": rows}
            f.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
            return self._json(200, {"ok": True})
        if u.path == "/api/undo":
            cur = Path(proj) / "剪切点清单.json"; prev = Path(proj) / "剪切点清单.prev.json"
            if not prev.exists(): return self._json(400, {"error": "没有可撤回的操作"})
            shutil.move(str(prev), str(cur))
            return self._json(200, {"ok": True})
        if u.path == "/api/feedback":
            return self._json(200, feedback_pack())
        if u.path == "/api/license":
            if body.get("act") == "bind":
                return self._json(200, lic_bind(body.get("key", ""), body.get("contact", "")))
            return self._json(400, {"error": "未知的授权操作"})
        if u.path == "/api/ideas":
            return self._json(200, ideas_save(proj, body.get("text", "")))
        if u.path == "/api/ideas_map":
            return self._json(200, ideas_map(proj, body))
        if u.path == "/api/sbdraft":
            r = sb_ai_draft(proj, body.get("text", ""))
            退 = r.pop("退回", "") if isinstance(r, dict) else ""
            if 退:
                r = sb_draft_from_text(proj, body.get("text", ""))
                r["AI退回原因"] = 退
                print("[讲述转分镜走本机词表] %s" % 退)
            return self._json(200, r)
        if u.path == "/api/ark_models":
            return self._json(200, ark_models(body))
        if u.path == "/api/ai_chat":
            return self._json(200, ai_chat(body))
        if u.path == "/api/localai_plan":
            return self._json(200, localai_plan())
        if u.path == "/api/localai_start":
            return self._json(200, localai_start())
        if u.path == "/api/localai_cancel":
            return self._json(200, localai_cancel())
        if u.path == "/api/localai_status":
            with LA_LOCK:
                return self._json(200, {"跑": LOCALAI["跑"], "取消": LOCALAI["取消"], "完成": LOCALAI["完成"],
                                        "错": LOCALAI["错"], "进": LOCALAI["进"], "步": [list(x) for x in LOCALAI["步"]]})
        if u.path == "/api/storyboard":
            return self._json(200, storyboard_save(proj, body.get("text", ""),
                                                   auto=body.get("auto_anchor", True)))
        self._json(404, {"error": "no route"})

BR_LIMIT = 400

def browse_roots():
    """「挑素材」窗首页:能枚举的盘符 + 快捷位置(项目文件夹/桌面/下载)。
    光驱读卡器抽风不能拖垮整页:哪盘试不到就跳过并打印原因。"""
    drives = []
    for i in range(65, 91):
        d = "%s:\\" % chr(i)
        try:
            if os.path.exists(d): drives.append(d)
        except Exception as e:
            print("[浏览盘符] %s: %r" % (d, e), flush=True)
    hs = Path.home()
    quick = [("📁 项目文件夹", str(PROJ_ROOT)), ("🖥 桌面", str(hs / "Desktop")),
             ("📥 下载", str(hs / "Downloads"))]
    return {"盘": drives, "快捷": [{"名": n, "路径": p} for n, p in quick if Path(p).is_dir()]}

def browse_dir(d):
    """给「挑素材」窗列一个文件夹:上级/子文件夹/视频(带大小)。只读,不写不开。
    太多截断时 截断=True 让前端提示跳精确路径;读不动就明确回原因,不许静默空白。"""
    p = Path(d)
    try:
        if not p.is_dir(): return {"error": "这不是当前存在的文件夹: %s" % d}
        subs, vids, trunc = [], [], False
        for f in sorted(p.iterdir(), key=lambda x: str(x.name).lower()):
            try:
                if f.is_dir():
                    if f.name.startswith(("$", ".")): continue
                    if len(subs) >= BR_LIMIT: trunc = True; continue
                    subs.append({"名": f.name, "路径": str(f)})
                elif f.suffix.lower() in VIDEO_EXT and f.is_file():
                    if len(vids) >= BR_LIMIT: trunc = True; continue
                    vids.append({"名": f.name, "路径": str(f),
                                 "MB": round(f.stat().st_size / 1048576.0, 1)})
            except (PermissionError, OSError) as e:
                print("[浏览条目] %s: %r" % (f, e), flush=True)
        up = str(p.parent) if str(p.parent) != str(p) else ""
        return {"路径": str(p), "上级": up, "文件夹": subs, "视频": vids, "截断": trunc}
    except Exception as e:
        print("[browse_dir] %s: %r" % (d, e), flush=True)
        slog("浏览失败", "", "%s: %s" % (d, str(e)[:120]))
        return {"error": "这个文件夹读不动: %s (%s)" % (d, e)}

# ―――― ①-E 文字效果分析 / 口播体检 / 文字执行卡(2026-10-21 新增) ――――
TEXTSTYLE_EXT = {"jpg", "jpeg", "png", "webp", "bmp", "mp4", "mov", "m4v", "avi", "mkv", "webm"}

def _textstyle_source(proj, body):
    """①-E 分析对象怎么选:显式路径优先;没有就用登记的第一条参考视频;没视频退第一条参考截图。"""
    proj = Path(proj)
    refp = (body.get("path") or "").strip()
    if refp:
        if not Path(refp).exists():
            return None, "文件不存在: " + refp
        return refp, ""
    items = refs_state(proj)["items"]
    for kind in ("video", "image"):
        hit = [x for x in items if x.get("kind") == kind]
        if hit:
            v = hit[0]
            return v.get("path") or str(proj / "参考" / v["name"]), ""
    return None, "先登记一条对标视频或截图(①-C 里那套素材,文字效果分析也吃它)"

def action_textstyle(proj, body):
    """①-E 主按钮:本机 OCR 读对标里的文字,量位置/大小/颜色/描边/动效,出 对标文字.json + 文字效果报告.md。"""
    refp, err = _textstyle_source(proj, body)
    if err:
        return {"error": err}
    if Path(refp).suffix.lower().lstrip(".") not in TEXTSTYLE_EXT:
        return {"error": "文字效果分析只认视频和图片(gif 动不了),当前: %s" % Path(refp).suffix}
    def _num(v, lo, hi, dft):
        try:
            x = float(v)
        except Exception:
            return dft
        return max(lo, min(hi, x))
    cmd = [PY, SCRIPTS / "text_style.py", refp, "--out", str(Path(proj) / "对标文字.json"),
           "--proj", str(proj), "--dur", _num(body.get("dur"), 5, 300, 90),
           "--fps", _num(body.get("fps"), 0.5, 4, 1.5)]
    st = _num(body.get("start"), 0, 600, 0)
    if st:
        cmd += ["--start", st]
    return start_job(proj, cmd, label="文字效果分析", timeout=2400)

def textstyle_state(proj):
    """读 对标文字.json,把每块截图挂成图片地址,喂界面①-E 的表。"""
    proj = Path(proj)
    f = proj / "对标文字.json"
    st = {"has": False}
    if not f.exists():
        return st
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        return {"has": True, "错误": "读不了 对标文字.json:%s(重跑一次分析)" % e}
    q = quote(str(proj), safe="")
    for b in d.get("文字块") or []:
        s = b.get("截图")
        b["截图URL"] = ("/media?dir=%s&name=textcrop&f=%s" % (q, quote(s, safe=""))) if s else ""
    return {"has": True, "对标源": d.get("对标源"), "分析时间": d.get("分析时间"),
            "输入类型": d.get("输入类型"), "统计": d.get("统计") or {},
            "文字块": d.get("文字块") or [], "样式分组": d.get("样式分组") or [],
            "提示": d.get("提示") or []}

FILL_WORDS = ["嗯", "呃", "额", "那个", "就是说", "怎么说呢", "对吧", "其实", "反正", "然后", "那么"]

def voice_summary(proj):
    """口播体检机器人:从 转写.json 本机总结「自己说的」的形式(语速/口癖/口头禅/句长/开头钩子)。
    语义级深总结它不装懂:给出可直接贴给对话 AI 的提示词。"""
    proj = Path(proj)
    tj = proj / "转写.json"
    if not tj.exists():
        return {"错误": "先完成第②步转写,体检才有话说"}
    try:
        d = json.loads(tj.read_text(encoding="utf-8"))
    except Exception as e:
        return {"错误": "转写.json 读不了:%s(去②重新转写)" % e}
    import statistics as _st
    segs = d.get("segments") or []
    if not segs:
        return {"错误": "转写里没有语音段,体检做不了(先检查这条片子有没有声音)"}
    def clen(s):
        return len(re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]", "", s))
    句 = [x for x in (re.sub(r"\s+", "", s.get("text") or "") for s in segs) if x]
    full = "".join(句)
    chars = clen(full)
    dur = float(d.get("duration") or (segs[-1].get("end") or 1))
    gaps = [round(segs[i + 1]["start"] - segs[i]["end"], 3) for i in range(len(segs) - 1)
            if (segs[i + 1].get("start") or 0) - (segs[i].get("end") or 0) >= 0]
    lens = [clen(x) for x in 句]
    over = sorted([(n, 句[i]) for i, n in enumerate(lens) if n > 30], reverse=True)[:3]
    tics = {w: full.count(w) for w in FILL_WORDS if full.count(w) > 0}
    cnt = {}
    cjk = re.sub(r"[^\u4e00-\u9fa5]", "@", full)
    for L in (2, 3, 4):
        for i in range(len(cjk) - L + 1):
            w = cjk[i:i + L]
            if "@" in w:
                continue
            cnt[w] = cnt.get(w, 0) + 1
    freq = sorted([(v, k) for k, v in cnt.items() if v >= 3], reverse=True)
    keep = []
    for v, k in freq:
        if not any(k in kk for _, kk in keep):
            keep.append((k, v))
    top = keep[:8]
    hook = 句[0] if 句 else ""
    if any(x in hook for x in ("?", "？", "吗", "为什么", "凭什么")):
        htype = "疑问/悬念型开头(钩子结构合格)"
    elif re.search(r"\d", hook):
        htype = "数字型开头(钩子结构合格)"
    elif any(x in hook for x in ("千万别", "别再", "停止")):
        htype = "警告祈使型开头(钩子结构合格)"
    else:
        htype = "陈述型开头——想爆建议改写成疑问/数字/警告(可点旁边的爆款开头工具)"
    lines = ["[%s] %s" % (fmt_t(s.get("start", 0)), s.get("text", "")) for s in segs]
    prompt = ("下面是我的完整口播转写(带时间码)。请作为短视频文案督导总结:1)一句话核心;2)三个关键词;"
              "3)最强的一句和最弱的一句;4)开头3秒钩子够不够,怎么改;5)哪几句冗余可以删。\n" + "\n".join(lines))
    return {"总字数": chars, "时长秒": round(dur, 1), "字每分钟": round(chars / max(0.1, dur) * 60, 1),
            "句数": len(句), "平均句长": int(_st.mean(lens)) if lens else 0,
            "超长句": [{"字数": n, "原句": s[:40]} for n, s in over],
            "口头禅": [{"词": k, "次数": v} for k, v in sorted(tics.items(), key=lambda x: -x[1])],
            "高频词": [{"词": k, "次数": v} for k, v in top],
            "长停顿次数": len([g for g in gaps if g > 0.8]),
            "句间停顿中位": round(_st.median(gaps), 3) if gaps else 0,
            "开头钩子": {"首句": hook[:38], "类型": htype},
            "AI深度总结提示词": prompt}

def textplan_run(proj, body):
    """①-E 融合:对标测出来的那套字效 + 用户要上屏的文案 → 逐句「执行参数」卡。
    数值给第④步渲染方(AI/HyperFrames)直接落地,括号里的菜单菜名留给手动照抄;不绑定某个剪辑软件。"""
    proj = Path(proj)
    text = (body.get("文案") or "").strip()
    if not text:
        return {"错误": "先把要上屏的文字粘贴进来"}
    style = None
    来源 = "没有对标文字分析——用安全默认(一律下沿:横屏留8%竖屏留20%/中字高/白字黑描边/0.3s渐显渐隐)"
    f = proj / "对标文字.json"
    if f.exists():
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            return {"错误": "对标文字.json 读不了:%s(重跑一次文字效果分析)" % e}
        blocks = d.get("文字块") or []
        pick = str(body.get("样式") or "auto")
        b = None
        if pick == "auto":
            if blocks:
                b = max(blocks, key=lambda x: x.get("持续秒") or 0)
        elif pick.startswith("T"):
            b = next((x for x in blocks if x.get("编号") == pick), None)
        if b:
            style = b
            来源 = "对标 %s「%s」%.1f~%.1fs,%s" % (b.get("编号"), (b.get("文字") or "")[:10],
                                                b.get("首现") or 0, b.get("末现") or 0, b["位置"]["锚位"])
    rate = 260.0
    fs = proj / "对标风格.json"
    if fs.exists():
        try:
            sp = (json.loads(fs.read_text(encoding="utf-8")).get("语速") or {}).get("字每分钟")
            if isinstance(sp, (int, float)) and sp > 0:
                rate = float(sp)
        except Exception as e:
            print("[对标语速读不了,用默认260字/分] %r" % e)
    sentences = [s.strip() for s in re.split(r"[。！？!?；;\n]+", text) if s.strip()]
    cards = []
    t = 0.0
    for i, s in enumerate(sentences, 1):
        n = len(re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]", "", s))
        sec = round(max(1.0, n / rate * 60), 1)
        ops = []
        if style:
            c = style.get("颜色") or {}
            mo = style.get("动效") or {}
            sz = style.get("大小") or {}
            pos = style.get("位置") or {}
            ops.append("字体颜色取 %s%s" % (c.get("文字色", "白色"),
                       (";描边取 %s" % c["描边"]["颜色"]) if c.get("描边") else ";没测出描边就不加"))
            ops.append("字号:字高≈%spx(占屏高%.1f%%),先打文案再调字号对高度" % (
                sz.get("字高px(按1920高换算)", "—"), sz.get("字高占屏%", 0)))
            if (pos.get("中心Y%") or 50) > 75:
                ops.append("对标位置在%s——本片一律下沿:横屏底边留8%%(Y≈+0.78),竖屏留20%%(Y≈+0.6)在遮挡区上方;对标贴死底部要抬,放正中的改下沿" % pos.get("锚位"))
            else:
                ops.append("位置:%s(相对画面中心偏移 X=%d Y=%d,渲染按此摆;手动可照抄)" % (
                    pos.get("锚位"),
                    round(((pos.get("中心X%") or 50) - 50) / 100 * 1080),
                    round((50 - (pos.get("中心Y%") or 50)) / 100 * 1920)))
            ops.append("动效:入场「%s」%s,出场「%s」" % (
                mo.get("入场"), ("(%s)" % mo["依据"]) if mo.get("依据") else "", mo.get("出场")))
            if (mo.get("滚动") or "无") != "无":
                ops.append("注意:对标是%s字幕(%.1f%%屏/秒)——逐句上屏别照抄滚动,改成渐显渐隐更稳" % (
                    mo["滚动"], mo.get("滚动速度%屏每秒") or 0))
            ED = {"卡拉OK": "逐字点亮(出现-卡拉OK类),或两层字:白底+红字带横向位置关键帧从左推到右",
                  "发光": "发光字效(外圈渐暗的那种)", "疑似3D": "入场先试「翻转」,置信低看截图定",
                  "闪烁": "不透明度关键帧100→0→100循环", "抖动": "抖动特效(动态-抖动)",
                  "呼吸": "缩放关键帧循环", "变色": "拆两段文案换色", "倾斜": "旋转参数照抄(%s)" % (style.get("位置", {}).get("倾角deg") or ""),
                  "打字机": "入场-打字机", "擦除": "入场-显影/擦除", "模糊": "清晰度关键帧0→100",
                  "阴影": "阴影参数 %s" % ((c.get("阴影") or {}).get("颜色") or ""),
                  "底色块": "背景-单色块 %s" % (c.get("底色块") or ""), "渐变": "渐变填充 %s" % ("/".join(c.get("渐变") or []))}
            for e in (mo.get("附加效果") or []):
                nm = e.get("效果", "")
                line = next((v for k, v in ED.items() if k in nm), None)
                if line:
                    ops.append("对标附加字效[%s]→%s" % (nm, line))
            fg = style.get("字体猜测") or {}
            if fg:
                ops.append("字体:对标像「%s」的无衬线,拿截图在剪辑软件字体列表比对候选(字体名机器定不死)" % (c.get("字重猜测") or "中"))
        else:
            ops.append("安全默认:白字黑描边、字高约6%屏、一律下沿(横屏底边留8%,竖屏留20%在遮挡区上方)、渐显0.3s+渐隐0.3s")
        cards.append({"行": i, "文本": s, "起": round(t, 1), "止": round(t + sec, 1),
                      "估秒": sec, "执行参数": ops})
        t += sec
    out = {"样式来源": 来源, "语速字每分钟": rate, "句数": len(cards), "合计秒": round(t, 1),
           "卡片": cards, "生成时间": time.strftime("%Y-%m-%d %H:%M:%S")}
    (proj / "文字方案.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    L = ["# 文字效果执行卡(工作台①-E 融合生成)", "",
         "- 样式来源:%s" % 来源,
         "- 时长依据:%.0f 字/分(对标语速或默认),每句停留按字数估算;真正对轨时跟着口播拖(交给渲染方还是手动进剪辑软件都一样)" % rate,
         "- 共 %d 句,约 %.1f 秒" % (len(cards), t), "",
         "| # | 文本 | 估停留 | 相对窗口 | 执行参数 |", "|---|---|---|---|---|"]
    for c in cards:
        L.append("| %d | %s | %.1fs | %.1f~%.1fs | %s |" % (
            c["行"], c["文本"], c["估秒"], c["起"], c["止"], ";".join(c.get("执行参数") or c.get("剪映操作") or [])))
    (proj / "文字效果执行卡.md").write_text("\n".join(L), encoding="utf-8")
    return {"ok": True, "句数": len(cards), "合计秒": round(t, 1), "样式来源": 来源,
            "md": str(proj / "文字效果执行卡.md")}


def check_ui_help():
    """界面说明自检:新增可点控件/输入项漏挂 HELP/IDHELP 字典时警告(规则见 ../AGENTS.md)"""
    try:
        h = (ROOT / "index.html").read_text(encoding="utf-8")
        mh = re.search(r"var HELP=\{(.*?)\n\};", h, re.S)
        mi = re.search(r"var IDHELP=\{(.*?)\n\};", h, re.S)
        if not mh: return ["index.html 缺少 HELP 说明字典"]
        keys = set(re.findall(r'"([^"]+)":', mh.group(1)))
        id_list = re.findall(r'"(\w+)":', mi.group(1)) if mi else []
        keys_id = set(id_list)
        def covered(o):
            g = re.search(r"getElementById\('([^']+)'\)", o)
            if g: return "pick:" + g.group(1) in keys
            hits = []
            for m in re.finditer(r"(^|[^.\w])([A-Za-z0-9_]+)\(\s*['\"]?([^'\"\)\]]*)", o):
                name, arg = m.group(2), m.group(3)
                hits.append(name + ((":" + arg) if arg else ""))
            return any((x in keys) or (x.split(":")[0] in keys) for x in hits)
        w = []
        for m in re.finditer(r'<(\w+)[^>]*onclick="([^"]+)"', h):
            o = m.group(2).replace("&quot;", '"')
            if not covered(o): w.append("控件缺说明: <%s> %s" % (m.group(1), o[:50]))
        for attrs in re.findall(r'<(?:input|select|textarea)([^>]*)>', h):
            mi2 = re.search(r'id="([^"]+)"', attrs)
            if not mi2: continue
            i = mi2.group(1)
            if re.search(r"\bhidden\b", attrs): continue   # 隐藏的 file input 按规则不挂提示
            if i not in keys_id: w.append("输入项缺提示: " + i)
        for i in sorted(set(x for x in id_list if id_list.count(x) > 1)):
            w.append("IDHELP 重复键(后者覆盖前者,请合并): " + i)
        return w
    except Exception as e:
        return ["说明自检异常: " + str(e)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=9527)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    PROJ_ROOT.mkdir(exist_ok=True)
    reap_interrupted()
    def running(port):
        try:
            return urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=1).getcode() == 200
        except Exception:
            return False
    if running(a.port):
        url = f"http://127.0.0.1:{a.port}"
        print(f"检测到工作台已在运行,直接打开浏览器: {url}")
        print("若浏览器没有弹出,请手动访问上面的地址。此窗口可直接关闭。")
        if not a.no_browser: webbrowser.open(url)
        return
    srv = None; port = a.port
    for p in range(a.port, a.port + 10):
        if running(p):
            print(f"端口 {p} 上已有工作台在运行,直接打开: http://127.0.0.1:{p}")
            if not a.no_browser: webbrowser.open(f"http://127.0.0.1:{p}")
            return
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p), H); port = p; break
        except OSError:
            continue
    if srv is None:
        print("启动失败:端口全部被占用或被系统保留。请关闭旧的工作台黑窗口后重试。")
        input("按回车退出...")
        sys.exit(1)
    url = f"http://127.0.0.1:{port}"
    print(f"口播剪辑工作台已启动: {url}")
    threading.Thread(target=assistant_boot, daemon=True).start()
    warns = check_ui_help()
    rep = ROOT / "说明自检.txt"
    if warns:
        print("[警告] 界面说明自检发现 %d 处遗漏(补齐规则见 ../AGENTS.md):" % len(warns))
        for x in warns: print("  - " + x)
        rep.write_text("有遗漏 \n" + "\n".join(warns), encoding="utf-8")
    else:
        rep.write_text("全部控件已挂说明 ✓", encoding="utf-8")
    print("若浏览器没有自动弹出,请手动把上面的地址粘贴到浏览器。")
    print("剪辑期间请保持本窗口开着(关闭窗口=工作台停止)。")
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n工作台已停止。")

if __name__ == "__main__":
    main()
